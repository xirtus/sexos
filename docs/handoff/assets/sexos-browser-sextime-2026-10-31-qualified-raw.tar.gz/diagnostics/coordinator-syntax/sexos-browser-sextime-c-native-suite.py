from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/tmp');F=T/'sexos-browser-sextime-c-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
from https_import_gate import wait_ports
P=T/'sexos-browser-sextime-c-native-suite-progress.json';assert not P.exists();rows=[];binding=F/'source-binding.json';bound=hashlib.sha256(binding.read_bytes()).hexdigest();profiles=[('wide','e1000e','1280x800'),('compact','e1000','1024x768')];jobs=[]
for mode in ['normal','invalid-year','close']:
 for label,model,resolution in profiles:jobs.append(('clock-'+mode+'-'+label,'certificate_time_gate.py',mode,label,model,resolution))
for label,model,resolution in profiles:jobs.append(('connected-'+label,'connected_desktop_gate.py',None,label,model,resolution))
for name,checker,mode,label,model,resolution in jobs:
 out=T/('sexos-browser-sextime-c-native-'+name);driver=T/('sexos-browser-sextime-c-native-'+name+'-driver.log');ports=T/'sexos-browser-sextime-c-native-ports'/name;assert not out.exists()and not driver.exists()and not ports.exists();ports.mkdir(parents=True);command=['python3',str(R/'scripts'/checker),'--iso',str(F/'tested.iso'),'--binding',str(binding),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',resolution]
 if mode:command+=['--mode',mode]
 row=dict(name=name,checker=checker,mode=mode,profile=dict(label=label,model=model,resolution=resolution),out=str(out),driver=str(driver),ports=str(ports),command=command,binding_sha256=bound,status='port-preflight');rows.append(row);P.write_text(json.dumps(rows,indent=2)+'\n');print('START',name,flush=True);wait_ports(ports);row['status']='running';P.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic()
 with driver.open('w')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);P.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 result=json.loads((out/'result.json').read_text());assert result['ok'];row['boots']=2 if mode is None else1;row['verified_captures']=result['frames']if mode is None else len(result['pixels']);row['raw_captures']=len(list(out.rglob('*.ppm')))
 assert hashlib.sha256(binding.read_bytes()).hexdigest()==bound;P.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==8 and sum(r['boots']for r in rows)==10 and sum(r['verified_captures']for r in rows)==46 and sum(r['raw_captures']for r in rows)==48
print('ALL8_COHORTS_PASS_10_BOOTS_46_PIXEL_CHECKS_48_RAW_CAPTURES',flush=True)
