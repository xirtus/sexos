from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-browser-sextime-c-frozen').resolve();sys.path.insert(0,str(F/'source/scripts'))
from certificate_time_gate import replay_evidence
rows=[]
for mode in ['normal','invalid-year','close']:
 for profile in ['wide','compact']:
  out=T/('sexos-browser-sextime-c-native-clock-'+mode+'-'+profile);proof=replay_evidence(F/'source',F/'tested.iso',F/'source-binding.json',out);stored=json.loads((out/'result.json').read_text());assert stored['ok']and json.loads(json.dumps(proof))==stored['replay'];rows.append(dict(mode=mode,profile=profile,out=str(out),binding_sha256=hashlib.sha256((F/'source-binding.json').read_bytes()).hexdigest(),proof=proof));print(mode,profile,'independent raw replay PASS',flush=True)
assert len(rows)==6 and sum(r['proof']['captures']for r in rows)==12
p=T/'sexos-browser-sextime-clock-independent-replay.json';assert not p.exists();p.write_text(json.dumps(dict(ok=True,native_runs=6,boots=6,verified_captures=12,close_raw_captures=2,iso_sha256=hashlib.sha256((F/'tested.iso').read_bytes()).hexdigest(),runs=rows),indent=2)+'\n')
