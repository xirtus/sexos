from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/tmp');F=T/'sexos-browser-sextime-d-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
from https_import_gate import wait_ports
P=T/'sexos-browser-sextime-d-connected-progress.json';assert not P.exists();rows=[]
def guests():
 out=subprocess.check_output(['ps','-axo','pid=,etime=,comm='],text=True);found=[]
 for line in out.splitlines():
  fields=line.split(None,2)
  if len(fields)!=3 or Path(fields[2]).name!='qemu-system-x86_64':continue
  value=fields[1];days=0
  if '-'in value:day,value=value.split('-',1);days=int(day)
  age=days*86400+sum(int(v)*factor for v,factor in zip(reversed(value.split(':')),(1,60,3600)))
  found.append(dict(pid=int(fields[0]),age_seconds=age))
 return found
for label,model,resolution in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]:
 name='connected-'+label;out=T/('sexos-browser-sextime-d-native-'+name);driver=T/('sexos-browser-sextime-d-native-'+name+'-driver.log');ports=T/'sexos-browser-sextime-d-ports'/name;assert not out.exists()and not driver.exists()and not ports.exists();ports.mkdir(parents=True);command=['python3',str(R/'scripts/connected_desktop_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',resolution];row=dict(name=name,status='awaiting_stable_other_guest_startup',out=str(out),driver=str(driver),ports=str(ports),command=command,profile=dict(label=label,model=model,resolution=resolution),observations=[]);rows.append(row);began=time.monotonic()
 while True:
  current=guests();row['observations'].append(dict(host_monotonic=time.monotonic(),guests=current));P.write_text(json.dumps(rows,indent=2)+'\n')
  if not any(g['age_seconds']<120 for g in current):break
  if time.monotonic()-began>600:raise TimeoutError('new unrelated guest startups keep sharing fixture ports; preserve and coordinate')
  time.sleep(10)
 row['other_guests_before']=current;wait_ports(ports);row['status']='running';P.write_text(json.dumps(rows,indent=2)+'\n');print('START',name,flush=True);began=time.monotonic()
 with driver.open('w')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began,other_guests_after=guests());P.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 result=json.loads((out/'result.json').read_text());assert result['ok']and result['boots']==2 and result['frames']==17;row.update(boots=2,verified_captures=17);P.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==2 and all(r['status']==0 for r in rows)
print('CONNECTED_BOTH_PROFILES_4_BOOTS_34_CAPTURES_PASS',flush=True)
