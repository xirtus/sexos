from pathlib import Path
import gzip,hashlib,io,json,os,re,subprocess,tarfile
from PIL import Image
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-browser-sextime-d-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');assert b['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for name,digest in {**b['sources'],**b['runner_sha256']}.items():assert sha(F/'source'/name)==sha(R/name)==digest,name
clock=read(T/'sexos-browser-sextime-clock-independent-replay.json');conn=read(T/'sexos-browser-sextime-d-connected-independent-replay.json');assert clock['ok']and conn['ok']and clock['boots']+conn['boots']==10 and clock['verified_captures']+conn['verified_captures']==46
host=read(T/'sexos-browser-sextime-d-host40/report.json');assert host['checks_passed']and len(host['checks'])==40 and host['sources_unchanged_during_checks'];rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in host['checks']);assert rust==2581
python=(T/'sexos-browser-sextime-d-python.log').read_text();assert 'Ran 851 tests in 'in python and python.rstrip().endswith('OK');assert read(T/'sexos-browser-sextime-c-d-equivalence.json')['ok'];scalar=read(T/'sexos-browser-sextime-c-scalar/result.json');assert scalar['ok']and scalar['iso_sha256']==b['iso_sha256']and scalar['results'][0]['instructions']==92261
controls=read(T/'sexos-browser-sextime-controls-preflight/sources.json');assert all(sha(F/'source'/name)==digest for name,digest in controls.items())
for name in ['measure','epoch']:assert 'test result: FAILED.'in(T/'sexos-browser-sextime-controls-preflight'/(name+'.log')).read_text()
items={};disks=[]
def add(name,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and name not in items;items[name]=p

def compress_disk(p):
 owner=subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True);assert not owner.stdout.strip(),str(p);raw=p.read_bytes();z=p.with_name(p.name+'.gz')
 if not z.exists():
  with z.open('xb')as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0)as packed:packed.write(raw)
 assert gzip.decompress(z.read_bytes())==raw;disks.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=sha(z)));return z

def tree(prefix,root):
 root=Path(root);assert root.is_dir(),str(root)
 for p in sorted(root.rglob('*.img')):compress_disk(p)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for name in ['c','d']:tree('frozen/'+name,T/('sexos-browser-sextime-'+name+'-frozen'))
tree('build/b',T/'sexos-browser-sextime-b-build');tree('diagnostics/build-a',T/'sexos-browser-sextime-a-build');tree('diagnostics/frozen-b',T/'sexos-browser-sextime-b-frozen')
for row in clock['runs']:tree('native/clock-'+row['mode']+'-'+row['profile'],row['out'])
for row in conn['runs']:tree('native/connected-'+row['profile'],row['out'])
tree('host/d',T/'sexos-browser-sextime-d-host40');tree('diagnostics/host-b',T/'sexos-browser-sextime-b-host40');tree('diagnostics/host-c',T/'sexos-browser-sextime-c-host40');tree('semantic/calendar',T/'sexos-browser-sextime-controls-preflight');tree('scalar/c',T/'sexos-browser-sextime-c-scalar');tree('bootloader',R/'limine')
for name,folder in [('native-b-preliminary','sexos-browser-sextime-b-native-clock-normal-wide'),('native-c-contended','sexos-browser-sextime-c-native-connected-wide'),('coordinator-syntax','sexos-browser-sextime-c-coordinator-syntax-diagnostic'),('replay-path','sexos-browser-sextime-replay-path-diagnostic')]:tree('diagnostics/'+name,T/folder)
add('seed/nvme.img.gz',compress_disk(T/'sexos-r100a-seed.img'))
for p in sorted(T.glob('sexos-browser-sextime-*')):
 if p.is_file()and p.suffix in('.py','.json','.log'):add('coordination/'+p.name,p)
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();manifest_sha=hashlib.sha256(raw).hexdigest();archive=A/'sexos-browser-sextime-2026-10-31-qualified-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for name,p in sorted(items.items()):tar.add(p,arcname=name,recursive=False)
 member=tarfile.TarInfo('payload-members.json');member.size=len(raw);member.mode=0o644;tar.addfile(member,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len(set(m.name for m in members))==len(members)
 for member in members:
  data=tar.extractfile(member).read();expected=dict(bytes=len(raw),sha256=manifest_sha)if member.name=='payload-members.json'else manifest[member.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],member.name
screens=[]
for label,folder,shot in [('clock-wide','sexos-browser-sextime-c-native-clock-normal-wide','clock-first'),('clock-compact','sexos-browser-sextime-c-native-clock-normal-compact','clock-first'),('clock-cleared-wide','sexos-browser-sextime-c-native-clock-normal-wide','clock-cleared')]:
 source=T/folder/(shot+'.ppm');target=A/('sexos-browser-sextime-2026-10-31-'+label+'.png');assert not target.exists();image=Image.open(source).convert('RGB');pixels=image.tobytes();image.save(target);assert Image.open(target).convert('RGB').tobytes()==pixels;screens.append(dict(path='assets/'+target.name,sha256=sha(target),source_ppm_sha256=sha(source),pixel_identical=True,width=image.width,height=image.height))
result=dict(qualified_on_feature_branch=True,global_goal_complete=False,branch='codex/browser-sextime',committed_master_base='f8058b31',round_number_unassigned=True,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),bindings=dict(clock_c=sha(T/'sexos-browser-sextime-c-frozen/source-binding.json'),host_and_connected_d=sha(F/'source-binding.json')),input_equivalence=read(T/'sexos-browser-sextime-c-d-equivalence.json'),build='GREEN_MASTER',registered_host_checks=40,rust_test_executions=2581,python_tests=851,compiled_calendar_controls_rejected=2,native=dict(runs=8,boots=10,verified_captures=46,raw_captures=48,clock_runs=6,clock_verified_captures=12,close_raw_captures_without_pixel_absence_claim=2,connected_runs=2,connected_live_and_cold_boots=4,connected_verified_captures=34,independent_replay=True),scalar_browser=dict(instructions=92261,inspected_vector_fp_matches=0,scope=scalar['scope']),release_gates_this_snapshot=dict(open=4,partial=26,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=manifest_sha,all_members_size_and_sha256_verified=True,disks=disks),screenshots=screens,scope='Existing validated last-query q35 CMOS UTC source displayed as Gregorian UTC, SexTime and Long Count; whole-body calendar foreground/erasure, exact display receipt and cold connected document/history regressions. Clock native modes use full-screen views at both desktop sizes; default/tiny tile geometry is actual-function host scope. C/D production/native/helper/Python/Rust inputs are identical, with only the host Bash child invocation changed; manifests retain original bindings. No integrated qualification of later primary UiIR/other commits, continuously live/authenticated physical/NTP clock, sustained newest-image alpha, public web/CA, physical/SMP, crash/power-loss, hostile containment or System Proven claim.')
p=A/'sexos-browser-sextime-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['qualified_on_feature_branch','iso_sha256','registered_host_checks','rust_test_executions','python_tests','native']}));print('ARCHIVE',archive.stat().st_size,'bytes',len(items)+1,'size+hash verified members')
