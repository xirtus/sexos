from pathlib import Path
import hashlib,json,re,subprocess
frozen=Path('/tmp/sexos-browser-sextime-c-frozen');out=Path('/tmp/sexos-browser-sextime-c-scalar');assert not out.exists();out.mkdir()
objdump='/Users/xmacbookm5/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-objdump'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fp=re.compile(r'^(?:f(?:2xm1|abs|add.*|bld|bstp|chs|clex|cmov.*|com.*|cos|decstp|div.*|free.*|iadd.*|icom.*|idiv.*|ild.*|imul.*|incstp|init|ist.*|isub.*|ld.*|mul.*|nclex|ninit|nop|nsave.*|nst.*|patan|prem.*|ptan|rndint|rstor.*|save.*|scale|sin.*|sqrt|st.*|sub.*|tst|ucom.*|wait|xam|xch.*|xtract|yl2x.*)|vzeroall|vzeroupper|ldmxcsr|stmxcsr|xsave.*|xrstor.*)$');results=[]
for name,source in [('kaleidoscope','/apps/kaleidoscope')]:
 elf=out/(name+'.elf');dis=out/(name+'.disassembly');command=['xorriso','-osirrox','on','-indev',str(frozen/'tested.iso'),'-extract',source,str(elf)]
 with (out/(name+'-extract.log')).open('w')as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 decode=[objdump,'--disassemble','--no-show-raw-insn','--x86-asm-syntax=att',str(elf)]
 with dis.open('w')as stream:subprocess.run(decode,stdout=stream,stderr=subprocess.STDOUT,check=True)
 count=0;matches=[]
 for line in dis.read_text().splitlines():
  m=re.match(r'^\s*[0-9a-f]+:\s+(\S+)(.*)$',line)
  if not m:continue
  count+=1
  if re.search(r'%(?:[xyz]mm\d+|mm\d+|st(?:\(|\b))',m[2])or fp.fullmatch(m[1]):matches.append(line)
 assert count>1000
 result=dict(name=name,ok=not matches,iso_path=source,elf_sha256=sha(elf),disassembly_sha256=sha(dis),instructions=count,vector_or_fp_matches=matches,commands=[command,decode]);results.append(result);print(name,count,'matches',len(matches),flush=True)
 assert not matches
p=out/'result.json';p.write_text(json.dumps(dict(ok=True,iso_sha256=sha(frozen/'tested.iso'),tool_version=subprocess.check_output([objdump,'--version'],text=True),results=results,scope='Decoded the changed ISO-extracted Browser ELF and inspected vector operands/FP-state mnemonics only. No whole-image, runtime stack/register/cache erasure, scheduler or hostile-containment proof.'),indent=2)+'\n')
