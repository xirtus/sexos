from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-browser-sextime-d-frozen').resolve();sys.path.insert(0,str(F/'source/scripts'))
from connected_desktop_gate import replay
rows=[]
for profile in ['wide','compact']:
 out=T/('sexos-browser-sextime-d-native-connected-'+profile);proof=replay(F/'source',F/'tested.iso',F/'source-binding.json',out);stored=json.loads((out/'result.json').read_text());assert stored['ok']and json.loads(json.dumps(proof))==stored and proof['boots']==2 and proof['frames']==17;rows.append(dict(profile=profile,out=str(out),proof=proof));print(profile,'independent connected live+cold raw replay PASS',flush=True)
p=T/'sexos-browser-sextime-d-connected-independent-replay.json';assert not p.exists();p.write_text(json.dumps(dict(ok=True,native_runs=2,boots=4,verified_captures=34,binding_sha256=hashlib.sha256((F/'source-binding.json').read_bytes()).hexdigest(),runs=rows),indent=2)+'\n')
