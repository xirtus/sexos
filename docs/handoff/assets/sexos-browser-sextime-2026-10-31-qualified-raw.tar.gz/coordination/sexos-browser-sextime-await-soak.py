from pathlib import Path
import json,subprocess,time
p=Path('/tmp/sexos-browser-sextime-soak-wait.json');events=[];began=time.monotonic()
while True:
 r=subprocess.run(['ps','-p','9157','-o','args='],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);command=r.stdout.strip();live=r.returncode==0 and 'quil_workflow_gate.py'in command and '--soak-seconds 1800'in command and 'alpha6'in command
 event=dict(wall_utc=time.time(),wait_seconds=time.monotonic()-began,python_pid=9157,expected_soak_live=live,command=command);events.append(event);p.write_text(json.dumps(dict(process_exit_is_not_acceptance=True,events=events),indent=2)+'\n')
 if not live:print('EXPECTED_SOAK_PROCESS_TERMINAL_CHECK_ITS_RESULT_BEFORE_ACCEPTANCE',flush=True);break
 time.sleep(10)
