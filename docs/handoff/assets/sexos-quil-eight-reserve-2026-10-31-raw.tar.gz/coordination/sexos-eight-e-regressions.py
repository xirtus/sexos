from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');progress=T/'sexos-eight-e-alpha-progress.json'
while True:
 rows=json.loads(progress.read_text())
 if any(isinstance(r['status'],int)and r['status']!=0 for r in rows):raise SystemExit('alpha failed; regressions not started')
 if len(rows)==2 and all(r.get('fresh_replay')for r in rows):break
 time.sleep(5)
for name in ['connected','pending']:
 p=T/('sexos-eight-e-'+name+'-suite-driver.log');assert not p.exists()
 print('START',name,flush=True)
 with p.open('x')as f:r=subprocess.run(['python3',str(T/('sexos-eight-e-'+name+'-suite.py'))],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
print('EIGHT_ADDITIONAL_REGRESSION_BOOTS_PASS',flush=True)
