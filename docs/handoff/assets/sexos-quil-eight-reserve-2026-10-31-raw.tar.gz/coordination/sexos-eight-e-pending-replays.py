from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');p=T/'sexos-eight-e-pending-native-progress.json'
while True:
 rows=json.loads(p.read_text())
 if any(isinstance(r['status'],int)and r['status']!=0 for r in rows):raise SystemExit('pending workflow failed')
 if len(rows)==4 and all(r['status']==0 for r in rows):break
 time.sleep(5)
result=[]
for row in rows:
 target=T/('sexos-eight-e-pending-'+row['profile']+'-'+row['kind']+'-independent-replay.json');assert not target.exists()
 with target.open('x')as f:r=subprocess.run(row['command']+['--check'],cwd=T/'sexos-eight-e-frozen/source',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert r.returncode==0;r=json.loads(target.read_text());assert r['ok'];result.append(dict(profile=row['profile'],kind=row['kind'],replay=str(target),ok=True))
p=T/'sexos-eight-e-pending-independent-replays.json';assert not p.exists();p.write_text(json.dumps(dict(ok=True,rows=result),indent=2)+'\n');print('FOUR_FRESH_PENDING_REPLAYS_PASS',flush=True)
