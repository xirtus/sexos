from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-eight-e-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');h=read(T/'sexos-eight-e-host/report.json');audit=read(T/'sexos-eight-e-source-audit.json');boot=read(T/'sexos-eight-e-boot-audit.json')
assert audit['ok']and boot['ok']and boot['boots']==11
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2684
assert 'Ran 968 tests in 'in(T/'sexos-eight-e-python.log').read_text()
groups={k:read(T/('sexos-eight-e-'+s+'-progress.json'))for k,s in [('connected','native'),('pending_device','pending-native'),('eight_quil_chain','alpha')]}
assert all(row['status']==0 for rows in groups.values()for row in rows)
assert sum(row['verified_captures']for rows in groups.values()for row in rows)==112
assert read(T/'sexos-eight-e-pending-independent-replays.json')['ok']
chains=[]
for row in groups['eight_quil_chain']:
 assert row['fresh_replay'];r=read(Path(row['out'])/'result.json');q=r['soak']['third_quil'];assert r['ok']and not r['acceptance']and q['final_target']==23 and q['append_count']==6 and [s['target']for s in q['chain']]==[18,19,20,21,22,23]
 chains.append(dict(profile=row['profile'],captures=len(r['stages']),chain=[9,16,18,19,20,21,22,23],last_target=q['final_target'],additional_edit_saves=q['append_count'],disk_documents=r['disk_documents'],fresh_replay=True))
scalar=read(T/'sexos-eight-e-scalar-v2/result.json');assert scalar['ok']and len(scalar['results'])==5 and all(not row['vector_or_fp_matches']for row in scalar['results'])
for n in ['views','nic','self-wait']:assert read(T/('sexos-eight-e-'+n+'.log'))['ok']
assert not read(T/'sexos-eight-c-alpha-compact/result.json')['ok']and not read(T/'sexos-eight-d-alpha-compact/result.json')['ok']
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('qualified/frozen',F);tree('qualified/sealed-build',T/'sexos-eight-e-build');tree('qualified/host',T/'sexos-eight-e-host');tree('qualified/scalar',T/'sexos-eight-e-scalar-v2')
for group,rows in groups.items():
 for row in rows:tree('qualified/native/'+group+'/'+Path(row['out']).name,Path(row['out']))
for name in ['sexos-eight-a-build','sexos-eight-b-build','sexos-eight-c-frozen','sexos-eight-c-host','sexos-eight-c-alpha-compact','sexos-eight-d-build','sexos-eight-d-frozen','sexos-eight-d-host','sexos-eight-d-alpha-compact']:
 tree('diagnostics/'+name,T/name)
for p in sorted(T.glob('sexos-eight-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-quil-eight-reserve-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=136,qualified_actual_quil_reserve=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='3046547b5bd267bcf9c291a0d3e3d4990af0a37c',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust,python_tests=968,roster=dict(total=11,quil=[9,16,18,19,20,21,22,23],spindle=[12,17],browser=[15],quil_relaunches=7),budgets=dict(registered_main_tasks=23,self_wait_capacity=32,document_backings=8,document_backing_bytes=131072,quil_private_pages_each=70,quil_private_bytes_each=286720,additional_five_private_and_document_bytes=1515520,document_participants=9,file_deferred_slots=53,desktop_tracked_surfaces=21,desktop_sends_per_pump_max=4),native=dict(workflow_boots=10,sealed_probe_boots=1,total_boots=11,verified_workflow_captures=112,groups=groups,chains=chains,boot_catalog_audit=boot,pending_device_fresh_replays=True,alpha_rehearsal_fresh_replays=True,new_image_1800s_acceptance=False,post_last_incarnation_cold_boot=False),scalar=dict(elfs=5,instructions=sum(row['instructions']for row in scalar['results']),inspected_vector_fp_matches=0,scope=scalar.get('scope')),diagnostics=dict(build_a='Original clipboard participant table filled during BOOT; failed gate retained',native_c='Quil19 activated/loaded/edited but viewport queue/decode numeric allowlist prevented geometry; failed capture retained',native_d='After viewport fix, Shell fixed16 DesktopStates readiness still rejected new308; original failure retained',final_e='Catalog-driven viewport and frame admission, full eleven-subject BOOT and eight-Quil chain; original failed attempts never relabelled'),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Eight actual BOOT-reserved Quil images and seven reopens at both desktop sizes, exact held-grant/lineage checks, two-document warm recovery, edit/save persistence receipts plus terminal disk bytes, all-incarnation cleanup, immutable completed-pixel captures and fresh exhaustion. Connected/pending-device cold recovery is separate from the longer-chain session. No runtime mint, processVAS/POSIX, unbounded relaunch, post-Quil23 cold boot, newimage1800s, physical/SMP/hostile containment/global epoch or daily-driver acceptance claim.')
p=A/'sexos-quil-eight-reserve-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('RESERVE_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
