from pathlib import Path
import hashlib,json,re,shlex,subprocess
T=Path('/tmp');P='sexos-text-candidates-a';F=T/(P+'-frozen');B=T/'sexos-completion-custody-c-frozen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((B/'source-binding.json').read_text());b=json.loads((F/'source-binding.json').read_text())
assert a['build_provenance']['git_revision']=='78227603f512a1a6c531542b4779c73168d628c3'
assert b['build_provenance']['git_revision']=='da40f6f3267bcadf34ed3c55b469a19159affc6f'
x,y=a['sources'],b['sources'];added=sorted(y.keys()-x.keys());removed=sorted(x.keys()-y.keys());changed=sorted(n for n in x.keys()&y.keys()if x[n]!=y[n])
assert len(x)==586 and len(y)==586 and not removed and not added and changed==['servers/sexdisplay/src/main.rs','servers/sexdisplay/src/scene.rs','servers/sexdisplay/src/text_transaction.rs']
def inputs(root):
 s=(root/'scripts/entrypoint_build.sh').read_text();m=re.search(r'ABI_INPUTS=\(\n(.*?)\n\)',s,re.S);assert m
 return shlex.split(m[1],comments=True)
old=inputs(B/'source');current=inputs(F/'source');assert len(current)==67 and current==old
assert all(sha(B/'source'/n)==sha(F/'source'/n)for n in current)
abi=hashlib.sha256(subprocess.check_output(['sha256sum',*current],cwd=F/'source')).hexdigest();assert abi=='3b98b23398b7a309a74d5d10526e9234fa372ff448c79f51aa4f4b9f44fdc36a'
r=dict(ok=True,baseline_commit=a['build_provenance']['git_revision'],candidate_commit=b['build_provenance']['git_revision'],baseline_binding_sha256=sha(B/'source-binding.json'),baseline_production=len(x),candidate_production=len(y),added=added,removed=removed,changed=changed,unchanged=len(x)-len(changed),kernel_identical=sha(B/'tested.kernel')==sha(F/'tested.kernel'),baseline_kernel_sha256=sha(B/'tested.kernel'),candidate_kernel_sha256=sha(F/'tested.kernel'),abi_inputs=67,prior_abi_inputs=67,abi_added_inputs=[],abi_sha256=abi,scope='Exact source-set, kernel and ABI byte/hash comparison. Native functional acceptance remains bound to the current image, never transferred from the baseline.')
assert r['kernel_identical'];out=T/(P+'-production-equivalence.json');assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
