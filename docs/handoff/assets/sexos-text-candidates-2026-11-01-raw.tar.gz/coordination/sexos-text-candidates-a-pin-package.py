from pathlib import Path
import ast,hashlib,json,re
T=Path('/tmp');P='sexos-text-candidates-a';A='sexos-completion-custody-a';F=T/(P+'-frozen')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
h=read(T/(P+'-frozen-host/report.json'));assert h['run_status']=='complete'and h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==46 and all(v['exit_code']==0 for v in h['checks'])
checks={v['id']:v for v in h['checks']}
def marker(name,tag):
 log=Path(checks[name]['log']).read_text();matches=re.findall(r'^\['+re.escape(tag)+r'\] PASS (\{[^\n]+\})$',log,re.M);assert len(matches)==1;return json.loads(matches[0])
b=read(F/'source-binding.json');source=read(T/(P+'-source-audit.json'));scalar=read(T/(P+'-scalar/result.json'));budget=read(T/(P+'-budget-audit.json'))
scene=marker('display_scene','display.scene.host');frames=marker('display_frame_output','display.frame.output.host');bitmap=marker('display_surface_groups','bitmap.stores.host')
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(v['log']).read_text())))for v in h['checks'])
py=(T/(P+'-frozen-python.log')).read_text();assert re.findall(r'Ran (\d+) tests in ',py)==['1132']and py.rstrip().endswith('OK')
pins=dict(binding_sha256=sha(F/'source-binding.json'),iso_sha256=b['iso_sha256'],runner_files=len(b['runner_sha256']),source_files=source['unique'],source_bytes=source['total_source_bytes'],scalar_instructions=scalar['total_instructions'],host_checks=len(checks),rust_log_test_executions=rust,python_tests=1132,scene_controls=[scene[k]for k in ['actual_cases','compiled_runtime_mutants','source_fence_controls']],bitmap_controls=[bitmap[k]for k in ['actual_case_executions','future_case_executions','compiled_mutants_rejected','published_bytes','published_stores3_bytes']],compositor_cases=52,frame_cases=frames['cases'],frame_controls=[frames[k]for k in ['compiled_runtime_mutants','paint_batch_runtime_mutants','compiler_trait_controls','source_controls']]+[len(frames['wiring'])],cursor_controls=[5,2,4],static_objects=budget['static_objects'],display_elf_bytes=budget['elf_bytes'],candidate_frames={k:v['local_reservation_bytes']for k,v in budget['frames']['candidate'].items()},candidate_register_push_bytes=48,boot_heap=budget['boot_heap'])
helpers={str(T/(P+suffix)):sha(T/(P+suffix))for suffix in ['-source-audit.py','-scalar-audit.py','-budget-audit.py','-boot-audit.py','-native-suite.py','-production-equivalence.py']}
diag_paths=set()
# Only R170 preflight diagnostics. Prior169 native acceptance/failed cohorts
# are not transferred into the current round.
for suffix in ['-scene-first-preflight','-scene-second-preflight']:
 folder=T/(P+suffix);assert folder.is_dir()
 diag_paths.update(p for p in folder.rglob('*')if p.is_file()and '__pycache__'not in p.parts)
for suffix in ['-scene-first-preflight.log','-scene-second-preflight.log']:
 path=T/(P+suffix);assert path.is_file();diag_paths.add(path)
path=T/'sexos-r170-compositor-host.log';assert path.is_file();diag_paths.add(path)

for suffix in ['-package-first-unqualified.py','-package-first-unqualified.log']:diag_paths.add(T/(P+suffix))
diag={str(path):sha(path)for path in sorted(diag_paths)}
p=T/(P+'-package.py');text=p.read_text();tree=ast.parse(text);values=dict(COMMIT=b['build_provenance']['git_revision'],PINS=pins,EXECUTED_HELPER_SHA256=helpers,UNQUALIFIED_DIAGNOSTIC_SHA256=diag);segments={}
for node in tree.body:
 if isinstance(node,ast.Assign):
  for target in node.targets:
   if isinstance(target,ast.Name)and target.id in values:segments[target.id]=ast.get_source_segment(text,node)
assert set(segments)==set(values)
for name,old in segments.items():assert text.count(old)==1;text=text.replace(old,name+' = '+repr(values[name]),1)
compile(text,str(p),'exec');p.write_text(text)
out=dict(ok=True,pins=pins,executed_helpers=helpers,unqualified_files=len(diag),unqualified_bytes=sum(path.stat().st_size for path in diag_paths),package_script_sha256=sha(p))
(T/(P+'-package-pins.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
