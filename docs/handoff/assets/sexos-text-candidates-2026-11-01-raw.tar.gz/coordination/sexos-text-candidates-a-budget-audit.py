from pathlib import Path
import hashlib,json,re,subprocess
T=Path('/tmp');P='sexos-text-candidates-a';O=T/(P+'-scalar');B=T/'sexos-completion-custody-c-scalar'
tool=Path('/Users/xmacbookm5/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
elf=O/'sexdisplay.elf';symbols=subprocess.check_output([str(tool),'--syms',str(elf)],text=True);(O/'sexdisplay-symbols.txt').write_text(symbols)
objects={};symbol_rows={}
# Actual finite source/receipt backing, measured from the ISO symbol table.
for name in ['TEXT_STAGES','BITMAP_STORES']:
 rows=[line for line in symbols.splitlines()if name in line];assert len(rows)==1
 size=int(rows[0].split()[-2],16);assert size>0;objects[name]=size;symbol_rows[name]=rows[0]
assert objects['BITMAP_STORES']==55992 and objects['TEXT_STAGES']%16==0

for name,size in [('RENDER_SCENE',60096),('FRAME_OUTPUT',88)]:
 rows=[line for line in symbols.splitlines()if name in line];assert len(rows)==1;row=rows[0]
 assert int(row.split()[-2],16)==size;objects[name]=size;symbol_rows[name]=row
sections=subprocess.check_output([str(tool),'--section-headers',str(elf)],text=True);(O/'sexdisplay-sections.txt').write_text(sections)
frames={}
for label,folder,tags in [('prior',B,{'_start':'<_start>','raster_batch':'10sexdisplay12raster_batch>','render_prepared':'10sexdisplay15render_prepared>'}),('candidate',O,{'_start':'<_start>','raster_batch':'10sexdisplay12raster_batch>','render_prepared':'10sexdisplay15render_prepared>'})]:
 text=(folder/'sexdisplay.asm').read_text();blocks=re.split(r'(?m)^(?=[0-9a-f]{16} <)',text);frames[label]={}
 for name,tag in tags.items():
  found=[v for v in blocks if v.splitlines()and tag in v.splitlines()[0]];assert len(found)==1
  lines=found[0].splitlines()[:15];prologue='\n'.join(lines);m=re.search(r'subq\s+\$0x([0-9a-f]+), %rsp',prologue);assert m
  frames[label][name]=dict(local_reservation_bytes=int(m[1],16),register_push_bytes=8*len(re.findall(r'\bpushq\b',prologue)),prologue=lines)
assembly=(O/'sexdisplay.asm').read_text();fences=[l for l in assembly.splitlines()if re.search(r'\bsfence\b',l)];assert fences
cur=next(r for r in json.loads((O/'result.json').read_text())['results']if r['name']=='sexdisplay');prior=next(r for r in json.loads((B/'result.json').read_text())['results']if r['name']=='sexdisplay')
smoke=json.loads((T/(P+'-boot-audit-smoke.json')).read_text());assert smoke['ok']and smoke['boots']==1;obs=smoke['observations'][0]
r=dict(ok=True,static_objects=objects,symbols=symbol_rows,elf_sha256=sha(elf),elf_bytes=cur['elf_size'],prior_elf_bytes=prior['elf_size'],elf_byte_delta=cur['elf_size']-prior['elf_size'],frames=frames,cpu_store_fence_instructions=fences,boot_heap=obs['heap_budget'],display_frame_backing=obs['display_frame_backing'],app_private_pages=obs['private_pages'],scope='Exact ISO Display static objects, ELF size, decoded SFENCE and selected prologues. Inlining combines primitive passes into raster_batch; prologues exclude transitive callees, interrupts and dynamic paths. BOOT frame buddy backing, heap and app-private records are not disjoint total RAM; physical free frames remain unmeasured. No GPU latch/atomic visibility or speedup claim.')
out=T/(P+'-budget-audit.json');assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
