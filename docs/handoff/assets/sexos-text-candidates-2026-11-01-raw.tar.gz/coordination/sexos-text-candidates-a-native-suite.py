from pathlib import Path
import json,os,subprocess,time,hashlib,re
T=Path('/tmp');P='sexos-text-candidates-a'
PINS = {'commit': 'da40f6f3267bcadf34ed3c55b469a19159affc6f', 'binding_sha256': '02c7b53800b4b0f12ea50754b8ec7dcdf31929ee3338ef1c51fd70f1fafe6aa8', 'iso_sha256': '5be3183a73811a619ae5149684b3a3f60fe493998badefe560bbae4dc94ef9f2', 'runner_files': 638, 'source_files': 1224, 'source_bytes': 12293089, 'host_checks': 46}
if any(v is None for v in PINS.values()):raise RuntimeError('Root must fill post-build R170 pins before running any guest')
assert re.fullmatch('[0-9a-f]{40}',PINS['commit'])
F=(T/(P+'-frozen')).resolve(strict=True);R=F/'source'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify_source():
 assert sha(F/'source-binding.json')==PINS['binding_sha256']
 b=json.loads((F/'source-binding.json').read_text());provenance=b['build_provenance']
 assert provenance['git_revision']==PINS['commit'] and provenance['build_gate']=='PASS' and provenance['sources_unchanged_during_build']
 assert sha(F/'tested.iso')==b['iso_sha256']==PINS['iso_sha256']
 assert sha(F/'tested.kernel')==b['kernel_sha256']=='26bace17d464d1ea04667a6ff1dc47514d76be472342ca4ed396000f62a20f89'
 closure={**b['sources'],**b['runner_sha256']}
 assert (len(b['sources']),len(b['runner_sha256']),len(closure))==(586,PINS['runner_files'],PINS['source_files'])
 assert set(closure)=={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and '__pycache__'not in p.parts}
 for name,digest in closure.items():
  p=R/name;assert p.resolve().is_relative_to(R)and not p.is_symlink()and sha(p)==digest
 assert sum((R/n).stat().st_size for n in closure)==PINS['source_bytes']
 return closure
closure=verify_source()
progress=T/(P+'-native-progress.json');assert not progress.exists()
began_wait=time.monotonic()
while True:
 host=json.loads((T/(P+'-frozen-host/report.json')).read_text())
 if host['run_status']=='complete':
  assert host['checks_passed'] and host['sources_unchanged_during_checks'] and len(host['checks'])==PINS['host_checks'] and all(v['exit_code']==0 for v in host['checks']);break
 if time.monotonic()-began_wait>900:raise TimeoutError('host observation deadline; no guest restart')
 time.sleep(10)
assert all(closure[name]==digest for name,digest in host['source_sha256'].items())
rows=[];plan=[]
for label,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 for mode in ('normal','invalid-year'):plan.append(('clock-'+mode+'-'+label,'certificate_time_gate.py',['--mode',mode],model,res,1,4,'clock'))
 plan.append(('connected-'+label,'connected_desktop_gate.py',[],model,res,2,17,'connected'))
 plan.append(('browser-'+label,'browser_reserve_gate.py',['--mode','quiesced'],model,res,1,10,'browser'))
for name,script,extra,model,res,boots,captures,kind in plan:
 verify_source()
 out=T/(P+'-native-'+name);driver=T/(P+'-native-'+name+'.driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',res,*extra]
 row=dict(name=name,kind=kind,out=str(out),command=command,status='running');rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');print('START',name,flush=True);began=time.monotonic()
 with driver.open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 result=json.loads((out/'result.json').read_text());assert result['ok']
 if kind=='clock':assert len(result['pixels'])==captures and all(v['civil_clock']['ok'] for v in result['pixels'])
 elif kind=='connected':assert result['boots']==boots and result['frames']==captures
 else:assert len(result['frames'])==captures
 check=command[:];at=check.index('--source-disk');del check[at:at+2];check+=['--check'];replay=T/(P+'-native-'+name+'-independent-replay.json')
 with replay.open('x')as log:r=subprocess.run(check,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert r.returncode==0;verified=json.loads(replay.read_text());assert verified['ok']
 if kind=='connected':assert verified['boots']==boots and verified['frames']==captures and verified['same_image']
 else:assert verified['captures']==captures
 if kind=='clock':
  code="import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;r=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(r/'scripts'));from certificate_time_gate import replay_evidence;print(json.dumps(replay_evidence(r,Path(sys.argv[2]).resolve(strict=True),Path(sys.argv[3]).resolve(strict=True),Path(sys.argv[4]).resolve(strict=True))))"
  api=T/(P+'-native-'+name+'-full-api-replay.json')
  with api.open('x')as log:r=subprocess.run(['python3','-c',code,str(R),str(F/'tested.iso'),str(F/'source-binding.json'),str(out)],cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=300)
  assert r.returncode==0;full=json.loads(api.read_text())
  assert {k:full[k]for k in ('ok','mode','captures')}==verified and len(full['pixels'])==4
  assert all(v['ok']and v['civil_clock']['ok']and v['civil_clock']['caption_profile']=='date-caption-v1'for v in full['pixels'])
  row['full_api_replay']=str(api)
 verify_source()
 row.update(fresh_replay=True,boots=boots,captures=captures,replay=str(replay));progress.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==8 and sum(r['boots']for r in rows)==10 and sum(r['captures']for r in rows)==70
print('EIGHT_NATIVE_WORKFLOWS_PASS_10_BOOTS_70_CAPTURES',flush=True)
