const MAX_FB_W: usize = 8192;
const MAX_FB_H: usize = 4320;
const BAR_BG_H: usize = 50;
const BAR_BG_W_CAP: usize = 2560;
static mut BAR_BG_BUF: [u32; BAR_BG_H * BAR_BG_W_CAP] = [0u32; BAR_BG_H * BAR_BG_W_CAP];
static mut BAR_BLUR_BUF: [u32; BAR_BG_H * BAR_BG_W_CAP] = [0u32; BAR_BG_H * BAR_BG_W_CAP];
const FOCUS_SURFACE_COLOR: u32 = 0x0089B4FA;
const FRAME_RIM_COLOR: u32 = 0x00B4BEFE;
const FRAME_TOP_BAR_COLOR: u32 = 0x001E1E2E;
const TAB_ACTIVE_COLOR: u32 = FOCUS_SURFACE_COLOR; // 0x00A8E0FF (bright cyan)
const TAB_INACTIVE_COLOR: u32 = 0x0045475A; // Catppuccin Surface1
const FRAME_LIGHT_CLOSE_COLOR: u32 = 0x00FF4444;
const FRAME_LIGHT_MINIMIZE_COLOR: u32 = 0x00FFCC44;
const FRAME_LIGHT_ZOOM_COLOR: u32 = 0x0044FF44;
const DEFAULT_RENDER_TOKENS: RenderTokensV1 = RenderTokensV1 {
    focus_surface_color:  FOCUS_SURFACE_COLOR,
    frame_rim_color:      FRAME_RIM_COLOR,
    frame_top_bar_color:  FRAME_TOP_BAR_COLOR,
    active_tab_color:     TAB_ACTIVE_COLOR,
    inactive_tab_color:   TAB_INACTIVE_COLOR,
    close_light_color:    FRAME_LIGHT_CLOSE_COLOR,
    minimize_light_color: FRAME_LIGHT_MINIMIZE_COLOR,
    zoom_light_color:     FRAME_LIGHT_ZOOM_COLOR,
    appearance_flags:     0,
    effect_levels:        0,
};
#[derive(Clone, Copy)]
#[repr(C)]
struct RenderTokensV1 {
    focus_surface_color: u32,
    frame_rim_color: u32,
    frame_top_bar_color: u32,
    active_tab_color: u32,
    inactive_tab_color: u32,
    close_light_color: u32,
    minimize_light_color: u32,
    zoom_light_color: u32,
    appearance_flags: u8,
    effect_levels: u8,
}
use silkbar_model::{SilkBar,DEFAULT_THEME};
use surface_lifecycle::{TEXT_BUF_CAP,TEXT_MAX_ROWS,TEXT_LEGACY_COLS};
fn lerp_color_xrgb(a: u32, b: u32, t: u8) -> u32 {
    if t == 0 { return a | 0xFF000000; }
    if t == 255 { return b | 0xFF000000; }
    let ar = (a & 0xFF) as u32;
    let ag = ((a >> 8) & 0xFF) as u32;
    let ab = ((a >> 16) & 0xFF) as u32;
    let br = (b & 0xFF) as u32;
    let bg = ((b >> 8) & 0xFF) as u32;
    let bb = ((b >> 16) & 0xFF) as u32;
    let ti = t as u32;
    let r = ar + ((br.wrapping_sub(ar)).wrapping_mul(ti) / 255);
    let g = ag + ((bg.wrapping_sub(ag)).wrapping_mul(ti) / 255);
    let b_ = ab + ((bb.wrapping_sub(ab)).wrapping_mul(ti) / 255);
    0xFF000000 | (b_ << 16) | (g << 8) | r
}
fn vertical_gradient_xrgb(y: usize, h: usize, top: u32, bottom: u32) -> u32 {
    if h <= 1 { return top; }
    let t = ((y.min(h - 1) as u32).wrapping_mul(255)) / ((h - 1) as u32);
    lerp_color_xrgb(top, bottom, t as u8)
}
fn bg(y: usize, h: usize) -> u32 {
    vertical_gradient_xrgb(y, h, DEFAULT_THEME.bg_top, DEFAULT_THEME.bg_bottom)
}
fn scene_bar_blur_rows(fb_h: usize) -> [u32; BAR_BG_H] {
    let height=BAR_BG_H.min(fb_h);
    let mut rows=[0;BAR_BG_H];
    for y in 0..height {
        let first=y.saturating_sub(1);
        let last=(y+1).min(height-1);
        let (mut r,mut g,mut b)=(0u32,0u32,0u32);
        for sy in first..=last {
            let color=bg(sy,fb_h);
            r+=color&255;g+=(color>>8)&255;b+=(color>>16)&255;
        }
        let count=(last-first+1)as u32;
        rows[y]=0xFF000000|((b/count)<<16)|((g/count)<<8)|(r/count);
    }
    rows
}
fn fill_bar_bg_buffer(fb_w: u32, fb_h: u32) -> bool {
    let fill_w = fb_w as usize;
    if fill_w > BAR_BG_W_CAP {
        return false;
    }
    let fill_h = BAR_BG_H.min(fb_h as usize);
    for y in 0..fill_h {
        let c = bg(y, fb_h as usize);
        for x in 0..fill_w {
            unsafe { BAR_BG_BUF[y * BAR_BG_W_CAP + x] = c; }
        }
    }
    true
}
fn blur_bar_bg_buffer_radius1(fb_w: u32, fb_h: u32) -> bool {
    let width = fb_w as usize;
    if width > BAR_BG_W_CAP {
        return false;
    }
    let height = BAR_BG_H.min(fb_h as usize);
    for y in 0..height {
        for x in 0..width {
            let mut acc_r: u32 = 0;
            let mut acc_g: u32 = 0;
            let mut acc_b: u32 = 0;
            let y0 = y.saturating_sub(1);
            let y1 = (y + 1).min(height.saturating_sub(1));
            let x0 = x.saturating_sub(1);
            let x1 = (x + 1).min(width.saturating_sub(1));
            for sy in y0..=y1 {
                for sx in x0..=x1 {
                    let c = unsafe { BAR_BG_BUF[sy * BAR_BG_W_CAP + sx] };
                    acc_r += c & 0xFF;
                    acc_g += (c >> 8) & 0xFF;
                    acc_b += (c >> 16) & 0xFF;
                }
            }
            let count = ((y1 - y0 + 1) * (x1 - x0 + 1)) as u32;
            let r = (acc_r / count) & 0xFF;
            let g = (acc_g / count) & 0xFF;
            let b = (acc_b / count) & 0xFF;
            unsafe { BAR_BLUR_BUF[y * BAR_BG_W_CAP + x] = 0xFF000000 | (b << 16) | (g << 8) | r; }
        }
    }
    true
}
fn surface_text_scale(surf: &Surface) -> usize {
    if sex_pdx::app_catalog::is_spindle(surf.owner_pd)
        && sex_pdx::app_catalog::native_pixel_bit(surf.owner_pd, surf.surface_id) != 0
    {
        sex_pdx::spindle_view::scale(surf.w) as usize
    } else {
        sex_pdx::desktop_style::scale(surf.w) as usize
    }
}
fn recompute_text_lines(surf: &mut Surface) {
    let len = (surf.text_len as usize).min(TEXT_BUF_CAP);
    surf.line_count = 0;
    surf.cell_count = 0;
    surf.cell_starts.fill(0);
    surf.line_cells.fill(0);
    surf.line_starts.fill(0);
    if len == 0 { surf.wrap_cols = TEXT_LEGACY_COLS; return; }

    let has_newline = surf.text_buf[..len].iter().any(|&b| b == b'\n');
    surf.wrap_cols = if has_newline {
        let advance = 6 * surface_text_scale(surf) as u32;
        (surf.w.saturating_sub(16) / advance).clamp(1, 80) as u8
    } else {
        TEXT_LEGACY_COLS
    };

    let cols = surf.wrap_cols as usize;
    let mut i = 0usize;
    let mut col = 0usize;
    surf.line_starts[0] = 0;
    surf.line_cells[0] = 0;
    surf.line_count = 1;
    while let Some((scalar,end)) = sex_pdx::text_encoding::cell(&surf.text_buf[..len],i) {
        surf.cell_starts[surf.cell_count as usize]=i as u16;
        surf.cell_count+=1;
        i=end;
        if scalar == 10 {
            if (surf.line_count as usize) >= TEXT_MAX_ROWS { break; }
            surf.line_starts[surf.line_count as usize] = i as u16;
            surf.line_cells[surf.line_count as usize] = surf.cell_count;
            surf.line_count += 1;
            col = 0;
        } else {
            col += 1;
            if col >= cols && i < len {
                if (surf.line_count as usize) >= TEXT_MAX_ROWS { break; }
                surf.line_starts[surf.line_count as usize] = i as u16;
                surf.line_cells[surf.line_count as usize] = surf.cell_count;
                surf.line_count += 1;
                col = 0;
            }
        }
    }
}
fn apply_pending_text(slot:&mut Surface,pending:&text_transaction::Pending<'_>)->bool{
    let context=pending.context();
    // Main already attested the sender and live Surface at intake. This is
    // candidate association under that policy, not another grant or task=PD.
    if !slot.active||slot.owner_pd!=context.owner()||slot.surface_id!=context.surface()
        ||pending.len()>TEXT_BUF_CAP{return false;}
    slot.text_buf.copy_from_slice(pending.bytes());
    slot.text_len=pending.len() as u16;
    slot.text_color=pending.color();
    (slot.selection_start,slot.selection_end)=pending.selection();
    recompute_text_lines(slot);
    true
}