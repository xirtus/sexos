static mut RENDER_SCENE: scene::SceneSnapshot = scene::SceneSnapshot::EMPTY;
static mut SURFACES: [Surface; MAX_SURFACES] = [SURFACE_EMPTY; MAX_SURFACES];
static mut FRAME_GROUPS: surface_groups::FrameGroups = surface_groups::FrameGroups::new();
static mut BITMAP_STORES: bitmap_stores::Stores<{sex_pdx::app_catalog::count(sex_pdx::app_catalog::App::Browser)}> = bitmap_stores::Stores::UNBOUND;
static mut DISPLAY_TOKENS: RenderTokensV1 = DEFAULT_RENDER_TOKENS;
static mut FOCUSED_SURFACE_ID: u64 = 0;
static RENDER_FRAME_COUNTER: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);
static mut TEXT_STAGES: [text_transaction::Stage; MAX_SURFACES] = [text_transaction::Stage::EMPTY; MAX_SURFACES];
static mut TOKEN_BUF_CALL1_RECEIVED: bool = false;
static mut TOKEN_BUF_OWNER: u32 = 0;
static mut TOKEN_BUF_ARG0: u64 = 0;
static mut TOKEN_BUF_ARG1: u64 = 0;
static mut TOKEN_BUF_ARG2: u64 = 0;
static mut CURSOR_UNDER_VALID: bool = false;
static mut APP_PRESENT_BITS: u64 = 0;
static mut CLOCK_CANON_SS: u8 = 0;
static mut FRAME_OUTPUT: Option<frame_output::Store> = None;
static mut PREPARED_CURSOR:Option<PreparedCursor>=None;
struct PublishedFrame{plan:Plan,present_bits:u64,canon_ss:u8,
    text_contexts:[Option<text_transaction::Context>;MAX_SURFACES]}
#[derive(Clone,Copy)]
struct PreparedCursor{x:usize,y:usize,seq:u32,shell_tick:u32}
struct SceneLease { _single_task: core::marker::PhantomData<*mut ()> }
impl SceneLease {
    fn capture(w: usize, h: usize, bar: &SilkBar) -> Option<Self> {
        unsafe {
            // Reject reentry using a shared read before constructing an
            // exclusive reference: an existing lease may still borrow data.
            if (*core::ptr::addr_of!(RENDER_SCENE)).is_valid() { return None; }
            let destination = &mut *core::ptr::addr_of_mut!(RENDER_SCENE);
            let frame = RENDER_FRAME_COUNTER.load(core::sync::atomic::Ordering::Relaxed);
            if !destination.capture(&SURFACES, &FRAME_GROUPS, &BITMAP_STORES, &TEXT_STAGES, bar,
                DISPLAY_TOKENS, FOCUSED_SURFACE_ID, frame, w, h) { return None; }
        }
        Some(Self { _single_task: core::marker::PhantomData })
    }
    fn view(&self) -> &scene::SceneSnapshot {
        unsafe { &*core::ptr::addr_of!(RENDER_SCENE) }
    }
}
impl Drop for SceneLease {
    fn drop(&mut self) {
        unsafe { (*core::ptr::addr_of_mut!(RENDER_SCENE)).scrub(); }
    }
}
fn prepare_app_cleanup(lifecycle: &mut surface_lifecycle::Lifecycle, bar: &mut SilkBar) -> bool {
    // A retained scene cannot be retired or release cleanup custody.
    if unsafe{(*core::ptr::addr_of!(RENDER_SCENE)).is_valid()}{return false;}
    let mut changed = false;
    for index in 0..surface_lifecycle::CATALOG_CAPACITY {
        let Some(catalog) = lifecycle.catalog(index) else { continue; };
        if lifecycle.phase(index) != Some(surface_lifecycle::Phase::Live) { continue; }
        let Ok(info) = sex_pdx::app_lifecycle::info(catalog.slot) else { continue; };
        if info.target_pd != catalog.target_pd || info.task_id != catalog.task_id
            || info.required_mask & sex_pdx::app_lifecycle::ROLE_DISPLAY == 0 { continue; }
        unsafe {
            let mut refs = surface_lifecycle::SceneRefs {
                focused_sid: FOCUSED_SURFACE_ID, active_app_sid: bar.phase1.active_app_sid,
                token_owner: TOKEN_BUF_OWNER, token_pending: TOKEN_BUF_CALL1_RECEIVED,
                cursor_under_valid: CURSOR_UNDER_VALID,
            };
            if let Some(removed) = lifecycle.prepare(index, info.target_pd, info.task_id, &mut SURFACES, &mut refs) {
                BITMAP_STORES.retire(info.target_pd,info.task_id);
                for (index,stage) in TEXT_STAGES.iter_mut().enumerate() {
                    stage.retire(info.target_pd,info.task_id);
                    if !SURFACES[index].active { stage.reset(); }
                }
                FOCUSED_SURFACE_ID = refs.focused_sid;
                bar.phase1.active_app_sid = refs.active_app_sid;
                TOKEN_BUF_OWNER = refs.token_owner;
                TOKEN_BUF_CALL1_RECEIVED = refs.token_pending;
                if !refs.token_pending { TOKEN_BUF_ARG0 = 0; TOKEN_BUF_ARG1 = 0; TOKEN_BUF_ARG2 = 0; }
                CURSOR_UNDER_VALID = refs.cursor_under_valid;
                scrub_cursor_under();
                if let Some(output)=FRAME_OUTPUT.as_mut(){output.scrub();}
                PREPARED_CURSOR=None;
                changed = true;
                sex_pdx::serial_record!("[display.app.cleanup.prepared] target={} task={} removed={} focus={} tombstone=1",
                    info.target_pd, info.task_id, removed, refs.focused_sid);
            }
        }
    }
    changed
}
fn typed_completion_needs_publication()->bool{
    unsafe{TEXT_STAGES.iter().any(text_transaction::Stage::needs_publication)
        ||BITMAP_STORES.needs_publication()}
}
fn commit_published_text(contexts:&[Option<text_transaction::Context>;MAX_SURFACES])->usize{
    let mut committed=0;
    for(index,context)in contexts.iter().copied().enumerate(){
        let Some(context)=context else{continue;};
        unsafe{
            let stage=&mut TEXT_STAGES[index];
            let Some(pending)=stage.pending()else{continue;};
            if pending.context()!=context{continue;}
            let slot=&mut SURFACES[index];
            let len=pending.len();
            let changed=slot.text_len as usize!=len||slot.text_color!=pending.color()
                ||slot.text_buf!=*pending.bytes()
                ||(slot.selection_start,slot.selection_end)!=pending.selection();
            if !apply_pending_text(slot,&pending){continue;}
            // Closed intake and immutable pending bytes make this exact match
            // stable through canonical commit. This metadata grants no route.
            assert!(stage.release_matching(context));
            committed+=1;
            sex_pdx::serial_record!("[display.text.committed] target={} surface={} paint={} bytes={} changed={} pixels=unconfirmed",
                context.owner(),context.surface(),context.sequence(),len,changed as u8);
            if sex_pdx::app_catalog::app_of(context.owner())==Some(sex_pdx::app_catalog::App::Browser){
                sex_pdx::serial_record!("[display.browser.text.committed] target={} task={} surface={} paint={} bytes={} hash={} changed={} pixels=unconfirmed",
                    context.owner(),context.task(),context.surface(),context.sequence(),len,
                    sex_pdx::text_batch::hash(&slot.text_buf[..len]),changed as u8);
            }
        }
    }
    committed
}
fn finish_display_transactions(lifecycle: &mut surface_lifecycle::Lifecycle, published: Option<&PublishedFrame>) {
    // A retained scene cannot be retired or release cleanup custody.
    if unsafe{(*core::ptr::addr_of!(RENDER_SCENE)).is_valid()}{return;}
    if let Some(published)=published.filter(|frame|frame.plan.is_full()){
        // This receipt belongs to the just-finished Main drain. No intake runs
        // between its scene capture, CPU publication and completion handling.
        // Full also settles no-op, hidden and empty updates; Applied remains a
        // data-admission receipt, not proof that those bytes were visible.
        let text=commit_published_text(&published.text_contexts);
        let bitmap=unsafe{BITMAP_STORES.release_after_publication()};
        if text+bitmap>0{
            sex_pdx::serial_record!("[display.typed.released] text={} bitmap={} full=1 scene_released=1 publication=1 pixels=unconfirmed",text,bitmap);
        }
        lifecycle.pixels_presented(published.present_bits);
        for index in 0..surface_lifecycle::CATALOG_CAPACITY {
            if lifecycle.scene_committed(index) {
                let c = lifecycle.catalog(index).unwrap();
                sex_pdx::serial_record!("[display.app.cleanup.committed] target={} task={} scene=1", c.target_pd, c.task_id);
            }
        }
    }
    for index in 0..surface_lifecycle::CATALOG_CAPACITY {
        if lifecycle.phase(index) != Some(surface_lifecycle::Phase::Committed) { continue; }
        let c = lifecycle.catalog(index).unwrap();
        if sex_pdx::app_lifecycle::ack(c.slot, c.task_id).is_ok() {
            assert!(lifecycle.acknowledge(index, c.target_pd, c.task_id));
            sex_pdx::serial_record!("[display.app.cleanup.ack] target={} task={} role=display", c.target_pd, c.task_id);
        }
    }
    for index in 0..surface_lifecycle::CATALOG_CAPACITY {
        let Some((target, value)) = lifecycle.presentation_reply(index) else { continue; };
        if sex_pdx::pdx_reply(target, value) == 0 {
            assert!(lifecycle.presentation_reply_sent(index, value));
            sex_pdx::serial_record!("[display.app.present.reply] target={} request={} scene=1", target, value >> 8);
        }
    }

}