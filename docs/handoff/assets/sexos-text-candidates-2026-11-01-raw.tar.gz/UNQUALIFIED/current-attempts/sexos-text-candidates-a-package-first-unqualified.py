"""Round170 exact eleven-boot/seventy-capture evidence package.
Root must pin executed helpers, review, and run after all native outputs stop.
No guest/build actions: only frozen read-only --check/API replay, then archive.
"""
from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,subprocess,tarfile
T=Path('/tmp');P='sexos-text-candidates-a'
COMMIT = 'da40f6f3267bcadf34ed3c55b469a19159affc6f'
BASELINE = '78227603f512a1a6c531542b4779c73168d628c3'
BASELINE_BINDING_SHA256 = '6e378854223af305f1606d0465e3aa487b62555332a72c80b1b55c2029c08b65'
# Explicit post-build pins. None/ROOT_PIN_PENDING always aborts before replay/archive.
PINS = {'binding_sha256': '02c7b53800b4b0f12ea50754b8ec7dcdf31929ee3338ef1c51fd70f1fafe6aa8', 'iso_sha256': '5be3183a73811a619ae5149684b3a3f60fe493998badefe560bbae4dc94ef9f2', 'runner_files': 638, 'source_files': 1224, 'source_bytes': 12293089, 'scalar_instructions': 325066, 'host_checks': 46, 'rust_log_test_executions': 3210, 'python_tests': 1132, 'scene_controls': [21, 12, 2], 'bitmap_controls': [17, 17, 5, 9272, 27816], 'compositor_cases': 49, 'frame_cases': {'layout': 7, 'paint_batch': 8, 'pipeline': 10, 'store': 8, 'va': 6}, 'frame_controls': [7, 3, 4, 7, 9], 'cursor_controls': [5, 2, 4], 'static_objects': {'TEXT_STAGES': 9088, 'BITMAP_STORES': 55992, 'RENDER_SCENE': 60096, 'FRAME_OUTPUT': 88}, 'display_elf_bytes': 291760, 'candidate_frames': {'_start': 4728, 'raster_batch': 2344, 'render_prepared': 1304}, 'candidate_register_push_bytes': 48, 'boot_heap': {'bytes': 268435456, 'used': 11851408, 'free': 256584048, 'point': 'after_grant_seal', 'allocator_lock_released': True, 'physical_free_frames': 'unmeasured'}}
EXECUTED_HELPER_SHA256 = {'/tmp/sexos-text-candidates-a-source-audit.py': '726fd1e3dba20a058bf9f7ddaafdf7963433d222dda3772440a0d0177eaaa918', '/tmp/sexos-text-candidates-a-scalar-audit.py': '70bb0256cb4020d4b758737952caef1b9b8588d962d176aae30d176bf3e941e6', '/tmp/sexos-text-candidates-a-budget-audit.py': '65fddef0fd45c707d9a8b40eab085b5a8f78c942e07582b71ddec9f2a63f2b4a', '/tmp/sexos-text-candidates-a-boot-audit.py': '123f09375f324fce05d0a181886f21b981925634dab8d5da58b72d08524d374e', '/tmp/sexos-text-candidates-a-native-suite.py': '28c7c155f2792c6539a96536bece10ef32a13f3f24b1417ef7c2c69cfc1ef4f7', '/tmp/sexos-text-candidates-a-production-equivalence.py': '95c7f6806968291bd52b1857d428290343f9a22f0f970c45f51bf2a8ad72a19c'}
# Root may add only current R170 failed diagnostics, if any. No R169 A/B evidence is carried forward.
UNQUALIFIED_DIAGNOSTIC_SHA256 = {'/tmp/sexos-r170-compositor-host.log': 'f551f30f609c18afcda597ec963a14a018336c0fffa47ca6b395839d281b47c5', '/tmp/sexos-text-candidates-a-scene-first-preflight/main-source.rs': '5d3174fd3c92fd7035cfa9270307462d59b93023434be97af3efbe49e1449dd8', '/tmp/sexos-text-candidates-a-scene-first-preflight.log': 'b203c4d051c2e6c3cc397273684f35be8d440c4cce09cf782e873b01a953e925', '/tmp/sexos-text-candidates-a-scene-second-preflight/actual.compile.log': '736e7307d8681a05c40ec8a24e8b99f6a4f961dce59d383fb0527004afd6da57', '/tmp/sexos-text-candidates-a-scene-second-preflight/actual.rs': 'c4edb8d64eafb9fdb3d9e4b25a7110d18c175727a0a19ddda86266a71a95d6c2', '/tmp/sexos-text-candidates-a-scene-second-preflight/lease.rs': '381266261d27b60d1fd040c57ff8a77f5ff4570abd1441a44ecb1b6b232b171b', '/tmp/sexos-text-candidates-a-scene-second-preflight/libsilkbar_model.rlib': 'f23b842b04d39a46d8a7a4c73a64229f2ee24c318eddc5324ef1ec38bc04b46f', '/tmp/sexos-text-candidates-a-scene-second-preflight/main-source.rs': '5d3174fd3c92fd7035cfa9270307462d59b93023434be97af3efbe49e1449dd8', '/tmp/sexos-text-candidates-a-scene-second-preflight/model.compile.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '/tmp/sexos-text-candidates-a-scene-second-preflight/parent.rs': '5bddf9b4fd1672bf3d5f48747bd5618adae857fee3cba2b6c207c4344708497a', '/tmp/sexos-text-candidates-a-scene-second-preflight.log': '465ab71cd3ae03b7ccf481223fe53f9c246c55c455397e2170aef0d7d4e887ff'}
EXPECTED_CHANGED = ['servers/sexdisplay/src/main.rs', 'servers/sexdisplay/src/scene.rs', 'servers/sexdisplay/src/text_transaction.rs']
EXPECTED_ADDED=[]
EXPECTED_ABI='3b98b23398b7a309a74d5d10526e9234fa372ff448c79f51aa4f4b9f44fdc36a'
EXPECTED_KERNEL='26bace17d464d1ea04667a6ff1dc47514d76be472342ca4ed396000f62a20f89'
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}

def require(value,why):
 if not value:raise AssertionError(why)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def marker(text,tag):
 matches=re.findall(r'^\['+re.escape(tag)+r'\] PASS (\{[^\n]+\})$',text,re.M)
 require(len(matches)==1,('exact host proof marker',tag));return json.loads(matches[0])
def rust_fixture(log,count,test_name):
 blocks=re.findall(r'^running (\d+) tests\n(.*?)^test result: ok\. (\d+) passed; 0 failed;[^\n]*$',log,re.M|re.S)
 matched=[(int(start),int(end))for start,body,end in blocks if re.search(r'^test '+re.escape(test_name)+r' \.\.\. ok$',body,re.M)]
 require(matched==[(count,count)],('exact actual Rust fixture',test_name,count,matched))
def plan():
 rows=[]
 for profile,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
  for mode in ('normal','invalid-year'):rows.append(dict(name=f'clock-{mode}-{profile}',kind='clock',script='certificate_time_gate.py',extra=['--mode',mode],model=model,resolution=res,boots=1,captures=4,mode=mode))
  rows.append(dict(name='connected-'+profile,kind='connected',script='connected_desktop_gate.py',extra=[],model=model,resolution=res,boots=2,captures=17))
  rows.append(dict(name='browser-'+profile,kind='browser',script='browser_reserve_gate.py',extra=['--mode','quiesced'],model=model,resolution=res,boots=1,captures=10,mode='quiesced'))
 return rows

def main():
 def pinned(value):
  if value is None or value=='ROOT_PIN_PENDING':return False
  if isinstance(value,dict):return all(pinned(v)for v in value.values())
  if isinstance(value,(list,tuple)):return all(pinned(v)for v in value)
  return True
 require(re.fullmatch('[0-9a-f]{40}',COMMIT)and pinned(PINS),'Root must fill every post-build R170 pin')
 F=(T/(P+'-frozen')).resolve(strict=True);R=F/'source'
 archive=T/(P+'-2026-11-01-raw.tar.gz');receipt_path=T/(P+'-package-result.json')
 require(not archive.exists()and not receipt_path.exists(),'archive/receipt already exists; never overwrite')
 required={str(T/(P+s))for s in ('-source-audit.py','-scalar-audit.py','-budget-audit.py','-boot-audit.py','-native-suite.py','-production-equivalence.py')}
 require(required==set(EXECUTED_HELPER_SHA256),'Root must pin all six executed auditor/coordinator sources')
 for path,digest in {**EXECUTED_HELPER_SHA256,**UNQUALIFIED_DIAGNOSTIC_SHA256}.items():
  require(re.fullmatch('[0-9a-f]{64}',digest)and sha(path)==digest,('executed helper/diagnostic changed',path))
 require(sha(F/'source-binding.json')==PINS['binding_sha256'],'pinned current binding')
 b=read(F/'source-binding.json');require(b['build_provenance']['git_revision']==COMMIT and b['build_provenance']['build_gate']=='PASS'and b['build_provenance']['sources_unchanged_during_build'],'exact sealed source')
 require(sha(F/'tested.iso')==b['iso_sha256']==PINS['iso_sha256']and sha(F/'tested.kernel')==b['kernel_sha256'],'current sealed image/kernel')
 closure={**b['sources'],**b['runner_sha256']}
 require((len(b['sources']),len(b['runner_sha256']),len(closure))==(586,PINS['runner_files'],PINS['source_files']),'exact source membership counts')
 require(set(closure)=={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and '__pycache__'not in p.parts},'exact frozen source closure')
 for name,digest in closure.items():
  p=R/name;require(p.resolve().is_relative_to(R)and not p.is_symlink()and sha(p)==digest,('frozen source changed',name))
 require(sum((R/n).stat().st_size for n in closure)==PINS['source_bytes'],'exact frozen byte count')
 source=read(T/(P+'-source-audit.json'));scalar=read(T/(P+'-scalar/result.json'));host=read(T/(P+'-frozen-host/report.json'));budget=read(T/(P+'-budget-audit.json'))
 require(source['ok']and(source['commit'],source['iso_sha256'],source['kernel_sha256'],source['unique'],source['total_source_bytes'])==(COMMIT,b['iso_sha256'],b['kernel_sha256'],PINS['source_files'],PINS['source_bytes']),'source audit binding/counts')
 require(len(source['rows'])==PINS['source_files'] and {v['path']for v in source['rows']}==set(closure),'all audited Git/source rows')
 for row in source['rows']:require(row['sha256']==closure[row['path']]and row['size']==(R/row['path']).stat().st_size,('source audit row',row['path']))
 require(scalar['ok']and scalar['commit']==COMMIT and scalar['iso_sha256']==b['iso_sha256']and scalar['total_instructions']==PINS['scalar_instructions'] and len(scalar['results'])==9,'current nine-ELF scalar scan')
 require({r['name']for r in scalar['results']}=={'kaleidoscope','silk-shell','sexdisplay','quil','silkbar','sexfiles','spindle','linen','sexnet'},'exact scalar ELF set')
 require(sum(r['instructions']for r in scalar['results'])==PINS['scalar_instructions'],'scalar aggregate')
 for row in scalar['results']:
  require(not row['vector_or_fp_matches']and row['instructions']>0,'scalar scan failure')
  for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/(P+'-scalar')/(row['name']+suffix))==row[key],'scalar bytes changed')
 require(host['run_status']=='complete'and host['checks_passed']and host['sources_unchanged_during_checks']and len(host['checks'])==PINS['host_checks'] and all(r['exit_code']==0 for r in host['checks']),'all pinned current registered host checks')
 checks={r['id']:r for r in host['checks']};require(len(checks)==PINS['host_checks'],'unique host check IDs')
 for name,digest in host['source_sha256'].items():require(closure[name]==digest,('host source binding',name))
 obligations=host['obligations'];require(host['system_proven']is False and len(obligations)==30 and sum(v=='partial'for v in obligations.values())==28 and {k for k,v in obligations.items()if v=='open'}=={'EPOCH_COMMIT','DETERMINISTIC_REPLAY'},'honest Open2/Partial28 obligations')
 rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(r['log']).read_text())))for r in host['checks'])
 require(rust==PINS['rust_log_test_executions'],'exact pinned logged Rust test executions, not unique test count')
 client_log=Path(checks['service_custody']['log']).read_text()
 require('[browser.tls.panel.host] PASS cases=21 compiled_controls=3 scope=actual_panel_main_metadata_outbox_display_stage_not_native_pixels_or_authority'in client_log,'actual Browser viewport regression and old-cancel compiled defect control')
 require('[browser.viewport.custody] PASS source_controls=2 scope=actual_live_notice_preserves_active_and_invalidates_layout_cache_not_native_pixels'in client_log,'actual live viewport callsite custody')
 rust_fixture(client_log,24,'pending_view_exposes_only_sealed_exact_utf8_payload_and_captured_metadata')
 scene=marker(Path(checks['display_scene']['log']).read_text(),'display.scene.host')
 require(scene['ok']and(scene['actual_cases'],scene['compiled_runtime_mutants'],scene['source_fence_controls'])==tuple(PINS['scene_controls']),'actual scene/lease host proof')
 for path,digest in scene['sha256'].items():require(Path(path).resolve().is_relative_to(R)and sha(path)==digest,('scene host source',path))
 groups_log=Path(checks['display_surface_groups']['log']).read_text();require(len(re.findall(rf"test result: ok\. {PINS['compositor_cases']} passed; 0 failed;",groups_log))==1,'actual pinned compositor cases')
 rust_fixture(groups_log,22,'unreleased_completion_cannot_reply_or_be_bypassed_by_duplicates')
 binding=marker(groups_log,'display.bitmap.binding')
 require(binding['ok']and(binding['metadata_tests'],binding['actual_live_helper_tests'],binding['actual_browser_text_guard_tests'],binding['compiled_binding_mutants_rejected'],binding['compiled_text_guard_mutants_rejected'],binding['wiring_controls_rejected'])==(5,3,5,2,3,15),'actual13 binding/helper cases, five compiled controls and15 source controls')
 require(binding['text_commit_wiring']=='sealed_candidate_owned_scene_successful_Full_then_canonical_commit_and_exact_release','candidate commit source-wiring contract')
 bitmap=marker(groups_log,'bitmap.stores.host');require(bitmap['ok']and(bitmap['actual_case_executions'],bitmap['future_case_executions'],bitmap['compiled_mutants_rejected'],bitmap['published_bytes'],bitmap['published_stores3_bytes'])==tuple(PINS['bitmap_controls']),'actual bitmap snapshot controls')
 frames=marker(Path(checks['display_frame_output']['log']).read_text(),'display.frame.output.host')
 require(frames['ok']and frames['cases']==PINS['frame_cases']and(frames['compiled_runtime_mutants'],frames['paint_batch_runtime_mutants'],frames['compiler_trait_controls'],frames['source_controls'],len(frames['wiring']))==tuple(PINS['frame_controls']),'actual frame SDK/Store/VA/Main pipeline controls')
 for path,digest in frames['sha256'].items():require(Path(path).resolve().is_relative_to(R)and sha(path)==digest,('frame host source',path))
 cursor_log=Path(checks['display_cursor_output']['log']).read_text()
 require(len(re.findall(rf"^\[display.cursor.output.host\] PASS actual_cases={PINS['cursor_controls'][0]} compiled_runtime_mutants={PINS['cursor_controls'][1]} overlay_source_controls={PINS['cursor_controls'][2]} scope=actual_cursor_scene_target_pixels_host_background_menu_CPU_output_not_Main_receipts_or_hardware$",cursor_log,re.M))==1,'actual cursor output proof')
 py=(T/(P+'-frozen-python.log')).read_text();counts=re.findall(r'Ran (\d+) tests in ',py);require(counts==[str(PINS['python_tests'])]and py.rstrip().endswith('OK')and 'FAILED ('not in py,'exact pinned Python tests')
 baseline_path=T/'sexos-completion-custody-c-frozen/source-binding.json';prior=read(baseline_path);prior_root=baseline_path.parent/'source'
 require(prior['build_provenance']['git_revision']==BASELINE and sha(baseline_path)==BASELINE_BINDING_SHA256,'qualified R169 reference binding only')
 current_keys=set(b['sources']);old_keys=set(prior['sources']);changed=sorted(n for n in current_keys&old_keys if b['sources'][n]!=prior['sources'][n]);added=sorted(current_keys-old_keys);removed=sorted(old_keys-current_keys)
 require(len(old_keys)==586 and changed==EXPECTED_CHANGED and added==EXPECTED_ADDED and not removed,'exact three Display text-candidate production changes, no additions')
 comparison=read(T/(P+'-production-equivalence.json'))
 for k,v in dict(ok=True,baseline_commit=BASELINE,candidate_commit=COMMIT,baseline_production=586,candidate_production=586,changed=changed,added=added,removed=[],unchanged=583,kernel_identical=True,baseline_kernel_sha256=prior['kernel_sha256'],candidate_kernel_sha256=b['kernel_sha256'],abi_inputs=67,prior_abi_inputs=67,abi_added_inputs=[],baseline_binding_sha256=BASELINE_BINDING_SHA256).items():require(comparison[k]==v,('production comparison',k))
 require(prior['kernel_sha256']==b['kernel_sha256']==EXPECTED_KERNEL,'exact unchanged kernel bytes; no native acceptance transfer')
 def abi_inputs(root,count):
  text=(root/'scripts/entrypoint_build.sh').read_text();found=re.findall(r'^ABI_INPUTS=\(\n(.*?)\n\)',text,re.M|re.S);require(len(found)==1,'exact ABI list');values=found[0].split();require(len(values)==len(set(values))==count,'exact ABI input count');return values
 names=abi_inputs(R,67);old_names=abi_inputs(prior_root,67)
 require(names==old_names,'unchanged ordered ABI67 input set')
 for name in names:require(sha(R/name)==sha(prior_root/name),('ABI input bytes changed',name))
 abi=hashlib.sha256(''.join(sha(R/n)+'  '+n+'\n'for n in names).encode()).hexdigest();require(abi==comparison['abi_sha256']==EXPECTED_ABI,'actual unchanged ABI67 hash')
 display=next(v for v in scalar['results']if v['name']=='sexdisplay')
 # Final budget schema is validated against actual scalar ELF/disassembly;
 # no total-stack/physical-free-frame conclusion follows from prologues.
 require(budget['ok']and budget['static_objects']==PINS['static_objects'] and budget['elf_sha256']==display['elf_sha256']and budget['elf_bytes']==display['elf_size']==PINS['display_elf_bytes'],'current Display ELF and scene backing')
 require(budget['prior_elf_bytes']==288680 and budget['elf_byte_delta']==PINS['display_elf_bytes']-288680,'exact ELF size delta, not a performance claim')
 symbols=(T/(P+'-scalar/sexdisplay-symbols.txt')).read_text()
 def static_symbol(name,size):
  found=[line for line in symbols.splitlines()if re.search(r'\bO\s+\.\S+\s+([0-9a-fA-F]+)\s+\S*'+name+r'$',line)]
  require(len(found)==1,('exact ELF static symbol',name));match=re.search(r'\bO\s+\.\S+\s+([0-9a-fA-F]+)',found[0]);require(int(match[1],16)==size,('static symbol size',name));return found[0]
 scene_symbol=static_symbol('RENDER_SCENE',PINS['static_objects']['RENDER_SCENE']);output_symbol=static_symbol('FRAME_OUTPUT',PINS['static_objects']['FRAME_OUTPUT'])
 require(budget['symbols']=={name:static_symbol(name,size)for name,size in PINS['static_objects'].items()},'all four measured static symbol rows')
 candidate_assembly=(T/(P+'-scalar/sexdisplay.asm')).read_text();fences=[line for line in candidate_assembly.splitlines()if re.search(r'\bsfence\b',line)]
 require(fences and fences==budget['cpu_store_fence_instructions'],'decoded CPU store fence; no hardware latch inference')
 prior_scalar=read(T/'sexos-completion-custody-c-scalar/result.json');require(prior_scalar['ok']and prior_scalar['commit']==BASELINE and prior_scalar['iso_sha256']==prior['iso_sha256'],'baseline budget-only scalar reference')
 old_display=next(v for v in prior_scalar['results']if v['name']=='sexdisplay')
 for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/('sexos-completion-custody-c-scalar/sexdisplay'+suffix))==old_display[key],'baseline Display budget reference bytes')
 require(budget['prior_elf_bytes']==old_display['elf_size'],'baseline ELF size')
 for label,prefix in [('candidate',P),('prior','sexos-completion-custody-c')]:
  assembly=(T/(prefix+'-scalar/sexdisplay.asm')).read_text()
  expected_frames={'candidate':PINS['candidate_frames'],'prior':{'_start':4696,'raster_batch':2344,'render_prepared':1304}}[label]
  require(set(budget['frames'][label])==set(expected_frames),'exact measured prologues only')
  for name,frame in budget['frames'][label].items():
   require(name in {'_start','raster_batch','render_prepared','raster_full'},('unexpected measured function',name))
   require(frame['local_reservation_bytes']==expected_frames[name] and frame['register_push_bytes']==(PINS['candidate_register_push_bytes']if label=='candidate'else 48) and frame['prologue']and'\n'.join(frame['prologue'])in assembly,('prologue bytes no longer match bound disassembly',label,name))
 require(budget['app_private_pages']==2465 and budget['boot_heap']==PINS['boot_heap'],'exact heap receipt; do not infer disjoint/physical free memory')
 audit=read(T/(P+'-boot-audit.json'));rows=read(T/(P+'-native-progress.json'));planned=plan()
 require(len(rows)==8 and len(planned)==8,'all eight terminal workflows required')
 require((T/(P+'-native-suite.driver.log')).read_text().rstrip().endswith('EIGHT_NATIVE_WORKFLOWS_PASS_10_BOOTS_70_CAPTURES'),'current coordinator must finish successfully')
 expected={(T/(P+'-build/serial.log')).resolve()};geometry_by_path={next(iter(expected)):(1280,800)}
 for spec in planned:
  out=T/(P+'-native-'+spec['name'])
  paths={out.resolve()/phase/'serial.log'for phase in ('session','recovery')}if spec['kind']=='connected'else{out.resolve()/'serial.log'}
  expected|=paths
  for path in paths:geometry_by_path[path]=tuple(map(int,spec['resolution'].split('x')))
 require(audit['ok']and audit['mode']=='explicit_eleven_boot_inventory'and audit['boots']==audit['expected_final_boots']==11 and audit['final_cohort_complete'],'full eleven-boot audit, not smoke')
 require(audit['functional_acceptance_checked']is False and audit['kernel_equality_to_prior_image_asserted']is False,'BOOT inventory is not functional acceptance or prior-kernel equivalence')
 require(audit['frozen']['revision']==COMMIT and audit['frozen']['binding_sha256']==sha(F/'source-binding.json'),'BOOT audit binding')
 require(len(audit['observations'])==11 and {Path(o['path']).resolve()for o in audit['observations']}==expected,'exact eleven boot paths')
 for o in audit['observations']:
  require(Path(o['path']).stat().st_size==o['bytes']and sha(o['path'])==o['sha256'],'audited serial changed')
  require((o['apps'],o['registered_main_domains'],o['self_wait_capacity'],o['private_pages'])==(28,40,64,2465),'unchanged actual inventory')
  require(o['denial_storage']==dict(bytes=1352,owners=28,slots=84,bound=4096,public=1)and o['original_five_authority_lines_byte_identical'],'source authority/layout receipt')
  require(o['heap_budget']==budget['boot_heap'],'exact post-seal heap snapshot')
  width,height=geometry_by_path[Path(o['path']).resolve()];frame=width*4*height;span=(frame+4095)//4096*4096
  serial=Path(o['path']).read_text();tasks={int(m[1])for m in re.finditer(r'^task\.running id=(\d+) pd_id=1(?= )',serial,re.M)}
  require(len(tasks)==1 and next(iter(tasks))>0,'actual observed Display main, never inferred from PD')
  backing=dict(width=width,height=height,pitch=width*4,frame_bytes=frame,span_bytes=span,total_bytes=2*span,buddy_reserved_bytes=8388608,slot=98,region=11,buffers=2,holder_pd=1,holder_main_task=next(iter(tasks)),rights=7,no_peer=True,no_dma=True,zero_leaf_readback_before_seal=True,held_before_first_paint=True,authority_scope='PD-held; no exact-task isolation claim',physical_free_frames='unmeasured')
  require(o['display_frame_backing']==backing,'exact geometry-sized BOOT/held private frame evidence')
  if Path(o['path']).resolve()==(T/(P+'-build/serial.log')).resolve():require(budget['display_frame_backing']==backing,'budget uses sealed-build frame receipt only')
 typed_witness=[]
 for observation in audit['observations']:
  serial=Path(observation['path']).read_text();found=[]
  for match in re.finditer(r'^\[display\.typed\.released\] text=(\d+) bitmap=(\d+) full=1 scene_released=1 publication=1 pixels=unconfirmed$',serial,re.M):
   text_count,bitmap_count=map(int,match.groups());require(0<=text_count<=16 and 0<=bitmap_count<=3 and text_count+bitmap_count>0,'bounded native typed release record');found.append(dict(text=text_count,bitmap=bitmap_count))
  require(found and any(v['text']for v in found),('native typed text release absent',observation['path']))
  require(len(found)==len(re.findall(r'^\[display\.typed\.released\]',serial,re.M)),'malformed typed release witness')
  typed_witness.append(dict(path=observation['path'],records=len(found),text_completions=sum(v['text']for v in found),bitmap_completions=sum(v['bitmap']for v in found),scope='aggregate service release witness only; no sender-to-pixel visibility or hardware-latch proof'))
 proofs={};capture_counts={};memory_receipts={};outdirs={};replays=[]
 for spec,row in zip(planned,rows):
  out=(T/(P+'-native-'+spec['name'])).resolve(strict=True);outdirs[spec['name']]=out
  require(row['name']==spec['name']and row['kind']==spec['kind']and Path(row['out']).resolve()==out and row['status']==0 and row['fresh_replay']is True and row['boots']==spec['boots']and row['captures']==spec['captures'],'exact terminal workflow row')
  command=['python3',str(R/'scripts'/spec['script']),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(T/(P+'-native-'+spec['name'])),'--model',spec['model'],'--resolution',spec['resolution'],*spec['extra']]
  require(row['command']==command,'exact native invocation source/image/profile')
  check=command[:];at=check.index('--source-disk');del check[at:at+2];check+=['--check']
  replay=T/(P+'-native-'+spec['name']+'-independent-replay.json');require(Path(row['replay']).resolve()==replay.resolve(strict=True),'exact saved replay path')
  run=subprocess.run(check,capture_output=True,text=True,timeout=300,env=ENV);require(run.returncode==0,('fresh frozen read-only replay',spec['name'],run.stderr[-2000:]))
  fresh=json.loads(run.stdout);saved=read(replay);result=read(out/'result.json');require(fresh==saved and fresh['ok']and result['ok'],'saved/current replay disagreement');replays.append(replay)
  manifests=[read(out/phase/'manifest.json')for phase in ('session','recovery')]if spec['kind']=='connected'else[read(out/'manifest.json')]
  for manifest in manifests:require(manifest['resolution']==spec['resolution']and manifest['model']==spec['model'],'native profile metadata')
  manifest=manifests[0]
  if spec['kind']=='clock':
   require(manifest['mode']==spec['mode']and fresh==dict(ok=True,mode=spec['mode'],captures=4),'exact clock CLI summary')
   code="import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;r=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(r/'scripts'));from certificate_time_gate import replay_evidence;print(json.dumps(replay_evidence(r,Path(sys.argv[2]).resolve(strict=True),Path(sys.argv[3]).resolve(strict=True),Path(sys.argv[4]).resolve(strict=True))))"
   api=subprocess.run(['python3','-c',code,str(R),str(F/'tested.iso'),str(F/'source-binding.json'),str(out)],capture_output=True,text=True,timeout=300,env=ENV);require(api.returncode==0,('full clock replay API',spec['name'],api.stderr[-2000:]));full=json.loads(api.stdout)
   require({n:full[n]for n in('ok','mode','captures')}==fresh and len(full['pixels'])==len(result['pixels'])==4 and all(p['ok']and p['civil_clock']['ok']and p['civil_clock']['caption_profile']=='date-caption-v1'for p in full['pixels']),'four independently replayed full clock/chip pixels')
   api_path=T/(P+'-native-'+spec['name']+'-full-api-replay.json')
   require(Path(row['full_api_replay']).resolve()==api_path.resolve(strict=True)and read(api_path)==full,'native coordinator/full fresh clock API disagreement')
   fresh=full;memory_receipts['fresh-full-clock/'+spec['name']+'.json']=(json.dumps(full,indent=2,sort_keys=True)+'\n').encode()
  elif spec['kind']=='connected':require(fresh['boots']==2 and fresh['frames']==17 and fresh['same_image']and fresh['same_disk_state']and fresh['full_alpha_acceptance']is False,'representative connected two-boot proof')
  else:
   require(result['mode']=='quiesced'and len(result['frames'])==10 and fresh['captures']==10 and fresh['browser_pixels_qualified']and fresh['launcher_pixels_qualified'],'three held Browser incarnations, nine TLS panels and exhaustion capture')
   require([v['identity']['target']for v in result['chain']]==[15,30,31],'exact current Browser chain')
  proofs[spec['name']]=fresh;capture_counts[spec['name']]=spec['captures']
 require(sum(r['boots']for r in rows)==10 and sum(capture_counts.values())==70,'exact10 native boots/70 captures plus sealed boot')
 # All acceptance preconditions above precede archive creation. Normalized tar
 # metadata/gzip header make repeat construction from identical inputs stable.
 items={}
 def add(name,path):
  path=Path(path);member=PurePosixPath(name);require(not member.is_absolute()and '..'not in member.parts and name not in items,'unsafe/duplicate archive member')
  require(path.is_file()and not path.is_symlink()and path.suffix!='.img',(name,path));items[name]=path
 def tree(prefix,folder):
  folder=Path(folder);require(folder.is_dir(),folder)
  for path in sorted(folder.rglob('*')):
   if path.is_file()and path.suffix!='.img'and '__pycache__'not in path.parts:add(prefix+'/'+str(path.relative_to(folder)),path)
 for name,folder in [('frozen',F),('sealed-build',T/(P+'-build')),('host',T/(P+'-frozen-host')),('scalar',T/(P+'-scalar'))]:tree('qualified/'+name,folder)
 for name,out in outdirs.items():tree('qualified/native/'+name,out)
 diagnostic_names={Path(name).name for name in UNQUALIFIED_DIAGNOSTIC_SHA256}
 for path in sorted(T.glob(P+'-*')):
  if path.is_file()and path.suffix in('.json','.log','.py','.sh','.txt')and path!=receipt_path and not(path.name.startswith(P+'-package')and path.suffix=='.log'):
   prefix='UNQUALIFIED/preflight'if path.name in diagnostic_names or 'preflight'in path.name else'coordination'
   add(prefix+'/'+path.name,path)
 for path in EXECUTED_HELPER_SHA256:add('executed-helpers/'+Path(path).name,path)
 for path in UNQUALIFIED_DIAGNOSTIC_SHA256:
  relative=Path(path).resolve().relative_to(T.resolve());add('UNQUALIFIED/current-attempts/'+str(relative),path)
 for path in replays:add('fresh-checks/'+path.name,path)
 add('reference/R169-source-binding.json',baseline_path)
 for name in ('result.json','sexdisplay.elf','sexdisplay.asm'):add('reference/R169-budget-only/'+name,T/'sexos-completion-custody-c-scalar'/name)
 require(sha(audit['reference']['path'])==audit['reference']['sha256'],'original authority reference changed');add('reference/original-authority.serial.log',audit['reference']['path'])
 summary=dict(ok=True,round=170,source_commit=COMMIT,source_binding_sha256=sha(F/'source-binding.json'),iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],host=dict(registered=PINS['host_checks'],rust_log_test_executions=rust,python_tests=PINS['python_tests'],scene=scene,bitmap=bitmap,bitmap_binding=binding,text_stage_cases=24,bitmap_stage_cases=22,frame_output=frames,cursor=dict(zip(('actual_cases','compiled_runtime_mutants','source_controls'),PINS['cursor_controls'])),compositor_cases=PINS['compositor_cases'],browser_viewport=dict(cases=21,compiled_controls=3,source_controls=2)),source=dict(files=PINS['source_files'],bytes=PINS['source_bytes']),scalar=dict(elfs=9,instructions=PINS['scalar_instructions'],vector_fp_matches=0),budget=budget,production_comparison=comparison,native=dict(boots=11,sealed_build_boots=1,native_boots=10,clock_boots=4,connected_boots=4,browser_boots=2,capture_counts=capture_counts,qualified_captures=70,proofs=proofs,alpha_acceptance=False,sustained_acceptance=False,complete_all_app_reserves=False),boot_observations=audit['observations'],typed_release_witness=typed_witness,obligations=obligations,system_proven=False,executed_helpers=EXECUTED_HELPER_SHA256,diagnostics=dict(pinned_unqualified=UNQUALIFIED_DIAGNOSTIC_SHA256),frame_storage=dict(scene_static_bytes=PINS['static_objects']['RENDER_SCENE'],frame_store_static_bytes=PINS['static_objects']['FRAME_OUTPUT'],physical_buddy_bytes_per_boot=8388608,authority='PD-held Region54/55; all tasks in Display PD share authority'),scope='Sealed typed text is projected into an owned scene candidate without mutating canonical Surface text. Successful Full CPU publication and SceneLease drop precede canonical application and exact captured-context release; mixed legacy text writes are denied while that candidate is unreleased. Other producer intake remains mutable, Context is not reset-unique authority, and Dirty is not a causal input stream. Display-owned private preparation and complete checked CPU publication with scoped scene release; not hardware latch/vblank, complete epochs or deterministic replay. Native evidence: clock/date, representative connected session/cold recovery, and Browser15→30→31 quiesced Close/panel/exhaustion controls. No Alpha/1800-second, full all-app reserve chain, performance speedup, hardware/SMP/hostile isolation, exact-task isolation or physical erasure claim. Region54/55 authority is PD-held; no new capkind, runtime mint or kernel allocation policy. Stack measurements cover explicit prologues only; app pages and Display backing are not additive disjoint memory totals. Earlier images transfer no native acceptance.')
 # Recheck source/image and audited raw logs after the read-only replays,
 # before constructing any archive. Archive reopen also checks every member.
 require(sha(F/'tested.iso')==b['iso_sha256']==PINS['iso_sha256']and sha(F/'tested.kernel')==b['kernel_sha256'],'image changed during replay')
 require(read(F/'source-binding.json')==b and sha(baseline_path)==BASELINE_BINDING_SHA256,'source bindings changed during replay')
 for name,digest in closure.items():require(sha(R/name)==digest,('source changed during replay',name))
 for o in audit['observations']:require(sha(o['path'])==o['sha256']and Path(o['path']).stat().st_size==o['bytes'],'audited serial changed during replay')
 for path,digest in {**EXECUTED_HELPER_SHA256,**UNQUALIFIED_DIAGNOSTIC_SHA256}.items():require(sha(path)==digest,('pinned evidence changed during replay',path))
 manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path))for name,path in items.items()}
 embedded={**memory_receipts,'COHORT.json':(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode(),'SCOPE.md':b'Round170: eleven explicit boots and seventy captures only after fresh frozen replay. Open2/Partial28. R169 binding/Display ELF references support source/kernel/budget comparison, not acceptance transfer. Kernel and ABI unchanged; current native image must qualify independently. Failed Round170 candidates A and B are explicitly retained under UNQUALIFIED; only current C qualifies. Earlier rounds transfer no native acceptance. Typed text candidate projection and matched canonical settlement are a bounded service boundary, not visible-pixel or hardware-latch evidence; other intake remains mutable and Context is not reset-unique authority. Dirty remains output obligations, not causal input capture. Intake remains mutable; no whole-system epoch or replay completion. Two private frames remain held by the Display PD, not isolated per task. Complete CPU copy is not a hardware flip/latch. No Alpha/1800s/performance/hardware/full-epoch claim.\n'}
 for name,data in embedded.items():require(name not in manifest,'embedded member collision');manifest[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
 with archive.open('xb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9)as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT)as tar:
  for name in sorted(set(items)|set(embedded)|{'MANIFEST.json'}):
   info=tarfile.TarInfo(name);info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
   if name in items:
    info.size=manifest[name]['bytes']
    with items[name].open('rb')as stream:tar.addfile(info,stream)
   else:payload=data if name=='MANIFEST.json'else embedded[name];info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();require(len(members)==len(manifest)+1 and all(m.isfile()for m in members),'archive member count/type')
  require({m.name for m in members}==set(manifest)|{'MANIFEST.json'},'exact archive names');require(tar.extractfile('MANIFEST.json').read()==data,'manifest reopen')
  for name,meta in manifest.items():
   payload=tar.extractfile(name).read();require(len(payload)==meta['bytes']and hashlib.sha256(payload).hexdigest()==meta['sha256'],('archive member changed',name))
 for name,path in items.items():require(path.stat().st_size==manifest[name]['bytes']and sha(path)==manifest[name]['sha256'],('input changed during packaging',name))
 receipt=dict(ok=True,archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_reopened_verified=True,cohort=summary)
 with receipt_path.open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
