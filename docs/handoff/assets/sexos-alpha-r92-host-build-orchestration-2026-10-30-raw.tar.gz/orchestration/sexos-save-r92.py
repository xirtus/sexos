"""Prepared round92 single-cohort archive. Execute only after root confirms closure.
No build, test suite, native workflow, staging or commit is launched here.
"""
from pathlib import Path
import hashlib,json,re,os,shutil,subprocess,tarfile
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Users/xmacbookm5/Projects/Sex');ASSETS=ROOT/'docs/handoff/assets';LOCAL=ROOT/'.evidence/alpha-2026-10-29/r92'
FROZEN=Path('/tmp/sexos-alpha-r92-frozen');BUILD=Path('/tmp/sexos-alpha-r92-build');HOST=Path('/tmp/sexos-alpha-r92-host')
PYTHON=Path('/tmp/sexos-r92-python-final.log')
ISO=json.loads((FROZEN/'source-binding.json').read_text())['iso_sha256']

def j(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as file:
  for part in iter(lambda:file.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def tree_files(path):
 path=Path(path);assert path.is_dir(),path
 for file in sorted(path.rglob('*')):
  # Compiler caches are unbound output, not evidence. Filter before checking
  # symlinks because Cargo caches contain symlinked dependency artifacts.
  if any(part in ('target','__pycache__')for part in file.relative_to(path).parts):continue
  assert not file.is_symlink(),file
  if file.is_file():yield file

def bound_snapshot():
 b=j(FROZEN/'source-binding.json');p=b['build_provenance']
 assert b['iso_sha256']==ISO==p['iso_sha256']==sha(FROZEN/'tested.iso')
 assert p['build_gate']=='PASS'and p['source_image_binding']=='sealed_build_this_run'and p['sources_unchanged_during_build']is True
 assert b['sources']==p['production_source_sha256']and len(b['sources'])==431 and len(b['runner_sha256'])==489
 assert sha(FROZEN/'tested.kernel')==b['kernel_sha256']
 for group in('sources','runner_sha256'):
  for name,digest in b[group].items():
   assert not any(part in ('target','__pycache__')for part in Path(name).parts),('boundcacheforbidden',group,name)
   assert sha(FROZEN/'source'/name)==digest,(group,name)
 build=(BUILD/'report.md').read_text();assert re.search(r'FINAL_SCORE[^\n]*GREEN_MASTER',build)and re.search(r'BUILD_GATE[^\n]*PASS',build)and 'probe_seconds: 25'in build
 assert j(BUILD/'provenance.json')['iso_sha256']==ISO
 return b,build

def raw_archive(label,roots):
 name=f'sexos-alpha-r92-{label}-2026-10-30-raw.tar.gz';target=ASSETS/name;members=[]
 with tarfile.open(target,'w:gz',compresslevel=9)as archive:
  for arcroot,source in roots:
   source=Path(source)
   if source.is_dir():files=[(arcroot+'/'+str(file.relative_to(source)),file)for file in tree_files(source)]
   else:assert source.is_file();files=[(arcroot,source)]
   for member,file in files:
    assert not file.is_symlink();digest=sha(file);archive.add(file,arcname=member,recursive=False)
    assert sha(file)==digest,('source changed during archive',file)
    members.append(dict(path=member,size=file.stat().st_size,sha256=digest))
 assert len({x['path']for x in members})==len(members)
 # Independently decompress every member immediately; no extraction, links or
 # path traversal. Inventory is compact metadata, not duplicated result JSON.
 expected={x['path']:x for x in members};seen=set()
 with tarfile.open(target,'r:gz')as archive:
  for member in archive:
   assert member.isfile()and member.name in expected and member.name not in seen
   h=hashlib.sha256();size=0;stream=archive.extractfile(member)
   for part in iter(lambda:stream.read(1024*1024),b''):h.update(part);size+=len(part)
   assert(size,h.hexdigest())==(expected[member.name]['size'],expected[member.name]['sha256']),member.name;seen.add(member.name)
 assert seen==set(expected)
 return dict(path=name,sha256=sha(target),compressed_bytes=target.stat().st_size,regular_members=len(members),uncompressed_bytes=sum(x['size']for x in members),members=members,decompression_verified=True)

def png(source,label,scope):
 source=Path(source);raw=source.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',raw);assert header,source
 dimensions=list(map(int,header.groups()));assert len(raw)-header.end()==dimensions[0]*dimensions[1]*3
 target=ASSETS/f'sexos-alpha-r92-{label}-2026-10-30.png';subprocess.run(['sips','-s','format','png',str(source),'--out',str(target)],check=True,stdout=subprocess.DEVNULL)
 data=target.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'and[int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')]==dimensions
 return dict(path=target.name,sha256=sha(target),source_ppm_sha256=sha(source),dimensions=dimensions,scope=scope)


def native_json_links(paths,archive):
 inventory={member['path']:member for member in archive['members']};links=[]
 def walk(value,trail=()):
  if isinstance(value,dict):
   for key,item in value.items():yield from walk(item,trail+(str(key),))
  elif isinstance(value,list):
   for index,item in enumerate(value):yield from walk(item,trail+(str(index),))
  elif isinstance(value,str):yield trail,value
 for name,directory in paths.items():
  for file in sorted(directory.glob('*.json')):
   for trail,value in walk(j(file)):
    target=Path(value)
    if target.is_absolute()or not value or target.suffix not in('.ppm','.json','.pcap','.img','.log'):continue
    candidate=(file.parent/target).resolve()
    if trail and trail[-1]=='screenshot':assert candidate.is_file(),('missing accepted screenshot',name,file,trail,value)
    if not candidate.is_file():continue
    assert candidate.is_relative_to(directory.resolve()),('relative native reference escapes acceptedrun',name,trail,value)
    relative=candidate.relative_to(directory.resolve());member='native/'+directory.name+'/'+str(relative)
    assert member in inventory and sha(candidate)==inventory[member]['sha256'],('native reference absent/wrong in archive',member)
    links.append(dict(source='native/'+directory.name+'/'+file.name,field='.'.join(trail),target=member,sha256=inventory[member]['sha256']))
 return dict(ok=True,count=len(links),links=links,scope='Every existing relative evidence-file reference in accepted native JSON joined to exact archived member; screenshots require a present local file.')

def archive():
 binding,build_report=bound_snapshot()
 # Joint binding checks cover every production input (including immutable
 # config), in addition to the architectural host gate's own source manifest.
 for group in ('sources','runner_sha256'):
  for name,digest in binding[group].items():assert sha(ROOT/name)==digest,(group,name)
 host=j(HOST/'report.json')
 assert host['checks_passed'] and host['sources_unchanged_during_checks'] and host['run_status']=='complete'
 assert len(host['checks'])==38 and all(r['exit_code']==0 for r in host['checks'])
 for name,digest in host['source_sha256'].items():assert sha(FROZEN/'source'/name)==digest
 rust=sum(int(n) for f in HOST.glob('*.log') for n in re.findall(r'test result: ok\. (\d+) passed',f.read_text(errors='replace')))
 assert rust==1556
 python_log=PYTHON.read_text();assert re.findall(r'^Ran (\d+) tests in ',python_log,re.M)==['512'] and python_log.rstrip().endswith('OK')
 assert list(host['obligations'].values()).count('open')==7 and list(host['obligations'].values()).count('partial')==23 and host['system_proven'] is False
 tls=j('/tmp/sexos-r92-tls-native-suite-progress.json');reg=j('/tmp/sexos-r92-regression-suite-progress.json');rows=tls+reg
 assert [r['name'] for r in tls]==['tls-'+mode+'-'+profile for mode in ('ready','close','unsupported','invalid-year') for profile in ('wide','compact')]
 assert [r['name'] for r in reg]==['chain-e1000e','stream-e1000','time-normal-wide','entropy-ready-compact','profile','compact','document-reboot','history-reboot','switch-wide','switch-compact']
 assert len(rows)==18 and all(r['status']==0 for r in rows)
 replay=j('/tmp/sexos-r92-tls-independent-replay.json');assert replay['ok'] and replay['runs']==8 and replay['source_binding_sha256']==sha(FROZEN/'source-binding.json')
 scalar=j('/tmp/sexos-r92-scalar-instructions.json');assert scalar['ok'] and scalar['iso_sha256']==ISO and scalar['elf_sha256']==sha('/tmp/sexos-r92-tested-kaleidoscope.elf') and scalar['disassembly_sha256']==sha('/tmp/sexos-r92-kaleidoscope.disassembly')
 paths={};summaries=[]
 for row in rows:
  name=row['name'];path=Path(row['out']);r=j(path/'result.json');m=j(path/'manifest.json');assert r['ok']
  assert m.get('iso_sha256',m.get('binding',{}).get('iso_sha256'))==ISO
  if 'binding' in m:assert m['binding']['sha256']==sha(FROZEN/'source-binding.json') and m['binding']['production_files']==431 and m['binding']['runner_files']==489
  for group in ('runner_sha256','pixel_source_sha256','authority_source_sha256'):
   for file,digest in m.get(group,{}).items():
    if group=='runner_sha256' and '/' not in file:file='scripts/'+file
    assert sha(FROZEN/'source'/file)==digest
  trace=(path/'serial.log').read_text(errors='replace');assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[sexfiles.defer.drop\]',trace)
  for check in ('check_nic_command.json','check_self_wait.json','check_document_views.json','check_document_snapshots.json'):
   if (path/check).exists():assert j(path/check)['ok']
  summary=dict(name=name,result_ok=True,mode=m.get('mode'),model=m.get('model'),resolution=m.get('resolution',r.get('resolution')),manifest='native/'+path.name+'/manifest.json',result='native/'+path.name+'/result.json',serial='native/'+path.name+'/serial.log',disk='native/'+path.name+'/nvme.img')
  if name.startswith('tls-'):
   assert all(r[k]['ok'] for k in ('tls','public_wire','owner_packet_joins','authority','self_wait'));summary['tls']=r['tls']
  if name in ('profile','compact'):summary['private_pages']=sum(int(n) for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace))
  if name.startswith('switch-'):assert r['switch_cycles']==10 and len(r['switches'])==40 and r['pixel_errors']==[];summary['switches']=40
  summaries.append(summary);paths[name]=path
 pages={s['name']:s['private_pages'] for s in summaries if 'private_pages' in s};switches={s['name']:s['switches'] for s in summaries if 'switches' in s};assert sum(switches.values())==80
 ASSETS.mkdir(parents=True,exist_ok=True);LOCAL.mkdir(parents=True,exist_ok=True)
 archives={'frozen':raw_archive('frozen',[('frozen',FROZEN)]),'native':raw_archive('native',[('native/'+p.name,p) for p in paths.values()])}
 drivers=sorted(p for p in (set(Path('/tmp').glob('sexos-r92*driver.log'))|{PYTHON}) if 'archive-driver' not in p.name)
 orchestration=[p for p in Path('/tmp').glob('sexos*r92*') if p.is_file() and p not in drivers and p.suffix in ('.py','.json','.log','.disassembly','.elf')]
 archives['host_build_orchestration']=raw_archive('host-build-orchestration',[('host',HOST),('build',BUILD)]+[('orchestration/'+p.name,p) for p in sorted(orchestration)]+[('drivers/'+p.name,p) for p in drivers])
 links=native_json_links(paths,archives['native'])
 selections=[('tls-ready-wide','tls-first.ppm','tls-hello-wide','Fresh held profile and public fixture check before private ClientHello; no peer.'),('tls-ready-compact','tls-first.ppm','tls-hello-compact','Actual1024x768 complete preparation status.'),('tls-ready-wide','tls-cleared.ppm','tls-cleared-wide','Actual Q erases19256 owned future and queue bytes.'),('tls-ready-compact','tls-cleared.ppm','tls-cleared-compact','Compact Q full glyph and trailing erasure.'),('tls-unsupported-wide','tls-first.ppm','tls-entropy-unavailable','Disabled entropy profile cannot prepare TLS despite valid trust policy.'),('tls-invalid-year-compact','tls-first.ppm','tls-utc-unavailable-compact','Invalid1999 UTC cannot prepare TLS.'),('tls-close-wide','tls-before-close.ppm','tls-allocated-before-close','Allocated HelloPending before real Close; no peer.'),('tls-close-compact','tls-closed.ppm','tls-after-close-compact','Actual framebuffer after allocated pending Close and116 private-page return.')]
 images={label:png(paths[run]/file,label,scope) for run,file,label,scope in selections}
 evidence=dict(round=92,scope='BOOT-held immutable controlled trust profile and strict bounded P256 chain/name/time/CertificateVerify validation. Public fixture self-check before private ClientHello; no peer, wire or public Internet trust.',iso_sha256=ISO,kernel_sha256=binding['kernel_sha256'],source_binding_sha256=sha(FROZEN/'source-binding.json'),source_counts=dict(production=431,runners=489),source_binding_member='frozen/source-binding.json',host=dict(gates=38,rust_executions=rust,python_tests=512,report_member='host/report.json',source_binding_sha256=sha(FROZEN/'source-binding.json')),native=dict(count=18,source_binding_sha256=sha(FROZEN/'source-binding.json'),runs=summaries),tls_independent_frozen_replay=replay,native_json_references=links,archives=archives,selected_images=images,private_pages=pages,ordinary_switches=switches,ordinary_switches_total=80,instruction_scope=scalar,acceptance_status=dict(open=7,partial=23,system_proven=False),joint_binding=dict(all_production_and_runner_bytes_match_frozen_and_working_tree=True,scope='Includes new immutable trust config in full sealed431-input production binding; architectural host report separately binds its own selected source set.'),excluded_unbound_caches=dict(relative_directory_components=['target','__pycache__'],before_symlink_checks=True,bound_sources_or_runners_excluded=False),candidate_failures=[dict(scope='Unfrozen preflight ran during metadata-fixture checker edits;507tests/onefailure. Retained diagnostic, final frozen512pass is authoritative.',archive_member='orchestration/sexos-r92-python-preflight.log'),dict(scope='Initial verifier compile lifetime error, then intermediate fixture missing strict serverAuth EKU; fixed without relaxing policy, frozen host tests pass.',archive_member='orchestration/sexos-r92-intermediate-diagnostic.log')],limits=['No real peer/TLS wire, public CA or Internet trust, revocation, RNG/RTC authenticity, own sustained latest-image, hostile containment, physical hardware, SMP or full replay proof.','Lab root/server keys are deliberately public small-scalar test fixtures; never production credentials.','All upstream completions remain unpublished/rejected; empty decrypted plaintext upstream panic must be patched and adversarially tested before real ingress93.','Owned future plus queue erasure excludes public Pipe metadata and stack/register/cache copies.'])
 target=ASSETS/'sexos-alpha-r92-2026-10-30-evidence.json';target.write_text(json.dumps(evidence,indent=2)+'\n')
 for artifact in archives.values():shutil.copyfile(ASSETS/artifact['path'],LOCAL/artifact['path'])
 shutil.copyfile(target,LOCAL/target.name)
 print(json.dumps(dict(evidence=str(target),evidence_sha256=sha(target),archives=3,pngs=8,raw_members=sum(a['regular_members'] for a in archives.values()),compressed_bytes=sum(a['compressed_bytes'] for a in archives.values()),native=18,host_gates=38,rust_executions=rust,python_tests=512,private_pages=pages,switches=80)))

if __name__=='__main__':archive()

