//! Shared native text metrics and focus ink; integer pixels only.
pub const INSET: u32 = 8;
pub const TEXT_TOP: u32 = 12;
pub const ASCII_FIRST: u8 = 32;
pub const ASCII_LAST: u8 = 126;
pub const GLYPH_WIDTH: u32 = 5;
pub const GLYPH_HEIGHT: u32 = 7;
pub const ADVANCE: u32 = 6;
pub const LINE: u32 = 9;
pub const TEXT: u32 = 0x00E0F0FF;
pub const FOCUS: u32 = 0x00E9D36A;
pub const fn scale(width: u32) -> u32 {
    if width >= 256 {
        2
    } else {
        1
    }
}

/// Visual family classification only. Callers must independently attest live
/// ownership before accepting any surface operation or routing input.
pub const fn native_label(surface:u64)->Option<&'static str>{
    match surface {
        156|201|301|307=>Some("Quil"),
        153|154|160|161|162|302|303|304|305|306=>Some("Spindle"),
        200=>Some("Linen"),300=>Some("Browser"),_=>None,
    }
}
pub const fn native_indicator(surface:u64)->Option<u32>{
    match surface {
        156|201|301|307=>Some(0x00CBA6F7),
        153|154|160|161|162|302|303|304|305|306=>Some(0x0089B4FA),
        200=>Some(0x00A6E3A1),300=>Some(0x005ED9C3),_=>None,
    }
}
pub const NATIVE_CANVAS:u32=0x000C1420;
/// A family ID or hardware key does not establish this exact BOOT ownership.
pub const fn native_canvas(owner:u32,surface:u64)->Option<u32>{
    // Every Quil and Spindle content surface; Browser paints its own canvas.
    if crate::app_catalog::native_pixel_bit(owner,surface)!=0&&!crate::app_catalog::is_browser(owner){Some(NATIVE_CANVAS)}else{None}
}

// IEC sRGB transfer function sampled at every 8-bit channel, rounded to
// millionths of linear light. A fixed table keeps guest drawing integer-only.
const LINEAR_SRGB: [u32; 256] = [
    0, 304, 607, 911, 1214, 1518, 1821, 2125,
    2428, 2732, 3035, 3347, 3677, 4025, 4391, 4777,
    5182, 5605, 6049, 6512, 6995, 7499, 8023, 8568,
    9134, 9721, 10330, 10960, 11612, 12286, 12983, 13702,
    14444, 15209, 15996, 16807, 17642, 18500, 19382, 20289,
    21219, 22174, 23153, 24158, 25187, 26241, 27321, 28426,
    29557, 30713, 31896, 33105, 34340, 35601, 36889, 38204,
    39546, 40915, 42311, 43735, 45186, 46665, 48172, 49707,
    51269, 52861, 54480, 56128, 57805, 59511, 61246, 63010,
    64803, 66626, 68478, 70360, 72272, 74214, 76185, 78187,
    80220, 82283, 84376, 86500, 88656, 90842, 93059, 95307,
    97587, 99899, 102242, 104616, 107023, 109462, 111932, 114435,
    116971, 119538, 122139, 124772, 127438, 130136, 132868, 135633,
    138432, 141263, 144128, 147027, 149960, 152926, 155926, 158961,
    162029, 165132, 168269, 171441, 174647, 177888, 181164, 184475,
    187821, 191202, 194618, 198069, 201556, 205079, 208637, 212231,
    215861, 219526, 223228, 226966, 230740, 234551, 238398, 242281,
    246201, 250158, 254152, 258183, 262251, 266356, 270498, 274677,
    278894, 283149, 287441, 291771, 296138, 300544, 304987, 309469,
    313989, 318547, 323143, 327778, 332452, 337164, 341914, 346704,
    351533, 356400, 361307, 366253, 371238, 376262, 381326, 386429,
    391572, 396755, 401978, 407240, 412543, 417885, 423268, 428690,
    434154, 439657, 445201, 450786, 456411, 462077, 467784, 473531,
    479320, 485150, 491021, 496933, 502886, 508881, 514918, 520996,
    527115, 533276, 539479, 545724, 552011, 558340, 564712, 571125,
    577580, 584078, 590619, 597202, 603827, 610496, 617207, 623960,
    630757, 637597, 644480, 651406, 658375, 665387, 672443, 679542,
    686685, 693872, 701102, 708376, 715694, 723055, 730461, 737910,
    745404, 752942, 760525, 768151, 775822, 783538, 791298, 799103,
    806952, 814847, 822786, 830770, 838799, 846873, 854993, 863157,
    871367, 879622, 887923, 896269, 904661, 913099, 921582, 930111,
    938686, 947307, 955973, 964686, 973445, 982251, 991102, 1000000,
];

/// WCAG relative luminance in millionths; XRGB's unused high byte is ignored.
pub const fn relative_luminance(color: u32) -> u32 {
    (((LINEAR_SRGB[((color >> 16) & 255) as usize] as u64) * 2126
        + (LINEAR_SRGB[((color >> 8) & 255) as usize] as u64) * 7152
        + (LINEAR_SRGB[(color & 255) as usize] as u64) * 722) / 10_000) as u32
}

/// Select the stronger black/white contrast against the actual composed pixel.
/// Comparing ratios by cross multiplication avoids division and guest floats.
/// The better of black and white has contrast at least sqrt(21), above 4.5:1;
/// table rounding is under two millionths of relative luminance.
pub const fn contrast_ink(background: u32) -> u32 {
    let light = relative_luminance(background) as u64 + 50_000;
    if light * light >= 1_050_000 * 50_000 { 0x000000 } else { 0xFFFFFF }
}
