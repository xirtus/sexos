from pathlib import Path
import hashlib,io,json,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-capacity-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');source=read(T/'sexos-capacity-a-source-audit.json');boot=read(T/'sexos-capacity-a-boot-audit.json');assert source['ok']and source['unchanged_boot_authority_records']==63 and boot['ok']and boot['boots']==7
h=read(T/'sexos-capacity-a-host/report.json');assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
assert 'Ran 965 tests in 'in(T/'sexos-capacity-a-python.log').read_text()
groups={s:read(T/('sexos-capacity-a-'+s+'-progress.json'))for s in ['native','alpha']};assert all(row['status']==0 for rows in groups.values()for row in rows);assert sum(row['verified_captures']for rows in groups.values()for row in rows)==76
for label in ['compact','wide']:
 for stem in ['connected','alpha']:
  v=read(T/('sexos-capacity-a-'+stem+'-'+label+'-independent-replay.json'));assert v['ok']
scalar=read(T/'sexos-capacity-a-scalar-v2/result.json');assert scalar['ok']and all(not r['vector_or_fp_matches']for r in scalar['results'])
for name in ['views','nic','self-wait']:assert read(T/('sexos-capacity-a-'+name+'.log'))['ok']
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,path in [('frozen',F),('sealed-build',T/'sexos-capacity-a-build'),('host',T/'sexos-capacity-a-host'),('scalar',T/'sexos-capacity-a-scalar-v2')]:tree(prefix,path)
for group,rows in groups.items():
 for row in rows:tree('native/'+group+'/'+Path(row['out']).name,row['out'])
for p in sorted(T.glob('sexos-capacity-a-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
add('comparison/prior-integrated-serial.log',T/'sexos-catalog-integration-build-c/serial.log');add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-catalog-capacity-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
result=dict(round=134,qualified_capacity_preparation=True,larger_actual_reserve=False,full_os_goal_complete=False,source_commit=source['commit'],iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),committed_input_audit=source,registered_host_checks=43,rust_test_executions=2663,python_tests=965,capacity_controls=dict(compiled_rows=[7,64],compile_rejected_rows=[65],actual_boot_incarnations=6,current_authority_records_unchanged=63,presentation_bits=64,document_legacy_region_ids=[6,7,8],further_document_region_base=8192),native=dict(workflow_boots=6,sealed_probe_boots=1,total_boots=7,verified_captures=76,groups=groups,boot_audit=boot,fresh_connected_and_alpha_replays=True,sustained_acceptance=False),scalar=dict(elfs=5,instructions=sum(row['instructions']for row in scalar['results']),inspected_vector_fp_matches=0),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Shared catalog-derived capacity, bounded presentation bits and future document namespace. Production BOOT authority unchanged; actual larger reserve/Browser successors, new-image pending-device/1800s, physical/SMP/hostile containment/global epoch and daily-driver acceptance remain outside this result.')
p=A/'sexos-catalog-capacity-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('CAPACITY_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
