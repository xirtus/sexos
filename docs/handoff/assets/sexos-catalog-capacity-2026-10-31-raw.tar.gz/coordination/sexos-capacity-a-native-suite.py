from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');F=T/'sexos-capacity-a-frozen';R=F/'source';rows=[];progress=T/'sexos-capacity-a-native-progress.json';assert not progress.exists()
for label,model,resolution in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 out=T/('sexos-capacity-a-connected-'+label);driver=T/(out.name+'-driver.log');assert not out.exists()and not driver.exists()
 cmd=['python3',str(R/'scripts/connected_desktop_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',resolution]
 row=dict(profile=label,status='running',command=cmd,out=str(out),driver=str(driver));rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');print('START connected',label,flush=True);start=time.monotonic()
 with driver.open('x')as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=p.returncode,seconds=time.monotonic()-start);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END connected',label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 r=json.loads((out/'result.json').read_text());assert r['ok']and r['boots']==2 and r['frames']==17;row.update(boots=2,verified_captures=17);progress.write_text(json.dumps(rows,indent=2)+'\n')
with (T/'sexos-capacity-a-alpha-suite-driver.log').open('x')as f:p=subprocess.run(['python3',str(T/'sexos-capacity-a-alpha-suite.py')],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
assert p.returncode==0
print('FOUR_CONNECTED_TWO_ALPHA_BOOTS_PASS',flush=True)
