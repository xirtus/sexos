#!/usr/bin/env python3
"""Round165 eleven-boot clock/date inventory audit; strict BOOT metadata only, not date pixels, authenticated time or sustained acceptance."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys
sys.dont_write_bytecode = True
T = Path('/tmp')
F = T / 'sexos-display-frames-a-frozen'
R = F / 'source'
sys.path.insert(0, str(R / 'scripts'))
from history_roster_evidence import verify_boot_roster, source_spindles
from quil_reserve_catalog import quil_catalog
from https_document_gate import source_inventory
from browser_source_evidence import records, exact, number

REVISION = '0c185625b086f6843e19d1c5de8c47d4c0a4e505'
TAGS = ('boot.entropy.source', 'boot.clock.source', 'boot.trust.policy',
        'boot.silkbar.clock.source', 'boot.network.tls')
EXPECTED_TARGETS = [9, 12, 15, *range(16, 41)]
EXPECTED_QUILS = [9, 16, 18, 19, 20, 21, 22, 23, 32, 33, 34, 35, 36, 37, 38, 39]
EXPECTED_SPINDLES = [12, 17, 24, 25, 26, 27, 28, 29, 40]
REFERENCE = T / 'sexos-bitmap-stores-a-build/serial.log'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def one(text, tag, expected):
    found = records(text, tag)
    assert len(found) == 1, (tag, 'missing/duplicate')
    exact(found[0][1], expected)
    return found[0][0]


def authority_lines(data):
    prefixes = tuple(('[' + tag + ']').encode() for tag in TAGS)
    return [line for line in data.splitlines(keepends=True) if line.startswith(prefixes)]


def original_subsequence(lines):
    return [line for line in lines if line.startswith(b'[boot.silkbar.clock.source]')
            or re.search(rb'\bconsumer=15\b', line)]


def binding_check():
    assert re.fullmatch(r'[0-9a-f]{40}', REVISION), 'Root must pin final integration commit before qualification'
    binding = json.loads((F / 'source-binding.json').read_text())
    assert binding['build_provenance']['git_revision'] == REVISION
    assert binding['build_provenance']['build_gate'] == 'PASS'
    assert digest((F / 'tested.iso').read_bytes()) == binding['iso_sha256']
    assert digest((F / 'tested.kernel').read_bytes()) == binding['kernel_sha256']
    closure = {**binding['sources'], **binding['runner_sha256']}
    used = ['kernel/src/init.rs', 'kernel/src/app_resources.rs', 'kernel/src/app_catalog_state.rs',
            'apps/kaleidoscope/src/main.rs', 'crates/sex-pdx/src/app_catalog.rs',
            'crates/sex-pdx/src/browser_sources.rs', 'scripts/browser_source_evidence.py',
            'scripts/history_roster_evidence.py', 'scripts/quil_reserve_catalog.py',
            'scripts/https_document_gate.py', 'servers/silk-shell/src/main.rs', 'servers/sexnet/src/main.rs',
            'servers/sexnet/src/source_denial.rs', 'kernel/src/lib.rs', 'kernel/src/self_wait.rs',
            'kernel/src/app_resource_state.rs', 'crates/sex-pdx/src/history_recovery.rs']
    # Verify every frozen production/runner entry, including transitive imports.
    for name, expected in closure.items():
        path = (R / name).resolve()
        assert path.is_relative_to(R.resolve()), ('source escaped frozen root', name)
        assert digest(path.read_bytes()) == expected, ('frozen closure changed', name)
    checked = {}
    for name in used:
        value = digest((R / name).read_bytes())
        assert value == closure[name], ('frozen source changed', name)
        checked[name] = value
    init = (R / 'kernel/src/init.rs').read_text()
    assert init.index('crate::app_resources::audit_boot_catalog(silkshell_id);') < init.index('crate::boot_memory::seal_all();')
    assert 'grant_capability(' not in init.split('crate::boot_memory::seal_all();', 1)[1]
    compact = re.sub(r'\s+', '', init)
    heap_code = 'let(heap_bytes,heap_used,heap_free)={letheap=crate::ALLOCATOR.lock();(heap.size(),heap.used(),heap.free())};'
    assert compact.count(heap_code) == 1
    heap_index = compact.index(heap_code)
    assert compact.index('crate::boot_memory::seal_all();') < heap_index < compact.index('serial_println!("[boot.heap.budget]')
    assert re.search(r'pub const HEAP_SIZE: usize = 256 \* 1024 \* 1024;', (R/'kernel/src/lib.rs').read_text())
    assert 'pub const MAX_PAGES:usize=512;' in (R/'kernel/src/app_resource_state.rs').read_text()
    assert re.search(r'pub const BOOT_MAIN_CAPACITY:\s*usize\s*=\s*64;', (R/'kernel/src/self_wait.rs').read_text())
    denial = (R/'servers/sexnet/src/source_denial.rs').read_text()
    assert 'pub const OWNERS_PER_KIND: usize = sex_pdx::app_catalog::COUNT;' in denial
    assert 'pub const TOTAL_SLOTS: usize = 3 * OWNERS_PER_KIND;' in denial
    net = re.sub(r'\s+', '', (R/'servers/sexnet/src/main.rs').read_text())
    assert 'letdenial_bytes=core::mem::size_of::<source_denial::Outbox>();' in net
    assert 'assert!(denial_bytes<4096,"SOURCE_DENIAL_STORAGE_BUDGET");' in net
    app = (R / 'apps/kaleidoscope/src/main.rs').read_text()
    assert app.count('if selected.is_original() { paging_probe::run(); }') == 1
    assert app.count('#[cfg(app_resource_cleanup_proof)]\n        if selected.is_original(){full_resource_cleanup_proof();}') == 1
    shell = (R / 'servers/silk-shell/src/main.rs').read_text()
    initial = re.search(r'^const BOOT_LIFECYCLE_SURFACES: \[\(u64, LifecycleState\); 17\] = \[(.*?)^\];', shell, re.M | re.S)
    assert initial is not None
    names = re.findall(r'\((SURFACE_ID_\w+), LifecycleState::\w+\)', initial[1])
    values = []
    for name in names:
        literal = re.findall(r'^(?:pub )?const ' + name + r': u64 = (0x[0-9a-fA-F]+|\d+);', shell, re.M)
        assert len(literal) == 1, ('nonliteral initial lifecycle SID', name)
        values.append(int(literal[0], 0))
    assert values == [100,101,102,103,200,201,202,203,204,153,144,146,147,148,149,150,151]
    count_fn = re.search(r'^const fn native_lifecycle_surface_count\(\) -> usize \{.*?^\}', shell, re.M | re.S)
    assert count_fn is not None
    assert re.sub(r'\s+', '', count_fn[0]) == 'constfnnative_lifecycle_surface_count()->usize{letmutcount=0;letmutindex=0;whileindex<app_catalog::COUNT{letrow=&app_catalog::INCARNATIONS[index];ifrow.ordinal>0||matches!(row.app,app_catalog::App::Browser){count+=1;}index+=1;}count}'
    assert 'const LIFECYCLE_MAX_SURFACES: usize = BOOT_LIFECYCLE_SURFACES.len() + native_lifecycle_surface_count();' in shell
    later = sorted([r['frame'] for r in quil_catalog(R) if r['ordinal'] > 0]
                   + [r['frame'] for r in source_spindles(R) if r['ordinal'] > 0] + [300,343,344])
    assert later == [300,301,306,307,308,309,310,311,312,314,319,324,329,334,339,343,344,345,346,347,348,349,350,351,352,354]
    assert len(set(values + later)) == 43
    return dict(revision=REVISION, retained_shell_metadata_source_bound=43, later_shell_frames=26, frozen_closure_entries=len(closure), iso_sha256=binding['iso_sha256'], kernel_sha256=binding['kernel_sha256'],
                binding_sha256=digest((F / 'source-binding.json').read_bytes()), source_sha256=checked)


def inspect_prior_contract(path, reference):
    data = path.read_bytes()
    text = data.decode(errors='replace')
    history = verify_boot_roster(R, text)
    quils = quil_catalog(R)
    spindles = source_spindles(R)
    assert [row['target'] for row in quils] == EXPECTED_QUILS
    assert [row['target'] for row in spindles] == EXPECTED_SPINDLES
    inventory, plans = source_inventory(text, root=R, require_version=True)
    assert [plan.target for plan in plans] == [15, 30, 31]
    assert inventory['trust_version_observed'] is True
    catalog = records(text, 'boot.app.catalog')
    assert [number(row, 'target', 2**32 - 1) for _, row in catalog] == EXPECTED_TARGETS
    by_target = {number(row, 'target'): row for _, row in catalog}
    tasks = {target: number(row, 'task', 2**32 - 1) for target, row in by_target.items()}
    assert all(tasks.values()) and len(set(tasks.values())) == 28
    # The legacy verify_boot_quil helper assumes task==PD. Join the observed
    # tasks instead; only source-owned PD/layout/lineage/slot data are expected.
    for family in (quils, spindles):
        for index, row in enumerate(family):
            target = row['target']
            exact(by_target[target], dict(target=target, task=tasks[target], surface=row['surface'],
                  logical=family[0]['target'], incarnation=index + 1,
                  predecessor=family[index - 1]['target'] if index else 0,
                  lifecycle=row['lifecycle'], close=row['close'], route=row['route'],
                  dormant=int(index != 0), grants_verified=1, data_only=1))
    assert history['participants'] == [dict(target=target, task=tasks[target]) for target in EXPECTED_SPINDLES]
    complete = one(text, 'boot.app.catalog.complete', dict(rows=28, actual_grants=1, runtime_mint=0))
    seal = one(text, 'boot.memory.authority.sealed', dict(runtime_alloc=0, runtime_map='capability_leaf', runtime_mint=0))
    wait = one(text, 'boot.self_wait.sealed', dict(tasks=40, capacity=64, max_ticks=64, runtime_registration=0))
    assert complete < wait < seal
    heaps = records(text, 'boot.heap.budget')
    assert len(heaps) == 1
    heap_at, heap = heaps[0]
    heap_bytes, heap_used, heap_free = [number(heap, key) for key in ('bytes','used','free')]
    assert heap_bytes == 256 * 1024 * 1024 and 0 < heap_used < heap_bytes
    assert heap_used + heap_free == heap_bytes
    exact(heap, dict(bytes=heap_bytes, used=heap_used, free=heap_free, apps=28,
                    point='after_grant_seal', allocator_lock_released=1, physical_free_frames='unmeasured'))
    # Handoff has a distinct producer schema: silk-shell includes a hyphen.
    # Keep Browser authority-field parsing strict; match every reserved marker,
    # the complete newline-terminated record, and exact source-named identities.
    handoffs = list(re.finditer(r'\[bootgraph\.boot\.handoff\] target=([A-Za-z0-9_-]+) id=([1-9][0-9]*) entry=0x([0-9a-f]+)\r?\n', text))
    assert len(handoffs) == text.count('[bootgraph.boot.handoff]') == 15
    handoff_names = ['sexdisplay','sexdrive','silk-shell','sexinput','sexusb',
                     'silkbar','linen','sexstore','quil','sexbell','sexfiles',
                     'spindle','sexnet','sext','kaleidoscope']
    assert [(m[1],int(m[2])) for m in handoffs] == list(zip(handoff_names,range(1,16)))
    assert all(0 < int(m[3],16) < 2**64 for m in handoffs)
    assert seal < heap_at < handoffs[0].start()
    denial_at = one(text, 'net.source.denial.storage',dict(bytes=1352,owners=28,slots=84,bound=4096,public=1))
    assert denial_at > seal
    main_records = list(re.finditer(r'pd: main_task registered pd_id=([0-9]+) \(not enqueued yet\)\r?$', text, re.M))
    assert len(main_records) == text.count('pd: main_task registered pd_id=') == 40
    assert [int(row[1]) for row in main_records] == list(range(1, 41))
    assert max(row.start() for row in main_records) < complete
    layout = one(text, 'boot.history.layout', dict(grant_bytes=96, capability_data_bytes=128,
                 capability_bytes=192, participants=9, bounded=1))
    assert layout < complete
    resources = records(text, 'boot.app.resources')
    assert [number(row, 'target') for _, row in resources] == EXPECTED_TARGETS
    pages = {}
    for at, row in resources:
        target = number(row, 'target')
        count = number(row, 'private_pages')
        assert 0 < count <= 512 and at < complete
        pages[target] = count
        exact(row, dict(target=target, task=tasks[target], surface=number(by_target[target], 'surface'),
              slot=number(by_target[target], 'lifecycle'), private_pages=count, private_bytes=count * 4096,
              required=31, pager=14, coordinator=3, metadata='retained'))
    family_totals = {}
    for name, targets in [('Quil',EXPECTED_QUILS), ('Spindle',EXPECTED_SPINDLES), ('Browser',[15,30,31])]:
        family_pages = sum(pages[target] for target in targets)
        family_totals[name] = dict(apps=len(targets), pages=family_pages, bytes=family_pages*4096)
    private_total = sum(pages.values())
    assert sum(f['apps'] for f in family_totals.values()) == 28
    assert sum(f['pages'] for f in family_totals.values()) == private_total == 2465
    assert family_totals == dict(Quil=dict(apps=16,pages=1136,bytes=4653056),
                                Spindle=dict(apps=9,pages=864,bytes=3538944),
                                Browser=dict(apps=3,pages=465,bytes=1904640))
    successors = records(text, 'boot.app.successor')
    assert [number(row, 'successor') for _, row in successors] == list(range(16, 41))
    for at, row in successors:
        target = number(row, 'successor')
        observed = by_target[target]
        exact(row, dict(logical=number(observed, 'logical'), incarnation=number(observed, 'incarnation'),
              predecessor=number(observed, 'predecessor'), successor=target, task=tasks[target],
              surface=number(observed, 'surface'), key=number(observed, 'logical'), dormant=1,
              leaves=pages[target], runtime_mint=0))
        assert at < complete
    routes = records(text, 'boot.browser.service.route')
    assert len(routes) == 4
    for (at, row), (target, slot, service) in zip(routes, [(30, 18, 13), (30, 12, 10), (31, 18, 13), (31, 12, 10)]):
        exact(row, dict(target=target, task=tasks[target], slot=slot, service=service, checked=1, readback=1, runtime_mint=0))
        assert at < complete
    # validate_inventory checks optional TLS as an all-planned-consumers set.
    # This cohort actually emits it: require exactly3 TLS +9 typed grants +bar.
    counts = {tag: len(records(text, tag)) for tag in TAGS}
    assert counts == dict(zip(TAGS, [3, 3, 3, 1, 3]))
    for tag in TAGS:
        assert all(at < complete for at, _ in records(text, tag))
    raw_authority = authority_lines(data)
    assert len(raw_authority) == 13
    old = authority_lines(reference)
    assert len(old) == 5 and original_subsequence(raw_authority) == old
    late = records(text, 'boot.browser.sources.readback')
    assert len(late) == 3 and all(wait < at < seal for at, _ in late)
    bitmap = records(text, 'display.bitmap.binding.held')
    assert len(bitmap) == 3
    for (at, row), plan in zip(bitmap, plans):
        exact(row, dict(target=plan.target, task=tasks[plan.target], surface=plan.surface,
                        slot=plan.lifecycle, before_dispatch=1))
        assert at > seal
    stores = one(text, 'display.bitmap.stores.ready', dict(stores=3, bytes=55992, static_backing=1, before_dispatch=1))
    assert max(at for at, _ in bitmap) < stores
    held = records(text, 'browser.instance.held')
    seen = set()
    for at, row in held:
        target = number(row, 'target')
        assert target in (15, 30, 31) and target not in seen
        seen.add(target)
        plan = next(plan for plan in plans if plan.target == target)
        exact(row, dict(target=target, task=tasks[target], surface=plan.surface,
                        ordinal=[15, 30, 31].index(target), coordinator=3, before_effects=1))
        assert at > seal
    assert 15 in seen
    assert held[0][0] < text.index('[browser.network.config.denied]')
    authority = one(text, 'files.history.authority', dict(slot=53, present=1, logical=12, runtime_mint=0))
    assert authority > seal
    return dict(path=str(path), bytes=len(data), sha256=digest(data), history=history,
                apps=28, registered_main_domains=40, self_wait_capacity=64, tasks=tasks,
                heap_budget=dict(bytes=heap_bytes, used=heap_used, free=heap_free,
                                 point='after_grant_seal', allocator_lock_released=True, physical_free_frames='unmeasured'),
                denial_storage=dict(bytes=1352,owners=28,slots=84,bound=4096,public=1),
                private_pages=private_total, private_bytes=private_total*4096,
                per_family_private=family_totals, per_app_private_pages=pages,
                private_page_limit=512, source_holder=inventory['holder'],
                source_consumers=[dict(target=p.target, task=tasks[p.target], surface=p.surface,
                    lifecycle=p.lifecycle, entropy=p.entropy, clock=p.clock, trust=p.trust) for p in plans],
                trust_version_observed=True, authority_records=counts,
                original_five_authority_lines_byte_identical=True, bitmap_stores=3, bitmap_bytes=55992,
                started_browser_targets=sorted(seen), grant_bytes=96, capability_data_bytes=128, capability_bytes=192)


def inspect(path, reference):
    result=inspect_prior_contract(path, reference)
    data=Path(path).read_bytes();text=data.decode('utf-8')
    geometry=records(text,'display.boot.geometry');assert len(geometry)==1
    g=geometry[0][1];width=number(g,'width');height=number(g,'height');pitch=number(g,'pitch')
    assert (width,height,pitch)in[(1024,768,4096),(1280,800,5120)]
    frame=pitch*height;span=(frame+4095)//4096*4096;total=2*span;reserved=1<<(total-1).bit_length()
    assert reserved==8388608
    observed={int(m[1])for m in re.finditer(r'^task\.running id=(\d+) pd_id=1(?= )',text,re.M)}
    assert len(observed)==1;display_task=next(iter(observed));assert display_task>0
    display_spawn=re.findall(r'^\[bootgraph\.pd\.spawn\.ok\] pd=sexdisplay id=(\d+) pkey=(\d+)\r?$',text,re.M)
    assert len(display_spawn)==1;assert int(display_spawn[0][0])==1;pkey=int(display_spawn[0][1]);assert 0<pkey<16
    at=one(text,'boot.display.frames',dict(pd=1,task=display_task,slot=98,region=11,width=width,height=height,pitch=pitch,
        frame_bytes=frame,span_bytes=span,total_bytes=total,reserved_bytes=reserved,buffers=2,pkey=pkey,private=1,zero=1,readback=1,sealed_later=1,runtime_mint=0))
    held=one(text,'display.frames.held',dict(slot=98,region=11,width=width,height=height,frame_bytes=frame,span_bytes=span,total_bytes=total,buffers=2,private=1,before_render=1))
    regions=[(i,r)for i,r in records(text,'boot.memory.region')if number(r,'pd')==1 and number(r,'slot')==98]
    assert len(regions)==1;region_at,region=regions[0];exact(region,dict(pd=1,slot=98,region=11,bytes=total,rights=7,peer=0))
    seal=text.index('[boot.memory.authority.sealed]');paint=text.index('[boot.firstpaint.display_surface] ok=1')
    assert region_at<at<seal<held<paint
    result['display_frame_backing']=dict(width=width,height=height,pitch=pitch,frame_bytes=frame,span_bytes=span,total_bytes=total,
        buddy_reserved_bytes=reserved,slot=98,region=11,buffers=2,holder_pd=1,holder_main_task=display_task,rights=7,
        no_peer=True,no_dma=True,zero_leaf_readback_before_seal=True,held_before_first_paint=True,authority_scope='PD-held; no exact-task isolation claim',physical_free_frames='unmeasured')
    return result


def cohort():
    # One sealed build, four explicit RTC/profile runs, four connected boots.
    paths = [T / 'sexos-display-frames-a-build/serial.log']
    paths += [T / f'sexos-display-frames-a-native-clock-{mode}-{profile}/serial.log'
              for mode in ('normal', 'invalid-year') for profile in ('compact', 'wide')]
    paths += [T / f'sexos-display-frames-a-native-connected-{profile}/{phase}/serial.log'
              for profile in ('compact', 'wide') for phase in ('session', 'recovery')]
    paths += [T / f'sexos-display-frames-a-native-browser-{profile}/serial.log' for profile in ('compact','wide')]
    assert len(paths) == len(set(paths)) == 11
    return paths


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke-build', action='store_true', help='One sealed-build log only; never eleven-boot completion')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    bound = binding_check()
    paths = cohort()[:1] if args.smoke_build else cohort()
    missing = [str(path) for path in paths if not path.is_file()]
    assert not missing, ('incomplete explicit cohort', missing)
    observations = [inspect(path, REFERENCE.read_bytes()) for path in paths]
    assert len(observations) == (1 if args.smoke_build else 11)
    result = dict(ok=True, mode='build_smoke_only' if args.smoke_build else 'explicit_eleven_boot_inventory',
                  boots=len(observations), expected_final_boots=11, final_cohort_complete=not args.smoke_build,
                  frozen=bound, reference=dict(path=str(REFERENCE), sha256=digest(REFERENCE.read_bytes())),
                  observations=observations, functional_acceptance_checked=False,
                  clock_date_pixel_behavior_checked=False, full_reserve_exhaustion_checked=False,
                  current_image_1800s_acceptance_checked=False, native_unsupported_source_packet_behavior_checked=False,
                  auxiliary_cold_boots=0, kernel_equality_to_prior_image_asserted=False,
                  scope='Captured BOOT catalog/registered tasks, held history and source metadata/readbacks, all global source streams, Display store bindings. Source original-only proof guards checked. Retained Shell metadata capacity43 is a source-bound calculation. Display bindings/stores initialize after seal and before dispatch; new text task guard/parallel commits are renderer-functional scope, not BOOT authority. Heap budget is a post-seal allocator snapshot, not physical free frames; private page totals count recorded app backing and are not total machine memory. Source-denial storage is public bounded receipt metadata, not payload or sampled secrets. Its1352-byte native size/owner/slot receipt is checked; unsupported-source packet behavior remains host-model/differential evidence unless separately qualified natively. This eleven-boot inventory covers one sealed build, four normal/invalid-year clock runs and four connected session/recovery boots and two Browser reserve boots. Invalid-year changes time availability, not the held grant inventory. Pixel/date captions and connected functional acceptance are separate replay obligations. No Alpha, complete app-reserve exhaustion, auxiliary cold helper or current-image1800-second acceptance claim. Kernel byte comparison is measured separately. Not an independent kernel dispatch, native activation, pixel, TLS handshake, or workflow-acceptance proof.')
    output = args.out or T / ('sexos-display-frames-a-boot-audit-smoke.json' if args.smoke_build else 'sexos-display-frames-a-boot-audit.json')
    with output.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(dict(ok=True, boots=len(observations), final_cohort_complete=result['final_cohort_complete'], output=str(output))))


if __name__ == '__main__':
    main()
