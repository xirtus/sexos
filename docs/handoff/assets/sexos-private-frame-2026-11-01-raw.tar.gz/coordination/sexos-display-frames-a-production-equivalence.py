from pathlib import Path
import hashlib,json,re,shlex,subprocess
T=Path('/tmp');P='sexos-display-frames-a';F=T/(P+'-frozen');B=T/'sexos-display-scene-a-frozen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((B/'source-binding.json').read_text());b=json.loads((F/'source-binding.json').read_text())
assert a['build_provenance']['git_revision']=='c947cccd53c7a4b7513b93c1c480eda502ea1fa6'
assert b['build_provenance']['git_revision']=='0c185625b086f6843e19d1c5de8c47d4c0a4e505'
x,y=a['sources'],b['sources'];added=sorted(y.keys()-x.keys());removed=sorted(x.keys()-y.keys());changed=sorted(n for n in x.keys()&y.keys()if x[n]!=y[n])
assert len(x)==583 and len(y)==585 and not removed
assert added==['crates/sex-pdx/src/display_frames.rs','servers/sexdisplay/src/frame_output.rs']
assert changed==['crates/sex-pdx/src/lib.rs','kernel/src/boot_memory.rs','kernel/src/init.rs','kernel/src/memory/va_allocator.rs','servers/sexdisplay/src/main.rs','sexos_build_spec.toml']
def inputs(root):
 s=(root/'scripts/entrypoint_build.sh').read_text();m=re.search(r'ABI_INPUTS=\(\n(.*?)\n\)',s,re.S);assert m
 return shlex.split(m[1],comments=True)
old=inputs(B/'source');current=inputs(F/'source');assert len(old)==66 and len(current)==67
assert [n for n in current if n not in old]==['crates/sex-pdx/src/display_frames.rs']
assert [n for n in current if n in old]==old
abi=hashlib.sha256(subprocess.check_output(['sha256sum',*current],cwd=F/'source')).hexdigest()
assert abi=='3b98b23398b7a309a74d5d10526e9234fa372ff448c79f51aa4f4b9f44fdc36a'
result=dict(ok=True,baseline_commit=a['build_provenance']['git_revision'],candidate_commit=b['build_provenance']['git_revision'],baseline_binding_sha256=sha(B/'source-binding.json'),baseline_production=len(x),candidate_production=len(y),added=added,removed=removed,changed=changed,unchanged=len(x)-len(changed),kernel_identical=sha(B/'tested.kernel')==sha(F/'tested.kernel'),baseline_kernel_sha256=sha(B/'tested.kernel'),candidate_kernel_sha256=sha(F/'tested.kernel'),abi_inputs=len(current),prior_abi_inputs=len(old),abi_added_inputs=['crates/sex-pdx/src/display_frames.rs'],abi_sha256=abi,scope='Exact source-set and image-hash comparison; the new BOOT frame grant changes authority metadata and kernel code. Native authority/pixels require separate qualified observations.')
out=T/(P+'-production-equivalence.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
