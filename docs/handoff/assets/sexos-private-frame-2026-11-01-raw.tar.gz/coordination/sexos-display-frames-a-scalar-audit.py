from pathlib import Path
import hashlib,json,re,subprocess
T=Path('/tmp');F=T/'sexos-display-frames-a-frozen';O=T/'sexos-display-frames-a-scalar';O.mkdir(exist_ok=False)
binding=json.loads((F/'source-binding.json').read_text());assert binding['build_provenance']['git_revision']=='0c185625b086f6843e19d1c5de8c47d4c0a4e505';assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tool=Path('/Users/xmacbookm5/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-objdump');assert tool.is_file();rows=[]
assert sha(F/'tested.iso')==binding['iso_sha256']
for name,where in [('kaleidoscope','apps'),('silk-shell','servers'),('sexdisplay','servers'),('quil','servers'),('silkbar','servers'),('sexfiles','servers'),('spindle','apps'),('linen','servers'),('sexnet','servers')]:
 elf=O/(name+'.elf');extract=['xorriso','-osirrox','on','-indev',str(F/'tested.iso'),'-extract','/'+where+'/'+name,str(elf)];r=subprocess.run(extract,capture_output=True,text=True);(O/(name+'-extract.log')).write_text(r.stdout+r.stderr);assert r.returncode==0
 data=elf.read_bytes();assert data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==62,(name,'not ELF64 x86-64')
 command=[str(tool),'--disassemble','--no-show-raw-insn','--x86-asm-syntax=att',str(elf)];text=subprocess.check_output(command,text=True);assembly=O/(name+'.asm');assembly.write_text(text);instructions=[];bad=[]
 for line in text.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+([A-Za-z][A-Za-z0-9.]*)\b(.*)$',line)
  if not m:continue
  instructions.append(line);mnemonic=m[2].lower()
  if re.search(r'%(?:[xyz]mm[0-9]+|mm[0-7]|st(?:\([0-7]\))?|k[0-7])\b',m[3])or mnemonic.startswith(('f','v','xsave','xrstor'))or mnemonic in ('ldmxcsr','stmxcsr','emms'):bad.append(line)
 assert instructions and not bad,(name,bad[:10]);rows.append(dict(name=name,iso_path='/'+where+'/'+name,elf_size=elf.stat().st_size,elf_sha256=sha(elf),disassembly_sha256=sha(assembly),instructions=len(instructions),vector_or_fp_matches=bad,commands=[extract,command]));print(name,len(instructions),'inspected_matches',len(bad),flush=True)
result=dict(ok=True,commit=binding['build_provenance']['git_revision'],architecture_sha256=binding['architecture_sha256'],total_instructions=sum(r['instructions']for r in rows),iso_sha256=sha(F/'tested.iso'),tool_version=subprocess.check_output([str(tool),'--version'],text=True),results=rows,scope='Nine exact ISO-extracted ELF disassemblies; inspect decoded instructions for vector/MMX/x87/opmask registers, f/v-prefixed FP/vector operations, xsave/xrstor, MXCSR and EMMS. This is a static scan, not runtime register/cache erasure or a complete instruction-set audit.')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
