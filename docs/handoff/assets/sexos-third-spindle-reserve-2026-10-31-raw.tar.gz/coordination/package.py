from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-spindle-third-b-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-spindle-third-b-source-audit.json');boot=read(T/'sexos-spindle-third-b-boot-audit.json');h=read(T/'sexos-spindle-third-b-frozen-host/report.json');scalar=read(T/'sexos-spindle-third-b-scalar-v3/result.json');alpha=read(T/'sexos-spindle-third-b-alpha-progress.json');connected=read(T/'sexos-spindle-third-b-native-progress.json');cold=read(T/'sexos-spindle-third-b-last-writer-cold-aux/result.json')
assert audit['ok']and audit['commit']=='c5bf51208562f1409e63065c5e23ab2285ac3a9a'and boot['ok']and boot['boots']==8
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2724
assert 'Ran 1011 tests in 'in(T/'sexos-spindle-third-b-python.log').read_text()
assert len(alpha)==2 and all(row['status']==0 and row['fresh_replay']and row['terminal_history']['source']==24 and row['terminal_history']['task']==24 for row in alpha)
assert len(connected)==2 and all(row['status']==0 and row['boots']==2 and row['verified_captures']==17 for row in connected)
assert cold['ok']and cold['stopped']and cold['binding']and cold['expected']['source']==24 and cold['expected']['task']==24 and cold['recall']=='net-probe'
assert scalar['ok']and len(scalar['results'])==8 and all(not r['vector_or_fp_matches']for r in scalar['results'])
assert read(T/'sexos-spindle-third-a-frozen/source-binding.json')['sources']==b['sources']
observations=[]
for row in alpha:
 out=Path(row['out']);text=(out/'serial.log').read_text(errors='replace');r=read(out/'result.json');s=r['soak']['third_spindle'];assert [step['target']for step in s['chain']]==[24]and s['reserve_exhausted'];accepted=sorted(set(map(int,re.findall(r'\[shell.spindle.status.accepted\] target=(\d+)',text))));assert accepted==[12,17,24]
 assert '[sext.app.pool.ready] target=24 task=24 bytes=389120 zeroed=389120 workspace_records=2 reused=1 zero_owner=sext ok=1'in text
 observations.append(dict(profile=row['profile'],status_subjects=accepted,third=s,terminal_history=row['terminal_history']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items,(n,p);items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('qualified/frozen',F),('qualified/sealed-build',T/'sexos-spindle-third-b-build'),('qualified/host',T/'sexos-spindle-third-b-frozen-host'),('qualified/scalar',T/'sexos-spindle-third-b-scalar-v3'),('qualified/auxiliary-cold',T/'sexos-spindle-third-b-last-writer-cold-aux')]:tree(prefix,root)
for row in alpha:tree('qualified/alpha/'+row['profile'],row['out'])
for row in connected:tree('qualified/connected/'+row['profile']['label'],row['out'])
for name in ['sexos-spindle-third-a-frozen','sexos-spindle-third-a-build','sexos-spindle-third-a-frozen-host','sexos-spindle-third-a-scalar-v3','sexos-spindle-third-a-alpha-compact','sexos-spindle-third-a-alpha-wide']:tree('superseded/'+name,T/name)
for name in ['sexos-spindle-third-a-host','sexos-spindle-third-a-host-final']:tree('diagnostic/'+name,T/name)
for name in ['sexos-r143-catalog-host','sexos-r143-spindle-pixels','sexos-r143-alpha-evidence-review','sexos-r143-activation-desktop']:
 p=T/name
 if p.exists():tree('host-controls/'+name,p)
for p in sorted(T.glob('sexos-spindle-third-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py','.sh','.txt']and 'package'not in p.name:add('coordination/'+p.name,p)
add('host-controls/history-prefix.log',T/'sexos-spindle-history-prefix-tests.log');add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-third-spindle-reserve-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
captures=sum(row['verified_captures']for row in alpha+connected)
e=dict(round=143,third_spindle_boot_reserve_qualified=True,full_os_goal_complete=False,source_commit=audit['commit'],catalog_commit='521fa3de154156bfd8ac1f6bed6f7456a163258d',main_parent='b99d4e84',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust,python_tests=1011,boot=dict(catalog_subjects=12,spindle_targets=[12,17,24],main_self_wait_tasks=24,self_wait_capacity=32,grant_bytes=48,capability_data_bytes=128,capability_bytes=192,app_surfaces=25,desktop_tracked_surfaces=26),native=dict(sealed_probe_boots=1,alpha_boots=2,connected_boots=4,auxiliary_cold_boots=1,total_qualified_boots=8,registry_verified_captures=captures,alpha=alpha,connected=connected,third_observations=observations,cold=dict(observed=True,source=24,task=24,fresh_target=12,recall=cold['recall'],generation=cold['expected']['generation'],bytes=cold['expected']['size'],standalone_artifact_replay=False,parent_source_bound_replayed=True),boot_roster_layout_audit=boot,new_image_1800s_acceptance=False,positive_controlled_tcp_release=True,pcap_proof=False),scalar=dict(elfs=8,instructions=sum(r['instructions']for r in scalar['results']),inspected_vector_fp_matches=0,scope=scalar['scope']),superseded=dict(source='521fa3de',production_sources_identical=True,alpha_boots=2,registry_verified_captures=58,all_fresh_replays=True,scope='A three-incarnation native workflows and host checks passed; final B declares exact legacy history prefix without changing production sources. Original source/image/positive evidence and earlier failing host goldens retained.'),limitations=dict(finite_spindle_incarnations=3,per_request_file_deferred_task_authentication=False,native_unequal_allocator=False,full_historical_desktop_close_gate_qualified=False),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='BOOT-only domain24 reservation, held three-participant history recovery, exact third relaunch/owned load/save, 33-byte storage create-fill-verify-delete, controlled1025-byte TCP echo through positive RELEASE, four-pane glyphs, five-role cleanup/389120-byte zeroed reusable private span and exhausted launcher. Both sizes use exact source/image immutable capture replay; cold24-to-fresh12 is an auxiliary observed probe with bound parent replay. No per-request deferred task authentication, unbounded relaunch, packet capture, native unequal task allocator, new1800s or unrestricted daily-driver acceptance claim.')
p=A/'sexos-third-spindle-reserve-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('THIRD_SPINDLE_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','captures',captures,flush=True)
