from pathlib import Path
import hashlib,json,re,sys
T=Path('/tmp');F=T/'sexos-spindle-third-b-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
from history_roster_evidence import verify_boot_roster
from quil_reserve_catalog import quil_catalog,verify_boot_quil
roots=[T/'sexos-spindle-third-b-build',T/'sexos-spindle-third-b-last-writer-cold-aux']
for suffix in ['alpha-progress','native-progress']:
 rows=json.loads((T/('sexos-spindle-third-b-'+suffix+'.json')).read_text());assert len(rows)==2 and all(r['status']==0 for r in rows);roots.extend(Path(r['out'])for r in rows)
logs=[]
for root in roots:
 for p in sorted(root.rglob('serial.log')):
  data=p.read_bytes();text=data.decode(errors='replace');roster=verify_boot_roster(R,text);verify_boot_quil(text,quil_catalog(R))
  assert roster['participants']==[dict(target=12,task=12),dict(target=17,task=17),dict(target=24,task=24)],p
  marker='[boot.history.layout] grant_bytes=48 capability_data_bytes=128 capability_bytes=192 participants=3 bounded=1';assert text.count(marker)==1 and text.index(marker)<text.index('[boot.memory.authority.sealed]'),p
  assert text.count('[boot.self_wait.sealed] tasks=24 capacity=32 max_ticks=64 runtime_registration=0')==1,p
  authority='[files.history.authority] slot=53 present=1 logical=12 runtime_mint=0';assert text.count(authority)==1,p
  logs.append(dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),roster=roster,grant_bytes=48,capability_data_bytes=128,capability_bytes=192))
assert len(logs)==8,len(logs)
p=T/'sexos-spindle-third-b-boot-audit.json';assert not p.exists();p.write_text(json.dumps(dict(ok=True,boots=8,normal_workflow_boots=6,sealed_probe_boots=1,auxiliary_cold_boots=1,observations=logs,scope='Actual inserted history capability queried beforeseal; exact registered tasks and both family catalogs/layout. Three actual Spindles, no per-request task authentication.'),indent=2)+'\n');print('EIGHT_BOOTS_HELD_ROSTER_AND_LAYOUT_PASS',flush=True)
