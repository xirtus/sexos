from pathlib import Path
import json,hashlib,subprocess
T=Path('/tmp');F=T/'sexos-spindle-third-a-frozen';b=json.loads((F/'source-binding.json').read_text());commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();groups={k:b[k]for k in ['sources','runner_sha256']};names=sorted(set().union(*groups.values()));raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(commit+':'+n+'\n'for n in names).encode());at=0
for name in names:
 end=raw.index(b'\n',at);size=int(raw[at:end].split()[-1]);start=end+1;blob=raw[start:start+size];at=start+size+1;actual=hashlib.sha256(blob).hexdigest();assert actual==hashlib.sha256((F/'source'/name).read_bytes()).hexdigest(),name
 for g in groups.values():
  if name in g:assert actual==g[name],name
result=dict(ok=True,commit=commit,production=len(groups['sources']),runner=len(groups['runner_sha256']),unique=len(names),iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256']);(T/'sexos-spindle-third-a-source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
