"""Prepared round91 finalC single-cohort archive. Execute only after root confirms closure.
No build, test suite, native workflow, staging or commit is launched here.
"""
from pathlib import Path
import hashlib,json,re,os,shutil,subprocess,tarfile
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Users/xmacbookm5/Projects/Sex');ASSETS=ROOT/'docs/handoff/assets';LOCAL=ROOT/'.evidence/alpha-2026-10-29/r91c'
FROZEN=Path('/tmp/sexos-alpha-r91c-frozen');BUILD=Path('/tmp/sexos-alpha-r91c-build');HOST=Path('/tmp/sexos-alpha-r91c-host')
PYTHON=Path('/tmp/sexos-r91c-python-driver.log')
ISO=json.loads((FROZEN/'source-binding.json').read_text())['iso_sha256']

def j(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as file:
  for part in iter(lambda:file.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def tree_files(path):
 path=Path(path);assert path.is_dir(),path
 for file in sorted(path.rglob('*')):
  # Compiler caches are unbound output, not evidence. Filter before checking
  # symlinks because Cargo caches contain symlinked dependency artifacts.
  if any(part in ('target','__pycache__')for part in file.relative_to(path).parts):continue
  assert not file.is_symlink(),file
  if file.is_file():yield file

def bound_snapshot():
 b=j(FROZEN/'source-binding.json');p=b['build_provenance']
 assert b['iso_sha256']==ISO==p['iso_sha256']==sha(FROZEN/'tested.iso')
 assert p['build_gate']=='PASS'and p['source_image_binding']=='sealed_build_this_run'and p['sources_unchanged_during_build']is True
 assert b['sources']==p['production_source_sha256']and len(b['sources'])==422 and len(b['runner_sha256'])==481
 assert sha(FROZEN/'tested.kernel')==b['kernel_sha256']
 for group in('sources','runner_sha256'):
  for name,digest in b[group].items():
   assert not any(part in ('target','__pycache__')for part in Path(name).parts),('boundcacheforbidden',group,name)
   assert sha(FROZEN/'source'/name)==digest,(group,name)
 build=(BUILD/'report.md').read_text();assert re.search(r'FINAL_SCORE[^\n]*GREEN_MASTER',build)and re.search(r'BUILD_GATE[^\n]*PASS',build)and 'probe_seconds: 90'in build
 assert j(BUILD/'provenance.json')['iso_sha256']==ISO
 return b,build

def raw_archive(label,roots):
 name=f'sexos-alpha-r91c-{label}-2026-10-30-raw.tar.gz';target=ASSETS/name;members=[]
 with tarfile.open(target,'w:gz',compresslevel=9)as archive:
  for arcroot,source in roots:
   source=Path(source)
   if source.is_dir():files=[(arcroot+'/'+str(file.relative_to(source)),file)for file in tree_files(source)]
   else:assert source.is_file();files=[(arcroot,source)]
   for member,file in files:
    assert not file.is_symlink();digest=sha(file);archive.add(file,arcname=member,recursive=False)
    assert sha(file)==digest,('source changed during archive',file)
    members.append(dict(path=member,size=file.stat().st_size,sha256=digest))
 assert len({x['path']for x in members})==len(members)
 # Independently decompress every member immediately; no extraction, links or
 # path traversal. Inventory is compact metadata, not duplicated result JSON.
 expected={x['path']:x for x in members};seen=set()
 with tarfile.open(target,'r:gz')as archive:
  for member in archive:
   assert member.isfile()and member.name in expected and member.name not in seen
   h=hashlib.sha256();size=0;stream=archive.extractfile(member)
   for part in iter(lambda:stream.read(1024*1024),b''):h.update(part);size+=len(part)
   assert(size,h.hexdigest())==(expected[member.name]['size'],expected[member.name]['sha256']),member.name;seen.add(member.name)
 assert seen==set(expected)
 return dict(path=name,sha256=sha(target),compressed_bytes=target.stat().st_size,regular_members=len(members),uncompressed_bytes=sum(x['size']for x in members),members=members,decompression_verified=True)

def png(source,label,scope):
 source=Path(source);raw=source.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',raw);assert header,source
 dimensions=list(map(int,header.groups()));assert len(raw)-header.end()==dimensions[0]*dimensions[1]*3
 target=ASSETS/f'sexos-alpha-r91c-{label}-2026-10-30.png';subprocess.run(['sips','-s','format','png',str(source),'--out',str(target)],check=True,stdout=subprocess.DEVNULL)
 data=target.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'and[int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')]==dimensions
 return dict(path=target.name,sha256=sha(target),source_ppm_sha256=sha(source),dimensions=dimensions,scope=scope)


def native_json_links(paths,archive):
 inventory={member['path']:member for member in archive['members']};links=[]
 def walk(value,trail=()):
  if isinstance(value,dict):
   for key,item in value.items():yield from walk(item,trail+(str(key),))
  elif isinstance(value,list):
   for index,item in enumerate(value):yield from walk(item,trail+(str(index),))
  elif isinstance(value,str):yield trail,value
 for name,directory in paths.items():
  for file in sorted(directory.glob('*.json')):
   for trail,value in walk(j(file)):
    target=Path(value)
    if target.is_absolute()or not value or target.suffix not in('.ppm','.json','.pcap','.img','.log'):continue
    candidate=(file.parent/target).resolve()
    if trail and trail[-1]=='screenshot':assert candidate.is_file(),('missing accepted screenshot',name,file,trail,value)
    if not candidate.is_file():continue
    assert candidate.is_relative_to(directory.resolve()),('relative native reference escapes acceptedrun',name,trail,value)
    relative=candidate.relative_to(directory.resolve());member='native/'+directory.name+'/'+str(relative)
    assert member in inventory and sha(candidate)==inventory[member]['sha256'],('native reference absent/wrong in archive',member)
    links.append(dict(source='native/'+directory.name+'/'+file.name,field='.'.join(trail),target=member,sha256=inventory[member]['sha256']))
 return dict(ok=True,count=len(links),links=links,scope='Every existing relative evidence-file reference in accepted native JSON joined to exact archived member; screenshot references additionally require a present local file. Historical failures retain their original incomplete raw state separately.')

def archive():
 # Every accepted execution belongs to C's one unchanged frozen cohort.
 tls_rows=j('/tmp/sexos-r91c-tls-native-suite-progress.json');regression=j('/tmp/sexos-r91c-regression-suite-progress.json')
 expected_tls=['tls-'+mode+'-'+profile for mode in('ready','close','unsupported','invalid-year')for profile in('wide','compact')]
 expected_regression=['chain-e1000e','stream-e1000','time-normal-wide','entropy-ready-compact','profile','compact','document-reboot','history-reboot','switch-wide','switch-compact']
 assert [r['name']for r in tls_rows]==expected_tls and [r['name']for r in regression]==expected_regression
 rows=tls_rows+regression;assert len(rows)==18 and all(r['status']==0 for r in rows)
 binding,build_report=bound_snapshot();host=j(HOST/'report.json');assert host['checks_passed']and host['sources_unchanged_during_checks']and host['run_status']=='complete'and len(host['checks'])==38 and all(r['exit_code']==0 for r in host['checks'])
 for name,digest in host['source_sha256'].items():assert sha(FROZEN/'source'/name)==digest
 rust=sum(int(n)for file in HOST.glob('*.log')for n in re.findall(r'test result: ok\. (\d+) passed',file.read_text(errors='replace')));assert rust==1514
 python_log=PYTHON.read_text();counts=re.findall(r'^Ran (\d+) tests in ',python_log,re.M);assert len(counts)==1 and python_log.rstrip().endswith('OK');python=int(counts[0]);assert python==504
 assert list(host['obligations'].values()).count('open')==7 and list(host['obligations'].values()).count('partial')==23 and host['system_proven']is False
 scalar=j('/tmp/sexos-r91c-scalar-instructions.json');assert scalar['ok']and scalar['iso_sha256']==ISO and scalar['elf_sha256']==sha('/tmp/sexos-r91c-tested-kaleidoscope.elf')and scalar['disassembly_sha256']==sha('/tmp/sexos-r91c-kaleidoscope.disassembly')and scalar['vector_or_fp_matches']==[]
 assert Path('/tmp/sexos-r91c-tested-kaleidoscope.elf').read_bytes()[:4]==b'\x7fELF'
 target_guard=j('/tmp/sexos-r91c-target-guard.json');assert target_guard['ok']and target_guard['target_sha256']==binding['sources']['x86_64-sex.json']
 replay_path=Path('/tmp/sexos-r91c-tls-independent-replay.json')
 with Path('/tmp/sexos-r91c-tls-independent-replay-driver.log').open('w')as log:subprocess.run(['python3','/tmp/sexos-r91c-replay-tls.py','--output',str(replay_path)],check=True,stdout=log)
 replay=j(replay_path);assert replay['ok']and replay['runs']==8
 paths={};summaries=[]
 for row in rows:
  name=row['name'];path=Path(row['out']);r=j(path/'result.json');m=j(path/'manifest.json');assert r['ok'];assert m.get('iso_sha256',m.get('binding',{}).get('iso_sha256'))==ISO
  if 'binding'in m:assert m['binding']['sha256']==sha(FROZEN/'source-binding.json')and m['binding']['production_files']==422 and m['binding']['runner_files']==481
  for group in('runner_sha256','pixel_source_sha256','authority_source_sha256'):
   for file,digest in m.get(group,{}).items():
    if group=='runner_sha256'and '/'not in file:file='scripts/'+file
    assert sha(FROZEN/'source'/file)==digest
  trace=(path/'serial.log').read_text(errors='replace');assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[sexfiles.defer.drop\]',trace)
  for check in('check_nic_command.json','check_self_wait.json','check_document_views.json','check_document_snapshots.json'):
   if(path/check).exists():assert j(path/check)['ok']
  summary=dict(name=name,result_ok=True,mode=m.get('mode'),model=m.get('model'),resolution=m.get('resolution',r.get('resolution')),manifest='native/'+path.name+'/manifest.json',result='native/'+path.name+'/result.json',serial='native/'+path.name+'/serial.log',disk='native/'+path.name+'/nvme.img')
  if name.startswith('tls-'):
   assert all(r[k]['ok']for k in('tls','public_wire','owner_packet_joins','authority','self_wait'));summary.update(tls=r['tls'])
  if name in('profile','compact'):summary['private_pages']=sum(int(n)for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace))
  if name.startswith('switch-'):assert r['switch_cycles']==10 and len(r['switches'])==40 and r['pixel_errors']==[];summary['switches']=40
  paths[name]=path;summaries.append(summary)
 pages={s['name']:s['private_pages']for s in summaries if'private_pages'in s};switches={s['name']:s['switches']for s in summaries if'switches'in s};assert sum(switches.values())==80
 # Earlier candidates remain explicitly rejected diagnostics, never inherited.
 historical_snapshots=[('candidate-a/frozen',Path('/tmp/sexos-alpha-r91-frozen')),('candidate-b/frozen',Path('/tmp/sexos-alpha-r91b-frozen')),('candidate-b/final-checkers-preflight',Path('/tmp/sexos-alpha-r91-final-checkers'))]
 for label,snapshot in historical_snapshots:
  held=j(snapshot/'source-binding.json')
  assert all(not any(part in ('target','__pycache__')for part in Path(name).parts)for group in('sources','runner_sha256')for name in held[group])
 a_rows=j('/tmp/sexos-r91-tls-native-suite-progress.json')+j('/tmp/sexos-r91-regression-suite-progress.json');assert len(a_rows)==18 and all(row['status']==0 for row in a_rows)
 b_rows=j('/tmp/sexos-r91b-tls-native-suite-progress.json')+j('/tmp/sexos-r91b-regression-suite-progress.json');assert len(b_rows)==16 and sum(row['status']==0 for row in b_rows)==15 and b_rows[-1]['name']=='history-reboot'and b_rows[-1]['status']!=0
 failed_pre_e=Path('/tmp/sexos-alpha-r91b-entropy-ready-compact');assert j(failed_pre_e/'result.json')['ok']is False
 failed_history=Path('/tmp/sexos-alpha-r91b-history-reboot');assert failed_history.is_dir()and j(failed_history/'result.json')['ok']is False
 ASSETS.mkdir(parents=True,exist_ok=True);LOCAL.mkdir(parents=True,exist_ok=True)
 native_roots=[('native/'+p.name,p)for p in paths.values()]+[('candidate-a/native/'+Path(row['out']).name,Path(row['out']))for row in a_rows]+[('candidate-b/native/'+Path(row['out']).name,Path(row['out']))for row in b_rows]+[('candidate-b-failure/pre-E-entropy-ZoomToggle',failed_pre_e)]
 archives={'frozen':raw_archive('frozen',[('frozen',FROZEN)]+historical_snapshots),'native':raw_archive('native',native_roots)}
 drivers=sorted(set(Path('/tmp').glob('sexos-r91*driver.log')));assert PYTHON in drivers
 current_names=('sexos-save-r91c.py','sexos-r91c-tls-native-suite.py','sexos-r91c-tls-native-suite-progress.json','sexos-r91c-regression-suite.py','sexos-r91c-regression-suite-progress.json','sexos-r91c-replay-tls.py','sexos-r91c-tls-independent-replay.json','sexos-r91c-scalar-instructions.json','sexos-r91c-target-guard.json','sexos-r91c-tested-kaleidoscope.elf','sexos-r91c-extract-browser.log','sexos-r91c-kaleidoscope.disassembly','sexos-r91c-tls-platform-guard.json')
 historical_names=('sexos-r91-tls-native-suite.py','sexos-r91-tls-native-suite-progress.json','sexos-r91-regression-suite.py','sexos-r91-regression-suite-progress.json','sexos-r91b-tls-native-suite.py','sexos-r91b-tls-native-suite-progress.json','sexos-r91b-regression-suite.py','sexos-r91b-regression-resume.py','sexos-r91b-regression-suite-progress.json','sexos-r91b-regression-first-attempt-progress.json','sexos-r91b-regression-first-attempt-driver.log','sexos-r91b-scalar-instructions.json','sexos-r91b-target-guard.json','sexos-r91b-tested-kaleidoscope.elf','sexos-r91b-extract-browser.log','sexos-r91b-kaleidoscope.disassembly','sexos-r91b-tls-platform-guard.json')
 orchestration=[Path('/tmp')/name for name in current_names+historical_names]
 roots=[('host',HOST),('build',BUILD),('candidate-a/build',Path('/tmp/sexos-alpha-r91-build')),('candidate-b/build',Path('/tmp/sexos-alpha-r91b-build')),('candidate-failure/initial-host-checker-seal',Path('/tmp/sexos-alpha-r91-host')),('candidate-failure/frozen-host-missing-libsys',Path('/tmp/sexos-alpha-r91-host-frozen')),('candidate-b/original-frozen-host',Path('/tmp/sexos-alpha-r91b-host-frozen')),('candidate-b/final-checkers-preflight-host',Path('/tmp/sexos-alpha-r91-final-host')),('candidate-failure/closure-host.log',Path('/tmp/sexos-r91-closure-host.log'))]+[('orchestration/'+file.name,file)for file in orchestration]+[('drivers/'+file.name,file)for file in drivers]
 archives['host_build_orchestration']=raw_archive('host-build-orchestration',roots)
 json_links=native_json_links(paths,archives['native'])
 selections=[('tls-ready-wide','tls-first.ppm','tls-hello-wide','Library-generated private ClientHello pending; no peer/network/authentication claim.'),('tls-ready-compact','tls-first.ppm','tls-hello-compact','Actual1024x768 complete preparation status.'),('tls-ready-wide','tls-cleared.ppm','tls-cleared-wide','Actual Q erases17112 owned future+queue payload bytes and replaces fullstatus.'),('tls-ready-compact','tls-cleared.ppm','tls-cleared-compact','Compact Q glyph/padding/trailing-erasure.'),('tls-unsupported-wide','tls-first.ppm','tls-entropy-unavailable','RDSEED/RDRAND-disabled CPU rejects both local attempts.'),('tls-invalid-year-compact','tls-first.ppm','tls-utc-unavailable-compact','Invalid1999 civilUTC profile rejects TLS preparation.'),('tls-close-wide','tls-before-close.ppm','tls-allocated-before-close','AllocatedHelloPending preceding real F11; seed/time already released.'),('tls-close-compact','tls-closed.ppm','tls-after-close-compact','AfterClose actual framebuffer; serial proves allocatedpending1/erasure/five-role98page return.')]
 images={label:png(paths[run]/file,label,scope)for run,file,label,scope in selections}
 evidence=dict(round=91,candidate='c',scope='Pinned non-Unix bounded private TLS ClientHello foundation and atomic Shell zoom receipts; all accepted native/host/Python use one finalCsourcebinding. No TLS wire or authenticated peer.',iso_sha256=ISO,kernel_sha256=binding['kernel_sha256'],source_binding_sha256=sha(FROZEN/'source-binding.json'),source_counts=dict(production=422,runners=481),source_binding_member='frozen/source-binding.json',host=dict(gates=38,rust_executions=rust,python_tests=python,report_member='host/report.json',source_binding_sha256=sha(FROZEN/'source-binding.json')),native=dict(count=18,source_binding_sha256=sha(FROZEN/'source-binding.json'),runs=summaries),tls_independent_frozen_replay=replay,native_json_references=json_links,archives=archives,selected_images=images,private_pages=pages,ordinary_switches=switches,ordinary_switches_total=80,excluded_unbound_caches=dict(relative_directory_components=['target','__pycache__'],before_symlink_checks=True,bound_sources_or_runners_excluded=False,scope='Unbound compiler/Python caches omitted; all snapshots assert no bound source/runner path uses these components. No files deleted.'),instruction_scope=scalar,target_metadata_scope=target_guard,acceptance_status=dict(open=7,partial=23,system_proven=False),historical_candidates=dict(a=dict(accepted_as_final=False,native_passes=18),b=dict(accepted_as_final=False,tls_passes=8,regression_passes=7,history_reboot_failed=True)),candidate_failures=[dict(scope='CandidateA initial host checker-source consistency seal failed; rejected/preserved.',archive_member='candidate-failure/initial-host-checker-seal/report.json'),dict(scope='CandidateA frozenCargoTLS source closure omitted local libsys; Amechanismresults neverfinalacceptance.',archive_member='candidate-failure/frozen-host-missing-libsys/report.json'),dict(scope='B503Python rejected two synthetic runtime-proof fixtures lacking realCargo; laterBpreflight504 repaired fixtures are historical, not inherited asCexecution.',archive_member='drivers/sexos-r91b-python-frozen-driver.log'),dict(scope='Bentropy compact pre-E interleaved legacy ZoomToggle receipt timedout; rejectedattempt andoriginalprogress remain separate.',archive_member='candidate-b-failure/pre-E-entropy-ZoomToggle/result.json'),dict(scope='Bhistoryreboot recovered17bytes but actual zoom.active serialfragment interleaved beforeUp; structured failedresult andrawserial retained. Cchanges exactlythreeShellzoomlogcalls toatomicserialrecords andreruns full18.',archive_member='candidate-b/native/sexos-alpha-r91b-history-reboot/result.json')],limits=['No TLS wire/handshake, certificate/hostname validation, authenticated peer/publicinternet, source-quality/physicalclock, hostilecontainment/SMP/fullreplay proof.','Default baremetal target metadata and decoded released app scalarinstructions do not prove every runtime register/cache copy erased.','private_bytes includes publicPipe metadata; erased bytes counts owned future and two4096byte arrays, metadata excluded.'])
 target=ASSETS/'sexos-alpha-r91c-2026-10-30-evidence.json';target.write_text(json.dumps(evidence,indent=2)+'\n')
 for artifact in archives.values():shutil.copyfile(ASSETS/artifact['path'],LOCAL/artifact['path'])
 shutil.copyfile(target,LOCAL/target.name)
 print(json.dumps(dict(evidence=str(target),evidence_sha256=sha(target),archives=3,pngs=8,raw_members=sum(a['regular_members']for a in archives.values()),compressed_bytes=sum(a['compressed_bytes']for a in archives.values()),native=18,host_gates=38,rust_executions=rust,python_tests=python,private_pages=pages,switches=80,local=str(LOCAL))))

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--host',type=Path,default=HOST);parser.add_argument('--python-log',type=Path,default=PYTHON);args=parser.parse_args();HOST=args.host;PYTHON=args.python_log;archive()
