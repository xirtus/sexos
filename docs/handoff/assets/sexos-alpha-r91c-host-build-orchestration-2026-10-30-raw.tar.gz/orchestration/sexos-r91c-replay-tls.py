"""Read-only independent replay of saved frozen91b TLS foundation evidence."""
from pathlib import Path
import argparse,hashlib,json,re,sys
p=argparse.ArgumentParser();p.add_argument('--frozen',type=Path,default=Path('/tmp/sexos-alpha-r91c-frozen'));p.add_argument('--progress',type=Path,default=Path('/tmp/sexos-r91c-tls-native-suite-progress.json'));p.add_argument('--output',type=Path);a=p.parse_args();source=a.frozen/'source';binding=json.loads((a.frozen/'source-binding.json').read_text());rows=json.loads(a.progress.read_text());expected=['tls-'+mode+'-'+profile for mode in('ready','close','unsupported','invalid-year')for profile in('wide','compact')]
assert len(rows)==8 and [r['name']for r in rows]==expected and all(r['status']==0 for r in rows)
for group in('sources','runner_sha256'):
 for name,digest in binding[group].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(source/'scripts'))
import tls_prepare_gate as gate
from network_contention_gate import frozen_binding,owner_joins,cleanup_receipts
from check_tcp_capture import inspect as tcp,frames
from check_nic_command import inspect as nic
from check_self_wait import inspect as self_wait
contract=gate.tls_contract(source);replays={}
for row in rows:
 out=Path(row['out']);r=json.loads((out/'result.json').read_text());m=json.loads((out/'manifest.json').read_text());trace=(out/'serial.log').read_text();raw=(out/'wire.pcap').read_bytes();mode=m['mode'];assert r['ok']
 assert frozen_binding(source,a.frozen/'tested.iso',Path(m['binding']['path']))==m['binding']
 assert m['qemu_version'].startswith('QEMU emulator version ')and m['secret_capture']is False
 actual=gate.inspect_tls(trace,mode,m['command'],m['host_utc_start'],m['host_utc_end']);assert actual['ok']and actual==r['tls'],actual
 authority=nic(trace,expected=1,preparation=True,ethernet=True,network_config=True,routing=True);assert authority['ok']and self_wait(trace)['ok']
 peer=json.loads((out/'endpoint-exchanges.json').read_text());assert len(peer['public_baseline'])==1
 assert tcp(raw,peer['public_baseline'],guest_ports=range(48001,65536),initiator='guest')['ok']and owner_joins(trace,raw,[(15,15)])['ok']
 for frame in frames(raw):assert not(len(frame)>=42 and frame[12:14]==b'\x08\0'and frame[23]==17 and frame[26:30]==bytes([10,0,2,15]))
 checked=[]
 for pixel in r['pixels']:
  image=(out/pixel['screenshot']).read_bytes();assert hashlib.sha256(image).hexdigest()==pixel['screenshot_sha256']
  for name,digest in pixel['source_sha256'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
  if pixel['screenshot']=='tls-first.ppm':
   clear=re.search(r'\[shell.browser.input\] code=16 down=1 slot=43 accepted=1',trace);assert clear;prefix=trace[:clear.start()]
  elif pixel['screenshot']=='tls-cleared.ppm':
   intents=list(re.finditer(r'\[browser.tls.intent\] accepted=1 explicit=1 network=0',trace));assert len(intents)==2;prefix=trace[:intents[1].start()]
  elif pixel['screenshot']=='tls-before-close.ppm':
   closed=re.search(r'\[browser.tls.closed\] pending=1 terminal=1 owned_storage=erased',trace);assert closed;prefix=trace[:closed.start()]
  else:prefix=trace
  actual_pixels=gate.verify_tls_pixels(prefix,image,pixel['expected'],contract,list(map(int,m['resolution'].split('x'))));assert actual_pixels['ok'],actual_pixels
  checked.append(dict(screenshot=pixel['screenshot'],state=pixel['expected'],checked_pixels=actual_pixels['checked_pixels']))
 if mode=='close':
  assert len(checked)==1
  closed=re.search(r'\[browser.tls.closed\] pending=1 terminal=1 owned_storage=erased',trace);assert closed
  assert cleanup_receipts(trace,15,15,closed.start())==r['cleanup']
  assert not re.search(r'\[browser.tls.prepared\]|\[browser.tls.view\] state=HelloPending|\[net\.(?:job|dns)\.egress\.submit\]',trace[r['cleanup']['ack_offset']:])
  assert(out/'tls-closed.ppm').is_file()
 else:assert len(checked)==3
 replays[row['name']]=dict(ok=True,mode=mode,platform_profile=gate.command_profile(m['command'],mode),prerequisite_joins=r['tls']['joins'],closed_pending=r['tls']['closed_pending'],pixels=checked,private_pages=sum(int(n)for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace)),secret_values_or_derivatives_recorded=False,scope=gate.SCOPE)
result=dict(ok=True,runs=8,source_binding_sha256=hashlib.sha256((a.frozen/'source-binding.json').read_bytes()).hexdigest(),replays=replays)
if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
