from pathlib import Path
import json,sys
T=Path('/tmp');F=(T/'sexos-pending-io-d-frozen').resolve();R=F/'source';sys.path.insert(0,str(R/'scripts'))
from alpha_evidence import replay as live
from pending_io_cold_gate import replay as cold
rows=[]
for profile in ['compact','wide']:
 session=T/('sexos-pending-io-d-'+profile+'-live');recovery=T/('sexos-pending-io-d-'+profile+'-cold');a=live(R,F/'tested.iso',F/'source-binding.json',session);b=cold(R,F/'tested.iso',F/'source-binding.json',session,recovery);result=json.loads((session/'result.json').read_text());p=result['pending_io_close'];v=p['trace_proof'];assert a['ok']and not a['acceptance']and a['verified_captures']==12 and b['ok']and b['cold_recovery_verified'];rows.append(dict(profile=profile,live=a,cold=b,device_proof=v,throttle_seconds=p['profile']['armed_seconds'],pool_bytes=v['pool_ready']['bytes'],document=p['terminal_document']));print('PASS',profile,'12live+1cold captures, CID',v['cid'],'order',v['finish']['last']['index'],v['completion']['event']['index'],v['pool_ready']['first']['index'],flush=True)
result=dict(ok=True,cold_recovery_verified=True,boots=4,verified_captures=26,profiles=rows,scope='Two exact source/image profiles: normal-app actual pending device WRITE across task.finish, completion before reusable zeroed pool, five-role cleanup and successor load/pixels, then independent same-image cold boot from exact terminal disk with native load/pixels.')
(T/'sexos-pending-io-d-independent-replay.json').write_text(json.dumps(result,indent=2)+'\n')
