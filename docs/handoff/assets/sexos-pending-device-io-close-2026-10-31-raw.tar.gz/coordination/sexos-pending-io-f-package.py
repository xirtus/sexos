from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-pending-io-f-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');prior=read(T/'sexos-civil-redraw-a-frozen/source-binding.json');assert b['sources']==prior['sources']and b['iso_sha256']==prior['iso_sha256']and b['kernel_sha256']==prior['kernel_sha256']
for n,d in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==d,n
assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
h=read(T/'sexos-pending-io-f-host42/report.json');assert h['checks_passed']and len(h['checks'])==42 and not h['source_drift'];rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(r['log']).read_text())))for r in h['checks']);assert rust==2630
py=(T/'sexos-pending-io-f-python.log').read_text();assert'Ran 964 tests in 'in py and py.rstrip().endswith('OK')
v=read(T/'sexos-pending-io-f-independent-replay.json');assert v['ok']and v['cold_recovery_verified']and v['boots']==4 and v['verified_captures']==26;assert all(r['pool_bytes']==286720 and r['document']['bytes']==12286 for r in v['profiles'])
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p

def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('host',T/'sexos-pending-io-f-host42')
for profile in ['compact','wide']:
 for kind in ['live','cold']:tree('native/'+profile+'-'+kind,T/('sexos-pending-io-f-'+profile+'-'+kind))
# Earlier cohorts retain their original bytes/checkers and never add qualified boots.
for cohort in ['a','b','c','d','e']:
 tree('diagnostic/'+cohort+'/frozen',T/('sexos-pending-io-'+cohort+'-frozen'))
 if cohort in ['a','b','c']:tree('diagnostic/'+cohort+'/native',T/('sexos-pending-io-'+cohort+'-native'))
 else:
  for profile in ['compact','wide']:
   for kind in ['live','cold']:tree('diagnostic/'+cohort+'/'+profile+'-'+kind,T/('sexos-pending-io-'+cohort+'-'+profile+'-'+kind))
# All matching prototype/final helpers and logs are terminal. Exclude mutable work-state.
for p in sorted(T.glob('sexos-pending-io-*')):
 if p.is_file()and p.suffix in ('.py','.json','.log')and p.name!='sexos-pending-io-work-state.json':add('coordination/'+p.name,p)
tree('qmp-schema',T/'sexos-pending-io-qmp-schema')
add('prior/image-qualification.json',R/'docs/handoff/assets/sexos-civil-clock-repaint-2026-10-31-evidence.json')
# Both live alpha output trees/logs have different explicit names and are excluded.
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-pending-device-io-close-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 member=tarfile.TarInfo('payload-members.json');member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for member in members:
  raw=tar.extractfile(member).read();e=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if member.name=='payload-members.json'else manifest[member.name];assert len(raw)==e['bytes']and hashlib.sha256(raw).hexdigest()==e['sha256'],member.name
result=dict(qualified_virtual_pending_device_close=True,full_os_goal_complete=False,branch='codex/quil-pending-io-implementation',base='af9caf35515da34a4351170f7b0bec1a01d7db14',production_unchanged=True,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),registered_host_checks=42,rust_test_executions=rust,python_tests=964,native=dict(boots=4,verified_captures=26,profiles=v['profiles'],cold_recovery_verified=True,independent_replay=True),fixture=dict(logical_baseline_bytes=12286,immutable_snapshot_bytes=12287,unsaved_editor_bytes=12288,physical_journal_bytes=65536,write_iops=2,absolute_kill_deadline_seconds=8,throttle_seconds=[r['throttle_seconds']for r in v['profiles']],qemu_version='11.0.2',trace_format='ISO8601Z/log',namespace=1,submission_queue=1,completion_queue=1,host_trusted=True),diagnostics=dict(a='Failed expectedTID/actualISO parser prefix; native ASCII preparation worked; restored0.162s.',b='Actual WRITE overlap/recovery reached; final replay failed missing post-cleanup Linen responsiveness. Not qualified.',c='Native component passed before cold gate; no standalone cold qualification.',d='Four boots passed pre-hardened cold checker; original data preserved, not relabelled final.',e='Three successful boots then wide cold failed two-read serial snapshot race; correct guest receipts retained. Not qualified.'),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Exact normal-image real keyboard/clipboard save/decline/confirmed Close with journal WRITE still uncompleted through task9 finish, successful same-CID completion before first reusable-pool receipt, five-role cleanup and zeroed/reused286720-byte pool observation, BOOT successor load/pixels, then exact terminal-disk same-image cold boot and provider/load/full journal identity-generation-bank-payload plus glyph proof. Cancellation permits old or complete new immutable snapshot; both final profiles recover baseline. No guest/ABI/capability changes, physical power-loss/SMP/hostile containment, whole-runtime erasure/global epoch replay or general daily-driver claim.')
p=A/'sexos-pending-device-io-close-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('ARCHIVE',len(items)+1,'verified members',archive.stat().st_size,'bytes; final4boots26captures, priorprototypesexcludedfromqualification')
