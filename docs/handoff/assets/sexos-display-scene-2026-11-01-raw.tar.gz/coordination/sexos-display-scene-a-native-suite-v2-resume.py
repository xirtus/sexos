from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');P='sexos-display-scene-a';F=(T/(P+'-frozen')).resolve(strict=True);R=F/'source'
progress=T/(P+'-native-progress.json');assert progress.exists()
began_wait=time.monotonic()
while True:
 host=json.loads((T/(P+'-frozen-host/report.json')).read_text())
 if host['run_status']=='complete':
  assert host['checks_passed'] and host['sources_unchanged_during_checks'] and len(host['checks'])==44;break
 if time.monotonic()-began_wait>900:raise TimeoutError('host observation deadline; no guest restart')
 time.sleep(10)
rows=json.loads(progress.read_text());assert len(rows)==4 and all(row['status']==0 for row in rows)
assert all(row.get('fresh_replay',False)for row in rows[:3]) and rows[3]['name']=='browser-compact' and not rows[3].get('fresh_replay',False)
row=rows[3];out=Path(row['out']);result=json.loads((out/'result.json').read_text());assert result['ok']and len(result['frames'])==10
check=row['command'][:];at=check.index('--source-disk');del check[at:at+2];check+=['--check'];replay=T/(P+'-native-browser-compact-independent-replay.json');assert not replay.exists()
with replay.open('x')as log:r=subprocess.run(check,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
assert r.returncode==0;verified=json.loads(replay.read_text());assert verified['ok']and verified['captures']==10
row.update(fresh_replay=True,boots=1,captures=10,replay=str(replay));progress.write_text(json.dumps(rows,indent=2)+'\n');print('RECOVER_READ_ONLY_browser-compact_PASS_NO_GUEST_RESTART',flush=True)
completed={row['name']for row in rows};plan=[]
for label,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 for mode in ('normal','invalid-year'):plan.append(('clock-'+mode+'-'+label,'certificate_time_gate.py',['--mode',mode],model,res,1,4,'clock'))
 plan.append(('connected-'+label,'connected_desktop_gate.py',[],model,res,2,17,'connected'))
 plan.append(('browser-'+label,'browser_reserve_gate.py',['--mode','quiesced'],model,res,1,10,'browser'))
for name,script,extra,model,res,boots,captures,kind in plan:
 if name in completed:continue
 out=T/(P+'-native-'+name);driver=T/(P+'-native-'+name+'.driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',res,*extra]
 row=dict(name=name,kind=kind,out=str(out),command=command,status='running');rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');print('START',name,flush=True);began=time.monotonic()
 with driver.open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 result=json.loads((out/'result.json').read_text());assert result['ok']
 if kind=='clock':assert len(result['pixels'])==captures and all(v['civil_clock']['ok'] for v in result['pixels'])
 elif kind=='connected':assert result['boots']==boots and result['frames']==captures
 else:assert len(result['frames'])==captures
 check=command[:];at=check.index('--source-disk');del check[at:at+2];check+=['--check'];replay=T/(P+'-native-'+name+'-independent-replay.json')
 with replay.open('x')as log:r=subprocess.run(check,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert r.returncode==0;verified=json.loads(replay.read_text());assert verified['ok']
 if kind=='connected':assert verified['boots']==boots and verified['frames']==captures and verified['same_image']
 else:assert verified['captures']==captures
 row.update(fresh_replay=True,boots=boots,captures=captures,replay=str(replay));progress.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==8 and sum(r['boots']for r in rows)==10 and sum(r['captures']for r in rows)==70
print('EIGHT_NATIVE_WORKFLOWS_PASS_10_BOOTS_70_CAPTURES',flush=True)
