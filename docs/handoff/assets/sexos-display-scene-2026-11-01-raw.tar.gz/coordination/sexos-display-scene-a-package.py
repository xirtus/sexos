"""Round166 exact eleven-boot/seventy-capture evidence package.
Root must pin executed helpers, review, and run after all native outputs stop.
No guest/build actions: only frozen read-only --check/API replay, then archive.
"""
from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,subprocess,tarfile
T=Path('/tmp');P='sexos-display-scene-a'
COMMIT='c947cccd53c7a4b7513b93c1c480eda502ea1fa6'
BASELINE='398810b4f168f0fe41d2131fda8bf173f9b5cf49'
BASELINE_BINDING_SHA256='1ff1034fbfb7dffb143923da4455bc211f0fb8c16cf5334dc50879c9e8db8442'
# Root fills final exact executed-source hashes after orchestration completes.
# Both original v1 coordinator and v2 read-only-recovery/resume are mandatory.
EXECUTED_HELPER_SHA256={'/tmp/sexos-display-scene-a-source-audit.py': 'c3270fb85b1964f134153ea86f9700a8d7c484a9e6a84db027d940648b590ba6', '/tmp/sexos-display-scene-a-scalar-audit.py': '1d229b9129361dc6563deb1e8c4b4bc9e2f72e13d290b19ff2d25479588dc88d', '/tmp/sexos-display-scene-a-budget-audit.py': 'e698281cbe313c3d2e582a4685e204cc83b1e67e1d5c634e1166daa29dc3abf4', '/tmp/sexos-display-scene-a-boot-audit.py': 'bfbb3eab07e08efece0b56aaa0d84b7a7abe326a0d03f9756e073236ce9360e8', '/tmp/sexos-display-scene-a-native-suite.py': '7c5d9f02dc5e3336bdc61b529d737f0a57f87351886cf0fa596c5d8c5eab266c', '/tmp/sexos-display-scene-a-native-suite-v2-resume.py': '30a59acf6d1f1a4afabfa5fcea2686d26fcdad524c475fa0984c9e1147d1d8b8', '/tmp/sexos-display-scene-a-production-equivalence.py': '4c1c8d9c6b7abb9bed244ad2a7c8c70aa3000bdf6380ad87956d33982a8fa501'}
# Optional exact R166 preflight diagnostics; never acceptance evidence.
UNQUALIFIED_DIAGNOSTIC_SHA256={'/tmp/sexos-r166-display-typecheck.log': '99c0409410d9a6878ab62b83855cf9005fbc5b3013c6f4132ade016c5bd13ab3', '/tmp/sexos-r166-main-compositor.log': '8da81450a2b900c77e65d9677b14c6e11e3bf8b72551dfbb286b72c9e3591575', '/tmp/sexos-r166-compositor-assembled.log': '2d3327b685c5bd2365e4fc16dc8527326241086ee9429a14759e5841efd13163', '/tmp/sexos-r166-main-clock-oracle.log': 'e70fec2825d9bf206d27463a792768195039599cb39bcca66339f47283f84cce'}
EXPECTED_CHANGED=['servers/sexdisplay/src/bitmap_stores.rs','servers/sexdisplay/src/bitmap_transaction.rs','servers/sexdisplay/src/main.rs','servers/sexdisplay/src/surface_groups.rs']
EXPECTED_ADDED=['servers/sexdisplay/src/scene.rs']
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}

def require(value,why):
 if not value:raise AssertionError(why)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def marker(text,tag):
 matches=re.findall(r'^\['+re.escape(tag)+r'\] PASS (\{[^\n]+\})$',text,re.M)
 require(len(matches)==1,('exact host proof marker',tag));return json.loads(matches[0])
def plan():
 rows=[]
 for profile,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
  for mode in ('normal','invalid-year'):rows.append(dict(name=f'clock-{mode}-{profile}',kind='clock',script='certificate_time_gate.py',extra=['--mode',mode],model=model,resolution=res,boots=1,captures=4,mode=mode))
  rows.append(dict(name='connected-'+profile,kind='connected',script='connected_desktop_gate.py',extra=[],model=model,resolution=res,boots=2,captures=17))
  rows.append(dict(name='browser-'+profile,kind='browser',script='browser_reserve_gate.py',extra=['--mode','quiesced'],model=model,resolution=res,boots=1,captures=10,mode='quiesced'))
 return rows

def main():
 F=(T/(P+'-frozen')).resolve(strict=True);R=F/'source'
 archive=T/(P+'-2026-11-01-raw.tar.gz');receipt_path=T/(P+'-package-result.json')
 require(not archive.exists()and not receipt_path.exists(),'archive/receipt already exists; never overwrite')
 required={str(T/(P+s))for s in ('-source-audit.py','-scalar-audit.py','-budget-audit.py','-boot-audit.py','-native-suite.py','-native-suite-v2-resume.py')}
 require(required<=set(EXECUTED_HELPER_SHA256),'Root must pin all six executed auditor/coordinator sources')
 for path,digest in {**EXECUTED_HELPER_SHA256,**UNQUALIFIED_DIAGNOSTIC_SHA256}.items():
  require(re.fullmatch('[0-9a-f]{64}',digest)and sha(path)==digest,('executed helper/diagnostic changed',path))
 b=read(F/'source-binding.json');require(b['build_provenance']['git_revision']==COMMIT and b['build_provenance']['build_gate']=='PASS'and b['build_provenance']['sources_unchanged_during_build'],'exact sealed source')
 require(sha(F/'tested.iso')==b['iso_sha256']and sha(F/'tested.kernel')==b['kernel_sha256'],'current sealed image/kernel')
 closure={**b['sources'],**b['runner_sha256']}
 require((len(b['sources']),len(b['runner_sha256']),len(closure))==(583,631,1214),'exact source membership counts')
 require(set(closure)=={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and '__pycache__'not in p.parts},'exact frozen source closure')
 for name,digest in closure.items():
  p=R/name;require(p.resolve().is_relative_to(R)and not p.is_symlink()and sha(p)==digest,('frozen source changed',name))
 require(sum((R/n).stat().st_size for n in closure)==12105849,'exact frozen byte count')
 source=read(T/(P+'-source-audit.json'));scalar=read(T/(P+'-scalar/result.json'));host=read(T/(P+'-frozen-host/report.json'));budget=read(T/(P+'-budget-audit.json'))
 require(source['ok']and(source['commit'],source['iso_sha256'],source['kernel_sha256'],source['unique'],source['total_source_bytes'])==(COMMIT,b['iso_sha256'],b['kernel_sha256'],1214,12105849),'source audit binding/counts')
 require(len(source['rows'])==1214 and {v['path']for v in source['rows']}==set(closure),'all audited Git/source rows')
 for row in source['rows']:require(row['sha256']==closure[row['path']]and row['size']==(R/row['path']).stat().st_size,('source audit row',row['path']))
 require(scalar['ok']and scalar['commit']==COMMIT and scalar['iso_sha256']==b['iso_sha256']and scalar['total_instructions']==324383 and len(scalar['results'])==9,'current nine-ELF scalar scan')
 require({r['name']for r in scalar['results']}=={'kaleidoscope','silk-shell','sexdisplay','quil','silkbar','sexfiles','spindle','linen','sexnet'},'exact scalar ELF set')
 require(sum(r['instructions']for r in scalar['results'])==324383,'scalar aggregate')
 for row in scalar['results']:
  require(not row['vector_or_fp_matches']and row['instructions']>0,'scalar scan failure')
  for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/(P+'-scalar')/(row['name']+suffix))==row[key],'scalar bytes changed')
 require(host['run_status']=='complete'and host['checks_passed']and host['sources_unchanged_during_checks']and len(host['checks'])==44 and all(r['exit_code']==0 for r in host['checks']),'all current44 registered host checks')
 checks={r['id']:r for r in host['checks']};require(len(checks)==44,'unique host check IDs')
 for name,digest in host['source_sha256'].items():require(closure[name]==digest,('host source binding',name))
 obligations=host['obligations'];require(host['system_proven']is False and len(obligations)==30 and sum(v=='partial'for v in obligations.values())==28 and {k for k,v in obligations.items()if v=='open'}=={'EPOCH_COMMIT','DETERMINISTIC_REPLAY'},'honest Open2/Partial28 obligations')
 rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(r['log']).read_text())))for r in host['checks'])
 scene=marker(Path(checks['display_scene']['log']).read_text(),'display.scene.host')
 require(scene['ok']and(scene['actual_cases'],scene['compiled_runtime_mutants'],scene['source_fence_controls'])==(11,6,2),'actual scene/lease host proof')
 for path,digest in scene['sha256'].items():require(Path(path).resolve().is_relative_to(R)and sha(path)==digest,('scene host source',path))
 groups_log=Path(checks['display_surface_groups']['log']).read_text();require(len(re.findall(r'test result: ok\. 46 passed; 0 failed;',groups_log))==1,'actual46 compositor cases')
 bitmap=marker(groups_log,'bitmap.stores.host');require(bitmap['ok']and(bitmap['actual_case_executions'],bitmap['future_case_executions'],bitmap['compiled_mutants_rejected'],bitmap['published_bytes'],bitmap['published_stores3_bytes'])==(17,17,5,9272,27816),'actual bitmap snapshot controls')
 py=(T/(P+'-frozen-python.log')).read_text();counts=re.findall(r'Ran (\d+) tests in ',py);require(counts==['1132']and py.rstrip().endswith('OK')and 'FAILED ('not in py,'exact1132 Python tests')
 baseline_path=T/'sexos-clock-date-c-frozen/source-binding.json';prior=read(baseline_path);prior_root=baseline_path.parent/'source'
 require(prior['build_provenance']['git_revision']==BASELINE and sha(baseline_path)==BASELINE_BINDING_SHA256,'qualified R165 reference binding only')
 current_keys=set(b['sources']);old_keys=set(prior['sources']);changed=sorted(n for n in current_keys&old_keys if b['sources'][n]!=prior['sources'][n]);added=sorted(current_keys-old_keys);removed=sorted(old_keys-current_keys)
 require(len(old_keys)==582 and changed==EXPECTED_CHANGED and added==EXPECTED_ADDED and not removed,'exact four changed Display modules plus scene addition')
 comparison=read(T/(P+'-production-equivalence.json'))
 for k,v in dict(ok=True,baseline_commit=BASELINE,candidate_commit=COMMIT,baseline_production=582,candidate_production=583,changed=changed,added=added,removed=[],unchanged=578,kernel_identical=True,baseline_kernel_sha256=prior['kernel_sha256'],candidate_kernel_sha256=b['kernel_sha256'],abi_inputs=66).items():require(comparison[k]==v,('production comparison',k))
 require(prior['kernel_sha256']==b['kernel_sha256'],'unchanged kernel bytes')
 def abi_inputs(root):
  text=(root/'scripts/entrypoint_build.sh').read_text();found=re.findall(r'^ABI_INPUTS=\(\n(.*?)\n\)',text,re.M|re.S);require(len(found)==1,'exact ABI list');values=found[0].split();require(len(values)==len(set(values))==66,'exact66 ABI inputs');return values
 names=abi_inputs(R);require(names==abi_inputs(prior_root),'ABI input order unchanged')
 for n in names:require(sha(R/n)==sha(prior_root/n),'ABI input changed: '+n)
 abi=hashlib.sha256(''.join(sha(R/n)+'  '+n+'\n'for n in names).encode()).hexdigest();require(abi==comparison['abi_sha256'],'actual ABI hash')
 display=next(v for v in scalar['results']if v['name']=='sexdisplay')
 require(budget['ok']and budget['scene_static_bytes']==59584 and budget['elf_sha256']==display['elf_sha256']and budget['elf_bytes']==display['elf_size'],'actual scene ELF/static symbol budget')
 symbols=(T/(P+'-scalar/sexdisplay-symbols.txt')).read_text();require(symbols.splitlines().count(budget['symbol'])==1 and re.search(r'\b000000000000e8c0\b',budget['symbol']),'exact static symbol receipt')
 for name,local in [('_start',5096),('render',2312)]:require(budget['frames']['candidate'][name]['local_reservation_bytes']==local and budget['frames']['candidate'][name]['register_push_bytes']==48,'measured prologue only')
 prior_scalar=read(T/'sexos-clock-date-c-scalar/result.json');require(prior_scalar['ok']and prior_scalar['commit']==BASELINE and prior_scalar['iso_sha256']==prior['iso_sha256'],'baseline budget-only scalar reference')
 old_display=next(v for v in prior_scalar['results']if v['name']=='sexdisplay')
 for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/('sexos-clock-date-c-scalar/sexdisplay'+suffix))==old_display[key],'baseline Display budget reference bytes')
 require(budget['prior_elf_bytes']==old_display['elf_size']and budget['elf_byte_delta']==budget['elf_bytes']-budget['prior_elf_bytes'],'measured Display ELF size difference')
 for label,prefix in [('candidate',P),('prior','sexos-clock-date-c')]:
  assembly=(T/(prefix+'-scalar/sexdisplay.asm')).read_text()
  require(set(budget['frames'][label])=={'_start','render'},'only two measured prologues')
  for frame in budget['frames'][label].values():require('\n'.join(frame['prologue'])in assembly,'prologue bytes no longer match bound disassembly')
 require(budget['app_private_pages']==2465 and budget['boot_heap']['physical_free_frames']=='unmeasured','do not infer disjoint/physical free memory')
 audit=read(T/(P+'-boot-audit.json'));rows=read(T/(P+'-native-progress.json'));planned=plan()
 require(len(rows)==8 and len(planned)==8,'all eight terminal workflows required')
 require((T/(P+'-native-suite-v2-resume.driver.log')).read_text().rstrip().endswith('EIGHT_NATIVE_WORKFLOWS_PASS_10_BOOTS_70_CAPTURES'),'resume coordinator must finish successfully')
 expected={(T/(P+'-build/serial.log')).resolve()}
 for spec in planned:
  out=T/(P+'-native-'+spec['name'])
  expected|={out.resolve()/phase/'serial.log'for phase in ('session','recovery')}if spec['kind']=='connected'else{out.resolve()/'serial.log'}
 require(audit['ok']and audit['mode']=='explicit_eleven_boot_inventory'and audit['boots']==audit['expected_final_boots']==11 and audit['final_cohort_complete'],'full eleven-boot audit, not smoke')
 require(audit['frozen']['revision']==COMMIT and audit['frozen']['binding_sha256']==sha(F/'source-binding.json'),'BOOT audit binding')
 require(len(audit['observations'])==11 and {Path(o['path']).resolve()for o in audit['observations']}==expected,'exact eleven boot paths')
 for o in audit['observations']:
  require(Path(o['path']).stat().st_size==o['bytes']and sha(o['path'])==o['sha256'],'audited serial changed')
  require((o['apps'],o['registered_main_domains'],o['self_wait_capacity'],o['private_pages'])==(28,40,64,2465),'unchanged actual inventory')
  require(o['denial_storage']==dict(bytes=1352,owners=28,slots=84,bound=4096,public=1)and o['original_five_authority_lines_byte_identical'],'source authority/layout receipt')
  require(o['heap_budget']==budget['boot_heap'],'exact post-seal heap snapshot')
 # Preserve the failed original coordinator without rejecting completed raw
 # guest runs: its fourth guest exited0, then result["captures"] raised KeyError.
 v1=read(T/(P+'-native-progress-v1-terminal.json'));v1log=(T/(P+'-native-suite.driver.log')).read_text()
 require(len(v1)==4 and all(r['status']==0 for r in v1)and all(r.get('fresh_replay')is True for r in v1[:3])and not v1[3].get('fresh_replay',False),'exact v1 coordinator diagnostic')
 require(v1[3]['name']=='browser-compact'and "KeyError: 'captures'"in v1log and 'END browser-compact 0'in v1log,'observed v1 schema mismatch only')
 for index,old in enumerate(v1):
  for key in('name','kind','out','command','status','seconds'):require(rows[index][key]==old[key],('completed compact command identity changed',index,key))
 proofs={};capture_counts={};memory_receipts={};outdirs={};replays=[]
 for spec,row in zip(planned,rows):
  out=(T/(P+'-native-'+spec['name'])).resolve(strict=True);outdirs[spec['name']]=out
  require(row['name']==spec['name']and row['kind']==spec['kind']and Path(row['out']).resolve()==out and row['status']==0 and row['fresh_replay']is True and row['boots']==spec['boots']and row['captures']==spec['captures'],'exact terminal workflow row')
  command=['python3',str(R/'scripts'/spec['script']),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(T/(P+'-native-'+spec['name'])),'--model',spec['model'],'--resolution',spec['resolution'],*spec['extra']]
  require(row['command']==command,'exact native invocation source/image/profile')
  check=command[:];at=check.index('--source-disk');del check[at:at+2];check+=['--check']
  replay=T/(P+'-native-'+spec['name']+'-independent-replay.json');require(Path(row['replay']).resolve()==replay.resolve(strict=True),'exact saved replay path')
  run=subprocess.run(check,capture_output=True,text=True,timeout=300,env=ENV);require(run.returncode==0,('fresh frozen read-only replay',spec['name'],run.stderr[-2000:]))
  fresh=json.loads(run.stdout);saved=read(replay);result=read(out/'result.json');require(fresh==saved and fresh['ok']and result['ok'],'saved/current replay disagreement');replays.append(replay)
  manifests=[read(out/phase/'manifest.json')for phase in ('session','recovery')]if spec['kind']=='connected'else[read(out/'manifest.json')]
  for manifest in manifests:require(manifest['resolution']==spec['resolution']and manifest['model']==spec['model'],'native profile metadata')
  manifest=manifests[0]
  if spec['kind']=='clock':
   require(manifest['mode']==spec['mode']and fresh==dict(ok=True,mode=spec['mode'],captures=4),'exact clock CLI summary')
   code="import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;r=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(r/'scripts'));from certificate_time_gate import replay_evidence;print(json.dumps(replay_evidence(r,Path(sys.argv[2]).resolve(strict=True),Path(sys.argv[3]).resolve(strict=True),Path(sys.argv[4]).resolve(strict=True))))"
   api=subprocess.run(['python3','-c',code,str(R),str(F/'tested.iso'),str(F/'source-binding.json'),str(out)],capture_output=True,text=True,timeout=300,env=ENV);require(api.returncode==0,('full clock replay API',spec['name'],api.stderr[-2000:]));full=json.loads(api.stdout)
   require({n:full[n]for n in('ok','mode','captures')}==fresh and len(full['pixels'])==len(result['pixels'])==4 and all(p['ok']and p['civil_clock']['ok']and p['civil_clock']['caption_profile']=='date-caption-v1'for p in full['pixels']),'four independently replayed full clock/chip pixels')
   fresh=full;memory_receipts['fresh-full-clock/'+spec['name']+'.json']=(json.dumps(full,indent=2,sort_keys=True)+'\n').encode()
  elif spec['kind']=='connected':require(fresh['boots']==2 and fresh['frames']==17 and fresh['same_image']and fresh['same_disk_state']and fresh['full_alpha_acceptance']is False,'representative connected two-boot proof')
  else:
   require(result['mode']=='quiesced'and len(result['frames'])==10 and fresh['captures']==10 and fresh['browser_pixels_qualified']and fresh['launcher_pixels_qualified'],'three held Browser incarnations, nine TLS panels and exhaustion capture')
   require([v['identity']['target']for v in result['chain']]==[15,30,31],'exact current Browser chain')
  proofs[spec['name']]=fresh;capture_counts[spec['name']]=spec['captures']
 require(sum(r['boots']for r in rows)==10 and sum(capture_counts.values())==70,'exact10 native boots/70 captures plus sealed boot')
 # All acceptance preconditions above precede archive creation. Normalized tar
 # metadata/gzip header make repeat construction from identical inputs stable.
 items={}
 def add(name,path):
  path=Path(path);member=PurePosixPath(name);require(not member.is_absolute()and '..'not in member.parts and name not in items,'unsafe/duplicate archive member')
  require(path.is_file()and not path.is_symlink()and path.suffix!='.img',(name,path));items[name]=path
 def tree(prefix,folder):
  folder=Path(folder);require(folder.is_dir(),folder)
  for path in sorted(folder.rglob('*')):
   if path.is_file()and path.suffix!='.img'and '__pycache__'not in path.parts:add(prefix+'/'+str(path.relative_to(folder)),path)
 for name,folder in [('frozen',F),('sealed-build',T/(P+'-build')),('host',T/(P+'-frozen-host')),('scalar',T/(P+'-scalar'))]:tree('qualified/'+name,folder)
 for name,out in outdirs.items():tree('qualified/native/'+name,out)
 diagnostic_names={P+'-native-progress-v1-terminal.json',P+'-native-suite.driver.log'}
 for path in sorted(T.glob(P+'-*')):
  if path.is_file()and path.suffix in('.json','.log','.py','.sh','.txt')and path!=receipt_path and not(path.name.startswith(P+'-package')and path.suffix=='.log'):
   prefix='UNQUALIFIED/coordinator-or-preflight'if path.name in diagnostic_names or 'preflight'in path.name else'coordination'
   add(prefix+'/'+path.name,path)
 for path in EXECUTED_HELPER_SHA256:add('executed-helpers/'+Path(path).name,path)
 for path in UNQUALIFIED_DIAGNOSTIC_SHA256:add('UNQUALIFIED/pinned-preflight/'+Path(path).name,path)
 for path in replays:add('fresh-checks/'+path.name,path)
 add('reference/R165-source-binding.json',baseline_path)
 for name in ('result.json','sexdisplay.elf','sexdisplay.asm'):add('reference/R165-budget-only/'+name,T/'sexos-clock-date-c-scalar'/name)
 require(sha(audit['reference']['path'])==audit['reference']['sha256'],'original authority reference changed');add('reference/original-authority.serial.log',audit['reference']['path'])
 summary=dict(ok=True,round=166,source_commit=COMMIT,source_binding_sha256=sha(F/'source-binding.json'),iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],host=dict(registered=44,rust_log_test_executions=rust,python_tests=1132,scene=scene,bitmap=bitmap,compositor_cases=46),source=dict(files=1214,bytes=12105849),scalar=dict(elfs=9,instructions=324383,vector_fp_matches=0),budget=budget,production_comparison=comparison,native=dict(boots=11,sealed_build_boots=1,native_boots=10,clock_boots=4,connected_boots=4,browser_boots=2,capture_counts=capture_counts,qualified_captures=70,proofs=proofs,alpha_acceptance=False,sustained_acceptance=False,complete_all_app_reserves=False),boot_observations=audit['observations'],obligations=obligations,system_proven=False,executed_helpers=EXECUTED_HELPER_SHA256,coordinator_diagnostic=dict(terminal=1,cause='v1 result.captures KeyError; browser result stores frames',completed_guest_commands=4,guest_command_failures=0,compact_guest_restart=False,recovery='v2 read-only replay of compact Browser, then four previously unstarted wide workflows; every accepted run freshly replayed'),scope='Display-owned committed scene snapshot and scoped release; not complete epochs or deterministic replay. Native evidence: clock/date, representative connected session/cold recovery, and current Browser15→30→31 quiesced Close/panel/exhaustion controls. No Alpha/1800-second, full all-app reserve chain, performance speedup, hardware/SMP/hostile isolation, physical erasure, or atomic framebuffer publication claim. Stack measurements cover two function prologues only; private app pages and Display backing are not additive disjoint memory totals. Earlier images transfer no native acceptance.')
 manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path))for name,path in items.items()}
 embedded={**memory_receipts,'COHORT.json':(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode(),'SCOPE.md':b'Round166: eleven explicit boots and seventy captures only after fresh frozen replay. Open2/Partial28. R165 binding/Display ELF references support source/kernel/budget comparison, not acceptance transfer. Original v1 coordinator failed after completed compact Browser; its raw run is accepted only by final strict replay. Failed preflight/coordinator diagnostics remain UNQUALIFIED. No Alpha/1800s/performance/hardware/full-epoch claim.\n'}
 for name,data in embedded.items():require(name not in manifest,'embedded member collision');manifest[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
 with archive.open('xb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9)as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT)as tar:
  for name in sorted(set(items)|set(embedded)|{'MANIFEST.json'}):
   info=tarfile.TarInfo(name);info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
   if name in items:
    info.size=manifest[name]['bytes']
    with items[name].open('rb')as stream:tar.addfile(info,stream)
   else:payload=data if name=='MANIFEST.json'else embedded[name];info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();require(len(members)==len(manifest)+1 and all(m.isfile()for m in members),'archive member count/type')
  require({m.name for m in members}==set(manifest)|{'MANIFEST.json'},'exact archive names');require(tar.extractfile('MANIFEST.json').read()==data,'manifest reopen')
  for name,meta in manifest.items():
   payload=tar.extractfile(name).read();require(len(payload)==meta['bytes']and hashlib.sha256(payload).hexdigest()==meta['sha256'],('archive member changed',name))
 for name,path in items.items():require(path.stat().st_size==manifest[name]['bytes']and sha(path)==manifest[name]['sha256'],('input changed during packaging',name))
 receipt=dict(ok=True,archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_reopened_verified=True,cohort=summary)
 with receipt_path.open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
