from pathlib import Path
import hashlib,json,re,shlex,subprocess
T=Path('/tmp');P='sexos-display-scene-a';F=T/(P+'-frozen');B=T/'sexos-clock-date-c-frozen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'source-binding.json')=='1ff1034fbfb7dffb143923da4455bc211f0fb8c16cf5334dc50879c9e8db8442'
a=json.loads((B/'source-binding.json').read_text());b=json.loads((F/'source-binding.json').read_text())
assert a['build_provenance']['git_revision']=='398810b4f168f0fe41d2131fda8bf173f9b5cf49'
assert b['build_provenance']['git_revision']=='c947cccd53c7a4b7513b93c1c480eda502ea1fa6'
x,y=a['sources'],b['sources'];added=sorted(y.keys()-x.keys());removed=sorted(x.keys()-y.keys());changed=sorted(n for n in x.keys()&y.keys()if x[n]!=y[n])
assert len(x)==582 and len(y)==583 and not removed and added==['servers/sexdisplay/src/scene.rs']
assert changed==['servers/sexdisplay/src/bitmap_stores.rs','servers/sexdisplay/src/bitmap_transaction.rs','servers/sexdisplay/src/main.rs','servers/sexdisplay/src/surface_groups.rs']
s=(F/'source/scripts/entrypoint_build.sh').read_text();m=re.search(r'ABI_INPUTS=\(\n(.*?)\n\)',s,re.S);assert m
inputs=shlex.split(m[1],comments=True);raw=subprocess.check_output(['sha256sum',*inputs],cwd=F/'source');abi=hashlib.sha256(raw).hexdigest()
assert len(inputs)==66 and abi=='ff1d1346b449ed2efe6e5cffbc9c545b27d4d351979ad890fac43ffaa9725ba8'
result=dict(ok=True,baseline_commit=a['build_provenance']['git_revision'],candidate_commit=b['build_provenance']['git_revision'],baseline_production=len(x),candidate_production=len(y),added=added,removed=removed,changed=changed,unchanged=len(x)-len(changed),kernel_identical=sha(B/'tested.kernel')==sha(F/'tested.kernel'),baseline_kernel_sha256=sha(B/'tested.kernel'),candidate_kernel_sha256=sha(F/'tested.kernel'),abi_inputs=len(inputs),abi_sha256=abi,scope='Exact source set and hash comparison; code identity does not establish runtime authority inventory or native functional acceptance.')
saved=json.loads((T/(P+'-production-equivalence.json')).read_text());assert result==saved
print(json.dumps(result,indent=2))
