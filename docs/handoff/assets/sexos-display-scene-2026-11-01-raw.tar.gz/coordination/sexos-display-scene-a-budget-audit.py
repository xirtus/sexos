from pathlib import Path
import hashlib,json,re,subprocess
T=Path('/tmp');P='sexos-display-scene-a';O=T/(P+'-scalar')
tool=Path('/Users/xmacbookm5/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
elf=O/'sexdisplay.elf';symbols=subprocess.check_output([str(tool),'--syms',str(elf)],text=True)
(O/'sexdisplay-symbols.txt').write_text(symbols)
matches=[line for line in symbols.splitlines()if 'RENDER_SCENE' in line]
assert len(matches)==1 and re.search(r'\b000000000000e8c0\b',matches[0])
sections=subprocess.check_output([str(tool),'--section-headers',str(elf)],text=True)
(O/'sexdisplay-sections.txt').write_text(sections)
frames={}
for label,prefix in [('prior','sexos-clock-date-c'),('candidate',P)]:
 path=T/(prefix+'-scalar/sexdisplay.asm');text=path.read_text();blocks=re.split(r'(?m)^(?=[0-9a-f]{16} <)',text)
 frames[label]={}
 for name,tag in [('_start','<_start>'),('render','10sexdisplay6render>')]:
  found=[block for block in blocks if block.splitlines()and tag in block.splitlines()[0]];assert len(found)==1
  lines=found[0].splitlines()[:12];prologue='\n'.join(lines);m=re.search(r'subq\s+\$0x([0-9a-f]+), %rsp',prologue);assert m
  frames[label][name]=dict(local_reservation_bytes=int(m[1],16),register_push_bytes=8*len(re.findall(r'\bpushq\b',prologue)),prologue=lines)
assert frames['candidate']['render']['local_reservation_bytes']==0x908
assert frames['candidate']['_start']['local_reservation_bytes']==0x13e8
smoke=json.loads((T/(P+'-boot-audit-smoke.json')).read_text());assert smoke['ok']and smoke['boots']==1
current=json.loads((O/'result.json').read_text());old=json.loads((T/'sexos-clock-date-c-scalar/result.json').read_text())
cur=next(r for r in current['results']if r['name']=='sexdisplay');prior=next(r for r in old['results']if r['name']=='sexdisplay')
r=dict(ok=True,scene_static_bytes=59584,symbol=matches[0],elf_sha256=sha(elf),elf_bytes=cur['elf_size'],prior_elf_bytes=prior['elf_size'],elf_byte_delta=cur['elf_size']-prior['elf_size'],frames=frames,boot_heap=smoke['observations'][0]['heap_budget'],app_private_pages=smoke['observations'][0]['private_pages'],scope='Exact ISO Display ELF symbol size and two actual function prologue reservations. Prologues exclude transitive callees, interrupts and dynamic paths. BOOT heap is its recorded allocator snapshot; physical free frames remain unmeasured. App-private pages exclude Display backing and must not be added as disjoint total memory.')
(T/(P+'-budget-audit.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
