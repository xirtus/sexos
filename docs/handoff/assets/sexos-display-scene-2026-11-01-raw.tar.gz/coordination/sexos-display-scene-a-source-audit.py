from pathlib import Path
import json,hashlib,subprocess
T=Path('/tmp');F=T/'sexos-display-scene-a-frozen'
REPO=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex')
COMMIT='c947cccd53c7a4b7513b93c1c480eda502ea1fa6'
ARCH='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
def sha(data):return hashlib.sha256(data).hexdigest()
b=json.loads((F/'source-binding.json').read_text());p=b['build_provenance']
assert p['git_revision']==COMMIT and p['build_gate']=='PASS' and p['sources_unchanged_during_build'] is True
assert b['architecture_sha256']==ARCH
assert b['sources']==p['production_source_sha256']
assert sha((F/'tested.iso').read_bytes())==b['iso_sha256']==p['iso_sha256']
assert sha((F/'tested.kernel').read_bytes())==b['kernel_sha256']==p['kernel_sha256']
groups={k:b[k]for k in ['sources','runner_sha256']};names=sorted(set().union(*groups.values()))
physical={str(path.relative_to(F/'source'))for path in (F/'source').rglob('*')if path.is_file()}
assert physical==set(names),dict(unbound=sorted(physical-set(names)),missing=sorted(set(names)-physical))
command=['git','-C',str(REPO),'cat-file','--batch']
raw=subprocess.check_output(command,input=''.join(COMMIT+':'+n+'\n'for n in names).encode());at=0;rows=[]
for name in names:
 end=raw.index(b'\n',at);header=raw[at:end].split();assert len(header)==3 and header[1]==b'blob',(name,header)
 size=int(header[2]);start=end+1;blob=raw[start:start+size];assert len(blob)==size and raw[start+size:start+size+1]==b'\n';at=start+size+1
 frozen=(F/'source'/name).read_bytes();digest=sha(blob)
 assert len(frozen)==size and sha(frozen)==digest,name
 for group in groups.values():
  if name in group:assert digest==group[name],name
 rows.append(dict(path=name,git_blob_oid=header[0].decode(),size=size,sha256=digest,groups=[key for key,group in groups.items()if name in group]))
assert at==len(raw)
assert sha((F/'source/ARCHITECTURE.md').read_bytes())==ARCH
result=dict(ok=True,commit=COMMIT,architecture_sha256=ARCH,production=len(groups['sources']),runner=len(groups['runner_sha256']),unique=len(names),frozen_source_files=len(physical),total_source_bytes=sum(row['size']for row in rows),iso_sha256=b['iso_sha256'],iso_size=(F/'tested.iso').stat().st_size,kernel_sha256=b['kernel_sha256'],kernel_size=(F/'tested.kernel').stat().st_size,command=command,rows=rows,scope='Every frozen source blob matches exact pinned Git commit size/SHA256 and all production/runner manifest memberships; frozen image hashes match sealed provenance. No HEAD lookup, build or guest execution.')
(T/'sexos-display-scene-a-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ('rows','command')},indent=2))
