from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-appearance-b-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-appearance-b-source-audit.json');boot=read(T/'sexos-appearance-b-boot-audit.json');h=read(T/'sexos-appearance-b-host/report.json');rows=read(T/'sexos-appearance-b-alpha-progress.json');scalar=read(T/'sexos-appearance-b-scalar-v2/result.json')
assert audit['ok']and boot['ok']and boot['boots']==3
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks'])
assert 'Ran 977 tests in 'in(T/'sexos-appearance-b-python.log').read_text()
assert len(rows)==2 and all(row['status']==0 and row['fresh_replay']for row in rows)and sum(row['verified_captures']for row in rows)==50
assert scalar['ok']and len(scalar['results'])==5  and all(not r['vector_or_fp_matches']for r in scalar['results'])
proofs=[]
for row in rows:
 r=read(Path(row['out'])/'result.json');assert r['ok']and not r['acceptance'];chain=r['soak']['third_quil']['chain'];assert [s['target']for s in chain]==[18,19,20,21,22,23]
 for step in chain:
  v=step['frame'];expected=dict(focus=step['surface'],app='Quil',indicator='0xcba6f7');assert v['proof']['native_family']==expected;proofs.append(dict(profile=row['profile'],target=step['target'],family=expected,frame_sha256=v['screenshot_sha256']))
assert len(proofs)==12
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('frozen',F),('sealed-build',T/'sexos-appearance-b-build'),('host',T/'sexos-appearance-b-host'),('scalar',T/'sexos-appearance-b-scalar-v2')]:tree(prefix,root)
for row in rows:tree('native/'+Path(row['out']).name,Path(row['out']))
for name in ['sexos-appearance-a-frozen','sexos-appearance-a-build','sexos-appearance-a-host','sexos-appearance-a-alpha-compact']:
 tree('diagnostics/'+name,T/name)
assert not read(T/'sexos-appearance-a-alpha-compact/result.json')['ok']
for p in sorted(T.glob('sexos-appearance-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-catalog-native-appearance-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=138,qualified_catalog_family_appearance=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='a780da6c',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,diagnostics=dict(native_a='Failed atQuil22 because nonatomicShellstatus interleaved with otherdomains. Originalfrozenbuild/capturefailure retained. Bpublishesboundedatomicrecord andreruns strictproofs.'),registered_host_checks=43,rust_test_executions=rust,python_tests=977,native=dict(workflow_boots=2,sealed_probe_boots=1,total_boots=3,verified_workflow_captures=50,fresh_replays=True,groups=rows,late_quil_family_proofs=proofs,exact_indicator_pixels=192,boot_catalog_audit=boot,new_image_1800s_acceptance=False),scalar=dict(elfs=5,instructions=sum(r['instructions']for r in scalar['results']),inspected_vector_fp_matches=0,scope=scalar.get('scope')),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Catalog-derived const visual family classification of every app frame/content/pane, preserving original palette and held-owner canvas checks. Actual lateQuil18..23 current family status and all16 focus-dot pixels perframe atbothsizes, full8chain and cleanup/exhaustion, otherappfamilies covered byactualrenderer/expandedfuturefixtures. Caption glyph renderer itself unchanged. No authority/reserve growth, newpending/cold qualification onthisimage, new1800s, physical/SMP/hostile containment/global epoch or daily-driver acceptance claim.')
p=A/'sexos-catalog-native-appearance-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('APPEARANCE_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','rust',rust,flush=True)
