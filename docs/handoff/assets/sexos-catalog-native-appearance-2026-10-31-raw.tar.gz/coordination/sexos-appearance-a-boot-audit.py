from pathlib import Path
import hashlib,json,re
T=Path('/tmp');roots=[T/'sexos-appearance-a-build']
expected={9:(156,9,1,0,38,41,11,0),12:(154,12,1,0,39,42,14,0),15:(300,15,1,0,40,43,43,0),16:(301,9,2,9,45,46,47,1),17:(302,12,2,12,50,51,52,1),18:(307,9,3,16,54,56,57,1),19:(308,9,4,18,110,111,113,1),20:(309,9,5,19,114,115,117,1),21:(310,9,6,20,118,119,121,1),22:(311,9,7,21,122,123,125,1),23:(312,9,8,22,126,127,129,1)}
for suffix in ['alpha-progress']:
 rows=json.loads((T/('sexos-appearance-a-'+suffix+'.json')).read_text());assert all(r['status']==0 for r in rows)
 roots.extend(Path(r['out'])for r in rows)
logs=[]
for root in roots:
 for path in sorted(root.rglob('serial.log')):
  raw=path.read_bytes();text=raw.decode('utf8',errors='replace');lines=re.findall(r'^\[boot.app.catalog\] (.+)$',text,re.M);assert len(lines)==11,path
  observed={}
  for line in lines:
   d={k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)};target=d['target'];assert target not in observed and d['task']==target and d['grants_verified']==1 and d['data_only']==1,path
   observed[target]=tuple(d[k]for k in ['surface','logical','incarnation','predecessor','lifecycle','close','route','dormant'])
  assert observed==expected,path
  complete='[boot.app.catalog.complete] rows=11 actual_grants=1 runtime_mint=0';assert text.count(complete)==1,path
  assert text.rindex('[boot.app.catalog]')<text.index(complete)<text.index('[boot.memory.authority.sealed]')<text.index('[bootgraph.boot.handoff]'),path
  logs.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),subjects=11,preseal=True))
assert len(logs)==3,len(logs)
out=T/'sexos-appearance-a-boot-audit.json';assert not out.exists();out.write_text(json.dumps(dict(ok=True,boots=3,workflow_boots=2,sealed_probe_boots=1,observations=logs,scope='Exact eleven independently spelled native preseal receipts per boot, coupled to frozen runtime grant/task validator and source. Not physical/SMP/hostile containment proof.'),indent=2)+'\n');print('THREE_BOOTS_CATALOG_RECEIPTS_PASS',flush=True)
