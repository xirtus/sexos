"""Prepared only. Execute solely after Root explicitly authorizes packaging.
No guest or replay is started; consumes terminal, independently replayed evidence.
Writes only /tmp assets; never copies into the repository.
"""
from pathlib import Path
import argparse,hashlib,io,json,tarfile
T=Path('/tmp');F=T/'sexos-spindle-typography-c-frozen'
PREFIX='sexos-readable-spindle-alpha-paired-2026-11-01-'
COMMIT='348cc9ab4d2988eb58c1e4dcacf8f7b4149d6ad7'
ISO='2ac80573a5240fc0d30dd2900fb59da19513b0f098d33013b8bc985f94e41b5e'
KERNEL='08bd29a9099ad90a8fa91698b973b18c1d9f6aa5e65dadbf6291f9e0f2064b82'
def require(condition,message):
    if not condition:raise ValueError(message)
def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def child(root,name):
    p=Path(name);require(not p.is_absolute() and '..'not in p.parts,'unsafe member path')
    return root/p

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root-authorized',action='store_true');args=parser.parse_args()
    require(args.root_authorized,'packaging requires explicit Root authorization before execution')
    progress=T/'sexos-spindle-typography-c-sustained-progress.json'
    rows=read(progress)
    require(len(rows)==2 and {r['profile']for r in rows}=={'compact','wide'},'exact compact/wide pair required')
    require(all(type(r.get('status'))is int and r['status']==0 and r.get('fresh_replay')is True for r in rows),'both terminal0 and fresh independent replay required')
    audit_path=T/'sexos-spindle-typography-c-source-audit.json';audit=read(audit_path)
    b=read(F/'source-binding.json');binding_sha=sha(F/'source-binding.json')
    require(audit['ok']is True and audit['commit']==COMMIT,'exact committed source audit required')
    for key,want in [('iso_sha256',ISO),('kernel_sha256',KERNEL)]:
        require(audit[key]==b[key]==b['build_provenance'][key]==want,'image identity mismatch: '+key)
    require(b['build_provenance']['git_revision']==COMMIT,'source revision mismatch')
    require(sha(F/'tested.iso')==ISO and sha(F/'tested.kernel')==KERNEL,'frozen image bytes mismatch')
    for group in ['sources','runner_sha256']:
        for name,value in b[group].items():require(sha(child(F/'source',name))==value,'frozen source changed: '+name)
    profiles=[];external=[]
    for row in sorted(rows,key=lambda r:r['profile']):
        out=T/('sexos-spindle-typography-c-sustained-'+row['profile'])
        require(Path(row['out']).resolve()==out.resolve(),'unexpected session path')
        replay=T/(out.name+'-independent-replay.json')
        r=read(out/'result.json');m=read(out/'manifest.json');v=read(replay);s=r['soak']
        require(all(value is True for value in [r['ok'],r['acceptance'],s['acceptance'],v['ok'],v['acceptance']]),'strict acceptance True required')
        require(m['error']is None and m['options']['rehearsal']is False and m['options']['soak_seconds']==1800,'raw1800 bound/rehearsal changed')
        require(s['elapsed_seconds']>=1800 and v['elapsed_seconds']>=1800,'raw elapsed below1800')
        require(r['iso_sha256']==m['iso_sha256']==ISO,'session image mismatch')
        for binding in [m['binding'],v['binding']]:
            require(binding['sha256']==binding_sha and binding['iso_sha256']==ISO,'replay/session source binding mismatch')
            require(Path(binding['path']).resolve()==(F/'source-binding.json').resolve(),'unexpected binding source')
        require(replay.stat().st_mtime_ns>=(out/'result.json').stat().st_mtime_ns,'independent replay predates terminal result')
        require(v['cycles']==s['cycles'] and v['verified_captures']==len(r['stages'])==row['verified_captures'],'replay counts differ')
        for name,value in m['raw_sha256'].items():require(sha(child(out,name))==value,'raw evidence changed: '+name)
        q=s['third_quil'];sp=s['third_spindle']
        require([step['target']for step in sp['chain']]==[24,25,26,27,28,29] and sp['reserve_exhausted']is True,'Spindle chain incomplete')
        require(q['final_target']==23 and q['append_count']==6 and [step['target']for step in q['chain']]==[18,19,20,21,22,23],'Quil chain incomplete')
        require(not s['cleanup_errors'],'cleanup errors')
        for step in q['chain']:require(step['frame']['proof']['native_family']==dict(focus=step['surface'],app='Quil',indicator='0xcba6f7'),'Quil family proof mismatch')
        model,resolution={'compact':('e1000','1024x768'),'wide':('e1000e','1280x800')}[row['profile']]
        require(m['model']==model and m['resolution']==resolution,'profile configuration mismatch')
        profiles.append(dict(profile=row['profile'],model=model,resolution=resolution,cycles=s['cycles'],verified_captures=len(r['stages']),elapsed_seconds=s['elapsed_seconds'],active_elapsed_seconds=s['active_elapsed_seconds'],idle_elapsed_seconds=s['idle_elapsed_seconds'],remaining_obligations=s['remaining_obligations'],disk_documents=r['disk_documents'],fresh_replay=True,result_sha256=sha(out/'result.json'),independent_replay_sha256=sha(replay)))
        external.append((row,out,replay))
    items={}
    def add(name,path):
        path=Path(path);child(T,name)
        require(path.is_file()and not path.is_symlink()and name not in items,'invalid archive member '+name);items[name]=path
    def tree(prefix,root):
        require(root.is_dir(),'missing directory '+str(root))
        for p in sorted(root.rglob('*')):
            if '__pycache__'in p.parts or p.suffix=='.img':continue
            require(not p.is_symlink(),'symlink in evidence '+str(p))
            if p.is_file():add(prefix+'/'+p.relative_to(root).as_posix(),p)
    tree('frozen',F)
    for row,out,replay in external:
        tree('sessions/'+row['profile'],out)
        add('coordination/'+replay.name,replay)
        driver=T/(out.name+'-driver.log');add('coordination/'+driver.name,driver)
    for p in [progress,audit_path,T/'sexos-spindle-typography-c-sustained.py',T/'sexos-spindle-typography-c-sustained-driver.log',Path(__file__)]:add('coordination/'+p.name,p)
    manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()}
    data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    archive=T/(PREFIX+'raw.tar.gz');evidence=T/(PREFIX+'evidence.json')
    require(not archive.exists()and not evidence.exists(),'refuse overwrite existing release assets')
    # Exact member bytes are hashed again after reopening; raw disk .img omitted,
    # compressed disk artifacts remain available for durable-byte inspection.
    with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
        for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
        meta=tarfile.TarInfo('payload-members.json');meta.size=len(data);meta.mode=0o644;tar.addfile(meta,io.BytesIO(data))
    with tarfile.open(archive,'r:gz')as tar:
        members=tar.getmembers();require(len(members)==len(items)+1 and len({m.name for m in members})==len(members),'archive member count/duplicates')
        require({m.name for m in members}==set(items)|{'payload-members.json'},'archive member set changed')
        for member in members:
            require(member.isfile(),'nonregular archive member')
            expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if member.name=='payload-members.json'else manifest[member.name]
            with tar.extractfile(member)as stream:
                digest=hashlib.file_digest(stream,'sha256').hexdigest()
            require(member.size==expected['bytes']and digest==expected['sha256'],'archive bytes mismatch '+member.name)
    # Refuse publication if source/evidence changed while being packaged.
    for name,p in items.items():require(p.stat().st_size==manifest[name]['bytes']and sha(p)==manifest[name]['sha256'],'source changed during packaging '+name)
    result=dict(round=150,readable_spindle_image_paired_sustained_accepted=True,full_os_goal_complete=False,source_commit=COMMIT,iso_sha256=ISO,kernel_sha256=KERNEL,architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,native=dict(acceptance_boots=2,cycles=sum(p['cycles']for p in profiles),verified_captures=sum(p['verified_captures']for p in profiles),profiles=profiles,all_fresh_replays=True),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Paired raw>=1800s workflow acceptance on frozen typography C: 2x Spindle font and corrected finish_cycle serial-read timing. Not Round149 Browser-output image, not guest CPU/idle benchmark, not power-loss or general daily-driver qualification. No new guest launched by packaging.')
    with evidence.open('x')as stream:stream.write(json.dumps(result,indent=2)+'\n')
    require(read(evidence)==result,'evidence reopen mismatch')
    print('READABLE_SPINDLE_PAIRED_ARCHIVE_PASS',len(items)+1,'members',flush=True)
if __name__=='__main__':main()
