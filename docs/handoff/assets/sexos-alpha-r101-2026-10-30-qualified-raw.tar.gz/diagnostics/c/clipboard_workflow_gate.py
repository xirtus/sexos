#!/usr/bin/env python3
"""Native register-only Browser→Quil clipboard qualification; never builds.

Fixtures are a finite loopback endpoint. Guest authority remains its held BOOT
routes in one GLOBAL_VAS. Synthetic tests exercise this checker, not the guest.
"""
import argparse,ast,gzip,hashlib,json,os,re,shutil,socket,subprocess,threading,time
from pathlib import Path
import http_content_gate as http
import https_import_gate as storage
import tls_responsiveness_gate as desktop
from desktop_close_gate import QMP
from desktop_focus import focus_surface
from network_contention_gate import frozen_binding,MAX_PCAP
from tls_exchange_gate import reassemble
from check_document_disk import recover,fnv
from check_desktop_pixels import final_view,glyph
from check_quil_ui_pixels import view as quil_view,verify as quil_pixels
from check_disk_persistence import ppm_rgb
from check_nonunix_target import inspect as target_check

BODY=http.STREAM_BODY
NAME='clip-note'
SCOPE=('Two actual boots of one sealed ISO: finite captured DNS/plain HTTP12288, real keyboard reverse/Shift selection and reflow, '
       'whole-document Browser Copy, Quil atomic selected replacement, SaveAs, exact independently decoded QJ02 bytes and cold user reopen. '
       'Whole source-bound Browser text/highlight cells and complete Quil admitted text are checked against actual PPM pixels. '
       'No public routing/TLS, process VAS, POSIX clipboard, crash/power-loss, physical hardware or SMP claim. '
       'Producer-close-before-Finish, cancellation, capacity failures and Full are host model qualifications unless separately recorded.')


def sha(data):return hashlib.sha256(data).hexdigest()
def source_contract(root):
 root=Path(root);c=http.load_pixel_contract(root)
 paths=('crates/sex-pdx/src/clipboard.rs','crates/sex-pdx/src/clipboard_client.rs','crates/sex-pdx/src/text_batch.rs',
        'servers/quil/src/main.rs','servers/quil/src/document_exchange.rs','servers/quil/src/view.rs',
        'servers/silk-shell/src/clipboard.rs','servers/silk-shell/src/linen_text_delivery.rs',
        'scripts/clipboard_workflow_gate.py','scripts/tests/test_clipboard_workflow_gate.py',
        'scripts/check_document_disk.py','scripts/https_import_gate.py','scripts/check_quil_ui_pixels.py')
 source={p:(root/p).read_text()for p in paths}
 app=(root/'apps/kaleidoscope/src/main.rs').read_text();renderer=(root/'servers/sexdisplay/src/main.rs').read_text()
 if 'self.reader.render_path_selected(self.http.document(),self.http.document_path(),self.selection.range())'not in app or 'self.ui.queue_selected(&text.bytes[..text.len]'not in app or 'visible_selection=f.selection'not in app:raise ValueError('actual selected reader/outbox binding changed')
 if 'if sender != SHELL'not in source[paths[1]]or 'pub const SHELL:Subject=Subject{pd:3,task:3}'not in source[paths[0]]:raise ValueError('exact authenticated Shell PD/task client check changed')
 if 'Phase::Commit => {\n                if v as usize != self.len'not in source['servers/quil/src/document_exchange.rs']or 'Phase::End => {\n                if v != 0'not in source['servers/quil/src/document_exchange.rs']:raise ValueError('positive exact COMMIT/END source binding changed')
 labels={name:ast.literal_eval(value)for name,value in re.findall(r'clipboard_client::View::(\w+)=>(b"[^"\n]*")',app)}
 selected=re.search(r'hi>lo\)\{(b"[^"\n]*")\}',app)
 if not selected or not all(name in labels for name in('Copied','Pending')):raise ValueError('source-bound clipboard reader status labels changed')
 c['clipboard_labels']=labels;c['selection_label']=ast.literal_eval(selected[1])
 bg=re.search(r'let background = if selected \{ Some\((0x[0-9a-f]+)\)',renderer)
 if not bg:raise ValueError('actual scalar selection background changed')
 c['selection_color']=int(bg[1],16)&0xffffff
 c['source_sha256'].update({p:sha(value.encode())for p,value in source.items()})
 return c


def selected_frame(body,w,h,c,anchor,selection,label):
 """Independent raw-source→rendered-cell model, without invoking Rust state."""
 f=http.reader_frame(body,w,h,c,anchor,b'/welcome');lo,hi=sorted(selection)
 if not 0<=lo<=hi<=len(body):raise ValueError('invalid expected raw source selection')
 trimmed=body.rstrip(b' \n');first=last=None
 for visible,index in enumerate(range(f['first'],f['end'])):
  start=f['starts'][index];end=start
  while end<len(trimmed)and end-start<f['cols']and trimmed[end]!=10:end+=1
  a,b=max(lo,start),min(hi,end)
  if a<b:
   if first is None:first=(visible+2)*(f['cols']+1)+a-start
   last=(visible+2)*(f['cols']+1)+b-start
 f['selection']=(0,0)if first is None else(first,last)
 if label:f['lines'][-1]=label[:f['cols']].ljust(f['cols'],b' ')
 return f


def verify_browser(trace,ppm,body,c,anchor,selection,status='Selected',resolution=None):
 try:
  current=http.reader_geometry(trace,body,c,anchor,b'/welcome');tile=current['tile']
  label=c['selection_label']if status=='Selected'else c['clipboard_labels'][status]if status else b''
  f=selected_frame(body,tile['w'],tile['h'],c,anchor,selection,label)
  f.update(tile=tile,viewport=current['viewport'])
  layouts=list(re.finditer(r'\[browser.reader.layout\] first=(\d+) end=(\d+) body_rows=(\d+) rows=(\d+) cols=(\d+) total_lines=(\d+) source_bytes=(\d+) viewport=(\d+) origin=validated_body tls=0 pixels=unconfirmed',trace))
  wanted=tuple(f[k]for k in('first','end','body_rows','rows','cols','total_lines','source_bytes','viewport'))
  if not layouts or tuple(map(int,layouts[-1].groups()))!=wanted:raise ValueError('current reader layout differs from independent source/caret model')
  http.reader_position(trace,layouts[-1].end(),f,0,True)
  if not re.search(rf'\[browser.view.applied\] bytes={f["bytes"]} http=258 body_bytes={len(body)} pixels=unconfirmed',trace[layouts[-1].end():]):raise ValueError('current atomic reader Applied missing')
  width,height,pixels=ppm_rgb(ppm,min_width=1,min_height=1)
  if resolution and(width,height)!=tuple(resolution):raise ValueError('actual framebuffer resolution differs')
  if tile['x']<0 or tile['y']<51 or tile['x']+tile['w']>width or tile['y']+tile['h']>height:raise ValueError('actual reader tile outside framebuffer')
  factor=f['scale'];fg=c['color'].to_bytes(3,'big');bg=c['selection_color'].to_bytes(3,'big');a,b=f['selection'];mismatch=ink=highlight=checked=0
  columns=min(80,max(0,(tile['w']-2*c['inset'])//(c['advance']*factor)))
  rows=min(c['max_rows'],max(0,(tile['h']-c['top']+c['line']*factor-1)//(c['line']*factor)))
  for row in range(rows):
   line=f['lines'][row]if row<f['rows']else b''
   for col in range(columns):
    byte=line[col]if col<len(line)else 32;bitmap=glyph(c['font'],chr(byte));index=row*(f['cols']+1)+col
    selected=row<f['rows']and col<f['cols']and a<=index<b
    for gy in range(c['line']):
     for gx in range(c['advance']):
      on=gy<c['glyph_height']and gx<5 and bool(bitmap[gy]&(1<<(4-gx)))
      for dy in range(factor):
       y=tile['y']+c['top']+(row*c['line']+gy)*factor+dy
       if y>=tile['y']+tile['h']:continue
       for dx in range(factor):
        x=tile['x']+c['inset']+(col*c['advance']+gx)*factor+dx
        if x>=tile['x']+tile['w']:continue
        value=pixels[(y*width+x)*3:(y*width+x)*3+3];checked+=1;ink+=on;highlight+=selected and not on
        mismatch+=(value!=fg)if on else(value!=bg)if selected else(value in(fg,bg))
  if mismatch:raise ValueError(f'whole Browser text/highlight/stale-band pixel mismatches={mismatch}')
  if not ink or a!=b and not highlight:raise ValueError('missing checked text/highlight pixels')
  return dict(ok=True,errors=[],checked_pixels=checked,highlight_pixels=highlight,selection=list(f['selection']),source_selection=list(selection),expected_rows=[line.decode('ascii')for line in f['lines']],geometry={k:v for k,v in f.items()if k not in('starts','lines')})
 except(ValueError,KeyError,IndexError,OverflowError,UnicodeError)as exc:return dict(ok=False,errors=[str(exc)])


def capture_prefix(raw,frame):
 size=frame.get('serial_bytes');digest=frame.get('serial_sha256')
 if type(size)is not int or not 0<size<=len(raw)or not isinstance(digest,str)or sha(raw[:size])!=digest:raise ValueError('immutable raw serial prefix missing or changed')
 return raw[:size].decode('utf-8',errors='strict')


def clipboard_join(trace,body=BODY):
 """Each exact transfer joins actual producer, publication and applied consumer."""
 value=hex(fnv(body));copy=list(re.finditer(r'\[browser.clipboard.copy\] ticket=(\d+) generation=(\d+) revision=(\d+) start=(\d+) end=(\d+) bytes=(\d+) hash=(0x[0-9a-f]+) accepted=1',trace))
 if len(copy)!=1:raise ValueError('missing/duplicate accepted actual Browser copy')
 cp=copy[0];ticket,generation,revision,start,end,length=map(int,cp.groups()[:6])
 if(ticket==0 or generation==0 or(start,end,length,cp[7])!=(0,len(body),len(body),value)):raise ValueError('Browser copied foreign/truncated source bytes')
 published=list(re.finditer(r'\[browser.clipboard.published\] ticket=(\d+) bytes=(\d+) generation=(\d+) hash=(0x[0-9a-f]+) positive_ack=1',trace))
 if len(published)!=1:raise ValueError('missing/duplicate positive publication')
 pub=published[0];pt,pl,pg=map(int,pub.groups()[:3])
 if(pt,pl,pub[4])!=(ticket,len(body),value)or pg==0 or pub.start()<=cp.end():raise ValueError('publication lacks exact prior whole-body copy')
 paste=list(re.finditer(r'\[quil.clipboard.paste\] ticket=(\d+) bytes=(\d+) generation=(\d+) hash=(0x[0-9a-f]+) applied=1 atomic=1(?: reason=\w+)?',trace))
 if len(paste)!=1:raise ValueError('missing/duplicate actual atomic Quil replacement')
 dest=paste[0];dt,dl,dg=map(int,dest.groups()[:3])
 if dt<=ticket or(dl,dg,dest[4])!=(len(body),pg,value)or dest.start()<=pub.end():raise ValueError('paste is foreign, partial or precedes publication')
 for pd,t,opcode in((15,ticket,0x281),(15,ticket,0x28a),(9,dt,0x283),(9,dt,0x285)):
  if not re.search(rf'\[shell.clipboard.request\] pd={pd} task={pd} ticket={t} opcode={hex(opcode)} result=Ok\(\(\)\)',trace):raise ValueError('missing actual authenticated subject broker admission')
 intent=re.search(rf'\[quil.clipboard.intent\] ticket={dt} action=paste generation=\d+ revision=\d+ start=(\d+) end=(\d+)',trace)
 selections=list(re.finditer(r'\[quil.selection\] generation=(\d+) revision=(\d+) bytes=(\d+) anchor=(\d+) caret=(\d+)',trace[:intent.start()if intent else 0]))
 if not intent or not selections:raise ValueError('paste lacks exact selected replacement snapshot')
 old=selections[-1];oldlen,anchor,caret=map(int,old.groups()[2:])
 if oldlen==0 or sorted((anchor,caret))!=[0,oldlen]or tuple(map(int,intent.groups()))!=(0,oldlen):raise ValueError('Quil paste did not atomically replace whole existing buffer')
 return dict(producer=dict(pd=15,task=15,ticket=ticket,source_generation=generation,revision=revision),consumer=dict(pd=9,task=9,ticket=dt,replaced_bytes=oldlen),publication_generation=pg,bytes=len(body),hash=value,copy_offset=cp.start(),published_offset=pub.start(),paste_offset=dest.start(),receiver_shell_subject=dict(pd=3,task=3,proof='positive workflow plus sealed exact Client::receive sender check'))


class Peer:
 def __init__(self,request,recovery=False):self.request=request;self.recovery=recovery;self.stop=threading.Event();self.errors=[];self.rows=[];self.dns=[];self.attempts=[];self.sockets=[];self.threads=[];self.live=[]
 def start(self):
  tcp=socket.socket();self.sockets=[tcp];tcp.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);tcp.bind(('127.0.0.1',46078));tcp.listen(3);tcp.settimeout(.2)
  udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);self.sockets.append(udp)
  try:udp.bind(('127.0.0.1',46079))
  except Exception:self.close();raise
  udp.settimeout(.2)
  def dns():
   while not self.stop.is_set():
    try:data,addr=udp.recvfrom(513)
    except socket.timeout:continue
    if self.recovery or self.dns or data!=http.dns_query(1):raise ValueError('unexpected actual DNS request')
    reply=http.dns_response(1);sent=udp.sendto(reply,addr);row=dict(ticket=1,response_hex=reply.hex());self.dns.append(row);self.attempts.append(dict(row,kind='answer',sent_bytes=sent))
  def serve():
   for ticket in range(1,2 if self.recovery else 3):
    while not self.stop.is_set():
     try:conn,_=tcp.accept();break
     except socket.timeout:continue
    else:return
    self.live.append(conn);conn.settimeout(45);data=bytearray()
    while True:
     part=conn.recv(4096)
     if not part:break
     data.extend(part)
     if len(data)>4096:raise ValueError('actual guest request exceeds finite endpoint bound')
    expected=http.ECHO if ticket==1 else self.request
    if bytes(data)!=expected:raise ValueError('actual guest request differs')
    response=http.ECHO if ticket==1 else http.wire_response('stream',BODY,12288)
    for start in range(0,len(response),1024):conn.sendall(response[start:start+1024])
    self.rows.append(dict(ticket=ticket,request_hex=bytes(data).hex(),response_hex=response.hex()));conn.shutdown(socket.SHUT_WR);conn.close()
   while not self.stop.is_set():
    try:conn,_=tcp.accept();conn.close();raise ValueError('unrequested actual TCP flow')
    except socket.timeout:pass
  def guarded(fn):
   try:fn()
   except Exception as exc:
    if not self.stop.is_set():self.errors.append(repr(exc))
  for fn in(dns,serve):thread=threading.Thread(target=guarded,args=(fn,),daemon=True);thread.start();self.threads.append(thread)
 def close(self):
  self.stop.set()
  for sock in self.sockets+self.live:
   try:sock.close()
   except OSError:pass
  for thread in self.threads:thread.join(timeout=1)


def wire_check(raw,peer,recovery=False):
 flows,packets=reassemble(raw);flows=sorted(flows,key=lambda f:f['guest_port']);wanted=1 if recovery else 2
 if len(flows)!=wanted or len(peer['rows'])!=wanted:raise ValueError('actual captured TCP flow count differs')
 for index,(flow,row)in enumerate(zip(flows,peer['rows']),1):
  response=http.ECHO if index==1 else http.wire_response('stream',BODY,12288);request=http.ECHO if index==1 else http.load_pixel_contract(Path(__file__).resolve().parents[1])['request']
  if(flow['peer_port'],flow['guest_port'],flow['outgoing'],flow['incoming'])!=(46078,48000+index,request,response)or row['request_hex']!=request.hex()or row['response_hex']!=response.hex():raise ValueError('captured full HTTP/Echo bytes differ from independent endpoint profile')
  if not(flow['fin_in']and flow['fin_out'])or flow['rst_in']or flow['rst_out']:raise ValueError('actual flow lacks complete clean transfer')
 dns=dict(ok=True,errors=[])if recovery else http.dns_capture(raw,'echo',attempts=peer['attempts'],expected=peer['dns'])
 if not dns['ok']:raise ValueError(str(dns['errors']))
 return dict(ok=True,flows=wanted,tcp_packets=packets,dns=dns,body_sha256=sha(BODY),body_bytes=len(BODY),scope='Independent checksum/handshake/TCP reassembly plus exact complete endpoint bytes; host send/serial alone cannot pass')


def disk_check(before,after):
 result=storage.import_disk(before,after,NAME,BODY)
 return result


def disk_bytes(path):
 p=path/'nvme.img';return p.read_bytes()if p.exists()else gzip.decompress((path/'nvme.img.gz').read_bytes())


def replay_boot(out,contract):
 manifest=json.loads((out/'manifest.json').read_text())
 if manifest.get('error')or manifest.get('source_sha256')!=contract['source_sha256']:raise ValueError('failed native run or changed sealed source/checker contract')
 root=Path(__file__).resolve().parents[1]
 actual_binding=frozen_binding(root,Path(manifest['iso_path']),Path(manifest['binding']['path']))
 if actual_binding!=manifest['binding']:raise ValueError('replayed ISO/source/runner binding differs')
 raw=(out/'serial.log').read_bytes();trace=raw.decode();resolution=tuple(map(int,manifest['resolution'].split('x')));checks=[]
 for row in json.loads((out/'frames.json').read_text()):
  image=(out/row['screenshot']).read_bytes()
  if sha(image)!=row['screenshot_sha256']:raise ValueError('actual immutable screenshot changed')
  prefix=capture_prefix(raw,row)
  if row['kind']=='browser':check=verify_browser(prefix,image,BODY,contract,row['anchor'],tuple(row['source_selection']),row['status'],resolution)
  else:
   errors=quil_pixels(prefix,image,contract['font'],target=9,resolution=resolution);v=quil_view(prefix)
   if not BODY[-28:].decode()in ''.join(v['text'].split('\n')):errors.append('whole-body unique tail missing from actual Quil view')
   check=dict(ok=not errors,errors=errors,geometry=v)
  if not check['ok']:raise ValueError('pixel replay: '+str(check['errors']))
  checks.append(dict(screenshot=row['screenshot'],**check))
 if not checks or manifest['recovery']and not any(c['screenshot'].startswith('quil-cold')for c in checks):raise ValueError('missing required actual frames')
 if not manifest['recovery']and not all(any(c['screenshot'].startswith(name)for c in checks)for name in('browser-reverse','browser-reflow','browser-all','browser-copied','quil-pasted','quil-reopened')):raise ValueError('missing complete selection/transfer/reopen frame set')
 peer=json.loads((out/'peer-exchanges.json').read_text())
 if peer.get('errors'):raise ValueError('actual finite endpoint failed')
 wire=wire_check((out/'wire.pcap').read_bytes(),peer,manifest['recovery']);disk=disk_bytes(out)
 if sha(disk)!=manifest['final_disk_sha256']:raise ValueError('terminal raw disk changed')
 if manifest['recovery']:
  document=manifest['expected_document'];actual=recover(disk,document['object'])
  if actual['payload']!=BODY or actual['identity']!=document['identity']:raise ValueError('cold raw document bytes/identity differ')
  join=None
 else:
  document=disk_check(gzip.decompress((out/'before-save.img.gz').read_bytes()),disk);join=clipboard_join(trace)
  saved=re.search(rf'\[quil.persist.save.ok\] bytes=12288 hash={hex(fnv(BODY))} doc={document["object"]}(?:\s|$)',trace[join['paste_offset']:])
  if not saved:raise ValueError('missing exact positive Save receipt after COMMIT+END')
  saved_end=join['paste_offset']+saved.end()
  if not re.search(r'\[quil.document.saved\] saved_revision=(\d+) revision=\1 dirty=0',trace[saved_end:]):raise ValueError('saved snapshot differs from current editor revision')
  if not re.search(r'\[quil.name.mode\] on=1 save_as=1',trace[join['paste_offset']:saved_end]):raise ValueError('new durable object lacks actual SaveAs interaction')
 if not re.search(rf'\[quil.persist.load.ok\] bytes=12288 hash={hex(fnv(BODY))} doc={document["object"]}(?:\s|$)',trace):raise ValueError('missing positive exact user reopen')
 return dict(ok=True,pixels=checks,wire=wire,clipboard=join,document=document,scope=SCOPE)


def run_boot(root,iso,binding,seed,out,contract,model,resolution_text,recovery=False,expected=None):
 out.mkdir(parents=True,exist_ok=True)
 if any(out.iterdir()):raise ValueError('fresh clipboard boot evidence directory required')
 bound=frozen_binding(root,iso,binding);held=json.loads(binding.read_text())
 for name,digest in contract['source_sha256'].items():
  if held.get('sources',{}).get(name,held.get('runner_sha256',{}).get(name))!=digest:raise ValueError('clipboard source/checker absent from sealed binding: '+name)
 version=subprocess.check_output(['qemu-system-x86_64','--version'],text=True)
 peer=Peer(contract['request'],recovery);disk=out/'nvme.img';shutil.copyfile(seed,disk);serial=out/'serial.log';pcap=out/'wire.pcap';sock=Path('/tmp')/f'sex-clipboard-{os.getpid()}.sock';resolution=tuple(map(int,resolution_text.split('x')));command=desktop.native_command(iso,disk,serial,sock,pcap,model,resolution_text)
 manifest=dict(binding=bound,iso_path=str(iso),command=command,resolution=resolution_text,recovery=recovery,expected_document=expected,input_disk_sha256=sha(seed.read_bytes()),source_sha256=contract['source_sha256'],qemu_version=version,scope=SCOPE);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 peer.start()
 try:proc=subprocess.Popen(command,stdout=(out/'qemu.log').open('w'),stderr=subprocess.STDOUT)
 except Exception:peer.close();raise
 started=time.monotonic();frames=[];actions=[];failure=None
 def raw():return serial.read_bytes()if serial.exists()else b''
 def text():return raw().decode('utf8',errors='strict')
 def health():
  if time.monotonic()-started>600:raise TimeoutError('bounded600second clipboard workflow')
  if proc.poll()is not None:raise RuntimeError('guest exited')
  if peer.errors:raise RuntimeError(str(peer.errors))
  if any(p.exists()and p.stat().st_size>MAX_PCAP for p in(serial,pcap)):raise ValueError('bounded clipboard evidence exceeded')
  if re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow',text()):raise ValueError('guest failure')
 def wait(pattern,start=0,timeout=90):
  end=time.monotonic()+timeout
  while time.monotonic()<end:
   health();match=re.search(pattern,text()[start:])
   if match:return match
   time.sleep(.01)
  raise TimeoutError(pattern)
 def key(code,pattern):
  start=len(text());actions.append(dict(keys=[code],serial_start=len(raw())));q.key(code);return wait(pattern,start)
 def chord(*keys):
  offset=len(raw());events=[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':code}}}for down,codes in((True,keys),(False,reversed(keys)))for code in codes]
  q.cmd('input-send-event',{'events':events});actions.append(dict(keys=list(keys),serial_start=offset))
 def zoom():
  key('grave_accent',r'\[shell.palette.item\] idx=0')
  for old,new in((0,9),(9,8)):key('k',rf'\[shell.palette.select\] old={old} new={new}')
  key('ret',r'\[shell.window.action\] action=ZoomToggle frame=\d+ sid=300 ok=1')
 def picture(name,kind='browser',selection=(0,0),status='',anchor=0):
  path=out/(name+'.ppm');deadline=time.monotonic()+30;check=dict(ok=False,errors=['no checked frame'])
  while time.monotonic()<deadline:
   health();q.cmd('screendump',{'filename':str(path)});snapshot=raw();trace=snapshot.decode();image=path.read_bytes()
   if kind=='browser':check=verify_browser(trace,image,BODY,contract,anchor,selection,status,resolution)
   else:
    errors=quil_pixels(trace,image,contract['font'],target=9,resolution=resolution)
    try:
     v=quil_view(trace)
     if BODY[-28:].decode()not in ''.join(v['text'].split('\n')):errors.append('actual complete body tail not visible')
    except ValueError as exc:errors.append(str(exc))
    check=dict(ok=not errors,errors=errors)
   if check['ok']:break
   time.sleep(.05)
  row=dict(kind=kind,screenshot=path.name,screenshot_sha256=sha(path.read_bytes()),serial_bytes=len(snapshot),serial_sha256=sha(snapshot),anchor=anchor,source_selection=list(selection),status=status,result=check);frames.append(row);(out/'frames.json').write_text(json.dumps(frames,indent=2)+'\n')
  if not check['ok']:raise RuntimeError(str(check['errors']))
 def open_linen():
  focus_surface(300,text,key);key('o',r'\[shell.document.open\] target=15 linen=200');focus_surface(200,text,key)
 def reopen(object_id):
  open_linen()
  for _ in range(40):
   try:
    v,labels=final_view(text())
    if any(name==NAME and identity==v['selected']for identity,_,name in labels):break
   except ValueError:pass
   key('j',r'\[shell.action.select_next_linen\] id=\d+')
  else:raise ValueError('saved document never selected in actual Linen')
  start=len(text());q.key('ret');wait(rf'\[quil.persist.load.ok\] bytes=12288 hash={hex(fnv(BODY))} doc={object_id}(?:\s|$)',start);focus_surface(201,text,key)
 try:
  deadline=time.monotonic()+20
  while not sock.exists():
   health()
   if time.monotonic()>deadline:raise TimeoutError('QMP unavailable')
   time.sleep(.02)
  q=QMP(sock)
  if resolution_text=='1024x768':wait(r'SexOS compact 1024x768',timeout=15);q.key('down');q.key('ret')
  wait(r'\[shell.app.registered.reply\] target=15 .*committed=1');wait(r'\[browser.net.job.released\] ticket=1 view=Verified private_job=0');wait(r'\[linen.disk.publish.done\]')
  start=len(text());q.cmd('input-send-event',{'events':[{'type':'abs','data':{'axis':'x','value':30000}},{'type':'abs','data':{'axis':'y','value':30000}}]});wait(r'\[shell.abs.normalize\] raw_x=30000 raw_y=30000 .*reason=(?:ok|duplicate_sample)',start)
  if recovery:reopen(expected['object']);picture('quil-cold-reopened','quil')
  else:
   focus_surface(300,text,key);key('h',r'\[browser.http.document\] ticket=2 path=/welcome status=200 private_bytes=12288 positive_release=1');q.key('v');picture('browser-reader')
   for _ in range(5):q.key('right')
   for _ in range(3):chord('shift','right')
   for _ in range(5):chord('shift','left')
   picture('browser-reverse',selection=(3,5),status='Selected');zoom();picture('browser-reflow',selection=(3,5),status='Selected');zoom()
   chord('ctrl','a');picture('browser-all',selection=(0,len(BODY)),status='Selected');start=len(text());chord('ctrl','c');wait(r'\[browser.clipboard.published\] ticket=\d+ bytes=12288 generation=\d+ hash='+hex(fnv(BODY))+r' positive_ack=1',start);picture('browser-copied',selection=(0,len(BODY)),status='Copied')
   focus_surface(201,text,key);start=len(text());chord('ctrl','n');wait(r'\[quil.new.ok\] bytes=0',start);start=len(text());q.key_sequence(['d','r','a','f','t']);wait(r'\[quil.document.edit\] revision=\d+ pending=0 bytes=5',start);start=len(text());chord('ctrl','a');wait(r'\[quil.selection\] generation=\d+ revision=\d+ bytes=\d+ anchor=0 caret=\d+',start);start=len(text());chord('ctrl','v');wait(r'\[quil.clipboard.paste\] ticket=\d+ bytes=12288 generation=\d+ hash='+hex(fnv(BODY))+r' applied=1 atomic=1',start);picture('quil-pasted','quil')
   before=disk.read_bytes();(out/'before-save.img.gz').write_bytes(gzip.compress(before,mtime=0));start=len(text());chord('ctrl','shift','s');wait(r'\[quil.name.mode\] on=1 save_as=1',start)
   for letter in NAME:q.key('minus'if letter=='-'else letter)
   saved=key('ret',r'\[quil.persist.save.ok\] bytes=12288 hash='+hex(fnv(BODY))+r' doc=(\d+)(?:\s|$)');wait(r'\[quil.document.saved\] saved_revision=(\d+) revision=\1 dirty=0');document=disk_check(before,disk.read_bytes());assert document['object']==int(saved[1])
   (out/'saved-raw-document.json.gz').write_bytes(gzip.compress((json.dumps(storage.raw_document(disk.read_bytes(),document['object']),indent=2)+'\n').encode(),mtime=0));reopen(document['object']);picture('quil-reopened','quil')
 except Exception as exc:failure=repr(exc)
 finally:
  peer.close()
  if proc.poll()is None:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
  sock.unlink(missing_ok=True);(out/'nvme.img.gz').write_bytes(gzip.compress(disk.read_bytes(),mtime=0));manifest['final_disk_sha256']=sha(disk.read_bytes());manifest['error']=failure;(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'peer-exchanges.json').write_text(json.dumps(dict(rows=peer.rows,dns=peer.dns,attempts=peer.attempts,errors=peer.errors),indent=2)+'\n');(out/'actions.json').write_text(json.dumps(actions,indent=2)+'\n');(out/'frames.json').write_text(json.dumps(frames,indent=2)+'\n')
 if failure or peer.errors:raise RuntimeError(str(dict(error=failure,peer_errors=peer.errors)))
 result=replay_boot(out,contract);result['binding']=bound;(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');return result


def main():
 p=argparse.ArgumentParser();p.add_argument('--iso',type=Path);p.add_argument('--binding',type=Path);p.add_argument('--source-disk',type=Path);p.add_argument('--out',type=Path);p.add_argument('--check',type=Path);p.add_argument('--model',choices=('e1000','e1000e'),default='e1000e');p.add_argument('--resolution',choices=('1280x800','1024x768'),default='1280x800');a=p.parse_args();root=Path(__file__).resolve().parents[1];contract=source_contract(root)
 if a.check:
  result={name:replay_boot(a.check/name,contract)for name in('write','recovery')};first=json.loads((a.check/'write/manifest.json').read_text());second=json.loads((a.check/'recovery/manifest.json').read_text())
  if first['binding']!=second['binding']or first['final_disk_sha256']!=second['input_disk_sha256']:raise ValueError('cold replay did not use exact same ISO/terminal disk')
  print(json.dumps(dict(ok=True,boots=2,results=result)));return
 if not all((a.iso,a.binding,a.source_disk,a.out)):p.error('native run requires --iso --binding --source-disk --out')
 if not target_check(root)['ok']:raise ValueError('non-Unix single GLOBAL_VAS target check failed')
 iso=a.iso.resolve(strict=True);binding=a.binding.resolve(strict=True);seed=a.source_disk.resolve(strict=True);out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
 if any(out.iterdir()):raise ValueError('fresh clipboard cohort directory required')
 first=run_boot(root,iso,binding,seed,out/'write',contract,a.model,a.resolution);second=run_boot(root,iso,binding,out/'write/nvme.img',out/'recovery',contract,a.model,a.resolution,True,first['document'])
 if first['binding']!=second['binding']or json.loads((out/'write/manifest.json').read_text())['final_disk_sha256']!=json.loads((out/'recovery/manifest.json').read_text())['input_disk_sha256']:raise ValueError('cold boot source/image/disk binding differs')
 result=dict(ok=first['ok']and second['ok'],boots=2,binding=first['binding'],document=first['document'],scope=SCOPE);(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()
