"""Fresh-process reader-only raw replay; no QEMU, source edits or inferred prefixes.

Run only after the entire supplied progress cohort is terminal0:
 PYTHONDONTWRITEBYTECODE=1 python3 /tmp/sexos-r100a-independent-replay.py \
   --frozen /tmp/sexos-alpha-r100b-frozen \
   --progress /tmp/sexos-r100b-native-suite-progress.json \
   --output /tmp/sexos-r100b-reader-independent-replay.json
Import/cold-recovery workflows remain explicitly outside this helper's scope.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

sys.dont_write_bytecode = True


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checks_ok(*checks):
    for check in checks:
        need(check['ok'] is True, 'raw replay failed: ' + json.dumps(check))


def path_in(out, name):
    path = (out / name).resolve(strict=True)
    need(path.is_relative_to(out) and path.is_file() and not Path(out / name).is_symlink(), 'raw artifact escapes native directory')
    return path


def assert_bound_maps(values, binding, root, runner_names=False):
    need(isinstance(values, dict) and values, 'missing native source/runner hash map')
    for name, wanted in values.items():
        key = 'scripts/' + name if runner_names else name
        candidates = [binding[group][key] for group in ('sources', 'runner_sha256') if key in binding[group]]
        need(candidates and all(value == wanted for value in candidates) and sha(root / key) == wanted, 'native unbound/changed source: ' + key)


def commands(row, manifest, frozen):
    need(row['source_binding_sha256'] == sha(frozen / 'source-binding.json'), 'coordinator binding differs')
    command = row['command']
    need(Path(command[1]).resolve() == frozen / 'source/scripts' / Path(command[1]).name, 'coordinator did not use frozen checker')
    need(Path(command[command.index('--iso') + 1]).resolve() == frozen / 'tested.iso', 'coordinator selected another ISO')
    actual = manifest['command']
    need(Path(actual[actual.index('-cdrom') + 1]).resolve() == frozen / 'tested.iso', 'actual QEMU selected another ISO')
    profile = row['profile']
    need((profile['model'], profile['resolution']) == (manifest['model'], manifest['resolution']), 'native/coordinator profile differs')
    need((manifest['model'], manifest['resolution']) == {'wide': ('e1000e', '1280x800'), 'compact': ('e1000', '1024x768')}[profile['label']], 'unknown actual desktop/NIC profile')


def raw_frame(out, trace, record, source_hashes, http, reader):
    path = path_in(out, record['screenshot'])
    need(path.suffix == '.ppm' and record['ok'] is True and sha(path) == record['screenshot_sha256'], 'native screenshot/hash failure')
    need(record['source_sha256'] == source_hashes, 'native screenshot source differs from frozen oracle')
    prefix = http.frame_prefix(trace, record, reader=reader)
    return path, prefix


def frame_result(record, path, result):
    checks_ok(result)
    need(result['geometry'] == record['geometry'], 'replayed source/viewport/pixel geometry differs: ' + path.name)
    return dict(screenshot=path.name, raw_sha256=sha(path), serial_end=record['serial_end'], serial_sha256=record['serial_sha256'], requested_anchor=record['requested_anchor'], geometry=result['geometry'], checked_pixels=result['checked_pixels'])


def https_ready(row, frozen, root, binding, bound, https, http, wait_check):
    out = Path(row['out']).resolve(strict=True); result = read(out / 'result.json'); manifest = read(out / 'manifest.json')
    need(result['ok'] is True and result['error'] is None and not result['server_errors'], 'HTTPS native run failed')
    need(result['binding'] == manifest['binding'] == bound and result['mode'] == manifest['mode'] == row['mode'] == 'ready', 'HTTPS binding/mode differs')
    commands(row, manifest, frozen)
    contract = https.load_contract(root); contract['reader_require_position'] = True
    need(manifest['pixel_source_sha256'] == contract['source_sha256'] and manifest['keylog_enabled'] is False, 'HTTPS source/private logging differs')
    need(manifest['request_hex'] == https.REQUEST.hex() and manifest['body_sha256'] == hashlib.sha256(https.BODY).hexdigest() and manifest['body_bytes'] == len(https.BODY), 'HTTPS expected fixture differs')
    checks_ok(https.tls.command_profile(manifest['command']))
    peer = read(out / 'peer-exchanges.json'); need(peer['keylog_enabled'] is False, 'HTTPS private key logging enabled')
    trace = (out / 'serial.log').read_text(errors='replace'); raw = (out / 'wire.pcap').read_bytes(); resolution = tuple(map(int, manifest['resolution'].split('x')))
    wire = https.inspect_wire(raw, peer['tls'], 'ready')
    dns = https.dns_capture(raw, 'echo', attempts=peer['dns_send_attempts'], expected=peer['dns'])
    document = https.inspect_document(trace, 'ready', wire, dns, raw, manifest['host_utc_start'], manifest['host_utc_end'], contract)
    authority = https.nic_check(trace, expected=1, preparation=True, ethernet=True, network_config=True, routing=True); waiting = wait_check(trace)
    checks_ok(wire, dns, document, authority, waiting)
    need(document['joins'] == result['document']['joins'] and wire['joins'] == result['wire']['joins'], 'HTTPS derived joins differ')
    expected = ['https-reader-initial', 'https-reader-pgdn', 'https-overview', 'https-reader-reopened', 'https-reader-restored-tile', 'https-reader-zoom-roundtrip', 'https-reader-end', 'https-reader-home', 'https-cleared', 'https-cannot-reopen']
    need([Path(frame['screenshot']).stem for frame in result['pixels']] == expected, 'missing/extra/reordered HTTPS reader workflow')
    anchor = 0; previous = None; frames = []; ends = []; retained = None; resume_tile = None; previous_viewport = None
    for record, name in zip(result['pixels'], expected):
        reader = record['kind'] == 'reader'; need(reader == name.startswith('https-reader-'), 'HTTPS frame kind differs')
        path, prefix = raw_frame(out, trace, record, contract['source_sha256'], http, reader)
        if reader:
            action = {'https-reader-pgdn': 'pgdn', 'https-reader-end': 'end', 'https-reader-home': 'home'}.get(name)
            if action: anchor = http.reader_move(previous, action)
            need(record['requested_anchor'] == record['anchor'] == anchor, 'stored HTTPS anchor differs from independent explicit navigation')
            current = https.reader_geometry(prefix, contract, anchor)
            replay = https.verify_reader_pixels(prefix, path.read_bytes(), contract, anchor, resolution)
            if name == 'https-reader-pgdn': retained = anchor; need(anchor > 0, 'HTTPS resume was masked by Home')
            if name in ('https-reader-reopened', 'https-reader-restored-tile', 'https-reader-zoom-roundtrip'):
                need(current['source_anchor'] == retained, 'HTTPS overview/Zoom lost requested source byte')
                if name == 'https-reader-reopened': resume_tile = current['tile']; previous_viewport = current['viewport']
                else:
                    need(current['viewport'] > previous_viewport, 'HTTPS Zoom did not advance held viewport'); previous_viewport = current['viewport']
                    need((current['tile'] != resume_tile) if name.endswith('restored-tile') else (current['tile'] == resume_tile), 'HTTPS actual Zoom/restore geometry differs')
            if name == 'https-reader-end': need(current['end'] == current['total_lines'] and https.TAIL in b''.join(current['lines'][2:-1]), 'HTTPS End omitted unique final source byte')
            previous = current
        else:
            state = 'Verified' if name == 'https-overview' else 'Cancelled'
            need(record['expected'] == state and record['requested_anchor'] is None, 'HTTPS status state/origin differs')
            replay = https.verify_status_pixels(prefix, path.read_bytes(), state, 'ready', contract, resolution)
        frames.append(frame_result(record, path, replay)); ends.append(record['serial_end'])
    need(all(a < b for a, b in zip(ends, ends[1:])), 'HTTPS captures lost chronological serial snapshots')
    navigation = trace[ends[0]:]
    need(not re.search(r'\[net\.(?:job|dns)\.egress\.submit\]|\[net.job.resolved.admitted\]', navigation), 'HTTPS local reader created new owned network work')
    clear = navigation.index('[browser.https.cleared]')
    need('[browser.reader.layout]' not in navigation[clear:], 'cleared HTTPS reopened reader')
    return dict(name=row['name'], out=str(out), mode=row['mode'], profile=row['profile'], boots=1, ok=True, frames=frames, wire=wire, dns=dns, document=document, authority=authority, self_wait=waiting, local_navigation_network_free=True, measured=dict(body_bytes=len(https.BODY), retained_anchor=retained, reader_frames=sum(frame['requested_anchor'] is not None for frame in frames)), raw_sha256={name: sha(out / name) for name in ('serial.log', 'wire.pcap', 'manifest.json', 'peer-exchanges.json', 'result.json')})


def http_stream(row, frozen, root, binding, bound, http, wait_check):
    out = Path(row['out']).resolve(strict=True); result = read(out / 'result.json'); manifest = read(out / 'manifest.json')
    need(result['ok'] is True and result['error'] is None and not result['server_errors'] and row['mode'] == manifest['mode'] == 'stream', 'plain HTTP native run failed/wrong mode')
    need(manifest['iso_sha256'] == bound['iso_sha256'], 'HTTP native ISO differs')
    commands(row, manifest, frozen)
    contract = http.load_pixel_contract(root); contract['reader_require_position'] = True
    need(manifest['pixel_source_sha256'] == contract['source_sha256'], 'HTTP pixel source differs')
    assert_bound_maps(manifest['authority_source_sha256'], binding, root)
    assert_bound_maps(manifest['runner_sha256'], binding, root, runner_names=True)
    need(manifest['http_request_hex'] == contract['request'].hex() and manifest['http_body_hex'] == http.STREAM_BODY.hex(), 'HTTP expected document differs')
    endpoint = read(out / 'endpoint-exchanges.json'); dns_endpoint = read(out / 'dns-endpoint-exchanges.json')
    rows = endpoint['connections']; need(len(rows) == 2 and len(dns_endpoint['queries']) == 1, 'plain reader generated extra/missing endpoint/DNS work')
    expected_response = http.wire_response('stream', http.STREAM_BODY, contract['wire_max_body'])
    for observed, ticket, kind, request, response in zip(rows, (1, 2), ('echo', 'http'), (http.ECHO, contract['request']), (http.ECHO, expected_response)):
        need((observed['ticket'], observed['kind'], observed['request_hex'], observed['response_hex'], observed['aborted']) == (ticket, kind, request.hex(), response.hex(), False), 'actual plain endpoint request/response differs')
        need(observed['request_sha256'] == hashlib.sha256(request).hexdigest(), 'actual endpoint request hash differs')
    attempts = endpoint['response_send_attempts']; need(len(attempts) == 2, 'missing actual endpoint send observations')
    for attempt, ticket, response in zip(attempts, (1, 2), (http.ECHO, expected_response)):
        need(attempt['ticket'] == ticket and attempt['attempted_hex'] == attempt['sent_hex'] == response.hex() and attempt['sent_sha256'] == hashlib.sha256(response).hexdigest() and attempt['error'] is None and not attempt['late_cancelled_peer'] and not attempt['early_rejection'], 'actual complete endpoint send differs')
    trace = (out / 'serial.log').read_text(errors='replace'); raw = (out / 'wire.pcap').read_bytes(); resolution = tuple(map(int, manifest['resolution'].split('x')))
    wire = http.capture(raw, [dict(payload_hex=r['request_hex'], response_hex=r['response_hex']) for r in rows], guest_ports=range(48001, 65536), initiator='guest')
    dns = http.dns_capture(raw, 'echo', dns_endpoint['response_send_attempts'], expected=[dict(ticket=r['ticket'], response_hex=r['response_hex']) for r in dns_endpoint['queries']])
    joined = http.resolution_joins(trace, raw, [(2, 1)], dns); streams = http.stream_receipts(trace, [2], contract, [2], [2]); authority = http.nic(trace, 1, True, True); waiting = wait_check(trace)
    checks_ok(wire, dns, joined, streams, authority, waiting)
    need(wire == result['capture'] and dns == result['dns_capture'] and joined == result['resolution_order'] and streams == result['streaming'], 'plain derived PCAP/DNS/admission/drain receipts differ')
    need(re.findall(r'\[browser.http.body\] ticket=(\d+) ', trace) == ['2'], 'partial/stale plain HTTP body became usable')
    records = [(frame, False) for frame in result['pixels']] + [(frame, True) for frame in result['reader_pixels']]
    records.sort(key=lambda item: item[0]['serial_end'])
    names = ['browser-http', 'browser-reader-initial', 'browser-reader-pgdn', 'browser-reader-down', 'browser-reader-pgup', 'browser-reader-home', 'browser-reader-end', 'browser-reader-up', 'browser-reader-expanded', 'browser-reader-restored', 'browser-reader-overview', 'browser-reader-resumed', 'browser-reader-erased', 'browser-reader-cannot-reopen']
    need([Path(frame['screenshot']).stem for frame, _ in records] == names, 'missing/extra/reordered plain reader workflow')
    frames = []; anchor = 0; previous = None; initial_tile = None; initial_reader_end = None; ends = []; overview = http.overview_preview(http.STREAM_BODY)
    for (record, reader), name in zip(records, names):
        path, prefix = raw_frame(out, trace, record, contract['source_sha256'], http, reader)
        if reader:
            action = {'browser-reader-pgdn': 'pgdn', 'browser-reader-down': 'down', 'browser-reader-pgup': 'pgup', 'browser-reader-home': 'home', 'browser-reader-end': 'end', 'browser-reader-up': 'up'}.get(name)
            if action: anchor = http.reader_move(previous, action)
            need(record['requested_anchor'] == anchor, 'stored HTTP anchor differs from independent explicit navigation')
            current = http.reader_geometry(prefix, http.STREAM_BODY, contract, anchor)
            replay = http.verify_reader_pixels(prefix, path.read_bytes(), http.STREAM_BODY, contract, anchor, resolution)
            if name == 'browser-reader-initial': initial_tile = current['tile']; initial_reader_end = record['serial_end']
            if name == 'browser-reader-expanded': need(current['tile'] != initial_tile, 'plain Zoom did not change actual geometry')
            if name == 'browser-reader-restored': need(current['tile'] == initial_tile, 'plain Zoom did not restore geometry')
            if name == 'browser-reader-resumed': need(anchor > 0 and current['source_anchor'] == anchor, 'plain overview/re-entry reset position')
            if name == 'browser-reader-end': need(current['end'] == current['total_lines'] and http.STREAM_TAIL in b''.join(current['lines'][2:-1]), 'plain End omitted unique final source byte')
            previous = current
        else:
            state = 'Ready' if name in ('browser-http', 'browser-reader-overview') else 'Cancelled'
            need(record['expected'] == state and record['requested_anchor'] is None, 'plain status origin/state differs')
            replay = http.verify_http_pixels(prefix, path.read_bytes(), state, overview, contract, resolution)
            need(not http.verify_kaleido_layout(prefix, path.read_bytes(), contract['font'], resolution=resolution), 'plain overview actual app layout differs')
        frames.append(frame_result(record, path, replay)); ends.append(record['serial_end'])
    need(all(a < b for a, b in zip(ends, ends[1:])), 'plain captures lost chronological serial snapshots')
    navigation = trace[initial_reader_end:]
    need(not re.search(r'\[net\.(?:job|dns)\.egress\.submit\]|\[net\.job\.resolved\.admitted\]|\[browser.http.body\]|\[browser.dns.answer\]', navigation), 'plain local navigation created owned network work')
    erased_prefix = http.frame_prefix(trace, records[-2][0], reader=False)
    need('[browser.reader.layout]' not in trace[len(erased_prefix):] and not re.search(r'\[browser.view.applied\] bytes=\d+ http=258 ', trace[len(erased_prefix):]), 'cancelled plain document reopened')
    return dict(name=row['name'], out=str(out), mode=row['mode'], profile=row['profile'], boots=1, ok=True, frames=frames, wire=wire, dns=dns, resolution_order=joined, streaming=streams, authority=authority, self_wait=waiting, local_navigation_network_free=True, measured=dict(body_bytes=len(http.STREAM_BODY), reader_frames=sum(reader for _, reader in records)), raw_sha256={name: sha(out / name) for name in ('serial.log', 'wire.pcap', 'manifest.json', 'endpoint-exchanges.json', 'dns-endpoint-exchanges.json', 'result.json')})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frozen', required=True, type=Path)
    parser.add_argument('--progress', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--expected-progress-runs', type=int, default=6)
    args = parser.parse_args(); need(not args.output.exists(), 'fresh replay output required')
    frozen = args.frozen.resolve(strict=True); root = frozen / 'source'; progress = read(args.progress)
    need(type(args.expected_progress_runs) is int and args.expected_progress_runs > 0 and len(progress) == args.expected_progress_runs, 'partial/wrong progress cohort')
    need(all(type(row['status']) is int and row['status'] == 0 for row in progress), 'progress not entirely terminal success; no replay acceptance')
    need(len({row['name'] for row in progress}) == len(progress), 'duplicate native progress names')
    sys.path.insert(0, str(root / 'scripts'))
    import http_content_gate as http
    import https_document_gate as https
    from network_contention_gate import frozen_binding
    from check_self_wait import inspect as wait_check
    need(callable(getattr(http, 'frame_prefix', None)), 'frozen checker predates exact-prefix evidence; do not reconstruct A captures')
    bound = frozen_binding(root, frozen / 'tested.iso', frozen / 'source-binding.json'); binding = read(frozen / 'source-binding.json')
    selected = []; excluded = []
    for row in progress:
        checker = Path(row['command'][1]).name
        if checker in ('https_document_gate.py', 'http_content_gate.py'):
            need(row['boots'] == 1, 'reader workflow is not one actual boot'); selected.append((row, checker))
        else:
            need(checker == 'https_import_gate.py' and row['boots'] == 2, 'unsupported workflow cannot be silently excluded')
            excluded.append(dict(name=row['name'], out=row['out'], scope='Import/cold-recovery raw replay is a separate root-owned helper; not qualified here.'))
    need(len(selected) == 4 and {(checker, row['profile']['label']) for row, checker in selected} == {(checker, profile) for checker in ('https_document_gate.py', 'http_content_gate.py') for profile in ('wide', 'compact')}, 'require both actual profiles for both reader protocols')
    rows = []
    for row, checker in selected:
        replay = https_ready(row, frozen, root, binding, bound, https, http, wait_check) if checker == 'https_document_gate.py' else http_stream(row, frozen, root, binding, bound, http, wait_check)
        rows.append(replay)
        print(json.dumps(dict(name=row['name'], ok=True, frames=len(replay['frames']))), flush=True)
    # Recheck the sealed closure after raw parsing; no source drift accepted.
    need(frozen_binding(root, frozen / 'tested.iso', frozen / 'source-binding.json') == bound, 'frozen source closure changed during independent replay')
    receipt = dict(ok=True, complete_reader_runs=True, all_progress_terminal=True, reader_runs=len(rows), reader_boots=sum(row['boots'] for row in rows), source_binding_sha256=bound['sha256'], binding=bound, progress_path=str(args.progress.resolve()), progress_sha256=sha(args.progress), rows=rows, excluded_runs=excluded, scope='Independent fresh-process frozen-source replay of actual endpoint plaintext/SSL, PCAP/checksums/TLS records, DNS, source/authority/positive-release and all exact immutable screenshot serial prefixes. All reader frames require actual source-byte position, held viewport, whole glyph/progress/padding/stale-erasure checks and independently derived explicit navigation. This qualifies four reader boots only; import/cold recovery is separate. No reconstructed A snapshots, inherited candidate acceptance, public web/public CA, physical/SMP/hostile containment, crash recovery or full-system acceptance claim.')
    with args.output.open('x') as handle: handle.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(ok=True, complete_reader_runs=True, reader_runs=len(rows), reader_boots=receipt['reader_boots'], frames=sum(len(row['frames']) for row in rows), output=str(args.output))))


if __name__ == '__main__':
    main()
