"""Fresh-process qualification of final J raw evidence; never builds or boots."""
from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys

sys.dont_write_bytecode = True
F = Path('/tmp/sexos-alpha-r101-clipboard-j-frozen').resolve()
ROOT = F / 'source'
sys.path.insert(0, str(ROOT / 'scripts'))
import clipboard_workflow_gate as clipboard
import https_document_gate as https
import http_content_gate as http
from network_contention_gate import frozen_binding
from check_self_wait import inspect as wait_check

def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

progress_path = Path('/tmp/sexos-r101-j-native-suite-progress.json')
progress = load(progress_path)
assert len(progress) == 6 and all(type(x['status']) is int and x['status'] == 0 for x in progress)
assert sum(x['boots'] for x in progress) == 10
bound = frozen_binding(ROOT, F/'tested.iso', F/'source-binding.json')
binding = load(F/'source-binding.json')
helper = Path('/tmp/sexos-r101-j-reader-replay-helper.py')
spec = importlib.util.spec_from_file_location('reader_replay', helper)
reader = importlib.util.module_from_spec(spec); spec.loader.exec_module(reader)
rows = []
for row in progress:
    assert row['source_binding_sha256'] == bound['sha256']
    out = Path(row['out'])
    if row['name'].startswith('clipboard-'):
        contract = clipboard.source_contract(ROOT)
        boots = []
        manifests = [load(out/name/'manifest.json') for name in ('write','recovery')]
        assert manifests[0]['binding'] == manifests[1]['binding'] == bound
        assert manifests[0]['final_disk_sha256'] == manifests[1]['input_disk_sha256']
        for name in ('write','recovery'):
            replay = clipboard.replay_boot(out/name, contract)
            stored = load(out/name/'result.json')
            # JSON stores the model's tuple selection as a list. Compare the
            # exact serialized evidence schema, without dropping any field.
            assert stored == json.loads(json.dumps(dict(replay, binding=bound)))
            boots.append(dict(boot=name, **replay))
        assert boots[0]['document'] == boots[1]['document'] == load(out/'result.json')['document']
        rows.append(dict(name=row['name'], out=str(out), mode=row['mode'], profile=row['profile'], boots=2, ok=True, results=boots))
    elif row['name'].startswith('https-reader-'):
        rows.append(reader.https_ready(row,F,ROOT,binding,bound,https,http,wait_check))
    else:
        assert row['name'].startswith('import-')
    print(row['name'], 'raw replay checked or queued to exact import helper', flush=True)

imports = [r for r in progress if r['name'].startswith('import-')]
assert len(imports) == 2
import_progress = Path('/tmp/sexos-r101-j-https-import-native-suite-progress.json')
import_progress.write_text(json.dumps(imports, indent=2)+'\n')
with Path('/tmp/sexos-r101-j-import-independent-replay.log').open('x') as log:
    subprocess.run([sys.executable,'/tmp/sexos-r101-j-import-replay.py'],stdout=log,stderr=subprocess.STDOUT,check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
imports_receipt = load('/tmp/sexos-r101-j-import-independent-replay.json')
assert imports_receipt['ok'] and imports_receipt['complete2profiles4boots_terminal'] and imports_receipt['binding'] == bound
for r in imports_receipt['rows']:
    row = next(x for x in imports if x['name']==r['name'])
    rows.append(dict(name=r['name'],out=r['out'],mode=row['mode'],profile=row['profile'],boots=2,ok=True,results=r))
assert len(rows)==6 and sum(r['boots'] for r in rows)==10 and all(r['ok'] for r in rows)
assert frozen_binding(ROOT,F/'tested.iso',F/'source-binding.json')==bound
receipt = dict(ok=True,complete=True,source_binding_sha256=bound['sha256'],binding=bound,runs=rows,native_runs=6,native_boots=10,progress_sha256=sha(progress_path),helper_sha256={str(p):sha(p) for p in [Path(__file__),helper,Path('/tmp/sexos-r101-j-import-replay.py')]},scope='Fresh-process exact frozen-source replay of final J serial prefixes, full actual pixels, PCAP and endpoint bytes, authenticated clipboard joins, negative no-edit status frames, terminal custody, raw durable objects and same-image cold reopen. No accepted mutation replay, general public web, physical/SMP, crash/power-loss or full-system acceptance claim.')
Path('/tmp/sexos-r101-j-root-independent-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(ok=True,complete=True,native_runs=6,native_boots=10)),flush=True)
