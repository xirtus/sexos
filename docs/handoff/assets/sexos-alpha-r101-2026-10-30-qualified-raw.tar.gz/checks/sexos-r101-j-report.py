"""Update the four established handoff reports from accepted J evidence."""
from pathlib import Path
import json
R=Path('/Users/xmacbookm5/Projects/Sex'); D=R/'docs/handoff'
e=json.loads((D/'assets/sexos-alpha-r101-2026-10-30-evidence.json').read_text())
assert e['accepted'] and e['round']==101 and e['checks']['native_boots']==10
short=f'''## Current checkpoint: accepted round 101; next 102

Browser and Quil now support keyboard selection and a finite capability-scoped clipboard over existing BOOT-sanctioned routes. Actual IPC sender task metadata accompanies the sender PD, and clients authenticate exact Shell3/task3. Full12288-byte Browser Copy replaces Quil’s selected draft atomically; capacity refusal and an empty clipboard after producer retirement preserve document bytes, caret and viewport. Save and user-selected cold reopen recover exact durable bytes. Status/name changes no longer scroll Quil’s unchanged document.

Sealed J ISO `{e['iso_sha256']}`, binding `{e['binding_sha256']}`;{e['production_inputs']} production/{e['runner_inputs']} runner inputs. BUILD/GREEN_MASTER, {e['checks']['rust_test_executions']:,} fresh frozen Rust executions, {e['checks']['python_tests']} frozen Python tests and ten fresh native boots pass. Both desktop profiles qualify clipboard/save/cold recovery; affected HTTPS reader and import/cold-recovery regressions also pass. Fresh independent replay checks actual pixels, exact serial prefixes, wire/endpoint bytes, sender/receipt joins, terminal custody and raw journals. Earlier failed candidates remain diagnostic. See the [round101 ledger](SEXOS_DEVELOPMENT_ROUNDS_80_200_2026_10_30.md) and [evidence](assets/sexos-alpha-r101-2026-10-30-evidence.json).

Next102 removes premature standalone Spindle panes and makes launcher actions reflect Open, Restore, Bring Here or Focus on the actual live incarnation. Next103–107 improve fonts, readable text, input, assets and navigation;108 qualifies a representative connected desktop session. Active80–200 progress:22/121 accepted;102–200 (99 substantive rounds) remain.7 Open/23 Partial/System Proven false remain. A trusted-builtins QEMU alpha still requires its then-current image’s own sustained mixed session and recovery qualification. General online/physical daily-driver readiness remains unproven. GLOBAL_VAS, BOOT-only capability genesis, sex-pdx authority, PKU and exact terminal incarnations remain mandatory; SexOS is not Unix/POSIX.

'''
for name in ('ALPHA_100_ROUND_CONTINUATION_2026_10_29.md','ALPHA_NATIVE_CONTINUATION_2026_10_29.md','ALPHA_DAILY_DRIVER_NEXT_SESSION_2026_10_29.md'):
    p=D/name;t=p.read_text();assert '## Current checkpoint: accepted round 101' not in t
    t=t.replace('## Current checkpoint: accepted round 100; next 101','## Historical checkpoint: accepted round 100; next 101 at that time',1)
    at=t.index('\n')+1;p.write_text(t[:at]+'\n'+short+t[at:])

p=D/'SEXOS_DEVELOPMENT_ROUNDS_80_200_2026_10_30.md';t=p.read_text()
t=t.replace('Through100 is accepted;21/121 rounds in the revised scope are complete and101–200 remain (100 rounds). Round100 improves readable document layout and preserves reading position;101 adds capability-scoped selection and clipboard.','Through101 is accepted;22/121 rounds in the revised scope are complete and102–200 remain (99 rounds). Round101 adds capability-scoped selection and clipboard;102 improves launcher/workspace usability.',1)
a=t.index('Round101 is in progress, not accepted.');b=t.index('\nPreserve GLOBAL_VAS',a)
detail=short.replace('## Current checkpoint: accepted round 101; next 102','Accepted101 checkpoint: authenticated selection and finite clipboard',1)
detail+='''Selection binds nonwrapping source generation/revision and exact anchor/caret. Browser copies source bytes without chrome or truncation. The held-catalog Shell broker serializes bounded user intents, verifies current exact producer/consumer liveness, retains Full packets unchanged, and admits positive Publish/Finish once. Quil Cut waits for positive publication and an unchanged source; Paste applies only a complete positively finished read to an unchanged selection with enough capacity, as one undo/revision. Cut, races, forged sender, queue Full, cancellation and retirement interleavings are actual-function host checks; native qualification specifically covers Copy/Paste, capacity refusal and producer retirement. Text and selection styling publish atomically; Close erases owned clipboard/staging/selection before terminal acknowledgment. Completed legitimate consumer content survives the producer’s later retirement, while new reads see Empty.

NativeC exposed a real syscall return defect: the listen handler prepared sender task in RDI, but the return stub restored the old selector. The fixed return path copies the scalar task before restoration, without R9 IPC use. Six actual assembly/layout model checks pass and the positive RDI test fails against frozenC. NativeI exposed status-dependent renderer capacity: transient longer chrome moved viewport492→493 on a rejected paste. Geometry-bounded chrome reservation fixes this, and its actual renderer regression fails against frozenI. FinalJ reruns qualification on its own new image. Earlier runner failures cover strict trailing UTF8, mixed held-key timing, focus traversal, legal y50/fresh viewport barriers and an unsupported test-name minus key; none is counted as acceptance. Failed C–I raw diagnostics and the negative controls are archived separately.

The bounded format remains printable ASCII/LF, keyboard selection,12288-byte payload and512-byte displayed text frame. The current sender/catalog checks do not establish hostile PKU containment or close remaining raw-pointer authority gaps. There is no native Cut/hostile-forgery/queue-pressure certification, general public web/CA, crash/power-loss, physical hardware, SMP, sustained latest-image daily-driver or whole-system deterministic replay claim. The archive includes the exact sealed ISO/kernel and source/checker closure, raw native evidence, logs and independently verified member hashes. No runtime capability is minted and no process address space or Unix/POSIX mechanism is introduced.
'''
p.write_text(t[:a]+detail+t[b:])
print('Updated4 handoff reports: accepted101,22/121 complete,102 next; release gates unchanged')
