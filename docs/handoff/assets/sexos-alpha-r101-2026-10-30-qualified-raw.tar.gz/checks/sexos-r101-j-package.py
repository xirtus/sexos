"""Package only terminal, independently replayed round101 J evidence."""
from pathlib import Path
import gzip, hashlib, io, json, re, tarfile
from PIL import Image

R=Path('/Users/xmacbookm5/Projects/Sex'); T=Path('/tmp')
F=T/'sexos-alpha-r101-clipboard-j-frozen'; B=T/'sexos-alpha-r101-clipboard-j-build'
A=R/'docs/handoff/assets'; stem='sexos-alpha-r101-2026-10-30'
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding=load(F/'source-binding.json'); progress=load(T/'sexos-r101-j-native-suite-progress.json')
replay=load(T/'sexos-r101-j-root-independent-replay.json')
assert replay['ok'] and replay['complete'] and replay['native_runs']==6 and replay['native_boots']==10
assert replay['source_binding_sha256']==sha(F/'source-binding.json')
assert len(progress)==6 and all(type(r['status']) is int and r['status']==0 for r in progress)
assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for name,digest in {**binding['sources'],**binding['runner_sha256']}.items():
    assert sha(F/'source'/name)==digest and sha(R/name)==digest, name
assert load(B/'provenance.json')['iso_sha256']==binding['iso_sha256']==sha(F/'tested.iso')
assert '| **FINAL_SCORE** | **GREEN_MASTER** |' in (B/'report.md').read_text()
logs=[]
for label in ('service-custody','display'):
    p=T/f'sexos-r101-j-frozen-{label}.log'; text=p.read_text()
    assert ('[service.custody.host.gate] PASS' if label=='service-custody' else '[gate.display_surface_groups.result] PASS') in text
    count=sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',text,re.M)))
    assert count>0
    logs.append(dict(name=label,path=str(p),executions=count,sha256=sha(p)))
p=T/'sexos-r101-j-frozen-python.log'; text=p.read_text()
assert re.search(r'^OK$',text,re.M)
python_count=int(re.search(r'Ran (\d+) tests',text)[1]); assert python_count>=698
scalar=load(T/'sexos-r101-j-scalar-instructions.json');assert scalar['ok'] and scalar['iso_sha256']==binding['iso_sha256']

members={}
def add(path,name):
    path=Path(path); assert path.is_file() and not path.is_symlink(),path
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name]=path
add(F/'source-binding.json','source-binding.json')
for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):add(F/'source'/name,'source/'+name)
for name in ('tested.iso','tested.kernel'):add(F/name,name)
for p in sorted(B.iterdir()):
    if p.is_file() and p.suffix!='.img':add(p,'build/'+p.name)
for row in progress:
    out=Path(row['out'])
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.suffix!='.img':add(p,'native/'+row['name']+'/'+str(p.relative_to(out)))
    add(Path(row['driver']),'checks/'+Path(row['driver']).name)
for pattern in ('sexos-r101-j-*.json','sexos-r101-j-*.log','sexos-r101-j-*.py','sexos-r101-j-*.disassembly','sexos-r101-j-*.elf'):
    for p in sorted(T.glob(pattern)):
        name='checks/'+p.name
        if name not in members:add(p,name)
for p in sorted(T.glob('sexos-r101-i-status-viewport-negative-control*')):add(p,'diagnostics/'+p.name)
for p in (T/'sexos-r101-ipc-return-frozen-c-negative.log',T/'sexos-r101-ipc-return-host-gate.log'):
    if p.exists():add(p,'diagnostics/'+p.name)
for letter in ('c','d','e','f','g','h','i'):
    out=T/f'sexos-r101-{letter}-native-clipboard-wide'
    if out.exists():
        for p in sorted(out.rglob('*')):
            if p.is_file() and p.suffix!='.img':add(p,'diagnostics/'+letter+'/'+str(p.relative_to(out)))
    frozen=T/f'sexos-alpha-r101-clipboard-{letter}-frozen'
    if frozen.exists():
        add(frozen/'source-binding.json','diagnostics/'+letter+'/source-binding.json')
        add(frozen/'source/kernel/src/interrupts.rs','diagnostics/'+letter+'/kernel-interrupts.rs')
        add(frozen/'source/scripts/clipboard_workflow_gate.py','diagnostics/'+letter+'/clipboard_workflow_gate.py')
seed=T/'sexos-r100a-seed.img'; seed_gz=T/'sexos-r101-j-seed.img.gz'
seed_gz.write_bytes(gzip.compress(seed.read_bytes(),mtime=0));add(seed_gz,'seed.img.gz')

screens=[]
for run,boot,filename,label in [
    ('clipboard-wide','write','browser-reflow.ppm','selection-wide'),
    ('clipboard-compact','write','browser-copied.ppm','copy-compact'),
    ('clipboard-compact','write','quil-capacity-rejected.ppm','capacity-compact'),
    ('clipboard-compact','recovery','quil-cold-reopened.ppm','cold-compact')]:
    out=Path(next(r['out'] for r in progress if r['name']==run))/boot
    frames=load(out/'frames.json');frame=next(f for f in frames if f['screenshot']==filename)
    assert frame['result']['ok'] and frame['screenshot_sha256']==sha(out/filename)
    dest=A/f'{stem}-{label}.png'; assert not dest.exists()
    Image.open(out/filename).save(dest)
    screens.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=run,boot=boot,raw_ppm=filename,raw_sha256=sha(out/filename),serial_bytes=frame['serial_bytes'],serial_sha256=frame['serial_sha256']))

archive=A/f'{stem}-qualified-raw.tar.gz';assert not archive.exists()
inventory=[dict(name=name,bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(members.items())]
with tarfile.open(archive,'w:gz') as tar:
    for row in inventory:
        path=members[row['name']];assert sha(path)==row['sha256'];tar.add(path,arcname=row['name'],recursive=False)
    data=(json.dumps(dict(scope='Final J acceptance plus separately named failed diagnostic attempts; diagnostic artifacts add no acceptance',members=inventory),indent=2)+'\n').encode()
    info=tarfile.TarInfo('archive-inventory.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    actual=tar.getmembers();assert len(actual)==len(inventory)+1 and all(p.isfile() for p in actual)
    for row in inventory:
        data=tar.extractfile(row['name']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']

evidence=dict(round=101,accepted=True,accepted_goal_rounds=22,total_goal_rounds=121,remaining_goal_rounds=99,
    iso_sha256=binding['iso_sha256'],kernel_sha256=binding['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),
    architecture_sha256=binding['architecture_sha256'],production_inputs=len(binding['sources']),runner_inputs=len(binding['runner_sha256']),
    checks=dict(master='BUILD PASS / GREEN_MASTER',rust=logs,rust_test_executions=sum(r['executions'] for r in logs),python_tests=python_count,python_log_sha256=sha(python_log:=T/'sexos-r101-j-frozen-python.log'),native_runs=6,native_boots=10,root_replay_sha256=sha(T/'sexos-r101-j-root-independent-replay.json'),scalar_audit=scalar),
    qualification_runs=progress,remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=screens,
    archive=dict(path=str(archive.relative_to(R/'docs/handoff')),sha256=sha(archive),members=len(inventory)+1,verified=True,bytes=archive.stat().st_size),
    failed_diagnostics='C syscall RDI return defect; D trailing UTF8 runner boundary; E input ordering; F focus; G y50/fresh viewport checker; H unsupported test-name key; I real status-driven viewport drift. None accepted; final J reruns both clipboard profiles and affected regressions.',
    limitations=['Selection and payload are bounded ASCII/LF, at most12288 bytes, with keyboard selection only.','Native proves full Browser Copy→Quil Paste, capacity refusal, producer terminal retirement, empty subsequent read, Save and cold reopen; Cut/races/Full/forged sender cases are actual-function host checks, not hostile native certification.','Exact incarnation/catalog routes and scalar sender metadata do not themselves prove hostile PKU containment, raw pointer route removal or whole-stack/register/cache erasure.','Laboratory DNS/HTTP and controlled pinned-root HTTPS regressions only; no public web/general CA qualification.','No crash/power-loss, physical hardware, SMP, sustained latest-image daily-driver, deterministic whole-system replay or System Proven claim.'],
    scope='One substantive round: authenticated finite cross-app selection/clipboard and stable rejected-paste layout, qualified on one exact sealed image with fresh host gates and ten native boots.')
(A/f'{stem}-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps(dict(ok=True,round=101,counts=evidence['checks'],archive=evidence['archive'])))
