"""Prepared compact round89 archive. Execute only after root confirms20 passes.
No build, test suite, native workflow, staging or commit is launched here.
"""
from pathlib import Path
import hashlib,json,re,os,shutil,subprocess,tarfile
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Users/xmacbookm5/Projects/Sex');ASSETS=ROOT/'docs/handoff/assets';LOCAL=ROOT/'.evidence/alpha-2026-10-29/r89'
FROZEN=Path('/tmp/sexos-alpha-r89-frozen');BUILD=Path('/tmp/sexos-alpha-r89-build');HOST=Path('/tmp/sexos-alpha-r89-host')
PYTHON=Path('/tmp/sexos-r89-python-driver.log');SUITE=Path('/tmp/sexos-r89-native-suite.py');PROGRESS=Path('/tmp/sexos-r89-native-suite-progress.json')
ISO='217f171fe14651fce2ca06fac968d94d1cc6d84d0aa9278bce60cd9428cb1c20'
REQUIRED=['entropy-ready-wide','entropy-ready-compact','entropy-unsupported-wide','entropy-unsupported-compact','entropy-close-wide','entropy-close-compact','chain-e1000e','contention-e1000e','stream-e1000e','chain-e1000','contention-e1000','stream-e1000','redirect-cancel-retry','redirect-close-compact','profile','compact','document-reboot','history-reboot','switch-wide','switch-compact']

def j(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as file:
  for part in iter(lambda:file.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def tree_files(path):
 path=Path(path);assert path.is_dir(),path
 for file in sorted(path.rglob('*')):
  assert not file.is_symlink(),file
  if file.is_file():yield file

def bound_snapshot():
 b=j(FROZEN/'source-binding.json');p=b['build_provenance']
 assert b['iso_sha256']==ISO==p['iso_sha256']==sha(FROZEN/'tested.iso')
 assert p['build_gate']=='PASS'and p['source_image_binding']=='sealed_build_this_run'and p['sources_unchanged_during_build']is True
 assert b['sources']==p['production_source_sha256']and len(b['sources'])==407 and len(b['runner_sha256'])==472
 assert sha(FROZEN/'tested.kernel')==b['kernel_sha256']
 for group in('sources','runner_sha256'):
  for name,digest in b[group].items():assert sha(FROZEN/'source'/name)==digest,(group,name)
 build=(BUILD/'report.md').read_text();assert re.search(r'FINAL_SCORE[^\n]*GREEN_MASTER',build)and re.search(r'BUILD_GATE[^\n]*PASS',build)and 'probe_seconds: 90'in build
 assert j(BUILD/'provenance.json')['iso_sha256']==ISO
 return b,build

def check_run(name,binding):
 p=Path('/tmp/sexos-alpha-r89-'+name);r=j(p/'result.json');m=j(p/'manifest.json');assert r['ok'],p
 actual=m['iso_sha256']if'iso_sha256'in m else m['binding']['iso_sha256'];assert actual==ISO,p
 if'binding'in m:
  held=m['binding'];assert held['sha256']==sha(FROZEN/'source-binding.json')and held['iso_sha256']==ISO and held['production_files']==407 and held['runner_files']==472,p
 for group in('runner_sha256','pixel_source_sha256','authority_source_sha256'):
  for file,digest in m.get(group,{}).items():
   if group=='runner_sha256'and '/'not in file:file='scripts/'+file
   assert sha(FROZEN/'source'/file)==digest,(name,group,file)
 assert(p/'nvme.img').is_file()
 for file in('check_nic_command.json','check_self_wait.json','check_document_views.json','check_document_snapshots.json'):
  if(p/file).exists():assert j(p/file)['ok'],(name,file)
 if(p/'check_nic_command.json').exists():
  nic=j(p/'check_nic_command.json');assert nic['configuration']['ok']and nic['routing']['ok'],name
 else:assert name=='entropy-ready-wide',('missing coordinator receipt',name)
 trace=(p/'serial.log').read_text(errors='replace');assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[sexfiles.defer.drop\]',trace),name
 if name.startswith('entropy-'):
  assert r['source_metadata']['ok']and r['public_wire']['ok']and r['owner_packet_joins']['ok']and r['authority']['ok']and r['self_wait']['ok'],name
  assert r['mode']==name.split('-')[1]
  assert(m['model'],m['resolution'])==(('e1000','1024x768')if name.endswith('compact')else('e1000e','1280x800'))
 summary=dict(name=name,result_ok=True,manifest='native/'+p.name+'/manifest.json',result='native/'+p.name+'/result.json',serial='native/'+p.name+'/serial.log',disk='native/'+p.name+'/nvme.img',mode=m.get('mode'),model=m.get('model'),resolution=m.get('resolution',r.get('resolution')),source_binding_sha256=sha(FROZEN/'source-binding.json'))
 if name in('profile','compact'):
  summary['private_pages']=sum(int(n)for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace));assert summary['private_pages']>=350
 if name.startswith('switch-'):
  records=r['switches'];assert r['switch_cycles']==10 and r['routes']==[[300,200,201,153]]*10 and len(records)==40
  assert r['cleanup_roles']==[1,2,4,8,16]and r['plain_tab_local']and r['legacy_placeholders_absent']and r['pixel_errors']==[]
  assert [(int(a),int(b))for a,b in re.findall(r'\[shell.app.switch\] old=(\d+) new=(\d+) live=1 shortcut=alt_tab',trace)]==[(x['old'],x['new'])for x in records]
  assert len(list(p.glob('focus-*.ppm')))==40
  summary['switches']=40
 return p,summary

# Import frozen checker modules only. All original raw files remain unchanged.
ENTROPY_REPLAY=r'''
import sys,json,re,hashlib
from pathlib import Path
source=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(source/'scripts'))
import entropy_seed_gate as gate
from check_nic_command import inspect as nic
from check_self_wait import inspect as self_wait
from check_tcp_capture import inspect as tcp
from network_contention_gate import owner_joins,cleanup_receipts
r=json.loads((out/'result.json').read_text());m=json.loads((out/'manifest.json').read_text());trace=(out/'serial.log').read_text();raw=(out/'wire.pcap').read_bytes();contract=gate.seed_contract(source);mode=m['mode']
metadata=gate.inspect_seed(trace,mode,m['command']);assert metadata['ok'],metadata
assert metadata==r['source_metadata']
assert m['qemu_version'].startswith('QEMU emulator version ')
authority=nic(trace,expected=1,preparation=True,ethernet=True,network_config=True,routing=True);assert authority['ok'];assert self_wait(trace)['ok']
peer=json.loads((out/'endpoint-exchanges.json').read_text());assert peer['seed_values_recorded']is False
wire=tcp(raw,peer['public_baseline'],guest_ports=range(48001,65536),initiator='guest');assert wire['ok']
assert owner_joins(trace,raw,[(15,15)])['ok'];checked=[]
for pixel in r['pixels']:
 assert pixel['ok'];image=(out/pixel['screenshot']).read_bytes();assert hashlib.sha256(image).hexdigest()==pixel['screenshot_sha256']
 for name,digest in pixel['source_sha256'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
 if pixel['screenshot']=='seed-first.ppm':
  clear=re.search(r'\[shell.browser.input\] code=16 down=1 slot=43 accepted=1',trace);assert clear;prefix=trace[:clear.start()]
 elif pixel['screenshot']=='seed-cleared.ppm':
  intents=list(re.finditer(r'\[browser.entropy.intent\] accepted=1 explicit=1 fallback=0',trace));assert len(intents)==2;prefix=trace[:intents[1].start()]
 else:prefix=trace
 actual=gate.verify_seed_pixels(prefix,image,pixel['expected'],contract,list(map(int,m['resolution'].split('x'))));assert actual['ok'],actual
 checked.append(dict(screenshot=pixel['screenshot'],state=pixel['expected'],checked_pixels=actual['checked_pixels']))
if mode=='close':
 closed=re.search(r'\[browser.entropy.closed\] target=15 task=15 pending=1 terminal=1 private_payload=erased',trace);assert closed
 cleanup=cleanup_receipts(trace,15,15,closed.start());assert cleanup==r['cleanup'];assert (out/'seed-closed.ppm').is_file()
 assert not re.search(r'\[net\.(?:job|dns)\.egress\.submit\]',trace[cleanup['ack_offset']:])
else:assert len(checked)==3
print(json.dumps(dict(ok=True,mode=mode,cpu_profile=gate.command_profile(m['command'],mode),sample_metadata_observed=len(metadata['samples_observed']),ready_cleanup_joins=len(metadata['joins']),pixels=checked,closed_pending=mode=='close',secret_values_or_derivatives_recorded=False)))
'''

def replay_entropy(path):
 output=subprocess.check_output(['python3','-c',ENTROPY_REPLAY,str(FROZEN/'source'),str(path)],text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});result=json.loads(output);assert result['ok'];return result

def raw_archive(label,roots):
 name=f'sexos-alpha-r89-{label}-2026-10-30-raw.tar.gz';target=ASSETS/name;members=[]
 with tarfile.open(target,'w:gz',compresslevel=9)as archive:
  for arcroot,source in roots:
   source=Path(source)
   if source.is_dir():files=[(arcroot+'/'+str(file.relative_to(source)),file)for file in tree_files(source)]
   else:assert source.is_file();files=[(arcroot,source)]
   for member,file in files:
    assert not file.is_symlink();digest=sha(file);archive.add(file,arcname=member,recursive=False)
    assert sha(file)==digest,('source changed during archive',file)
    members.append(dict(path=member,size=file.stat().st_size,sha256=digest))
 assert len({x['path']for x in members})==len(members)
 # Independently decompress every member immediately; no extraction, links or
 # path traversal. Inventory is compact metadata, not duplicated result JSON.
 expected={x['path']:x for x in members};seen=set()
 with tarfile.open(target,'r:gz')as archive:
  for member in archive:
   assert member.isfile()and member.name in expected and member.name not in seen
   h=hashlib.sha256();size=0;stream=archive.extractfile(member)
   for part in iter(lambda:stream.read(1024*1024),b''):h.update(part);size+=len(part)
   assert(size,h.hexdigest())==(expected[member.name]['size'],expected[member.name]['sha256']),member.name;seen.add(member.name)
 assert seen==set(expected)
 return dict(path=name,sha256=sha(target),compressed_bytes=target.stat().st_size,regular_members=len(members),uncompressed_bytes=sum(x['size']for x in members),members=members,decompression_verified=True)

def png(source,label,scope):
 source=Path(source);raw=source.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',raw);assert header,source
 dimensions=list(map(int,header.groups()));assert len(raw)-header.end()==dimensions[0]*dimensions[1]*3
 target=ASSETS/f'sexos-alpha-r89-{label}-2026-10-30.png';subprocess.run(['sips','-s','format','png',str(source),'--out',str(target)],check=True,stdout=subprocess.DEVNULL)
 data=target.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'and[int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')]==dimensions
 return dict(path=target.name,sha256=sha(target),source_ppm_sha256=sha(source),dimensions=dimensions,scope=scope)

def archive():
 # Nothing is published before all20 actual current coordinator rows pass.
 rows=j(PROGRESS);assert len(rows)==20 and [x['name']for x in rows]==REQUIRED and all(x['status']==0 for x in rows)
 assert all(x['out']=='/tmp/sexos-alpha-r89-'+x['name']for x in rows)
 binding,build_report=bound_snapshot();host=j(HOST/'report.json');assert host['checks_passed']and host['sources_unchanged_during_checks']and host['run_status']=='complete'and len(host['checks'])==38 and all(x['exit_code']==0 for x in host['checks'])
 for name,digest in host['source_sha256'].items():assert sha(FROZEN/'source'/name)==digest
 rust=sum(int(n)for file in HOST.glob('*.log')for n in re.findall(r'test result: ok\. (\d+) passed',file.read_text(errors='replace')));assert rust>0
 python=PYTHON.read_text();assert re.findall(r'^Ran (\d+) tests in ',python,re.M)==['457']and python.rstrip().endswith('OK')
 obligations=host['obligations'];assert list(obligations.values()).count('open')==7 and list(obligations.values()).count('partial')==23 and host['system_proven']is False
 paths={};summaries=[];entropy={}
 for name in REQUIRED:
  path,summary=check_run(name,binding);paths[name]=path;summaries.append(summary)
  if name.startswith('entropy-'):entropy[name]=replay_entropy(path)
 assert len(entropy)==6
 pages={s['name']:s['private_pages']for s in summaries if'private_pages'in s};switches={s['name']:s['switches']for s in summaries if'switches'in s};assert sum(switches.values())==80
 ASSETS.mkdir(parents=True,exist_ok=True);LOCAL.mkdir(parents=True,exist_ok=True)
 archives={}
 archives['frozen']=raw_archive('frozen',[('frozen',FROZEN)])
 archives['native']=raw_archive('native',[('native/'+path.name,path)for path in paths.values()])
 drivers=sorted(set(Path('/tmp').glob('sexos-r89*driver.log'))|set(Path('/tmp').glob('sexos-alpha-r89*driver.log')))
 assert Path('/tmp/sexos-r89-entropy-ready-wide-driver.log')in drivers
 host_roots=[('host',HOST),('build',BUILD),('orchestration/native-suite.py',SUITE),('orchestration/native-suite-progress.json',PROGRESS),('orchestration/save.py',Path('/tmp/sexos-save-r89.py'))]+[('drivers/'+file.name,file)for file in drivers]
 assert PYTHON in drivers
 archives['host_build_orchestration']=raw_archive('host-build-orchestration',host_roots)
 images={};selections=[('entropy-ready-wide','seed-first.ppm','seed-ready-wide','Full64-byte source-bound Ready status; no seed data.'),('entropy-ready-compact','seed-first.ppm','seed-ready-compact','Actual1024x768 full Ready status.'),('entropy-ready-wide','seed-cleared.ppm','seed-cleared-wide','Actual Q full64-byte Cancelled replacement and trailing erasure.'),('entropy-ready-compact','seed-cleared.ppm','seed-cleared-compact','Actual compact Q erasure.'),('entropy-unsupported-wide','seed-first.ppm','seed-unsupported-wide','Explicit CPU disabled RDSEED/RDRAND: visible Unavailable, no samples/admissions.'),('entropy-unsupported-compact','seed-first.ppm','seed-unsupported-compact','Actual compact unsupported CPU status.'),('entropy-close-compact','seed-closed.ppm','seed-pending-close-compact','After-close framebuffer; exact pending ownership, private retirement-before-ACK and Sext are established by raw serial receipts, not an active seed label.'),('profile','third-quil-edit.ppm','profile','Existing desktop profile regression; no own sustained-session claim.')]
 for run,file,label,scope in selections:images[label]=png(paths[run]/file,label,scope)
 evidence=dict(round=89,scope='CPU RDSEED private seed32 foundation through exact immutable BOOT holder/consumer identities and existing sex-pdx route; GLOBAL_VAS is addressing only. No seed values/derivatives are logged or archived as protocol evidence.',iso_sha256=ISO,kernel_sha256=binding['kernel_sha256'],source_binding_sha256=sha(FROZEN/'source-binding.json'),source_counts=dict(production=407,runners=472),source_binding_member='frozen/source-binding.json',host=dict(gates=38,rust_executions=rust,python_tests=457,report_member='host/report.json'),native=dict(count=20,coordinator_sha256=sha(SUITE),progress_sha256=sha(PROGRESS),runs=summaries),entropy_independent_frozen_replay=entropy,archives=archives,selected_images=images,private_pages=pages,ordinary_switches=switches,ordinary_switches_total=80,configReceipts=True,routingReceipts=True,selfWaitReceipts=True,acceptance_status=dict(open=7,partial=23,system_proven=False),candidate_failures=[],limits=[
 'Six actual E/Q/E supported, unsupported and pending-Close runs cover e1000e1280x800/e1000 1024x768. Exact QEMU versions/commands and frozen runner/source binding remain in raw manifests. Positive CPU profile forbids seed/icount/incoming/replay/loadvm flags; unsupported profile explicitly disables RDSEED and RDRAND. This is not randomness-quality or opcode-exclusivity certification.',
 'Provider receipts contain only exact holder task/slot, bounded attempts and sampled ordinal metadata. Fourwords form32private bytes; Client takes only after all actual correlated READs and positive RELEASE. Native source-bound Ready guards plus actual host client/broker tests establish transfer completeness; no nonexistent native consumed32 receipt is invented. All secret buffers/READ receipts have explicit volatile cleanup; registers/CPU caches are outside that claim.',
 'Pending Close requires an actual admitted owned job and pending client, private retirement before cleanup ACK, five exact-task service roles and Sext pool return. Source values, fingerprints or value differences are never used as success evidence. Prior submitted DMA is separate driver custody.',
 'Other actual regressions cover redirect chains/fresh DNS/release barriers, shared-client contention, full12KiB reader on both NIC/resolution pairs, redirect cancel/Close, desktop profiles, both durable reboots and40switches per resolution80total. Full raw PCAP/disks/serial/pixels/results/checkers are retained; no older candidate failure is borrowed.',
 'No TLS construction, public internet/arbitrary endpoints, own sustained session, physical hardware, hostile containment, SMP, DMA/IOMMU epochs, complete replay closure, hard performance, instruction exclusivity or source-quality certification. Seven Open and23Partial obligations remain; System Proven is false.'
 ])
 target=ASSETS/'sexos-alpha-r89-2026-10-30-evidence.json';target.write_text(json.dumps(evidence,indent=2)+'\n')
 for archive in archives.values():shutil.copyfile(ASSETS/archive['path'],LOCAL/archive['path'])
 shutil.copyfile(target,LOCAL/target.name)
 print(json.dumps(dict(evidence=str(target),evidence_sha256=sha(target),archives=len(archives),pngs=len(images),raw_members=sum(x['regular_members']for x in archives.values()),compressed_bytes=sum(x['compressed_bytes']for x in archives.values()),native=20,host_gates=38,rust_executions=rust,python_tests=457,private_pages=pages,switches=80,local=str(LOCAL))))

if __name__=='__main__':archive()
