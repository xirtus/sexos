from pathlib import Path
import json,os,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-civil-redraw-a-frozen').resolve();R=F/'source';sys.path.insert(0,str(R/'scripts'))
from https_import_gate import wait_ports
P=T/'sexos-civil-redraw-a-extra-native-progress.json';assert not P.exists();rows=[]
def guests():
 result=[]
 for line in subprocess.check_output(['ps','-axo','pid=,etime=,comm='],text=True).splitlines():
  fields=line.split(None,2)
  if len(fields)!=3 or Path(fields[2]).name!='qemu-system-x86_64':continue
  value=fields[1];days=0
  if '-'in value:day,value=value.split('-',1);days=int(day)
  result.append(dict(pid=int(fields[0]),age_seconds=days*86400+sum(int(v)*n for v,n in zip(reversed(value.split(':')),(1,60,3600)))))
 return result
plan=[('clock-invalid-year-'+label,'certificate_time_gate.py',['--mode','invalid-year'],label,model,res,4,1)for label,model,res in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]]
plan += [('responsive-'+label,'tls_responsiveness_gate.py',[],label,model,res,0,1)for label,model,res in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]]
for name,script,extra,label,model,res,count,boots in plan:
 out=T/('sexos-civil-redraw-a-extra-native-'+name);driver=T/('sexos-civil-redraw-a-extra-native-'+name+'-driver.log');ports=T/'sexos-civil-redraw-a-extra-ports'/name;assert not out.exists()and not driver.exists()and not ports.exists();ports.mkdir(parents=True);command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',res,*extra];row=dict(name=name,status='awaiting_stable_other_guest_startup',out=str(out),driver=str(driver),ports=str(ports),command=command,profile=dict(label=label,model=model,resolution=res),observations=[]);rows.append(row);began=time.monotonic()
 while True:
  current=guests();row['observations'].append(dict(host_monotonic=time.monotonic(),guests=current));P.write_text(json.dumps(rows,indent=2)+'\n')
  if not any(g['age_seconds']<120 for g in current):break
  if time.monotonic()-began>600:raise TimeoutError('other new guests keep sharing fixture ports; preserve and coordinate')
  time.sleep(10)
 row['other_guests_before']=current;wait_ports(ports);row['status']='running';P.write_text(json.dumps(rows,indent=2)+'\n');print('START',name,flush=True);began=time.monotonic()
 with driver.open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began,other_guests_after=guests());P.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 result=json.loads((out/'result.json').read_text());assert result['ok']
 if script=='certificate_time_gate.py':assert result['replay']['ok']and result['replay']['captures']==count
 elif script=='connected_desktop_gate.py':assert result['boots']==boots and result['frames']==count
 else:count=len(result['pixels']);assert count>=3 and len([p for p in result['pixels']if p['kind']=='clock'])==3
 row.update(boots=boots,verified_captures=count);P.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==4 and sum(r['boots']for r in rows)==4 and sum(r['verified_captures']for r in rows)>=14
print('REDRAW_4_EXTRA_COHORTS_PASS',flush=True)
