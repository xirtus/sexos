from pathlib import Path
import hashlib,json,sys
T=Path('/tmp');F=T/'sexos-civil-redraw-a-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
from silkbar_clock_gate import repaint_metrics
from network_contention_gate import frozen_binding
b=frozen_binding(R,F/'tested.iso',F/'source-binding.json');paths=[('boot-probe',T/'sexos-civil-redraw-a-build'),('compact-workflow',T/'sexos-civil-redraw-a-compact-rehearsal'),('wide-workflow',T/'sexos-civil-redraw-a-wide-rehearsal')]+[(r['name'],Path(r['out']))for r in json.loads((T/'sexos-civil-redraw-a-extra-native-progress.json').read_text())];rows=[]
for name,out in paths:
 serial=out/'serial.log';trace=serial.read_text(errors='replace');m=repaint_metrics(trace);receipts=m.pop('completed_civil_draws');rows.append(dict(name=name,serial=str(serial),serial_sha256=hashlib.sha256(serial.read_bytes()).hexdigest(),**m,completed_draw_receipts=receipts));print(name,m['admissions'],m['clock_repaint_requests'],m['unchanged_admissions'],receipts,flush=True)
result=dict(ok=True,binding=b,cohorts=rows,draw_receipt_semantics='civil_clock_drawn deduplicates identical stamps. Completed-draw receipts are not a count of every top-strip redraw invocation.',scope='Repaint decisions recomputed from chronological actual source admissions and health state, using both rendered rows. Source sampling cadence, source authority, model admission and health refresh remain. No CPU/input-latency/wall-time speedup or sustained-session claim.')
(T/'sexos-civil-redraw-a-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
