from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-civil-redraw-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');old=read(T/'sexos-alpha-evidence-a-frozen/source-binding.json');delta=[n for n in b['sources']if b['sources'][n]!=old['sources'][n]];assert delta==['servers/sexdisplay/src/main.rs']
for n,d in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==d,n
assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
h=read(T/'sexos-civil-redraw-a-host42/report.json');assert h['checks_passed']and len(h['checks'])==42 and not h['source_drift']
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(v['log']).read_text())))for v in h['checks']);assert rust==2630
py=(T/'sexos-civil-redraw-a-python.log').read_text();assert'Ran 906 tests in 'in py and py.rstrip().endswith('OK')
scalar=read(T/'sexos-civil-redraw-a-scalar-v2/result.json');assert scalar['ok']and scalar['iso_sha256']==b['iso_sha256']and len(scalar['results'])==5
extra=read(T/'sexos-civil-redraw-a-extra-independent-replay.json');assert extra['ok']and extra['boots']==4 and extra['verified_captures']==28
workflows=[]
for mode in ['compact','wide']:
 v=read(T/('sexos-civil-redraw-a-'+mode+'-independent-replay.json'));assert v['ok']and not v['acceptance']and v['verified_captures']==20
 workflows.append(dict(profile=mode,**v))
metrics=read(T/'sexos-civil-redraw-a-metrics.json');assert metrics['ok']and len(metrics['cohorts'])==7
items={};disks=[]
def add(name,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and name not in items;items[name]=p

def compress(p):
 p=Path(p);assert not subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True).stdout.strip(),'disk writer still open'
 raw=p.read_bytes();z=p.with_name(p.name+'.gz')
 if not z.exists():
  with z.open('xb')as target:
   with gzip.GzipFile(filename='',fileobj=target,mode='wb',mtime=0)as g:g.write(raw)
 assert gzip.decompress(z.read_bytes())==raw;disks.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=sha(z)))

def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*.img')):compress(p)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,folder in [('frozen','sexos-civil-redraw-a-frozen'),('build','sexos-civil-redraw-a-build'),('host','sexos-civil-redraw-a-host42'),('scalar','sexos-civil-redraw-a-scalar-v2')]:tree(prefix,T/folder)
for mode in ['compact','wide']:tree('native/workflow-'+mode,T/('sexos-civil-redraw-a-'+mode+'-rehearsal'))
for row in extra['runs']:tree('native/'+row['name'],row['out'])
# Explicit terminal cohort list: both live alpha trees and logs are excluded.
for name in ['sexos-civil-redraw-a-build-console.log','sexos-civil-redraw-a-host42-driver.log','sexos-civil-redraw-a-python.log','sexos-civil-redraw-a-freeze.log','sexos-civil-redraw-a-compact-driver.log','sexos-civil-redraw-a-wide-driver.log','sexos-civil-redraw-a-compact-independent-replay.json','sexos-civil-redraw-a-wide-independent-replay.json','sexos-civil-redraw-a-extra-suite.py','sexos-civil-redraw-a-extra-suite-driver.log','sexos-civil-redraw-a-extra-native-progress.json','sexos-civil-redraw-a-independent-extra-replay.py','sexos-civil-redraw-a-independent-extra-replay.log','sexos-civil-redraw-a-extra-independent-replay.json','sexos-civil-redraw-a-metrics.py','sexos-civil-redraw-a-metrics.json','sexos-civil-redraw-a-metrics.log','sexos-civil-redraw-a-scalar-audit-v2.py','sexos-civil-redraw-a-scalar-driver-v2.log','sexos-civil-redraw-a-scalar-audit.py','sexos-civil-redraw-a-scalar-driver.log']:
 add('coordination/'+name,T/name)
for name in ['limine','limine-bios-cd.bin','limine-uefi-cd.bin','limine-bios.sys']:add('bootloader/'+name,R/'limine'/name)
add('coordination/package.py',Path(__file__));manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-civil-clock-repaint-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for name,p in sorted(items.items()):tar.add(p,arcname=name,recursive=False)
 member=tarfile.TarInfo('payload-members.json');member.size=len(raw);member.mode=0o644;tar.addfile(member,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  data=tar.extractfile(m).read();expected=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],m.name
result=dict(qualified_on_feature_branch=True,goal_complete=False,branch='codex/civil-clock-redraw',base='20c50957027e69c258b98e701ef1efab0d2563f6',production_delta=delta,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),build='GREEN_MASTER',registered_host_checks=42,rust_test_executions=rust,python_tests=906,compiled_controls=dict(actual_authority_guard_removed_rejected=True,actual_redraw_suppression_removed_rejected=True,within_registered_host_gate=True,binaries_retained=False,exact_checker_and_test_inputs_retained=True),native=dict(boots=6,verified_captures=68,workflow_boots=2,workflow_captures=40,invalid_source_boots=2,invalid_source_captures=8,tls_responsiveness_boots=2,tls_responsiveness_captures=20,independent_replay=True,workflow_acceptance=False),repaint_metrics=metrics,scalar=dict(elfs=5,instructions=sum(v['instructions']for v in scalar['results']),inspected_vector_fp_matches=0,results=scalar['results'],scope=scalar['scope']),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(raw).hexdigest(),all_members_size_and_sha256_verified=True,disks=disks),diagnostics='Initial scalar-wrapper tool discovery found no llvm-objdump in the pinned compiler sysroot; the successful v2 wrapper uses the existing installed decoder, recording its version and exact commands. Both wrapper/log inputs retained. No native attempt failed.',scope='Only Display repaint selection changes. Fresh canonical source admissions still advance sequence/health; both actual text rows determine dirty state, preserving other dirty causes. Receipt counts deduplicate identical completed stamps and are not total top-strip render calls. Two short native workflows plus invalid-source/TLS regressions on this exact image; no sustained-alpha, CPU/latency speedup, physical/power-loss/SMP, global epoch replay or System Proven claim. The separately live compact/wide1800s cohorts use the earlier image and are excluded.')
p=A/'sexos-civil-clock-repaint-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('ARCHIVE',len(items)+1,'verified members',archive.stat().st_size,'bytes');print('Native6 boots68 captures; five ELFs',result['scalar']['instructions'],'instructions; production delta Display only')
