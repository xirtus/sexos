from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-spindle-eight-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
rows=read(T/'sexos-spindle-eight-a-sustained-progress.json');assert len(rows)==2 and all(row['status']==0 and row['fresh_replay']for row in rows)
audit=read(T/'sexos-spindle-eight-a-source-audit.json');b=read(F/'source-binding.json');h=read(T/'sexos-spindle-eight-a-frozen-host/report.json');previous=read(A/'sexos-eight-spindle-reserve-2026-10-31-evidence.json')
assert audit['ok']and audit['commit']=='502dda457c9fc8e22733918f20c8b37750cee022'and previous['iso_sha256']==b['iso_sha256']and previous['kernel_sha256']==b['kernel_sha256']
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2730
assert 'Ran 1017 tests in 'in(T/'sexos-spindle-eight-a-frozen-python.log').read_text()
for group in ['sources','runner_sha256']:
 for name,value in b[group].items():assert sha(F/'source'/name)==value,name
profiles=[]
for row in rows:
 out=Path(row['out']);r=read(out/'result.json');v=read(T/(out.name+'-independent-replay.json'));s=r['soak'];q=s['third_quil']
 assert r['ok']and r['acceptance']and v['ok']and v['acceptance']and s['elapsed_seconds']>=1800 and v['cycles']==s['cycles']and v['verified_captures']==len(r['stages'])
 assert [step['target']for step in r['soak']['third_spindle']['chain']]==[24,25,26,27,28,29]and r['soak']['third_spindle']['reserve_exhausted']
 assert q['final_target']==23 and q['append_count']==6 and [step['target']for step in q['chain']]==[18,19,20,21,22,23]and not s['cleanup_errors']
 
 for step in q['chain']:assert step['frame']['proof']['native_family']==dict(focus=step['surface'],app='Quil',indicator='0xcba6f7')
 profiles.append(dict(profile=row['profile'],cycles=s['cycles'],verified_captures=len(r['stages']),elapsed_seconds=s['elapsed_seconds'],active_elapsed_seconds=s['active_elapsed_seconds'],idle_elapsed_seconds=s['idle_elapsed_seconds'],terminal_scope=s['quil_close']['terminal_scope'],pending_device_close=s['pending_quil_close'],remaining_obligations=s['remaining_obligations'],all_eight_quil_finished=True,last_target=23,disk_documents=r['disk_documents'],fresh_replay=True))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('host',T/'sexos-spindle-eight-a-frozen-host')
for row in rows:
 out=Path(row['out']);tree('sessions/'+row['profile'],out)
 for suffix in ['-independent-replay.json','-driver.log']:add('coordination/'+out.name+suffix,T/(out.name+suffix))
for name in ['sexos-spindle-eight-a-source-audit.json','sexos-spindle-eight-a-frozen-python.log','sexos-spindle-eight-a-frozen-host-driver.log','sexos-spindle-eight-a-sustained.py','sexos-spindle-eight-a-sustained-progress.json','sexos-spindle-eight-a-sustained-driver.log']:add('coordination/'+name,T/name)
add('support/round145-evidence.json',A/'sexos-eight-spindle-reserve-2026-10-31-evidence.json');add('support/scalar-result.json',T/'sexos-spindle-eight-a-scalar-v3/result.json');add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=T/'sexos-eight-spindle-alpha-paired-2026-11-01-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=147,eight_spindle_image_paired_sustained_accepted=True,full_os_goal_complete=False,source_commit=audit['commit'],iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust+8,rust_gate_log_passes=rust,additional_extracted_lifecycle_cases=8,python_tests=1017,native=dict(acceptance_boots=2,cycles=sum(p['cycles']for p in profiles),verified_captures=sum(p['verified_captures']for p in profiles),profiles=profiles,all_fresh_replays=True),support=dict(round145_same_image_evidence='sexos-eight-spindle-reserve-2026-10-31-evidence.json',pending_device_qualification_on_this_image=False,last_quil23_cold_recovery_on_this_image=False,newer_typography_image_accepted=False,cold_spindle29_to12_same_image_short_workflow_qualified=True,long_session_disks_cold_rebooted=False),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Two terminal >=1800s mixed desktop workflows on the Round145 eight-Spindle BOOT reserve production image, with actual input/save/load/history/refresh, all eight Quil and eight Spindle incarnations, complete BOOT successor chain, cleanup, final disk bytes and exhausted launcher. This image retains the old256px Spindle font threshold and original cycle timing; it is distinct from the newer Round146 readable-tile/corrected-timing image. Both strict original replays passed; this is workflow acceptance, not a guest CPU/idle benchmark. No relabelled pending-device close, power-loss, physical/SMP/hostile containment/global epoch or unrestricted daily-driver acceptance claim.')
p=T/'sexos-eight-spindle-alpha-paired-2026-11-01-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('EXPANDED_PAIRED_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','cycles',e['native']['cycles'],'frames',e['native']['verified_captures'],flush=True)
