from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
from PIL import Image
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-browser-sextime-e-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for n,v in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==v,n
proof=read(T/'sexos-browser-sextime-e-independent-replay.json');assert proof['ok']and proof['boots']==10 and proof['verified_captures']==50 and proof['raw_captures']==52
h=read(T/'sexos-browser-sextime-e-host41/report.json');assert h['checks_passed']and len(h['checks'])==41 and h['sources_unchanged_during_checks']and not h['source_drift'];rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2590;inventory=h['obligations'];assert sum(v=='open'for v in inventory.values())==2 and sum(v=='partial'for v in inventory.values())==28
py=(T/'sexos-browser-sextime-e-python.log').read_text();assert 'Ran 854 tests in 'in py and py.rstrip().endswith('OK');audit=read(T/'sexos-browser-sextime-e-scalar/result.json');assert audit['ok']and len(audit['results'])==4 and sum(v['instructions']for v in audit['results'])==222704 and audit['iso_sha256']==b['iso_sha256']
controls=read(T/'sexos-browser-sextime-controls-preflight/sources.json');assert all(sha(F/'source'/n)==v for n,v in controls.items());assert all('test result: FAILED.'in(T/'sexos-browser-sextime-controls-preflight'/(n+'.log')).read_text()for n in ['measure','epoch'])
items={};disks=[]
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p

def compress(p):
 p=Path(p);assert not subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True).stdout.strip();raw=p.read_bytes();z=p.with_name(p.name+'.gz')
 if not z.exists():
  with z.open('xb')as f:
   with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0)as g:g.write(raw)
 assert gzip.decompress(z.read_bytes())==raw;disks.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=sha(z)));return z

def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*.img')):compress(p)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,folder in [('frozen','sexos-browser-sextime-e-frozen'),('build','sexos-browser-sextime-e-build'),('host','sexos-browser-sextime-e-host41'),('scalar','sexos-browser-sextime-e-scalar'),('semantic/calendar','sexos-browser-sextime-controls-preflight')]:tree(prefix,T/folder)
for row in proof['runs']:tree('native/'+row['name'],row['out'])
tree('bootloader',R/'limine');add('bootloader/input-record.json',T/'sexos-browser-sextime-bootloader-inputs.json');add('seed/nvme.img.gz',compress(T/'sexos-r100a-seed.img'))
for p in sorted(T.glob('sexos-browser-sextime-e-*')):
 if p.is_file()and p.suffix in('.py','.json','.log'):add('coordination/'+p.name,p)
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();manifest_sha=hashlib.sha256(raw).hexdigest();archive=A/'sexos-browser-sextime-integrated-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 entry=tarfile.TarInfo('payload-members.json');entry.size=len(raw);entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  data=tar.extractfile(m).read();expected=dict(bytes=len(raw),sha256=manifest_sha)if m.name=='payload-members.json'else manifest[m.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],m.name
screens=[]
for profile in ['wide','compact']:
 source=T/('sexos-browser-sextime-e-native-clock-normal-'+profile)/'clock-tile.ppm';target=A/('sexos-browser-sextime-integrated-2026-10-31-clock-tile-'+profile+'.png');assert not target.exists();im=Image.open(source).convert('RGB');pixels=im.tobytes();im.save(target);assert Image.open(target).convert('RGB').tobytes()==pixels;screens.append(dict(path='assets/'+target.name,sha256=sha(target),source_ppm_sha256=sha(source),pixel_identical=True,width=im.width,height=im.height))
result=dict(qualified_on_feature_branch=True,global_goal_complete=False,branch='codex/browser-sextime',committed_master_base='e5b95eb00285475209f59e54374c8e7a28957235',prior_qualified_checkpoint='bf5de8db2171dbb0af75b92915caf447f894f968',round_number_unassigned=True,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),build='GREEN_MASTER',registered_host_checks=41,rust_test_executions=2590,python_tests=854,compiled_calendar_controls=dict(rejected=2,retained_input_hashes_identical_to_current=controls),native=dict(runs=8,boots=10,verified_captures=50,raw_captures=52,clock_runs=6,clock_verified_captures=16,clock_original_tile_restore_captures=4,close_observational_raw_captures=2,connected_runs=2,connected_live_and_cold_boots=4,connected_verified_captures=34,independent_replay=True,uiir_boot_attachment_and_sampled_focus_records_observed_in_all_boots=True),scalar=dict(elfs=4,instructions=222704,inspected_vector_fp_matches=0,results=audit['results'],scope=audit['scope']),release_gates=dict(open=2,partial=28,system_proven=False,inventory=inventory),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=manifest_sha,all_members_size_and_sha256_verified=True,disks=disks),screenshots=screens,prior_evidence=dict(path='assets/sexos-browser-sextime-2026-10-31-evidence.json',sha256=sha(A/'sexos-browser-sextime-2026-10-31-evidence.json')),diagnostics='The first external E combined replay wrapper expected a nonexistent stored proof key and cold-directory name; original wrapper/log retained. Corrected fresh wrapper uses the existing connected replay result shape and recovery directory. Native source, manifests, captures and result files were unchanged.',scope='One frozen E image/source/checker cohort integrates committed primary e5b95eb0. Clock normal/invalid-year runs restore exact original held-shell tiles after T/Q/T without another query; all four frames are pixel/receipt/source joined. Tiny fallback remains host scope. UiIR observations cover BOOT pairing, attachments and sampled committed focus records, not complete stream capture, rendering authority or global epochs. No later-primary, sustained-newest-image alpha, live/authenticated physical/NTP clock, public-web/CA, physical/SMP, power-loss/crash, hostile-containment, runtime register/cache erasure or System Proven claim.')
p=A/'sexos-browser-sextime-integrated-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['iso_sha256','registered_host_checks','rust_test_executions','python_tests','native']}));print('ARCHIVE',archive.stat().st_size,'bytes',len(items)+1,'size+hash verified members')
