from pathlib import Path
import json,os,re,sys,time
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-browser-sextime-e-frozen').resolve();R=F/'source';sys.path.insert(0,str(R/'scripts'))
from certificate_time_gate import replay_evidence as clock
from connected_desktop_gate import replay as connected
P=T/'sexos-browser-sextime-e-native-progress.json';output=T/'sexos-browser-sextime-e-independent-replay.json';assert not output.exists();start=time.monotonic()
while True:
 rows=json.loads(P.read_text())
 if any(isinstance(r['status'],int)and r['status']!=0 for r in rows):raise RuntimeError('failed native cohort remains diagnostic')
 if len(rows)==8 and all(r['status']==0 for r in rows):break
 if time.monotonic()-start>900:raise TimeoutError('native suite still incomplete')
 time.sleep(5)
checked=[]
for row in rows:
 out=Path(row['out']).resolve();native=json.loads((out/'result.json').read_text());assert native['ok'];is_clock=row['name'].startswith('clock-');proof=clock(R,F/'tested.iso',F/'source-binding.json',out)if is_clock else connected(R,F/'tested.iso',F/'source-binding.json',out)
 if is_clock:assert proof==native['replay']and proof['captures']==row['verified_captures']
 else:assert json.loads(json.dumps(proof))==native and proof['boots']==2 and proof['frames']==17
 logs=[out/'serial.log']if is_clock else[out/'session/serial.log',out/'recovery/serial.log']
 observed=[]
 for path in logs:
  text=path.read_text(errors='strict');assert '[boot.uiir.stream] producer=3 consumer=1 ring_region=9 cursor_region=10 runtime_mint=0'in text and '[uiir.shell.attached] peer=1 ok=1'in text and '[uiir.display.attached] peer=3 ok=1'in text
  records=re.findall(r'\[uiir.display.record\] sequence=(\d+) epoch=(\d+) kind=1 payload=(\d+) in_order=1',text);assert records and all(int(s)>0 and int(e)>0 for s,e,_ in records)and '[uiir.display.error]'not in text and '[uiir.shell.error]'not in text;observed.append(dict(serial=str(path),observed_logged_records=records,scope='Observed BOOT pairing, successful held mappings and logged committed focus records; sampled diagnostics are not complete stream capture or rendering authority.'))
 checked.append(dict(name=row['name'],out=str(out),boots=row['boots'],verified_captures=row['verified_captures'],proof=proof,uiir_observations=observed));print('PASS',row['name'],row['verified_captures'],'captures',flush=True)
result=dict(ok=True,runs=checked,boots=sum(r['boots']for r in checked),verified_captures=sum(r['verified_captures']for r in checked),raw_captures=sum(r['verified_captures']for r in checked)+2,close_observational_raw_captures=2);assert result['boots']==10 and result['verified_captures']==50 and sum(len(r['uiir_observations'])for r in checked)==10;output.write_text(json.dumps(result,indent=2)+'\n');print('FRESH_REPLAY_10_BOOTS_50_VERIFIED_52_RAW_PASS',flush=True)
