"""Semantic case-folding negative control against actual extracted renderer."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('/Users/xmacbookm5/Projects/Sex');F=Path('/tmp/sexos-alpha-r103-font-b-frozen');T=Path('/tmp');P=T/'sexos-r103-b-font-negative-production.rs';B=T/'sexos-r103-b-font-negative-host'
s=(F/'source/scripts/display_surface_groups_gate.sh').read_text();extract=s.split("<<'PY'\n",1)[1].split('\nPY\n',1)[0];sys.argv=['extract',str(F/'source'),str(P)];exec(compile(extract,'frozen-display-extractor','exec'))
s=P.read_text();needle='fn ascii_glyph_index(byte: u8) -> Option<usize> {';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    let byte = byte.to_ascii_uppercase();',1);P.write_text(s)
env=__import__('os').environ.copy();env['DISPLAY_COMPOSITION_SOURCE']=str(P)
r=subprocess.run(['rustc','--edition=2021','--test',str(R/'tests/display_surface_groups.rs'),'-o',str(B)],env=env,capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([str(B),'--exact','actual_text_shader_covers_all_bytes_at_both_scales_without_rewriting_selection','--nocapture','--test-threads=1'],capture_output=True,text=True);log=r.stdout+r.stderr;(T/'sexos-r103-b-font-negative-host.log').write_text(log)
assert r.returncode!=0 and 'w=240 byte=97'in log,log
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=dict(ok=True,negative_rejected=True,returncode=r.returncode,mutation='Only ascii_glyph_index shadows its byte with to_ascii_uppercase; original95-entry ROM and all actual shaders remain.',source_binding_sha256=sha(F/'source-binding.json'),mutant_extracted_source_sha256=sha(P),test_source_sha256=sha(R/'tests/display_surface_groups.rs'),log_sha256=sha(T/'sexos-r103-b-font-negative-host.log'),scope='Actual extracted renderer fails at lowercase a under case-folding; no native hostile or image mutation claim.')
(T/'sexos-r103-b-font-negative.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e))
