"""Actual native mixed-case pixels reject the old uppercase appearance."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
T=Path('/tmp');F=T/'sexos-alpha-r103-font-b-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
import launcher_workflow_gate as g
c=g.source_contract(R);controls=[]
for profile,resolution in [('wide',(1280,800)),('compact',(1024,768))]:
 out=T/('sexos-r103-b-native-launcher-'+profile);assert json.loads((out/'result.json').read_text())['ok'];frames=json.loads((out/'frames.json').read_text());full=(out/'serial.log').read_bytes()
 for name in ('quil-9-typed','spindle-17-typed','launcher-9-bring'):
  frame=next(f for f in frames if f['name']==name);trace=g.input_gate.capture_prefix(full,frame);image=(out/frame['screenshot']).read_bytes();assert g.sha(image)==frame['screenshot_sha256'];positive=g.verify_frame(trace,image,frame,c,resolution);assert json.loads(json.dumps(positive))==frame['result']
  mutant=copy.deepcopy(c)
  for byte in range(ord('a'),ord('z')+1):mutant['font'][byte-32]=mutant['font'][byte-ord('a')+ord('A')-32]
  try:g.verify_frame(trace,image,frame,mutant,resolution)
  except ValueError as exc:failure=str(exc)
  else:raise AssertionError('old uppercase appearance unexpectedly passes '+name)
  controls.append(dict(profile=profile,name=name,negative_rejected=True,error=failure,raw_ppm_sha256=frame['screenshot_sha256'],serial_bytes=frame['serial_bytes'],serial_sha256=frame['serial_sha256']))
result=dict(ok=True,source_binding_sha256=hashlib.sha256((F/'source-binding.json').read_bytes()).hexdigest(),controls=controls,scope='Same raw native Quil/Spindle typed text and launcher names at both resolutions: exact case-sensitive oracle passes; substituting uppercase shapes for lowercase fails. No actual image or production source is modified.')
(T/'sexos-r103-b-native-case-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
