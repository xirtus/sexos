"""Package terminal independently replayed font foundation evidence."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
from PIL import Image
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');F=T/'sexos-alpha-r103-font-b-frozen';B=T/'sexos-alpha-r103-font-b-build';A=R/'docs/handoff/assets';stem='sexos-alpha-r103-2026-10-30'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding=load(F/'source-binding.json');progress=load(T/'sexos-r103-b-native-suite-progress.json');replay=load(T/'sexos-r103-b-root-independent-replay.json');controls=load(T/'sexos-r103-b-native-case-controls.json');negative=load(T/'sexos-r103-b-font-negative.json')
assert replay['ok']and replay['complete']and(replay['native_runs'],replay['native_boots'],replay['frames'])==(4,6,80)
assert replay['source_binding_sha256']==sha(F/'source-binding.json')==controls['source_binding_sha256']==negative['source_binding_sha256']
assert controls['ok']and len(controls['controls'])==6 and all(r['negative_rejected']for r in controls['controls'])and negative['negative_rejected']
assert len(progress)==4 and all(type(r['status'])is int and r['status']==0 for r in progress)
assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for name,digest in {**binding['sources'],**binding['runner_sha256']}.items():assert sha(F/'source'/name)==digest and sha(R/name)==digest,name
assert load(B/'provenance.json')['iso_sha256']==binding['iso_sha256']==sha(F/'tested.iso')
assert '| **FINAL_SCORE** | **GREEN_MASTER** |'in(B/'report.md').read_text()
logs=[]
for label,expected,marker in [('service-custody',1734,'[service.custody.host.gate] PASS'),('display',49,'[gate.display_surface_groups.result] PASS'),('launcher',35,'[launcher.workspace.host] PASS')]:
 p=T/f'sexos-r103-b-frozen-{label}.log';text=p.read_text();assert marker in text;count=sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',text,re.M)));assert count==expected,(label,count);logs.append(dict(name=label,path=str(p),executions=count,sha256=sha(p)))
p=T/'sexos-r103-b-frozen-python.log';text=p.read_text();assert re.search(r'^OK$',text,re.M);python_count=int(re.search(r'Ran (\d+) tests',text)[1]);assert python_count==734
scalar=load(T/'sexos-r103-b-scalar-instructions.json');assert scalar['ok']and scalar['iso_sha256']==binding['iso_sha256']and scalar['elf_sha256']==sha(T/'sexos-r103-b-tested-kaleidoscope.elf')
members={}
def add(path,name):
 path=Path(path);assert path.is_file()and not path.is_symlink(),path;assert name not in members and not name.startswith('/')and '..'not in Path(name).parts;members[name]=path
add(F/'source-binding.json','source-binding.json')
for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):add(F/'source'/name,'source/'+name)
for name in('tested.iso','tested.kernel'):add(F/name,name)
for p in sorted(B.iterdir()):
 if p.is_file()and p.suffix!='.img':add(p,'build/'+p.name)
for row in progress:
 out=Path(row['out'])
 for p in sorted(out.rglob('*')):
  if p.is_file()and p.suffix!='.img':add(p,'native/'+row['name']+'/'+str(p.relative_to(out)))
 add(row['driver'],'checks/'+Path(row['driver']).name)
for pattern in('sexos-r103-b-*.json','sexos-r103-b-*.log','sexos-r103-b-*.py','sexos-r103-b-*.rs','sexos-r103-b-*.disassembly','sexos-r103-b-*.elf'):
 for p in sorted(T.glob(pattern)):
  if 'package.log'in p.name:continue
  name='checks/'+p.name
  if name not in members:add(p,name)
for p in sorted((T/'sexos-alpha-r103-font-a-build').iterdir()):
 if p.is_file()and p.suffix!='.img':add(p,'diagnostics/a-build-abi-input-hash/'+p.name)
seed=T/'sexos-r100a-seed.img';z=T/'sexos-r103-b-seed.img.gz';assert not z.exists();z.write_bytes(gzip.compress(seed.read_bytes(),mtime=0));add(z,'seed.img.gz')
screens=[]
for run,boot,filename,label in [('launcher-wide','', 'spindle-17-brought.ppm','spindle-wide'),('launcher-compact','','launcher-9-bring.ppm','launcher-compact'),('clipboard-compact','write','browser-reflow.ppm','reader-compact'),('clipboard-compact','recovery','quil-cold-reopened.ppm','cold-compact')]:
 out=Path(next(r['out']for r in progress if r['name']==run))/boot;frame=next(f for f in load(out/'frames.json')if f['screenshot']==filename);assert frame['screenshot_sha256']==sha(out/filename)
 dest=A/f'{stem}-{label}.png';assert not dest.exists();Image.open(out/filename).save(dest);screens.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=run,boot=boot,raw_ppm=filename,raw_sha256=sha(out/filename),serial_bytes=frame['serial_bytes'],serial_sha256=frame['serial_sha256']))
archive=A/f'{stem}-qualified-raw.tar.gz';assert not archive.exists();inventory=[dict(name=n,bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(members.items())]
with tarfile.open(archive,'w:gz')as tar:
 for row in inventory:
  path=members[row['name']];assert sha(path)==row['sha256'];tar.add(path,arcname=row['name'],recursive=False)
 data=(json.dumps(dict(scope='FinalB native/font acceptance; priorA prebuild hash failure is separately diagnostic only.',members=inventory),indent=2)+'\n').encode();info=tarfile.TarInfo('archive-inventory.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 actual=tar.getmembers();assert len(actual)==len(inventory)+1 and all(p.isfile()for p in actual)
 for row in inventory:
  data=tar.extractfile(row['name']).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
e=dict(round=103,accepted=True,accepted_goal_rounds=24,total_goal_rounds=121,remaining_goal_rounds=97,iso_sha256=binding['iso_sha256'],kernel_sha256=binding['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),architecture_sha256=binding['architecture_sha256'],production_inputs=len(binding['sources']),runner_inputs=len(binding['runner_sha256']),font=dict(printable_glyphs=95,distinct_lowercase=26,rom_row_bytes=665,dimensions=[5,7],cell=[6,9],loaded_fonts=False,heap_cache=False,unsupported_bytes='No ink; newline remains structural. Byte positions and selection custody unchanged.'),checks=dict(master='BUILD PASS / GREEN_MASTER',rust=logs,rust_test_executions=sum(r['executions']for r in logs),python_tests=python_count,python_log_sha256=sha(T/'sexos-r103-b-frozen-python.log'),native_runs=4,native_boots=6,independent_frames=80,root_replay_sha256=sha(T/'sexos-r103-b-root-independent-replay.json'),scalar_audit=scalar,actual_renderer_case_negative=negative,native_case_controls=controls),qualification_runs=progress,remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=screens,archive=dict(path=str(archive.relative_to(R/'docs/handoff')),sha256=sha(archive),members=len(inventory)+1,verified=True,bytes=archive.stat().st_size),failed_diagnostics='A stopped before compile/probe because shared-metrics changes required the ABI input inventory hash update. Final sealedB includes the updated hash and runs its own full cohort. It is not an ABI authority change or acceptedA run.',limitations=['Actual-function host tests cover every byte and printable glyph at both scales, selection and toolbar semantics. Native six-case negative controls prove mixed-case Quil/Spindle/launcher pixels at both sizes; no all95-glyph native atlas claim.','The fixed5x7 font remains intentionally small. This round preserves geometry; larger typography/accessibility and encoding/input are subsequent work. No Unicode, shaped text, font loading, heap cache or font authority is added.','Native clipboard/Save/cold recovery is qualified at both resolutions on this image. No new sustained latest-image daily-driver, public-web/general CA, crash/power-loss, hostile-containment, physical hardware, SMP or System Proven claim.'],scope='One substantive round: complete case-preserving printable ASCII rendering and finite shared metrics, visible in actual app/workspace/clipboard workflows. GLOBAL_VAS, BOOT-only genesis and typed sex-pdx authority preserved; not Unix/POSIX.')
(A/f'{stem}-evidence.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(dict(ok=True,round=103,rust=e['checks']['rust_test_executions'],python=python_count,archive=e['archive'])))
