"""Fresh-process raw qualification of final round103 cohort; never boots."""
from pathlib import Path
import gzip,hashlib,json,sys
sys.dont_write_bytecode=True
F=Path('/tmp/sexos-alpha-r103-font-b-frozen').resolve();ROOT=F/'source'
sys.path.insert(0,str(ROOT/'scripts'))
import launcher_workflow_gate as launcher
import clipboard_workflow_gate as clipboard
from network_contention_gate import frozen_binding
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(v):return json.loads(json.dumps(v))
progress=load('/tmp/sexos-r103-b-native-suite-progress.json')
assert len(progress)==4 and all(type(r['status'])is int and r['status']==0 for r in progress)
assert sum(r['boots']for r in progress)==6
bound=frozen_binding(ROOT,F/'tested.iso',F/'source-binding.json');runs=[]
for row in progress:
 out=Path(row['out']);assert row['source_binding_sha256']==bound['sha256']
 if row['name'].startswith('launcher-'):
  result=launcher.replay(ROOT,out,F/'source-binding.json',F/'tested.iso')
  assert canonical(result)==load(out/'result.json') and result['binding']==bound
  manifest=load(out/'manifest.json')
  assert (manifest['model'],manifest['resolution'])==(row['profile']['model'],row['profile']['resolution'])
  disk=out/'nvme.img';assert disk.is_file()
  compressed=out/'root-terminal-disk.img.gz';assert not compressed.exists()
  compressed.write_bytes(gzip.compress(disk.read_bytes(),mtime=0))
  runs.append(dict(name=row['name'],out=str(out),ok=True,boots=1,profile=row['profile'],mode=row['mode'],frames=len(result['frames']),replay=result,root_terminal_disk_sha256=sha(disk),scope='Root captured terminal disk after confirmed successful native process exit; no durable mutation or read-only-disk claim for this launcher workflow.'))
 else:
  assert row['name']in ('clipboard-wide','clipboard-compact') and row['boots']==2
  contract=clipboard.source_contract(ROOT);results=[]
  for boot in ('write','recovery'):
   replay=clipboard.replay_boot(out/boot,contract)
   assert canonical(dict(replay,binding=bound))==load(out/boot/'result.json')
   results.append(dict(boot=boot,**replay))
  first=load(out/'write/manifest.json');second=load(out/'recovery/manifest.json')
  assert first['binding']==second['binding']==bound and first['final_disk_sha256']==second['input_disk_sha256']
  assert results[0]['document']==results[1]['document']==load(out/'result.json')['document']
  runs.append(dict(name=row['name'],out=str(out),ok=True,boots=2,profile=row['profile'],mode=row['mode'],frames=sum(len(r['pixels'])for r in results),replay=results))
 print(row['name'],'raw replay PASS',flush=True)
assert sum(r['frames']for r in runs)==80 and sum(r['boots']for r in runs)==6
assert frozen_binding(ROOT,F/'tested.iso',F/'source-binding.json')==bound
result=dict(ok=True,complete=True,round=103,source_binding_sha256=bound['sha256'],binding=bound,native_runs=4,native_boots=6,frames=80,runs=runs,scope='Fresh exact frozen-source replay: both launcher profiles and original Quil9/Spindle12/BOOT successor17, all immutable screenshot prefixes/full glyphs, opaque/glyph sliver absence region, exact identities and accepted/final action joins, terminal custody/reserve exhaustion, startup PCAP; both-profile full clipboard/Save/same-image cold reopen regressions. No hostile containment, crash/power-loss, physical/SMP or full-system acceptance claim.')
Path('/tmp/sexos-r103-b-root-independent-replay.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(ok=True,complete=True,native_runs=4,native_boots=6,frames=80)),flush=True)
