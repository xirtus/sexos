const FONT_ASCII_5X7: [[u8; 7]; 95] = [
    [0, 0, 0, 0, 0, 0, 0], // ASCII 32
    [4, 4, 4, 4, 4, 0, 4], // ASCII 33
    [10, 10, 10, 0, 0, 0, 0], // ASCII 34
    [10, 10, 31, 10, 31, 10, 10], // ASCII 35
    [4, 15, 20, 14, 5, 30, 4], // ASCII 36
    [25, 26, 2, 4, 8, 11, 19], // ASCII 37
    [12, 18, 18, 12, 21, 18, 13], // ASCII 38
    [12, 4, 8, 0, 0, 0, 0], // ASCII 39
    [2, 4, 8, 8, 8, 4, 2], // ASCII 40
    [8, 4, 2, 2, 2, 4, 8], // ASCII 41
    [0, 4, 21, 14, 21, 4, 0], // ASCII 42
    [0, 4, 4, 31, 4, 4, 0], // ASCII 43
    [0, 0, 0, 0, 12, 4, 8], // ASCII 44
    [0, 0, 0, 31, 0, 0, 0], // ASCII 45
    [0, 0, 0, 0, 0, 12, 12], // ASCII 46
    [1, 2, 2, 4, 8, 8, 16], // ASCII 47
    [14, 17, 19, 21, 25, 17, 14], // ASCII 48
    [4, 12, 4, 4, 4, 4, 14], // ASCII 49
    [14, 17, 1, 2, 4, 8, 31], // ASCII 50
    [14, 17, 1, 6, 1, 17, 14], // ASCII 51
    [2, 6, 10, 18, 31, 2, 2], // ASCII 52
    [31, 16, 30, 1, 1, 17, 14], // ASCII 53
    [6, 8, 16, 30, 17, 17, 14], // ASCII 54
    [31, 1, 2, 4, 8, 8, 8], // ASCII 55
    [14, 17, 17, 14, 17, 17, 14], // ASCII 56
    [14, 17, 17, 15, 1, 2, 12], // ASCII 57
    [0, 12, 12, 0, 12, 12, 0], // ASCII 58
    [0, 12, 12, 0, 12, 4, 8], // ASCII 59
    [2, 4, 8, 16, 8, 4, 2], // ASCII 60
    [0, 0, 31, 0, 31, 0, 0], // ASCII 61
    [8, 4, 2, 1, 2, 4, 8], // ASCII 62
    [14, 17, 1, 2, 4, 0, 4], // ASCII 63
    [14, 17, 19, 21, 19, 16, 14], // ASCII 64
    [14, 17, 17, 31, 17, 17, 17], // ASCII 65
    [30, 17, 17, 30, 17, 17, 30], // ASCII 66
    [14, 17, 16, 16, 16, 17, 14], // ASCII 67
    [30, 17, 17, 17, 17, 17, 30], // ASCII 68
    [31, 16, 16, 30, 16, 16, 31], // ASCII 69
    [31, 16, 16, 30, 16, 16, 16], // ASCII 70
    [14, 17, 16, 23, 17, 17, 14], // ASCII 71
    [17, 17, 17, 31, 17, 17, 17], // ASCII 72
    [14, 4, 4, 4, 4, 4, 14], // ASCII 73
    [7, 1, 1, 1, 1, 17, 14], // ASCII 74
    [17, 18, 20, 24, 20, 18, 17], // ASCII 75
    [16, 16, 16, 16, 16, 16, 31], // ASCII 76
    [17, 27, 21, 21, 17, 17, 17], // ASCII 77
    [17, 25, 21, 19, 17, 17, 17], // ASCII 78
    [14, 17, 17, 17, 17, 17, 14], // ASCII 79
    [30, 17, 17, 30, 16, 16, 16], // ASCII 80
    [14, 17, 17, 17, 21, 18, 13], // ASCII 81
    [30, 17, 17, 30, 20, 18, 17], // ASCII 82
    [14, 17, 16, 14, 1, 17, 14], // ASCII 83
    [31, 4, 4, 4, 4, 4, 4], // ASCII 84
    [17, 17, 17, 17, 17, 17, 14], // ASCII 85
    [17, 17, 17, 17, 17, 10, 4], // ASCII 86
    [17, 17, 17, 21, 21, 27, 17], // ASCII 87
    [17, 17, 10, 4, 10, 17, 17], // ASCII 88
    [17, 17, 10, 4, 4, 4, 4], // ASCII 89
    [31, 1, 2, 4, 8, 16, 31], // ASCII 90
    [14, 8, 8, 8, 8, 8, 14], // ASCII 91
    [16, 8, 8, 4, 2, 2, 1], // ASCII 92
    [14, 2, 2, 2, 2, 2, 14], // ASCII 93
    [4, 10, 17, 0, 0, 0, 0], // ASCII 94
    [0, 0, 0, 0, 0, 0, 31], // ASCII 95
    [8, 4, 2, 0, 0, 0, 0], // ASCII 96
    [0, 0, 14, 1, 15, 17, 15], // ASCII 97
    [16, 16, 30, 17, 17, 17, 30], // ASCII 98
    [0, 0, 14, 16, 16, 16, 14], // ASCII 99
    [1, 1, 15, 17, 17, 17, 15], // ASCII 100
    [0, 0, 14, 17, 31, 16, 14], // ASCII 101
    [6, 9, 8, 28, 8, 8, 8], // ASCII 102
    [0, 0, 15, 17, 15, 1, 14], // ASCII 103
    [16, 16, 30, 17, 17, 17, 17], // ASCII 104
    [4, 0, 12, 4, 4, 4, 14], // ASCII 105
    [2, 0, 6, 2, 2, 18, 12], // ASCII 106
    [16, 16, 18, 20, 24, 20, 18], // ASCII 107
    [12, 4, 4, 4, 4, 4, 14], // ASCII 108
    [0, 0, 26, 21, 21, 17, 17], // ASCII 109
    [0, 0, 30, 17, 17, 17, 17], // ASCII 110
    [0, 0, 14, 17, 17, 17, 14], // ASCII 111
    [0, 0, 30, 17, 30, 16, 16], // ASCII 112
    [0, 0, 15, 17, 15, 1, 1], // ASCII 113
    [0, 0, 22, 25, 16, 16, 16], // ASCII 114
    [0, 0, 15, 16, 14, 1, 30], // ASCII 115
    [8, 8, 28, 8, 8, 9, 6], // ASCII 116
    [0, 0, 17, 17, 17, 19, 13], // ASCII 117
    [0, 0, 17, 17, 17, 10, 4], // ASCII 118
    [0, 0, 17, 17, 21, 21, 10], // ASCII 119
    [0, 0, 17, 10, 4, 10, 17], // ASCII 120
    [0, 0, 17, 17, 15, 1, 14], // ASCII 121
    [0, 0, 31, 2, 4, 8, 31], // ASCII 122
    [2, 4, 4, 8, 4, 4, 2], // ASCII 123
    [4, 4, 4, 4, 4, 4, 4], // ASCII 124
    [8, 4, 4, 2, 4, 4, 8], // ASCII 125
    [0, 0, 9, 22, 0, 0, 0], // ASCII 126
];
const BAR_BG_H: usize = 50;
const FRAME_RIM_PX: usize = 8;
const FRAME_RIM_COLOR: u32 = 0x00B4BEFE;
const FRAME_LIGHT_SIZE_PX: usize = 8;
const FRAME_LIGHT_GAP_PX: usize = 3;
const FRAME_LIGHT_CLOSE_COLOR: u32 = 0x00FF4444;
const FRAME_LIGHT_MINIMIZE_COLOR: u32 = 0x00FFCC44;
const FRAME_LIGHT_ZOOM_COLOR: u32 = 0x0044FF44;
const FRAME_LIGHT_CLOSE_DISABLED_BASE_ALPHA: u8 = 160;
const TAB_STRIP_LIGHT_EXCLUSION_PX: usize = 20;
const SURFACE_CHROME_TOP_BAR: u8 = 1 << 0;
const SURFACE_CHROME_FRAME_HOVER: u8 = 1 << 1;
const SURFACE_CHROME_LIGHT_HOVER: u8 = 1 << 2;
const SURFACE_CHROME_LIGHT_KIND_MASK: u8 = 0x18; // bits 3-4
const SURFACE_CHROME_LIGHT_KIND_SHIFT: u8 = 3;
const SURFACE_CHROME_CLOSE_ALLOWED: u8 = 1 << 5;
const FRAME_TOP_BAR_HEIGHT_PX: usize = 28;
const FRAME_TOP_BAR_LIGHT_SIZE_PX: usize = 10;
const FRAME_TOP_BAR_LIGHT_GAP_PX: usize = 5;
const FRAME_TOP_BAR_LIGHT_EXCLUSION_PX: usize = 50;
const FRAME_TOP_BAR_COLOR: u32 = 0x001E1E2E;
const FRAME_TOP_BAR_DIVIDER_COLOR: u32 = 0x00B4BEFE;
const FRAME_TOP_BAR_LIGHT_TOP: usize = 9;
const FRAME_TOP_BAR_LIGHT_BOTTOM: usize = 19; // 9 + 10
fn clamp_surface(surf: &Surface, fb_w: usize, fb_h: usize) -> (usize, usize, usize, usize) {
    // BAR_H covers model PANEL_Y+PANEL_H (10+38=48) plus 2px safety margin.
    // Must remain >= PANEL_Y + PANEL_H from silkbar-model.
    const BAR_H: usize = 50;
    let x = (surf.x.max(0) as usize).min(fb_w.saturating_sub(1));
    let y = (surf.y.max(BAR_H as i32) as usize).min(fb_h.saturating_sub(1));
    let max_w = fb_w.saturating_sub(x);
    let max_h = fb_h.saturating_sub(y);
    let w = (surf.w as usize).min(max_w);
    let h = (surf.h as usize).min(max_h);
    (x, y, w, h)
}
fn composite_pixel(x: usize, y: usize, w: usize, h: usize, bg: u32, focused_id: u64) -> u32 {
    let selected=unsafe{FRAME_GROUPS.winner(&SURFACES,focused_id,x,y,w,h).map(|s|s.surface_id)};
    composite_pixel_selected(x,y,w,h,bg,focused_id,selected)
}
fn composite_pixel_selected(x: usize, y: usize, w: usize, h: usize, bg: u32, focused_id: u64, selected:Option<u64>) -> u32 {
    let source = unsafe { SURFACES.iter().find(|s| s.active && Some(s.surface_id) == selected)
        .map(|surface| surface_groups::PixelSource {
            surface,
            content: FRAME_GROUPS.content(surface, &SURFACES, x, y, w, h),
            chrome: surface.surface_id == focused_id || FRAME_GROUPS.is_frame(surface),
        }) };
    composite_pixel_source(x,y,w,h,bg,source)
}
fn composite_pixel_source(x: usize, y: usize, w: usize, h: usize, bg: u32, source: Option<surface_groups::PixelSource<'_>>) -> u32 {
    let Some(source) = source else { return bg; };
    let surf = source.surface;
    let (sx, sy, sw, sh) = clamp_surface(surf, w, h);
    if !surf.active || sw == 0 || sh == 0 || x < sx || x >= sx + sw || y < sy || y >= sy + sh { return bg; }
    let mut c = bg;
    let mut winner_mask = surface_lifecycle::native_pixel_bit(surf.owner_pd, surf.surface_id);
    if !source.chrome {
        c = fill_rect_color(surf, x, y, surf.color);
        c = bitmap_color(surf, x, y, c);
        if let Some(tc) = surface_text_fg_at(x, y, surf) { c = tc; }
    } else { unsafe {
        // ── Phase 6 proof: real render-path markers ──────────────
        // Emit once when the focused-surface pixel path is entered.
        // Proves bounds were checked via clamp_surface + sw/sh guards
        // and that the real compositor loop called composite_pixel.
        unsafe {
            static mut PHASE6_RENDER_BEGIN_PROOF: u32 = 1;
            if PHASE6_RENDER_BEGIN_PROOF > 0 {
                PHASE6_RENDER_BEGIN_PROOF -= 1;
                let active_count = SURFACES.iter().filter(|s| s.active).count();
                let frame_count = SURFACES.iter().filter(|s| s.active && s.tab_count > 0 && (s.chrome_flags & SURFACE_CHROME_TOP_BAR) != 0).count();
                serial_println!("[sexdisplay.frame_lights.render.begin] fb_w={} fb_h={} surfaces={} frames={}", w, h, active_count, frame_count);
            }
            static mut PHASE6_BOUNDS_OK_PROOF: u32 = 1;
            if PHASE6_BOUNDS_OK_PROOF > 0 {
                PHASE6_BOUNDS_OK_PROOF -= 1;
                serial_println!("[sexdisplay.frame_lights.bounds.ok] all_lights_within_fb=1 fb_w={} fb_h={} light_w=40 light_h=10 ok=1 reason=clamp_surface_guarantee", w, h);
            }
        }
        // Rim + Frame Light + Top Bar check (focused surface only).
        let lx = x - sx;  // local x within clamped surface
        let ly = y - sy;  // local y within clamped surface

        // Edge detection with saturating_sub to prevent underflow
        // on tiny surfaces (rim fills entire surface if sw/sh < RIM_PX).
        let rim_right = sw.saturating_sub(FRAME_RIM_PX);
        let rim_bottom = sh.saturating_sub(FRAME_RIM_PX);
        let top_bar_active = (surf.chrome_flags & SURFACE_CHROME_TOP_BAR) != 0;
        let frame_hovered = (surf.chrome_flags & SURFACE_CHROME_FRAME_HOVER) != 0;
        let light_hovered = (surf.chrome_flags & SURFACE_CHROME_LIGHT_HOVER) != 0;
        let hovered_light_kind = (surf.chrome_flags & SURFACE_CHROME_LIGHT_KIND_MASK) >> SURFACE_CHROME_LIGHT_KIND_SHIFT;
        let close_allowed = (surf.chrome_flags & SURFACE_CHROME_CLOSE_ALLOWED) != 0;
        let single_tab = surf.tab_count <= 1;

        // One-shot reveal mode marker.
        unsafe {
            static mut HOVER_REVEAL_PROOF: u32 = 1;
            if HOVER_REVEAL_PROOF > 0 && ly == 0 && lx == 0 {
                HOVER_REVEAL_PROOF -= 1;
                serial_println!("[sexdisplay.frame.hover.reveal] mode=v1b single_tab={} hovered={}",
                    single_tab as u8, frame_hovered as u8);
            }
        }

        // Hover reveal: single-tab frame chrome dims when not hovered,
        // brightens on hover. Multi-tab always fully visible.
        let chrome_dim: u8 = if single_tab && !frame_hovered { 5 } else { 10 };
        // Scale: 5 → ~20% alpha, 10 → full alpha.
        fn scale_alpha(base: u8, dim: u8) -> u8 {
            ((base as u16 * dim as u16) / 10) as u8
        }

        // ── TOP BAR ZONE (default chrome mode, R6 glass) ──
        // [silk.live_topstrip.v2.clip] Safety: frame chrome must never render
        // above the global SilkBar strip. y is the global framebuffer row;
        // composite_pixel is only called for y >= 51 (see render/redraw_surface_area),
        // but this belt-and-suspenders guard catches any future path that might
        // call composite_pixel at y < BAR_BG_H+1.
        if y < (BAR_BG_H + 1) {
            // y is in or above the SilkBar glow row — skip frame chrome entirely.
            // This pixel will get bar_color or panel_glow from the top strip pass.
        } else if top_bar_active && ly < FRAME_TOP_BAR_HEIGHT_PX {
            // Frosted glass toolbar background.
            let base_alpha: u8 = if frame_hovered { 220 } else { 200 };
            let toolbar_alpha = scale_alpha(base_alpha, chrome_dim);
            if toolbar_alpha > 0 {
                c = glass_over_bg(DISPLAY_TOKENS.frame_top_bar_color, x, y, toolbar_alpha);
            }
            // Divider: bright opaque line at bottom edge.
            if ly == FRAME_TOP_BAR_HEIGHT_PX - 1 {
                c = FRAME_TOP_BAR_DIVIDER_COLOR;
            }
            // Tab strip: glass background with tab color overlay.
            if surf.tab_count > 0
                && lx >= FRAME_TOP_BAR_LIGHT_EXCLUSION_PX
                && lx < rim_right
            {
                let available = rim_right - FRAME_TOP_BAR_LIGHT_EXCLUSION_PX;
                let slot_w = available / surf.tab_count as usize;
                if slot_w > 0 {
                    let tab_idx = (lx - FRAME_TOP_BAR_LIGHT_EXCLUSION_PX) / slot_w;
                    let tab_color = if tab_idx == surf.active_tab as usize {
                        DISPLAY_TOKENS.active_tab_color
                    } else {
                        DISPLAY_TOKENS.inactive_tab_color
                    };
                    let tab_glass = glass_over_bg(tab_color, x, y, 224);
                    let tab_alpha: u8 = if tab_idx == surf.active_tab as usize { 240 } else { 200 };
                    c = alpha_blend_xrgb_over_xrgb(tab_color, tab_glass, tab_alpha);
                }
            }
            // Title ink follows the tab background; tabs must not erase it.
            if let Some(fg)=toolbar_title_fg_at(lx,ly,surf.surface_id){c=fg;}
            // Frame lights: glass background with light color overlay.
            // Dimmed for single-tab non-hover; full bright for hovered light.
            if ly >= FRAME_TOP_BAR_LIGHT_TOP && ly < FRAME_TOP_BAR_LIGHT_BOTTOM {
                unsafe {
                    static mut FRAME_LIGHT_STARTUP_RENDER_BUDGET: u32 = 32;
                    if FRAME_LIGHT_STARTUP_RENDER_BUDGET > 0 && lx == FRAME_TOP_BAR_LIGHT_GAP_PX && ly == FRAME_TOP_BAR_LIGHT_TOP {
                        FRAME_LIGHT_STARTUP_RENDER_BUDGET -= 1;
                        if hot_log() { serial_println!(
                            "[sexdisplay.frame.light.startup.render] sid={} red={} close_allowed={} reason={}",
                            surf.surface_id,
                            if close_allowed { "enabled" } else { "disabled" },
                            close_allowed as u8,
                            if close_allowed { "close_allowed" } else { "default_disabled_or_protected" }
                        ); }
                    }
                    // Phase 6 draw.ok: one-shot proof emitted from real render path.
                    static mut PHASE6_DRAW_OK_PROOF: u32 = 1;
                    if PHASE6_DRAW_OK_PROOF > 0 && lx == FRAME_TOP_BAR_LIGHT_GAP_PX && ly == FRAME_TOP_BAR_LIGHT_TOP {
                        PHASE6_DRAW_OK_PROOF -= 1;
                        serial_println!("[sexdisplay.frame_lights.draw.ok] rendered=1 red=disabled yellow=available green=available ok=1 reason=render_path");
                    }
                }
                let l1_end = FRAME_TOP_BAR_LIGHT_GAP_PX + FRAME_TOP_BAR_LIGHT_SIZE_PX;
                let l1_hovered = light_hovered && hovered_light_kind == 0;
                let l1_close_base: u8 = if close_allowed {
                    if l1_hovered { 255 } else { 224 }
                } else if l1_hovered {
                    255
                } else {
                    FRAME_LIGHT_CLOSE_DISABLED_BASE_ALPHA
                };
                let light_alpha: u8 = scale_alpha(l1_close_base, chrome_dim);
                if lx >= FRAME_TOP_BAR_LIGHT_GAP_PX && lx < l1_end {
                    if light_alpha > 0 { c = glass_over_bg(DISPLAY_TOKENS.close_light_color, x, y, light_alpha); }
                } else {
                    let l2_start = l1_end + FRAME_TOP_BAR_LIGHT_GAP_PX;
                    let l2_end = l2_start + FRAME_TOP_BAR_LIGHT_SIZE_PX;
                    let l2_hovered = light_hovered && hovered_light_kind == 1;
                    let l2_alpha = scale_alpha(if l2_hovered { 255 } else { 224 }, chrome_dim);
                    if lx >= l2_start && lx < l2_end {
                        if l2_alpha > 0 { c = glass_over_bg(DISPLAY_TOKENS.minimize_light_color, x, y, l2_alpha); }
                    } else {
                        let l3_start = l2_end + FRAME_TOP_BAR_LIGHT_GAP_PX;
                        let l3_end = l3_start + FRAME_TOP_BAR_LIGHT_SIZE_PX;
                        let l3_hovered = light_hovered && hovered_light_kind == 2;
                        let l3_alpha = scale_alpha(if l3_hovered { 255 } else { 224 }, chrome_dim);
                        if lx >= l3_start && lx < l3_end {
                            if l3_alpha > 0 { c = glass_over_bg(DISPLAY_TOKENS.zoom_light_color, x, y, l3_alpha); }
                        }
                    }
                }
            }
        }
        // ── RIM BAND (minimal mode top edge, or left/right/bottom edges always) ──
        else if ly < FRAME_RIM_PX || lx < FRAME_RIM_PX
            || lx >= rim_right || ly >= rim_bottom
        {
            // In the rim band. Check for Frame Lights in top-left corner.
            // This path is reached in minimal mode (top_bar_active=false) or
            // for left/right/bottom edges when top bar is active.
            if ly < FRAME_RIM_PX && !top_bar_active {
                // Minimal mode top rim lights — glass version.
                // Close light dimmed: close_allowed=0, non-interactive.
                let l1_alpha: u8 = if close_allowed { 224 } else { FRAME_LIGHT_CLOSE_DISABLED_BASE_ALPHA };
                if lx >= FRAME_LIGHT_GAP_PX
                    && lx < FRAME_LIGHT_GAP_PX + FRAME_LIGHT_SIZE_PX
                {
                    c = glass_over_bg(DISPLAY_TOKENS.close_light_color, x, y, l1_alpha);
                }
                else if lx >= FRAME_LIGHT_GAP_PX + FRAME_LIGHT_SIZE_PX + FRAME_LIGHT_GAP_PX
                    && lx < FRAME_LIGHT_GAP_PX + FRAME_LIGHT_SIZE_PX + FRAME_LIGHT_GAP_PX + FRAME_LIGHT_SIZE_PX
                {
                    c = glass_over_bg(DISPLAY_TOKENS.minimize_light_color, x, y, 224);
                }
                else if lx >= FRAME_LIGHT_GAP_PX + 2 * (FRAME_LIGHT_SIZE_PX + FRAME_LIGHT_GAP_PX)
                    && lx < FRAME_LIGHT_GAP_PX + 2 * (FRAME_LIGHT_SIZE_PX + FRAME_LIGHT_GAP_PX) + FRAME_LIGHT_SIZE_PX
                {
                    c = glass_over_bg(DISPLAY_TOKENS.zoom_light_color, x, y, 224);
                }
                // Tab strip — glass version.
                else if surf.tab_count > 0
                    && lx >= TAB_STRIP_LIGHT_EXCLUSION_PX
                    && lx < rim_right
                {
                    let available = rim_right - TAB_STRIP_LIGHT_EXCLUSION_PX;
                    let slot_w = available / surf.tab_count as usize;
                    if slot_w > 0 {
                        let tab_idx = (lx - TAB_STRIP_LIGHT_EXCLUSION_PX) / slot_w;
                        let tab_color = if tab_idx == surf.active_tab as usize {
                            DISPLAY_TOKENS.active_tab_color
                        } else {
                            DISPLAY_TOKENS.inactive_tab_color
                        };
                        let tab_alpha: u8 = if tab_idx == surf.active_tab as usize { 220 } else { 180 };
                        c = glass_over_bg(tab_color, x, y, tab_alpha);
                    } else {
                        c = glass_over_bg(DISPLAY_TOKENS.frame_rim_color, x, y, 196);
                    }
                } else {
                    c = glass_over_bg(DISPLAY_TOKENS.frame_rim_color, x, y, 196);
                }
            } else {
                // Left, right, or bottom rim edge — pulsing neon glass.
                let frame = RENDER_FRAME_COUNTER.load(core::sync::atomic::Ordering::Relaxed);
                const RIM_BASE_ALPHA: u8 = 196;
                const RIM_AMP: u8 = 12;
                const RIM_PERIOD: u64 = 128;
                let rim_alpha = pulse_alpha(RIM_BASE_ALPHA, RIM_AMP, frame, RIM_PERIOD);
                c = glass_over_bg(DISPLAY_TOKENS.frame_rim_color, x, y, rim_alpha);
            }
        } else {
            // ── SURFACE CONTENT AREA ──
            let content = source.content;
            winner_mask = surface_lifecycle::native_pixel_bit(content.owner_pd, content.surface_id);
            c = fill_rect_color(content, x, y, content.color);
            c = bitmap_color(content, x, y, c);
            // Child text uses its own origin; the parent alone draws chrome.
            if let Some(tc) = surface_text_fg_at(x, y, content) { c = tc; }
        }
    } }
    if winner_mask != 0 { unsafe { APP_PRESENT_BITS |= winner_mask; } }
    c
}
fn bitmap_viewport(surf: &Surface) -> bitmap_transaction::Viewport {
    let chrome = surf.chrome_flags & SURFACE_CHROME_TOP_BAR != 0;
    bitmap_transaction::Viewport { x: surf.x, y: surf.y, width: surf.w, height: surf.h,
        inset: if chrome { 8 } else { 0 }, top: if chrome { FRAME_TOP_BAR_HEIGHT_PX as u32 + 8 } else { 0 } }
}
fn bitmap_color(surf: &Surface, x: usize, y: usize, base: u32) -> u32 {
    if !surf.active || surf.owner_pd != 15 || surf.surface_id != 300 { return base; }
    let Some((x, y)) = bitmap_viewport(surf).local(x, y) else { return base; };
    unsafe { BITMAP_STAGE.sample(surf.owner_pd, surf.surface_id, x, y) }
        .map_or(base, |pixel| bitmap_transaction::blend(pixel, base))
}
fn bitmap_surface_damage(surf: &Surface, geometry: Option<sex_pdx::bitmap_batch::Geometry>, w: usize, h: usize) -> (usize, usize, usize, usize) {
    bitmap_viewport(surf).screen(geometry, w, h)
}
fn fill_rect_color(surf: &Surface, x: usize, y: usize, base_color: u32) -> u32 {
    if surf.fill_count == 0 { return base_color; }
    let lx = (x as i32) - surf.x;
    let ly = (y as i32) - surf.y;
    let mut c = base_color;
    for i in 0..surf.fill_count as usize {
        if surf.fill_sw[i] == 0 || surf.fill_sh[i] == 0 { continue; }
        if lx >= surf.fill_sx[i] && lx < surf.fill_sx[i] + surf.fill_sw[i] as i32
            && ly >= surf.fill_sy[i] && ly < surf.fill_sy[i] + surf.fill_sh[i] as i32
        {
            c = surf.fill_color[i];
        }
    }
    c
}
fn ascii_glyph_index(byte: u8) -> Option<usize> {
    let byte = byte.to_ascii_uppercase();
    use sex_pdx::desktop_style::{ASCII_FIRST, ASCII_LAST};
    (ASCII_FIRST..=ASCII_LAST).contains(&byte).then(|| (byte - ASCII_FIRST) as usize)
}
fn toolbar_title_fg_at(lx: usize, ly: usize, surface_id: u64) -> Option<u32> {
    const SCALE: usize = 2;
    const GLYPH_W: usize = sex_pdx::desktop_style::GLYPH_WIDTH as usize;
    const GLYPH_H: usize = sex_pdx::desktop_style::GLYPH_HEIGHT as usize;
    let title_x = FRAME_TOP_BAR_LIGHT_EXCLUSION_PX + 12;
    let title_y = (FRAME_TOP_BAR_HEIGHT_PX - GLYPH_H * SCALE) / 2;
    if lx < title_x || ly < title_y || ly >= title_y + GLYPH_H * SCALE { return None; }
    let col = (lx - title_x) / ((GLYPH_W + 1) * SCALE);
    let px = ((lx - title_x) / SCALE) % (GLYPH_W + 1);
    let py = (ly - title_y) / SCALE;
    if px >= GLYPH_W { return None; }
    let title: &[u8] = match surface_id {
        200 => b"Linen", 201 | 156 | 301 | 307 => b"Quil", 0x99 | 154 | 302 | 306 => b"Spindle",
        300 => b"Browser", 100 => b"App", _ => return None,
    };
    let glyph = ascii_glyph_index(*title.get(col)?)?;
    if (FONT_ASCII_5X7[glyph][py] >> (4 - px)) & 1 != 0 { Some(0x00E8FFFF) } else { None }
}
fn surface_text_scale(surf: &Surface) -> usize {
    sex_pdx::desktop_style::scale(surf.w) as usize
}
fn recompute_text_lines(surf: &mut Surface) {
    let len = (surf.text_len as usize).min(TEXT_BUF_CAP);
    surf.line_count = 0;
    if len == 0 { surf.wrap_cols = TEXT_LEGACY_COLS; return; }

    let has_newline = surf.text_buf[..len].iter().any(|&b| b == b'\n');
    surf.wrap_cols = if has_newline {
        let advance = 6 * surface_text_scale(surf) as u32;
        (surf.w.saturating_sub(16) / advance).clamp(1, 80) as u8
    } else {
        TEXT_LEGACY_COLS
    };

    let cols = surf.wrap_cols as usize;
    let mut i = 0usize;
    let mut col = 0usize;
    surf.line_starts[0] = 0;
    surf.line_count = 1;
    while i < len {
        let c = surf.text_buf[i];
        i += 1;
        if c == b'\n' {
            if (surf.line_count as usize) >= TEXT_MAX_ROWS { break; }
            surf.line_starts[surf.line_count as usize] = i as u16;
            surf.line_count += 1;
            col = 0;
        } else {
            col += 1;
            if col >= cols && i < len {
                if (surf.line_count as usize) >= TEXT_MAX_ROWS { break; }
                surf.line_starts[surf.line_count as usize] = i as u16;
                surf.line_count += 1;
                col = 0;
            }
        }
    }
}
fn legacy_text_clear(slot:&mut Surface)->bool{
    let changed=slot.text_len!=0 || slot.selection_start!=0 || slot.selection_end!=0;
    slot.erase_selection();
    slot.text_len=0;slot.text_buf=[0u8;TEXT_BUF_CAP];
    slot.line_count=0;slot.wrap_cols=TEXT_LEGACY_COLS;
    changed
}
fn legacy_text_draw(slot:&mut Surface,packed:u64,arg2:u64)->bool{
    let offset=((arg2&0xFF)|((arg2>>4)&0xF00))as usize;
    let count=((arg2>>8)&0xF)as usize;
    let color=((arg2>>32)as u32)|0xFF000000;
    let mut changed=(slot.text_color!=color&&slot.text_len!=0) || slot.selection_start!=0 || slot.selection_end!=0;
    slot.erase_selection();
    slot.text_color=color;
    let mut i=0;
    while i<count&&i<8&&offset+i<TEXT_BUF_CAP{
        let byte=((packed>>(i*8))&0xFF)as u8;
        changed|=slot.text_buf[offset+i]!=byte;slot.text_buf[offset+i]=byte;i+=1;
    }
    if offset+i>slot.text_len as usize{
        changed=true;slot.text_len=(offset+i).min(TEXT_BUF_CAP)as u16;
    }
    recompute_text_lines(slot);changed
}
fn surface_text_fg_at(x: usize, y: usize, surf: &Surface) -> Option<u32> {
    if surf.text_len == 0 || surf.line_count == 0 { return None; }
    const GLYPH_W: usize = sex_pdx::desktop_style::GLYPH_WIDTH as usize;
    const GLYPH_H: usize = sex_pdx::desktop_style::GLYPH_HEIGHT as usize;
    const CHAR_SPACING: usize = 1;
    let scale = surface_text_scale(surf);
    let line_h = (GLYPH_H + 2) * scale;
    let tx = (surf.x.max(0) as usize).saturating_add(sex_pdx::desktop_style::INSET as usize);
    let top_inset = if surf.chrome_flags & SURFACE_CHROME_TOP_BAR != 0 { FRAME_TOP_BAR_HEIGHT_PX + 8 } else { sex_pdx::desktop_style::TEXT_TOP as usize };
    let ty = (surf.y.max(0) as usize).saturating_add(top_inset);

    if x < tx || y < ty { return None; }

    let col = (x - tx) / ((GLYPH_W + CHAR_SPACING) * scale);
    let row = (y - ty) / line_h;
    let px = ((x - tx) / scale) % (GLYPH_W + CHAR_SPACING);
    let py = ((y - ty) / scale) % (GLYPH_H + 2);

    if col >= surf.wrap_cols as usize { return None; }
    if row >= surf.line_count as usize { return None; }

    // TEXT_MODEL_V2: character index via the per-line start table.
    let start = surf.line_starts[row] as usize;
    let end = if row + 1 < surf.line_count as usize {
        surf.line_starts[row + 1] as usize
    } else {
        surf.text_len as usize
    };
    let char_idx = start + col;
    if char_idx >= end || char_idx >= surf.text_len as usize { return None; }

    let c = surf.text_buf[char_idx];
    if c == b'\n' { return None; }
    // Selection belongs to this committed surface text. Paint the whole cell,
    // including spaces and inter-glyph spacing, beneath existing foreground ink.
    let selected = char_idx >= surf.selection_start as usize
        && char_idx < surf.selection_end as usize
        && surf.selection_end as usize <= surf.text_len as usize;
    let background = if selected { Some(0xff36577c) } else { None };
    if px >= GLYPH_W || py >= GLYPH_H { return background; }
    let Some(glyph_idx) = ascii_glyph_index(c) else { return background; };
    let glyph_row = FONT_ASCII_5X7[glyph_idx][py];
    let bit = (glyph_row >> (GLYPH_W - 1 - px)) & 1;
    if bit != 0 { Some(surf.text_color) } else { background }
}
fn redraw_surface_damage(fb: *mut u32, w: usize, h: usize, rect: damage::Rect) {
    let repaint_started = repaint_begin();
    if (fb as u64) < HIGH_HALF_BASE || w == 0 || h < 51 || w > MAX_FB_W || h > MAX_FB_H { return; }
    if rect.x >= rect.right || rect.y < 51 || rect.y >= rect.bottom || rect.right > w || rect.bottom > h { return; }
    if ATLAS_PHASE_C_RENDER_STUB_PROOF_ENABLED || ATLAS_PHASE_D_FRAME_PREVIEW_STUB_PROOF_ENABLED {
        redraw_surface_area(fb,w,h); return;
    }
    let Some(total) = w.checked_mul(h) else { return; };
    let focused = unsafe { FOCUSED_SURFACE_ID };
    unsafe { restore_cursor_under(fb,w,h,total); APP_PRESENT_BITS = 0; }
    for y in rect.y..rect.bottom {
        let mut row=unsafe{FRAME_GROUPS.row_winners(&SURFACES,focused,y,w,h)};
        for x in rect.x..rect.right {
            let color=if let Some(row)=row.as_mut() {
                composite_pixel_source(x,y,w,h,bg(y,h),row.source(x))
            } else { composite_pixel(x,y,w,h,bg(y,h),focused) };
            unsafe { core::ptr::write_volatile(fb.add(y*w+x),color); }
        }
    }
    draw_cursor_z_top(fb,w,h,total,true);
    draw_launcher_panel(fb,w,h,total);
    report_app_presented();
    repaint_end("text", repaint_started);
}
fn text_surface_damage(surf: &Surface, w: usize, h: usize) -> (usize,usize,usize,usize) {
    if surf.text_len == 0 || surf.line_count == 0 {return (0,0,0,0);}
    let (x,y,sw,sh)=surface_groups::rect(surf,w,h);
    let top=if surf.chrome_flags & SURFACE_CHROME_TOP_BAR != 0 {FRAME_TOP_BAR_HEIGHT_PX+8} else {sex_pdx::desktop_style::TEXT_TOP as usize};
    let text_y=(surf.y.max(0) as usize).saturating_add(top).max(y);
    let bottom=(surf.y.max(0) as usize).saturating_add(top)
        .saturating_add(surf.line_count as usize * 9 * surface_text_scale(surf))
        .min(y.saturating_add(sh));
    (x,text_y,sw,bottom.saturating_sub(text_y))
}
fn app_indicator_color(sid: u32) -> Option<u32> {
    if let Some(color)=sex_pdx::desktop_style::native_indicator(sid as u64){return Some(color);}
    match sid {
        200 => Some(0x00A6E3A1), // Linen  → green
        201 => Some(0x00CBA6F7), // Quil   → mauve
        202 => Some(0x0094E2D5), // Mesh   → teal
        203 => Some(0x00FAB387), // Collar → peach
        204 => Some(0x00F38BA8), // Bell   → red
        153 => Some(0x0089B4FA), // Spindle→ blue
        0   => None,            // no active app
        _   => Some(0x00444444), // unknown → dim gray
    }
}
fn phase5_active_app_at(x: usize, y: usize, _bar: &SilkBar) -> Option<u32> {
    // The admitted compositor focus is live in normal builds; the separate
    // phase1 field is updated only by the optional protocol proof path.
    let focused = unsafe { FOCUSED_SURFACE_ID };
    if focused == 0 { return None; }
    const DOT_X: usize = 155;
    const DOT_Y: usize = 22;
    const DOT_SZ: usize = 4;
    if x >= DOT_X && x < DOT_X + DOT_SZ && y >= DOT_Y && y < DOT_Y + DOT_SZ {
        app_indicator_color(focused as u32)
    } else {
        None
    }
}
fn top_strip_pixel(x: usize, y: usize, bar: &SilkBar) -> u32 {
    if let Some(fg) = clock_fg_at(x, y, bar) { fg }
    else if let Some(fg) = bell_badge_at(x, y, bar) { fg }
    else if let Some(fg) = phase5_active_app_at(x, y, bar) { fg }
    else if let Some(fg) = phase5_tint_swatch_at(x, y, bar) { fg }
    else if let Some(fg) = phase5_palette_dot_at(x, y, bar) { fg }
    else { bar_color(x, y, bar) }
}