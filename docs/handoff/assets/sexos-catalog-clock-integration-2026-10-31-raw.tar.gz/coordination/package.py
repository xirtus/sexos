from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-catalog-integration-c-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');h=read(T/'sexos-catalog-integration-c-host/report.json');git=read(T/'sexos-catalog-integration-c-git-binding.json');boot=read(T/'sexos-catalog-integration-c-boot-audit.json');assert git['ok']and boot['ok']and boot['boots']==19
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2661
assert 'Ran 965 tests in 'in(T/'sexos-catalog-integration-c-python.log').read_text()
groups={k:read(T/('sexos-catalog-integration-c-'+s+'-progress.json'))for k,s in [('clock_connected_tls','native'),('pending_device','pending-native'),('find_relaunch','alpha')]}
assert all(row['status']==0 for rows in groups.values()for row in rows)
assert sum(row['verified_captures']for rows in groups.values()for row in rows)==138
assert read(T/'sexos-catalog-integration-c-pending-independent-replays.json')['ok']
scalar=read(T/'sexos-catalog-integration-c-scalar-v2/result.json');assert scalar['ok']and len(scalar['results'])==5 and all(not row['vector_or_fp_matches']for row in scalar['results'])
for n in ['views','nic','self-wait']:assert read(T/('sexos-catalog-integration-c-'+n+'.log'))['ok']
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('sealed-build',T/'sexos-catalog-integration-build-c');tree('host',T/'sexos-catalog-integration-c-host');tree('scalar',T/'sexos-catalog-integration-c-scalar-v2')
for group,rows in groups.items():
 for row in rows:tree('native/'+group+'/'+Path(row['out']).name,Path(row['out']))
for p in sorted(T.glob('sexos-catalog-integration-c-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and p!=Path(__file__)and 'package'not in p.name:add('coordination/'+p.name,p)
for name in ['sexos-catalog-integration-build','sexos-catalog-integration-build-b']:
 tree('diagnostics/'+name,T/name)
for name in ['sexos-catalog-integration-host-preflight','sexos-catalog-integration-build-driver.log','sexos-catalog-integration-build-b-driver.log']:
 p=T/name
 if p.is_dir():tree('diagnostics/'+name,p)
 else:add('diagnostics/'+name,p)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-catalog-clock-integration-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(qualified_catalog_clock_integration=True,full_os_goal_complete=False,source_commit=git['commit'],main_parent='8faeafbb43a925269831cfa1b47663b295282a5e',stack_parent='1c9c64ec82e6eb5570222efc7b890b64841a79bd',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],production_inputs=576,runner_inputs=578,committed_source_audit=git,registered_host_checks=43,rust_test_executions=rust,python_tests=965,native=dict(workflow_boots=18,sealed_probe_boots=1,total_boots=19,verified_workflow_captures=138,groups=groups,boot_catalog_audit=boot,pending_device_fresh_replays=True,alpha_rehearsal_fresh_replays=True,new_image_1800s_acceptance=False),scalar=dict(elfs=5,instructions=sum(row['instructions']for row in scalar['results']),inspected_vector_fp_matches=0,scope=scalar.get('scope')),diagnostics=dict(first_build='ABI hash stale after source comment edit; rejected before guest',second_build='GREEN before final task-context audit enhancement; not the final qualification',preflight='One stale document BOOT source anchor failed; source drift detected while updating host hooks; superseded by frozen43-check run',first_freeze='Incorrect kernel path; no source binding published; corrected retry froze exact C artifacts'),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Round133 catalog and PR4-10 ancestry integrated. Actual preseal kernel app/task-context/grant/route/activation audit; lossless accepted reply accounting. Exact frozen virtual clock/connected/TLS/pending-device/cold/find/relaunch checks. Finite BOOT reserves remain. No runtime mint, process VAS/POSIX, general daily-driver, physical/power-loss/SMP/hostile containment/global epoch replay claim.')
p=A/'sexos-catalog-clock-integration-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('INTEGRATION_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
