from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');F=(T/'sexos-catalog-integration-c-frozen').resolve();R=F/'source';rows=[];progress=T/'sexos-catalog-integration-c-pending-native-progress.json';assert not progress.exists()
for label,model,resolution in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 live=T/('sexos-catalog-integration-c-pending-'+label+'-live');cold=T/('sexos-catalog-integration-c-pending-'+label+'-cold')
 for kind,out,script,extra in [('live',live,'quil_workflow_gate.py',['--source-disk',str(T/'sexos-r100a-seed.img'),'--pending-io-close','--capture-profile']),('cold',cold,'pending_io_cold_gate.py',['--session',str(live)])]:
  driver=T/('sexos-catalog-integration-c-pending-'+label+'-'+kind+'-driver.log');assert not out.exists()and not driver.exists();command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--out',str(out),'--resolution',resolution,'--model',model,*extra];row=dict(profile=label,kind=kind,out=str(out),driver=str(driver),command=command,status='running');rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');print('START',label,kind,flush=True);start=time.monotonic()
  with driver.open('x')as log:process=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  row.update(status=process.returncode,elapsed_seconds=time.monotonic()-start);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',label,kind,process.returncode,flush=True)
  if process.returncode:raise SystemExit(process.returncode)
  if kind=='live':r=json.loads((out/'result.json').read_text());assert r['ok']and r['pending_io_close']['terminal_pending']and not r['acceptance'];row['verified_captures']=len(r['stages'])
  else:r=json.loads(driver.read_text());assert r['ok']and r['cold_recovery_verified'];row['verified_captures']=1
  progress.write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==4 and sum(r['verified_captures']for r in rows)==26
print('PENDING_IO_2LIVE_2COLD_26_CAPTURES_PASS',flush=True)
