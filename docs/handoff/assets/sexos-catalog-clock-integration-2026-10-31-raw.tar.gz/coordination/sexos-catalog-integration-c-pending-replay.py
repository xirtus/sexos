from pathlib import Path
import json,os,subprocess
T=Path('/tmp');F=T/'sexos-catalog-integration-c-frozen';R=F/'source';rows=[]
for label,model,resolution in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 live=T/('sexos-catalog-integration-c-pending-'+label+'-live');cold=T/('sexos-catalog-integration-c-pending-'+label+'-cold')
 for kind,script,out,extra in [('live','quil_workflow_gate.py',live,[]),('cold','pending_io_cold_gate.py',cold,['--session',str(live)])]:
  command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--out',str(out),'--model',model,'--resolution',resolution,'--check',*extra];target=T/(out.name+'-independent-replay.json');assert not target.exists()
  with target.open('x')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  assert p.returncode==0,(label,kind,target)
  result=json.loads(target.read_text());assert result['ok'];rows.append(dict(profile=label,kind=kind,replay=str(target),ok=True))
target=T/'sexos-catalog-integration-c-pending-independent-replays.json';assert not target.exists();target.write_text(json.dumps(dict(ok=True,rows=rows),indent=2)+'\n');print('FOUR_PENDING_FRESH_REPLAYS_PASS',flush=True)
