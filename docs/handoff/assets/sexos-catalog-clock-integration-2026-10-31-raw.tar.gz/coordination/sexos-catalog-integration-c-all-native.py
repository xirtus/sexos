from pathlib import Path
import os,subprocess
T=Path('/tmp')
for name in ['native','pending']:
 p=T/('sexos-catalog-integration-c-'+name+'-suite.py');log=T/('sexos-catalog-integration-c-'+name+'-suite-driver.log')
 with log.open('x')as f:r=subprocess.run(['python3',str(p)],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
