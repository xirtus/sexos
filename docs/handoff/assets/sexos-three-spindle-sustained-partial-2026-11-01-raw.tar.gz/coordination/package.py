from pathlib import Path
import hashlib,io,json,tarfile
T=Path('/tmp');F=T/'sexos-spindle-third-b-frozen';A=T
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
progress=read(T/'sexos-spindle-third-b-sustained-progress.json');assert [r['status']for r in progress]==[0,1]and progress[0]['fresh_replay']and not progress[1].get('fresh_replay')
compact=read(T/'sexos-spindle-third-b-sustained-compact/result.json');wide=read(T/'sexos-spindle-third-b-sustained-wide/result.json');replay=read(T/'sexos-spindle-third-b-sustained-compact-independent-replay.json');assert replay['ok']and replay['acceptance'];assert 'excessive unaccounted idle time'in(T/'sexos-spindle-third-b-sustained-wide-driver.log').read_text()
audit=read(T/'sexos-spindle-third-b-source-audit.json');b=read(F/'source-binding.json');assert audit['commit']=='c5bf51208562f1409e63065c5e23ab2285ac3a9a'
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 for p in sorted(Path(root).rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F)
for profile in ['compact','wide']:
 out=T/('sexos-spindle-third-b-sustained-'+profile);tree('sessions/'+profile,out);add('coordination/'+out.name+'-driver.log',T/(out.name+'-driver.log'))
for name in ['sexos-spindle-third-b-sustained-progress.json','sexos-spindle-third-b-sustained.py','sexos-spindle-third-b-sustained-driver.log','sexos-spindle-third-b-sustained-rejected-wide-audit.json','sexos-spindle-third-b-sustained-compact-independent-replay.json','sexos-spindle-third-b-source-audit.json']:add('coordination/'+name,T/name)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();archive=A/'sexos-three-spindle-sustained-partial-2026-11-01-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1
 for m in members:
  raw=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(raw)==expected['bytes']and hashlib.sha256(raw).hexdigest()==expected['sha256']
e=dict(paired_accepted=False,source_commit=audit['commit'],iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],coordinator_exit=1,compact=dict(accepted=True,fresh_readonly_replay=True,elapsed_seconds=compact['soak']['elapsed_seconds'],cycles=compact['soak']['cycles'],verified_captures=replay['verified_captures']),wide=dict(accepted=False,recorded_result_ok=wide['ok'],recorded_result_acceptance=wide['acceptance'],final_replay_rejected=True,elapsed_seconds=wide['soak']['elapsed_seconds'],cycles=wide['soak']['cycles'],candidate_captures=len(wide['stages']),reason='excessive unaccounted idle time',active_seconds=wide['soak']['active_elapsed_seconds'],idle_seconds=wide['soak']['idle_elapsed_seconds'],idle_bound_seconds=wide['soak']['cycles']*15+1),future_correction=dict(source_commit='348cc9ab4d2988eb58c1e4dcacf8f7b4149d6ad7',read_final_snapshot_before_end_timestamp=True,anchor_idle_to_same_end=True,acceptance_bound_unchanged=True,old_wide_remains_rejected=True),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,all_members_size_sha256_verified=True),scope='Original stopped three-reserve image: compact accepted; wide failed strict idle accounting despite recorded result flags. No paired or unrestricted daily-driver acceptance. All failed raw artifacts preserved; future harness correction does not relabel old evidence.')
p=T/'sexos-three-spindle-sustained-partial-2026-11-01-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('PARTIAL_ONLY_ARCHIVE_VERIFIED',len(items)+1,archive.stat().st_size)
