impl App {
    fn fence_asset(&mut self,reason:&str){
        self.asset_fenced=true;self.asset_status=asset_view::Status::Uncertain;self.image.clear();self.bitmap.close();
        let _=self.asset_presentation.invalidate();
        self.exchange.cancel();
        if matches!(self.intent,Some(Intent::TlsAssetDns|Intent::TlsStart)){
            self.intent=None;self.dns.cancel();
        }
        let erased=self.tls.cancel(&mut self.trust,&mut self.seed,&mut self.clock);
        if erased>0{sex_pdx::serial_record!("[browser.tls.erased] bytes={} owned_storage=1",erased);}
        sex_pdx::serial_record!("[browser.asset.fenced] reason={} accepted_replay=0 owned_storage=erased",reason);
    }
    fn update_asset_peer(&mut self,peer_view:tls_exchange::View,peer_ticket:u32){
            if peer_view!=self.asset_peer_view{
                self.asset_peer_view=peer_view;
                if true{
                match peer_view{
                    tls_exchange::View::Verified=>{if let Some(body)=self.exchange.take_asset(){
                        let len=body.as_bytes().len();let hash=public_fingerprint(body.as_bytes());
                        sex_pdx::serial_record!("[browser.asset.released] ticket={} tx={} rx={} body_bytes={} body_hash={:#x} positive_release=1 authenticated=1",peer_ticket,self.exchange.tx_bytes(),self.exchange.rx_bytes(),len,hash);
                        self.asset_status=if self.image.begin(body,peer_ticket).is_ok(){asset_view::Status::Decoding}else{sex_pdx::serial_record!("[browser.asset.rejected] reason=invalid_qoi_or_allocation effects=0 owned_storage=erased");asset_view::Status::Invalid};
                    }},
                    tls_exchange::View::Unavailable=>{self.image.clear();self.asset_status=asset_view::Status::Unavailable;},
                    tls_exchange::View::Uncertain=>{self.image.clear();self.asset_status=asset_view::Status::Uncertain;},
                    tls_exchange::View::Cancelled=>{if !self.bitmap.pending(){self.asset_status=asset_view::Status::Cleared;}},
                    _=>{},
                }
                }
                sex_pdx::serial_record!("[browser.asset.view] state={:?} controlled_profile=1 public_internet=0",peer_view);
            }
    }
}