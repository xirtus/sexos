from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
F=Path('/tmp/sexos-alpha-r106-images-a-frozen').resolve()
R=F/'source'
T=Path('/tmp/sexos-r106-a-semantic-controls')
T.mkdir(exist_ok=False)
B=F/'source-binding.json'
binding=json.loads(B.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
closure={**binding['sources'],**binding['runner_sha256']}
checked={}
def bound(path):
 path=path.resolve();relative=str(path.relative_to(R));assert relative in closure,relative
 digest=sha(path);assert digest==closure[relative],(relative,'frozen hash mismatch')
 checked[relative]=digest
 return digest

def rewrite_paths(fixture,overrides):
 def replace(match):
  target=(fixture.parent/match[1]).resolve();bound(target)
  return '#[path="'+str(overrides.get(target,target))+'"]'
 return re.sub(r'#\[path\s*=\s*"([^"]+)"\]',replace,fixture.read_text())

def run(command,name,environment):
 log=T/(name+'.log')
 env={**os.environ,**environment}
 with log.open('w')as output:
  result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env=env)
 return dict(returncode=result.returncode,log_path=str(log),log_sha256=sha(log),command=command,environment=environment)

controls=[]
specs=[
 ('asset-centering','apps/kaleidoscope/src/asset_view.rs','tests/browser_asset.rs',
  'let x=INSET+(available_w-image_w)/2;let y=top+(available_h-image_h)/2;',
  'let x=INSET;let y=top;',
  ['image_modes_center_complete_pixels_in_the_same_reserved_body']),
 ('presentation-sequence-floor','apps/kaleidoscope/src/asset_presentation.rs','tests/browser_asset_presentation.rs',
  '|| sequence <= self.sequence_floor','',
  ['stale_actual_fit_same_geometry_ack_cannot_be_rebound_to_new_generation']),
 ('asset-peer-fence','apps/kaleidoscope/src/main.rs','tests/browser_asset_fence.rs',
  'if !self.asset_fenced{\n                match peer_view{','if true{\n                match peer_view{',
  ['fenced_q_cancel_does_not_claim_display_clear','fenced_late_verified_never_adopts_or_reallocates_image_storage']),
]
for name,module,fixture_name,old,new,tests in specs:
 source=R/module;fixture=R/fixture_name
 source_hash=bound(source);fixture_hash=bound(fixture)
 source_copy=T/(name+'-original-source.rs');shutil.copyfile(source,source_copy)
 original_test=T/(name+'-original-test.rs');shutil.copyfile(fixture,original_test)
 original=source_copy.read_text()
 baseline_module=source_copy
 if name=='asset-peer-fence':
  gate=R/'scripts/browser_asset_fence_host_gate.sh';bound(gate)
  # Extract precisely the actual frozen App methods, as its canonical host gate.
  parts=[]
  for function in ('fence_asset','update_asset_peer'):
   found=re.findall(r'^    fn '+function+r'\b.*?^    }',original,re.M|re.S)
   assert len(found)==1,function
   parts.extend(found)
  assert 'self.update_asset_peer(peer_view,peer_ticket);'in original
  original='impl App {\n'+'\n'.join(parts)+'\n}'
  baseline_module=T/(name+'-actual-methods.rs');baseline_module.write_text(original)
 assert original.count(old)==1,(name,original.count(old))
 mutant=T/(name+'-mutant.rs');mutant.write_text(original.replace(old,new,1));assert mutant.read_text()!=original
 row=dict(name=name,source_path=module,source_sha256=source_hash,
  source_fixture_path=str(source_copy),source_fixture_sha256=sha(source_copy),
  fixture_path=fixture_name,fixture_sha256=fixture_hash,
  original_test_fixture_path=str(original_test),original_test_fixture_sha256=sha(original_test),
  baseline_module_path=str(baseline_module),baseline_module_sha256=sha(baseline_module),
  mutant_path=str(mutant),mutant_sha256=sha(mutant),mutation=dict(old=old,new=new,count=1),tests=tests)
 for kind,module_path in [('baseline',baseline_module),('mutant',mutant)]:
  wrapper=T/(name+'-'+kind+'-fixture.rs')
  overrides={source.resolve():module_path}
  wrapper.write_text(rewrite_paths(fixture,overrides))
  row[kind+'_fixture_path']=str(wrapper);row[kind+'_fixture_sha256']=sha(wrapper)
  environment={'BROWSER_ASSET_FENCE':str(module_path)}if name=='asset-peer-fence'else{}
  binary=T/(name+'-'+kind+'-tests')
  compile_result=run(['rustc','--edition=2021','-A','dead_code','--test',str(wrapper),'-o',str(binary)],name+'-'+kind+'-compile',environment)
  assert compile_result['returncode']==0,(name,kind,compile_result)
  test_results=[]
  for test in tests:
   result=run([str(binary),'--exact',test,'--test-threads=1'],name+'-'+kind+'-'+test,environment)
   result['name']=test
   log=Path(result['log_path']).read_text()
   if kind=='baseline':
    assert result['returncode']==0 and 'test result: ok. 1 passed;'in log and test+' ... ok'in log,(name,test,result)
   else:
    assert result['returncode']==101 and 'test result: FAILED. 0 passed; 1 failed;'in log and test+' ... FAILED'in log,(name,test,result)
   test_results.append(result)
  row[kind]=dict(compile=compile_result,tests=test_results)
  binary.unlink()
 row['baseline_passed']=True;row['negative_rejected']=True;controls.append(row)
result=dict(ok=True,frozen_root=str(F),source_binding_sha256=sha(B),
 control_script_path=str(Path(__file__).resolve()),control_script_sha256=sha(Path(__file__).resolve()),
 controls_count=len(controls),baseline_tests_passed=sum(len(c['tests'])for c in controls),
 mutant_tests_rejected=sum(len(c['tests'])for c in controls),frozen_inputs_verified=checked,controls=controls,
 scope='Three semantic controls against exact frozen round106A asset geometry, presentation sequence fence and actual extracted Browser peer methods. Six baseline/mutant host test compilations passed; four baseline exact tests passed and all four mutant exact tests failed with exit101. Mutations and absolute-path fixture rewrites exist only in copied /tmp files. No production or frozen file edited; no native, authority, pixel, storage, build or QEMU claim.')
out=Path('/tmp/sexos-r106-a-semantic-controls.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(ok=result['ok'],controls=result['controls_count'],baseline_tests=result['baseline_tests_passed'],mutant_tests=result['mutant_tests_rejected'],output=str(out),sha256=sha(out))))
