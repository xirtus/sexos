"""Round106 candidate A packaging preparation; never builds/boots/edits sources.
--check-only validates terminal evidence without writes; --execute writes assets.
Root reviews and authorizes execution only after the full cohort is accepted.
"""
from pathlib import Path
import argparse,gzip,hashlib,io,json,os,re,subprocess,tarfile
from PIL import Image
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');C='a'
F=T/f'sexos-alpha-r106-images-{C}-frozen';B=T/f'sexos-alpha-r106-images-{C}-build'
A=R/'docs/handoff/assets';STEM='sexos-alpha-r106-2026-10-31'
EXPECTED_RUST={'service-custody':1803,'display':56,'readability':9,'launcher':35,'text-pipeline':65,'drive-wait':38}
MARKERS={'service-custody':'[service.custody.host.gate] PASS','display':'[gate.display_surface_groups.result] PASS','readability':'[gate.display_text_readability.result] PASS','launcher':'[launcher.workspace.host] PASS','text-pipeline':'[gate.linen_text_delivery.result] PASS','drive-wait':'[gate.sexdrive_service.result] PASS'}
SCOPES={'service-custody':'Actual Rust custody/clipboard/editor/reader/network/asset functions with explicitly modeled callbacks; executions rather than unique-test deduplication.','display':'Actual display Stage/scalar/scanline/damage and exact parent policy; native pixels are separate.','readability':'Actual readable layout/contrast functions.','launcher':'Actual Shell action/workspace/admission callbacks.','text-pipeline':'Actual UTF8 Reader/shared Outbox/Display Stage/Applied with finite callbacks.','drive-wait':'Four runtime NVMe completion paths/dispatch with fake ticks, CQEs and event words; callbacks are assumed to return.'}
EXCLUDED_CACHE_COMPONENTS={'target','__pycache__'}
CHECK_SUFFIXES={'.rs','.py','.json','.log','.disassembly','.elf'}
SCOPE='Retained authenticated QOI viewing with explicit F Fit/A 1:1 controls, centered bounded image geometry, complete source-font metrics/help and current-generation text/bitmap acknowledgments. Both desktop profiles retain pixels across A/F, Zoom/restore without new network fetches; controlled negative MIME/QOI/partial Q/Close and exact12288-byte UTF8 clipboard/Save/cold recovery regressions. GLOBAL_VAS, BOOT-only capability genesis and typed exact-incarnation sex-pdx remain; not Unix/POSIX.'
LIMITATIONS=[
 'The finite source-defined 48x48 procedural QOI has straight alpha 0/128/255. Native evidence covers centered Fit/1:1 at 1280x800 and1024x768; tiny/no-fit views and exhaustion/fence edge cases are actual host-function scopes unless separately recorded.',
 'Image controls reuse the same released/decoded immutable pixels. Eight presentation frames plus one clear per ready boot prove current glyphs/image/guard and former image rectangles intersecting the current owned body; this is not whole-desktop erasure or arbitrary-image safety.',
 'TLS uses an immutable BOOT public lab root and fixed controlled endpoint. No public Internet/CA/arbitrary URL, host proxy, TLS-secret capture, physical hardware, SMP or hostile-content containment is qualified.',
 'UTF8 clipboard regression preserves exact source bytes and same-image cold reopen; one scalar per cell/finite fallback font is not shaping, grapheme composition, normalization, IME, bidi or Unicode filenames.',
 'The Browser scalar audit is ISO-extracted ELF operand/mnemonic inspection, not whole-image, runtime stack/register/cache erasure or hostile containment proof.',
 'NVMe host evidence covers exactly four runtime waits with bounded elapsed ticks/yield and DMA quarantine; clock/yield callbacks must return. No whole-driver timing, crash/power-loss, full-system deterministic replay, sustained daily-driver or System Proven claim.'
]
def load(path):return json.loads(Path(path).read_text())
def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as stream:
  for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def safe(name):
 p=Path(name)
 assert name and not p.is_absolute()and '..'not in p.parts and not(EXCLUDED_CACHE_COMPONENTS&set(p.parts)),name
 return name

def verify_frozen(directory,live=False):
 directory=Path(directory);binding=load(directory/'source-binding.json');sources={**binding['sources'],**binding['runner_sha256']}
 assert not(set(binding['sources'])&set(binding['runner_sha256']))
 for name,expected in sources.items():
  safe(name);path=directory/'source'/name;assert path.is_file()and not path.is_symlink()and sha(path)==expected,name
  if live:assert sha(R/name)==expected,('live source differs',name)
 assert sha(directory/'tested.iso')==binding['iso_sha256'];assert sha(directory/'tested.kernel')==binding['kernel_sha256']
 return binding

def ensure_no_qemu():
 p=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True,check=True)
 owners=[line for line in p.stdout.splitlines()if re.search(r'(^|\s|/)qemu-system-[^/ ]+\s*$',line)]
 assert not owners,('QEMU remains live; do not package/compress',owners)

def semantic_controls(binding):
 path=T/f'sexos-r106-{C}-semantic-controls.json';data=load(path);directory=(T/f'sexos-r106-{C}-semantic-controls').resolve()
 assert data['controls_count']==3 and data['baseline_tests_passed']==4 and data['mutant_tests_rejected']==4 and isinstance(data['frozen_inputs_verified'],dict)and data['frozen_inputs_verified']
 for name,wanted in data['frozen_inputs_verified'].items():
  safe(name);assert binding['sources'].get(name,binding['runner_sha256'].get(name))==wanted
 script=Path(data['control_script_path']);assert script.resolve().parent==T.resolve()and sha(script)==data['control_script_sha256']
 assert data['ok']is True and data['source_binding_sha256']==sha(F/'source-binding.json')and Path(data['frozen_root']).resolve()==F.resolve()
 assert{row['name']for row in data['controls']}=={'asset-centering','presentation-sequence-floor','asset-peer-fence'}and len(data['controls'])==3
 for row in data['controls']:
  assert row['baseline_passed']is True and row['negative_rejected']is True
  for key in('source_path','fixture_path'):safe(row[key])
  assert row['source_path']in binding['sources']and row['fixture_path']in binding['runner_sha256']
  assert row['source_sha256']==binding['sources'][row['source_path']]and row['fixture_sha256']==binding['runner_sha256'][row['fixture_path']]
  for key in('source_fixture','original_test_fixture','baseline_fixture','mutant_fixture','baseline_module','mutant'):
   item=Path(row[key+'_path']).resolve();assert item.is_relative_to(directory)and item.is_file()and not item.is_symlink()and sha(item)==row[key+'_sha256']
  assert row['source_fixture_sha256']==row['source_sha256']and row['original_test_fixture_sha256']==row['fixture_sha256']
  baseline=Path(row['baseline_module_path']).read_text();mutant=Path(row['mutant_path']).read_text();change=row['mutation'];assert change['count']==1 and change['old']!=change['new']and baseline.count(change['old'])==1 and baseline.replace(change['old'],change['new'],1)==mutant
  assert row['tests']and len(row['tests'])==len(set(row['tests']))
  for phase in('baseline','mutant'):
   compile=row[phase]['compile'];log=Path(compile['log_path']).resolve();assert log.is_relative_to(directory)and sha(log)==compile['log_sha256']and compile['returncode']==0
   assert not re.search(r'error: aborting|^error\[E',log.read_text(),re.M)
   tests=row[phase]['tests'];assert[t['name']for t in tests]==row['tests']
   for test in tests:
    log=Path(test['log_path']).resolve();assert log.is_relative_to(directory)and sha(log)==test['log_sha256'];text=log.read_text()
    assert test['returncode']==(0 if phase=='baseline'else 101)
    assert test['name']+' ... '+('ok'if phase=='baseline'else'FAILED')in text
    assert('test result: ok. 1 passed;'if phase=='baseline'else'1 failed;')in text
 return path,data

def validation():
 binding=verify_frozen(F,True);assert(len(binding['sources']),len(binding['runner_sha256']))==(564,534)
 assert binding['architecture_sha256']==binding['sources']['ARCHITECTURE.md']==sha(R/'ARCHITECTURE.md')
 provenance=load(B/'provenance.json');assert provenance['iso_sha256']==binding['iso_sha256']and provenance['source_image_binding']=='sealed_build_this_run'and provenance['sources_unchanged_during_build']is True and provenance['build_gate']=='PASS'
 assert provenance['production_source_sha256']==binding['sources']
 assert '| **FINAL_SCORE** | **GREEN_MASTER** |'in(B/'report.md').read_text()
 progress=load(T/f'sexos-r106-{C}-native-suite-progress.json');replay_path=T/f'sexos-r106-{C}-root-independent-replay.json';replay=load(replay_path)
 assert len(progress)==12 and all(type(row['status'])is int and row['status']==0 for row in progress)
 assert replay['ok']is True and replay['complete']is True and(replay['native_runs'],replay['native_boots'],replay['frames'])==(12,14,48)
 assert replay['source_binding_sha256']==sha(F/'source-binding.json')and sum(row['boots']for row in progress)==14 and sum(row['frames']for row in replay['runs'])==48
 expected_names={'asset-'+mode+'-'+profile for mode in('ready','wrong-mime','invalid-qoi','partial-clear','partial-close')for profile in('wide','compact')}|{'clipboard-wide','clipboard-compact'}
 assert{row['name']for row in progress}==expected_names and{row['name']for row in replay['runs']}==expected_names and len(replay['runs'])==12
 for row in progress:
  other=next(r for r in replay['runs']if r['name']==row['name']);assert other['ok']is True and all(other[k]==row[k]for k in('out','mode','profile','boots'))
  expected_frames=11 if row['name'].startswith('clipboard-')else 9 if row['mode']=='ready'else 1
  assert other['frames']==row['frames']==expected_frames and row['boots']==(2 if row['name'].startswith('clipboard-')else 1)
  assert row['source_binding_sha256']==sha(F/'source-binding.json');result=load(Path(row['out'])/'result.json');assert result['ok']is True
  label=row['profile']['label'];assert label in('wide','compact')and row['profile']==dict(label=label,model='e1000e'if label=='wide'else'e1000',resolution='1280x800'if label=='wide'else'1024x768')
  if row['name'].startswith('clipboard-'):
   manifests=[load(Path(row['out'])/boot/'manifest.json')for boot in('write','recovery')]
   assert all(m['text_profile']=='utf8'and m['body_bytes']==12288 for m in manifests)and manifests[0]['body_sha256']==manifests[1]['body_sha256']
   assert all(m['binding']['sha256']==sha(F/'source-binding.json')for m in manifests)
  else:
   manifest=load(Path(row['out'])/'manifest.json');assert manifest['mode']==row['mode']and manifest['binding']['sha256']==sha(F/'source-binding.json')and len(manifest['frames'])==expected_frames
   assert result['binding']['sha256']==sha(F/'source-binding.json')and result['wire']['ok']is True and result['trace']['ok']is True
 logs=[]
 for label,expected in EXPECTED_RUST.items():
  path=T/f'sexos-r106-{C}-frozen-{label}.log';text=path.read_text();assert MARKERS[label]in text
  assert not re.search(r'test result: FAILED|error: aborting|^error\[E',text,re.M),(label,'failure in host log')
  count=sum(map(int,re.findall(r'\btest result: ok\. (\d+) passed;',text)));assert count==expected,(label,count,expected)
  logs.append(dict(name=label,path=str(path),executions=count,sha256=sha(path),scope=SCOPES[label]))
 assert sum(row['executions']for row in logs)==2046
 python_log=T/f'sexos-r106-{C}-frozen-python.log';text=python_log.read_text();assert re.search(r'^OK$',text,re.M)and not re.search(r'^FAILED|^ERROR:|^FAIL:',text,re.M)
 counts=re.findall(r'Ran (\d+) tests',text);assert len(counts)==1 and int(counts[0])==778
 controls_path,controls=semantic_controls(binding)
 scalar=load(T/f'sexos-r106-{C}-scalar-instructions.json');assert scalar['ok']is True and type(scalar['instructions'])is int and scalar['instructions']>0 and scalar['vector_or_fp_matches']==[]
 assert scalar['iso_sha256']==binding['iso_sha256']and scalar['elf_sha256']==sha(T/f'sexos-r106-{C}-tested-kaleidoscope.elf')and scalar['disassembly_sha256']==sha(T/f'sexos-r106-{C}-kaleidoscope.disassembly')
 return dict(binding=binding,progress=progress,replay=replay,replay_path=replay_path,rust=logs,python_count=int(counts[0]),python_log=python_log,controls=controls,controls_path=controls_path,scalar=scalar)

class Collector:
 def __init__(self):self.members={};self.disk_copies=[];self.excluded_caches=[];self.omitted_negative_binaries=[]
 def add(self,path,name):
  path=Path(path);safe(name);assert path.is_file()and not path.is_symlink(),path
  if name in self.members:assert self.members[name]==path;return
  self.members[name]=path
 def disk(self,path):
  path=Path(path);ensure_no_qemu();owner=subprocess.run(['lsof','-t',str(path)],capture_output=True,text=True)
  assert owner.returncode in (0,1)and not owner.stdout.strip()and not owner.stderr.strip(),('raw disk is owned',str(path),owner.stdout,owner.stderr)
  before=path.stat();raw_sha=sha(path);candidates=[path.with_name(path.name+'.gz'),path.parent/'root-terminal-disk.img.gz',path.with_name(path.name+'.archive-copy.gz')];compressed=next((p for p in candidates if p.is_file()),None)
  created=False
  if compressed is None:
   compressed=path.with_name(path.name+'.archive-copy.gz');assert not compressed.exists();created=True
   with path.open('rb')as source,compressed.open('xb')as target:
    with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0)as zipped:
     for block in iter(lambda:source.read(1<<20),b''):zipped.write(block)
  h=hashlib.sha256();size=0
  with gzip.open(compressed,'rb')as stream:
   for block in iter(lambda:stream.read(1<<20),b''):h.update(block);size+=len(block)
  after=path.stat();assert(before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)and raw_sha==sha(path)==h.hexdigest()and size==after.st_size
  ensure_no_qemu();owner2=subprocess.run(['lsof','-t',str(path)],capture_output=True,text=True);assert owner2.returncode in(0,1)and not owner2.stdout.strip()and not owner2.stderr.strip()
  self.disk_copies.append(dict(raw=str(path),raw_sha256=raw_sha,bytes=size,compressed=str(compressed),compressed_sha256=sha(compressed),created_after_terminal_checks=created,uncompressed_verified=True));return compressed
 def tree(self,directory,prefix,controls_only=False):
  directory=Path(directory);assert directory.is_dir(),directory
  for path in sorted(directory.rglob('*')):
   relative=path.relative_to(directory)
   if EXCLUDED_CACHE_COMPONENTS&set(relative.parts):
    self.excluded_caches.append(str(path));continue
   assert not path.is_symlink(),path
   if not path.is_file():continue
   if controls_only and path.suffix not in CHECK_SUFFIXES:self.omitted_negative_binaries.append(str(path));continue
   if path.suffix=='.img':
    compressed=self.disk(path);self.add(compressed,prefix+'/'+str(relative)+'.verified.gz')
   else:self.add(path,prefix+'/'+str(relative))
 def frozen(self,directory,prefix):
  binding=verify_frozen(directory)
  for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):self.add(Path(directory)/'source'/name,prefix+'/source/'+name)
  for name in('source-binding.json','tested.iso','tested.kernel'):self.add(Path(directory)/name,prefix+'/'+name)

def collect(context):
 c=Collector();c.frozen(F,'final');c.tree(B,'build')
 for row in context['progress']:
  c.tree(row['out'],'native/'+row['name']);c.add(row['driver'],'checks/'+Path(row['driver']).name)
 for path in sorted(T.glob(f'sexos-r106-{C}-*')):
  if path.is_file()and path.suffix in CHECK_SUFFIXES and 'package.log'not in path.name:c.add(path,'checks/'+path.name)
 controls=T/f'sexos-r106-{C}-semantic-controls';c.tree(controls,'checks/semantic-controls',True)
 # Unfrozen preparatory logs are explicitly diagnostic, not frozen gate runs.
 for name in('sexos-r106-asset-fence-host.log','sexos-r106-asset-fence-removed-guard-negative.log','sexos-r106-asset-presentation-host.log','sexos-r106-browser-asset-tests.log','sexos-r106-network-asset-preflight.log'):
  path=T/name
  if path.is_file():c.add(path,'diagnostics/unfrozen-preflight/'+name)
 seed=T/'sexos-r100a-seed.img';compressed=c.disk(seed);c.add(compressed,'seed.img.gz')
 return c

SCREENSHOTS=[('asset-ready-wide','','initial-image.ppm','fit-wide'),('asset-ready-wide','','actual-image.ppm','actual-wide'),('asset-ready-compact','','zoomed-image.ppm','zoom-fit-compact'),('asset-ready-compact','','restored-fit.ppm','restored-fit-compact'),('clipboard-compact','recovery','quil-cold-reopened.ppm','cold-compact')]
def screenshots(context):
 result=[]
 for name,boot,filename,label in SCREENSHOTS:
  row=next(r for r in context['progress']if r['name']==name);out=Path(row['out'])/boot;manifest=load(out/'manifest.json');raw=out/filename
  for source,wanted in manifest['source_sha256'].items():
   safe(source);assert context['binding']['sources'].get(source,context['binding']['runner_sha256'].get(source))==wanted
  if name.startswith('asset-'):
   frames=manifest['frames'];found=[f for f in frames if f['file']==filename];assert len(found)==1;frame=found[0]
   assert manifest['raw_sha256'][filename]==sha(raw);trace=(out/'serial.log').read_bytes().decode('utf-8',errors='strict');size=frame['serial_end'];assert 0<size<=len(trace);prefix=trace[:size].encode('utf-8');assert digest_bytes(prefix)==frame['serial_sha256'];prefix_unit='UTF8 characters reencoded exactly'
  else:
   frames=load(out/'frames.json');found=[f for f in frames if f['screenshot']==filename];assert len(found)==1;frame=found[0]
   assert frame['screenshot_sha256']==sha(raw);serial=(out/'serial.log').read_bytes();size=frame['serial_bytes'];assert 0<size<=len(serial);prefix=serial[:size];assert digest_bytes(prefix)==frame['serial_sha256'];prefix_unit='raw bytes'
  dest=A/f'{STEM}-{label}.png';assert not dest.exists()
  with Image.open(raw)as image:
   image=image.convert('RGB');original=image.tobytes();dimensions=image.size;image.save(dest)
  with Image.open(dest)as image:assert image.convert('RGB').tobytes()==original and image.size==dimensions
  result.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=name,boot=boot,raw_ppm=filename,raw_sha256=sha(raw),serial_prefix_length=size,serial_prefix_unit=prefix_unit,serial_sha256=frame['serial_sha256'],rgb_sha256=digest_bytes(original),dimensions=dimensions,pixel_identical=True))
 return result

def archive(collector):
 path=A/f'{STEM}-qualified-raw.tar.gz';assert not path.exists();inventory=[dict(name=name,bytes=source.stat().st_size,sha256=sha(source))for name,source in sorted(collector.members.items())]
 note=dict(scope='Round106 final candidate '+C.upper()+' acceptance only. Unfrozen preparatory logs are diagnostics; no prior round acceptance or failure is repackaged.',excluded_unbound_cache_components=sorted(EXCLUDED_CACHE_COMPONENTS),excluded_unbound_caches=collector.excluded_caches,omitted_negative_compiled_outputs=collector.omitted_negative_binaries,raw_disk_omissions_only_with_exact_compressed_copy=collector.disk_copies,members=inventory)
 index=(json.dumps(note,indent=2)+'\n').encode()
 with path.open('xb')as target,gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as tar:
  for row in inventory:
   source=collector.members[row['name']];assert sha(source)==row['sha256'];info=tarfile.TarInfo(row['name']);info.size=row['bytes'];info.mtime=0;info.uid=info.gid=0;info.mode=0o644
   with source.open('rb')as stream:tar.addfile(info,stream)
  info=tarfile.TarInfo('archive-inventory.json');info.size=len(index);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(index))
 expected=inventory+[dict(name='archive-inventory.json',bytes=len(index),sha256=digest_bytes(index))]
 with tarfile.open(path,'r:gz')as tar:
  members=tar.getmembers();assert len(members)==len(expected)and all(member.isfile()for member in members)and{member.name for member in members}=={row['name']for row in expected}
  for row in expected:
   data=tar.extractfile(row['name']).read();assert len(data)==row['bytes']and digest_bytes(data)==row['sha256'],row['name']
 return dict(path=str(path.relative_to(R/'docs/handoff')),sha256=sha(path),members=len(expected),verified=True,bytes=path.stat().st_size,raw_disk_copies=collector.disk_copies)

def main():
 p=argparse.ArgumentParser();mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--check-only',action='store_true');mode.add_argument('--execute',action='store_true');args=p.parse_args();context=validation();rust=sum(r['executions']for r in context['rust'])
 if args.check_only:print(json.dumps(dict(ok=True,mode='read-only terminal-evidence preflight',candidate=C,rust=rust,python=context['python_count'],native_runs=12,native_boots=14,frames=48)));return
 ensure_no_qemu();evidence_path=A/f'{STEM}-evidence.json';assert A.is_dir()and not evidence_path.exists()
 for *_,label in SCREENSHOTS:assert not(A/f'{STEM}-{label}.png').exists()
 assert not(A/f'{STEM}-qualified-raw.tar.gz').exists();collector=collect(context);pictures=screenshots(context);raw=archive(collector)
 assert verify_frozen(F,True)==context['binding']
 evidence=dict(round=106,accepted=True,accepted_goal_rounds=27,total_goal_rounds=121,remaining_goal_rounds=94,candidate=C.upper(),iso_sha256=context['binding']['iso_sha256'],kernel_sha256=context['binding']['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),architecture_sha256=context['binding']['architecture_sha256'],production_inputs=len(context['binding']['sources']),runner_inputs=len(context['binding']['runner_sha256']),checks=dict(master='BUILD PASS / GREEN_MASTER',rust=context['rust'],rust_test_executions=rust,python_tests=context['python_count'],python_log_sha256=sha(context['python_log']),native_runs=12,native_boots=14,independent_frames=48,root_replay_sha256=sha(context['replay_path']),scalar_audit=context['scalar'],semantic_negative_controls=context['controls'],semantic_controls_sha256=sha(context['controls_path'])),qualification_runs=context['progress'],remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=pictures,archive=raw,diagnostics_scope='Only explicitly labeled round106 unfrozen preflights are historical diagnostics. Prior accepted105 evidence remains in its own committed archive.',limitations=LIMITATIONS,scope=SCOPE)
 with evidence_path.open('x')as stream:stream.write(json.dumps(evidence,indent=2)+'\n')
 print(json.dumps(dict(ok=True,round=106,candidate=C,rust=rust,python=context['python_count'],archive=raw)))
if __name__=='__main__':main()
