from pathlib import Path
import errno,hashlib,json,os,socket,subprocess,time
f=Path('/tmp/sexos-alpha-r106-images-a-frozen');binding=f/'source-binding.json';progress=Path('/tmp/sexos-r106-a-native-suite-progress.json');assert not progress.exists();rows=[];port_evidence=[];port_file=Path('/tmp/sexos-r106-a-native-port-waits.json')
def await_ports(name):
 began=time.monotonic();turn=0;checks=[];record=dict(name=name,checks=checks);port_evidence.append(record)
 while True:
  turn+=1;blocked=[];sockets=[]
  try:
   for port,kind in[(46078,socket.SOCK_STREAM),(46079,socket.SOCK_STREAM),(46080,socket.SOCK_STREAM),(46079,socket.SOCK_DGRAM)]:
    sock=socket.socket(socket.AF_INET,kind);sockets.append(sock)
    try:sock.bind(('127.0.0.1',port))
    except OSError as error:
     if error.errno!=errno.EADDRINUSE:raise
     blocked.append(dict(port=port,protocol='TCP'if kind==socket.SOCK_STREAM else'UDP',error=error.errno))
  finally:
   for sock in sockets:sock.close()
  owners=[]
  for item in blocked:
   flag='-iTCP:'+str(item['port'])if item['protocol']=='TCP'else'-iUDP:'+str(item['port']);cmd=['lsof','-nP',flag]+(['-sTCP:LISTEN']if item['protocol']=='TCP'else[]);r=subprocess.run(cmd,capture_output=True,text=True)
   if r.stdout.strip():owners.append(dict(command=cmd,output=r.stdout.strip()))
  check=dict(turn=turn,elapsed_seconds=time.monotonic()-began,blocked=blocked,live_owners=owners);checks.append(check);port_file.write_text(json.dumps(port_evidence,indent=2)+'\n')
  if owners:raise RuntimeError('live process owns required fixture port; preserve/diagnose before continuing: '+str(owners))
  if not blocked:print('PORTS_AVAILABLE',name,'turn',turn,'elapsed',check['elapsed_seconds'],flush=True);return
  print('PORT_WAIT',name,'turn',turn,'blocked',blocked,'no_live_listener',flush=True)
  if time.monotonic()-began>=120:raise TimeoutError('authoritative port bind checks still fail after120seconds')
  time.sleep(.5)
jobs=[]
profiles=[('wide','e1000e','1280x800'),('compact','e1000','1024x768')]
for mode in ['ready','wrong-mime','invalid-qoi','partial-clear','partial-close']:
 for profile,model,resolution in profiles:jobs.append(('asset-'+mode+'-'+profile,'https_asset_gate.py',mode,profile,model,resolution,1,9 if mode=='ready'else 1))
for profile,model,resolution in profiles:jobs.append(('clipboard-'+profile,'clipboard_workflow_gate.py',None,profile,model,resolution,2,11))
for name,checker,mode,profile,model,resolution,boots,frames in jobs:
 out=Path('/tmp/sexos-r106-a-native-'+name);driver=Path('/tmp/sexos-r106-a-native-'+name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(f/'source/scripts'/checker),'--iso',str(f/'tested.iso'),'--binding',str(binding),'--source-disk','/tmp/sexos-r100a-seed.img','--out',str(out),'--model',model,'--resolution',resolution]
 if mode:command+=['--mode',mode]
 if checker=='clipboard_workflow_gate.py':command+=['--text-profile','utf8']
 row=dict(name=name,status='port-preflight',out=str(out),driver=str(driver),command=command,mode=mode or 'clipboard-recovery',profile=dict(label=profile,model=model,resolution=resolution),boots=boots,frames=frames,source_binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest());rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');await_ports(name)
 row['status']='running';progress.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic();print('START',name,flush=True)
 with driver.open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert json.loads((out/'result.json').read_text())['ok']
assert len(rows)==12 and sum(r['boots']for r in rows)==14 and sum(r['frames']for r in rows)==48
print('ALL12_RUNS_14_BOOTS_48_FRAMES_FROZEN_R106A_NATIVE_PASS',flush=True)
