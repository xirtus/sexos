from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');F=T/'sexos-eight-e-frozen';R=F/'source';P=T/'sexos-eight-e-sustained-progress.json';assert not P.exists();rows=[];active=[]
for label,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 if active:time.sleep(120)
 out=T/('sexos-eight-e-sustained-'+label);driver=T/(out.name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(R/'scripts/quil_workflow_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',res,'--soak-seconds','1800','--third-quil','--capture-profile','--find','--round','137']
 f=driver.open('x');p=subprocess.Popen(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});row=dict(profile=label,command=command,out=str(out),driver=str(driver),status='running',pid=p.pid,started_monotonic=time.monotonic());rows.append(row);active.append((p,f,row));P.write_text(json.dumps(rows,indent=2)+'\n');print('START',label,p.pid,flush=True)
failed=False
for p,f,row in active:
 status=p.wait();f.close();row.update(status=status,elapsed_seconds=time.monotonic()-row['started_monotonic']);P.write_text(json.dumps(rows,indent=2)+'\n');print('END',row['profile'],status,flush=True)
 if status:failed=True;continue
 target=T/('sexos-eight-e-sustained-'+row['profile']+'-independent-replay.json');assert not target.exists()
 with target.open('x')as output:r=subprocess.run(row['command']+['--check'],cwd=R,stdout=output,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert r.returncode==0;v=json.loads(target.read_text());assert v['ok']and v['acceptance'];row.update(fresh_replay=True,verified_captures=v['verified_captures']);P.write_text(json.dumps(rows,indent=2)+'\n')
if failed:raise SystemExit(1)
print('TWO_EXPANDED_IMAGE_1800S_ACCEPTANCE_SESSIONS_PASS',flush=True)
