from pathlib import Path
import json,os,subprocess,time,gzip,sys
T=Path('/tmp');F=T/'sexos-startup-a-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'));from history_roster_evidence import verify_boot_roster;from spindle_durable_reboot_gate import snapshot;rows=[];progress=T/'sexos-startup-a-alpha-progress.json';assert not progress.exists()
for label,model,resolution in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 out=T/('sexos-startup-a-alpha-'+label);driver=T/(out.name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(R/'scripts/quil_workflow_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(out),'--model',model,'--resolution',resolution,'--soak-seconds','20','--rehearsal','--third-quil','--capture-profile','--find','--round','142']
 row=dict(profile=label,command=command,out=str(out),driver=str(driver),status='running');rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');print('START',label,flush=True);start=time.monotonic()
 with driver.open('x')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=p.returncode,seconds=time.monotonic()-start);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 r=json.loads((out/'result.json').read_text());assert r['ok']and not r['acceptance']and r['find']['replace']['undone']
 for step in r['soak']['third_quil']['chain']:
  assert step['frame']['proof']['native_family']==dict(focus=step['surface'],app='Quil',indicator='0xcba6f7')
 replay=T/(out.name+'-independent-replay.json')
 with replay.open('x')as f:p=subprocess.run(command[:command.index('--soak-seconds')]+['--check'],cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert p.returncode==0
 v=json.loads(replay.read_text());assert v['ok']and not v['acceptance'];row['verified_captures']=v['verified_captures'];row['fresh_replay']=True;row['history_roster']=verify_boot_roster(R,(out/'serial.log').read_text(errors='replace'));row['terminal_history']=snapshot(gzip.decompress((out/'nvme.img.gz').read_bytes()),row['history_roster']);assert(row['terminal_history']['source'],row['terminal_history']['task'])==(17,17);progress.write_text(json.dumps(rows,indent=2)+'\n')
print('TWO_ALPHA_FIND_REHEARSALS_PASS',flush=True)
