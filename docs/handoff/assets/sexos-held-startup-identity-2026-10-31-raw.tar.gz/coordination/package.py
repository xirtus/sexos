from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-startup-b-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-startup-b-source-audit.json');boot=read(T/'sexos-startup-b-boot-audit.json');h=read(T/'sexos-startup-b-host/report.json');scalar=read(T/'sexos-startup-b-scalar-v3/result.json');rows=read(T/'sexos-startup-b-alpha-progress.json')
assert audit['ok']and boot['ok']and boot['boots']==3
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2716
assert 'Ran 989 tests in 'in(T/'sexos-startup-b-python.log').read_text()
assert len(rows)==2 and all(row['status']==0 and row['fresh_replay']and row['terminal_history']['source']==17 for row in rows)
captures=sum(row['verified_captures']for row in rows);assert captures>=48
assert scalar['ok']and len(scalar['results'])==8 and sum(r['instructions']for r in scalar['results'])==290390 and all(not r['vector_or_fp_matches']for r in scalar['results'])
status=[]
for row in rows:
 p=Path(row['out']);text=(p/'serial.log').read_text(errors='replace');accepted=sorted(set(map(int,re.findall(r'\[shell.spindle.status.accepted\] target=(\d+)',text))));assert accepted==[12,17];status.append(dict(profile=row['profile'],accepted_spindle_subjects=accepted,registry_captures=row['verified_captures']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('qualified/frozen',F),('qualified/sealed-build',T/'sexos-startup-b-build'),('qualified/host',T/'sexos-startup-b-host'),('qualified/scalar',T/'sexos-startup-b-scalar-v3')]:tree(prefix,root)
for row in rows:tree('qualified/native/'+row['profile'],Path(row['out']))
for name in ['sexos-r142-app-startup-identity','sexos-r142-spindle-status-host','sexos-r142-linen-observer-host','sexos-r142-shell-spindle-status']:tree('host-controls/'+name,T/name)
for name in ['sexos-startup-a-frozen','sexos-startup-a-build','sexos-startup-a-host','sexos-startup-a-alpha-compact','sexos-startup-a-alpha-wide']:tree('superseded/'+name,T/name)
for p in sorted(T.glob('sexos-startup-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-held-startup-identity-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=142,qualified_held_startup_task_policy=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='e8327af3',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust,python_tests=989,host_behavior=dict(actual_startup_functions=2,startup_tests=6,startup_compiled_mutants=4,status_sdk_tests=7,status_sdk_mutants=2,linen_tests=5,linen_mutants=2,shell_receiver_tests=8,shell_mutants=4,independent_domain_task_metadata=True),native=dict(sealed_probe_boots=1,workflow_boots=2,total_boots=3,registry_verified_captures=captures,all_fresh_parent_replays=True,groups=rows,spindle_status_observations=status,boot_roster_layout_audit=boot,current_boot_task_ids_coincide_with_domain_ids=True,native_unequal_allocator=False,new_image_1800s_acceptance=False),scalar=dict(elfs=8,instructions=290390,inspected_vector_fp_matches=0,scope=scalar.get('scope')),superseded=dict(source='5e11ae61',scope='A passed initial startup/status checks but review found downstream Linen/Shell task inference. B fixes complete path before publication; original source/positive runs retained, not claimed as final.'),limitations=dict(per_request_file_deferred_task_authentication=False,browser_task_namespace_migrated=False,third_spindle_reserved=False,native_unequal_allocator=False),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Quil/Spindle startup select metadata only after successful heldSELF query, preserve exact nonzero task, family/surface/coordinator checks. SDK status supports heldindependenttuples; Linen checksactualheldsubject/LIVE; Shell bindsReceiverfromexactheldcustody aftercatalog/LIVE+authenticatedfreshIPCcaller_task, never domainassynthesis. Actualcompiledhelpers/receivers tested againstunequalPDtasks; currentnativeIDscoincide andfullappchains/status pass. No runtime capabilitymint/processVAS/POSIX, generaldeferredtaskauth, nativeunequalallocator, thirdSpindle/new1800s/physicalSMP/hostilecontainment/globalepoch or daily-driver acceptance claim.')
p=A/'sexos-held-startup-identity-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('STARTUP_IDENTITY_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','captures',captures,flush=True)
