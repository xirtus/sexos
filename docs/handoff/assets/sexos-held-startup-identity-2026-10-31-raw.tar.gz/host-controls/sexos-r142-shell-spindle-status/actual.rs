unsafe fn spindle_history_status_receive(msg:&sex_pdx::PdxMessage)->bool{
 if msg.type_id!=sex_pdx::spindle_status::OP{return false}
 let Some(index)=app_catalog::SPINDLE_TARGETS.iter().position(|target|*target==msg.caller_pd)else{return true};
 let Some(e)=APP_CUSTODY.iter().flatten().find(|e|e.target==msg.caller_pd)else{return true};
 if e.dead||e.retired||e.close_pending{
  if let Some(receiver)=SPINDLE_HISTORY_STATUS[index].as_mut(){receiver.retire();}
  return true;
 }
 let live=matches!(sex_pdx::app_lifecycle::catalog(e.slot),Ok(c) if (c.target_pd,c.task_id,c.surface_id,c.coordinator_pd)==(e.target,e.task,e.surface,3))
    &&sex_pdx::app_lifecycle::info(e.slot)==Err(sex_pdx::app_lifecycle::LIVE);
 if !live||msg.caller_task!=e.task{return true}
 // Bind once from held custody, never a caller-selected packed task or domain.
 let receiver=SPINDLE_HISTORY_STATUS[index].get_or_insert_with(||sex_pdx::spindle_status::Receiver::new(e.target,e.task));
 if receiver.accept(msg.caller_pd,live,[msg.arg0,msg.arg1,msg.arg2]){
  sex_pdx::serial_record!("[shell.spindle.status.accepted] target={} sequence={} state={} live=1",msg.caller_pd,msg.arg1,msg.arg2);
  if COMMAND_PALETTE_OPEN{palette_render_list();}
 }true
}
