fn linen_request_allowed(caller:u32,opcode:u64)->bool {
    let grant=sex_pdx::app_catalog::by_target(caller).filter(|i|i.app==sex_pdx::app_catalog::App::Spindle).map(|i|(i.lifecycle_slot,i.target,i.surface));
    let status=grant.and_then(|(slot,target,surface)|{
        match sex_pdx::app_lifecycle::catalog(slot) {
            Ok(c) if c.target_pd==target && c.task_id==target && c.surface_id==surface && c.coordinator_pd==3=>{
                match sex_pdx::app_lifecycle::info(slot){Err(code)=>Some(code),Ok(_)=>Some(0)}
            },_=>None,
        }
    });
    let allowed=reply_delivery::admit(caller,opcode,status);
    if let Some(i)=sex_pdx::app_catalog::by_target(caller).filter(|i|i.app==sex_pdx::app_catalog::App::Spindle&&i.ordinal!=0){sex_pdx::serial_record!("[linen.spindle.authority] target={} slot={} op={} status={} allowed={}",caller,i.lifecycle_slot,opcode,status.unwrap_or(u64::MAX),allowed as u8);}
    allowed
}