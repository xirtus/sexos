mod quil {
fn startup_incarnation(catalog:sex_pdx::app_lifecycle::CatalogInfo)->Option<&'static sex_pdx::app_catalog::Incarnation>{
    let row=sex_pdx::app_catalog::by_surface(catalog.target_pd,catalog.surface_id)?;
    if row.app!=sex_pdx::app_catalog::App::Quil{return None;}
    Some(row)
}
pub fn resolve(catalog:sex_pdx::app_lifecycle::CatalogInfo)->Option<&'static sex_pdx::app_catalog::Incarnation>{startup_incarnation(catalog)}
}

mod spindle {
fn startup_incarnation(catalog:sex_pdx::app_lifecycle::CatalogInfo)->Option<&'static sex_pdx::app_catalog::Incarnation>{
    let row=sex_pdx::app_catalog::by_surface(catalog.target_pd,catalog.surface_id)?;
    if row.app!=sex_pdx::app_catalog::App::Spindle{return None;}
    Some(row)
}
pub fn resolve(catalog:sex_pdx::app_lifecycle::CatalogInfo)->Option<&'static sex_pdx::app_catalog::Incarnation>{startup_incarnation(catalog)}
}
