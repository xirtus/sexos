"""Archive final round102 evidence only after independent raw replay."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
from PIL import Image
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');F=T/'sexos-alpha-r102-launcher-e-frozen';B=T/'sexos-alpha-r102-launcher-d-build';A=R/'docs/handoff/assets';stem='sexos-alpha-r102-2026-10-30'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding=load(F/'source-binding.json');progress=load(T/'sexos-r102-e-native-suite-progress.json');replay=load(T/'sexos-r102-e-root-independent-replay.json');equiv=load(T/'sexos-r102-e-d-equivalence.json')
assert replay['ok'] and replay['complete'] and (replay['native_runs'],replay['native_boots'],replay['frames'])==(3,4,69)
assert replay['source_binding_sha256']==sha(F/'source-binding.json')
assert len(progress)==3 and all(type(r['status'])is int and r['status']==0 for r in progress)
assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for name,digest in {**binding['sources'],**binding['runner_sha256']}.items():assert sha(F/'source'/name)==digest and sha(R/name)==digest,name
assert load(B/'provenance.json')['iso_sha256']==binding['iso_sha256']==sha(F/'tested.iso')
assert '| **FINAL_SCORE** | **GREEN_MASTER** |'in(B/'report.md').read_text()
assert equiv['production_identical']and equiv['rust_shell_inputs_identical']
logs=[]
for label,expected,marker in [('service-custody',1734,'[service.custody.host.gate] PASS'),('display',46,'[gate.display_surface_groups.result] PASS'),('launcher',35,None)]:
 p=T/f'sexos-r102-d-frozen-{label}.log';text=p.read_text();assert marker is None or marker in text
 count=sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',text,re.M)));assert count==expected,(label,count)
 logs.append(dict(name=label,path=str(p),executions=count,sha256=sha(p),scope='Completed D frozen Rust checks reused by exact D/E production and Rust/shell input equivalence; launcher35 is separate from service-custody.'))
p=T/'sexos-r102-e-frozen-python.log';text=p.read_text();assert re.search(r'^OK$',text,re.M);python_count=int(re.search(r'Ran (\d+) tests',text)[1]);assert python_count==730,python_count
scalar=load(T/'sexos-r102-d-browser-binary-equivalence.json');assert scalar['ok']and scalar['iso_sha256']==binding['iso_sha256']
members={}
def add(path,name):
 path=Path(path);assert path.is_file()and not path.is_symlink(),path
 assert name not in members and not name.startswith('/')and '..'not in Path(name).parts;members[name]=path
add(F/'source-binding.json','source-binding.json')
for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):add(F/'source'/name,'source/'+name)
for name in('tested.iso','tested.kernel'):add(F/name,name)
for p in sorted(B.iterdir()):
 if p.is_file()and p.suffix!='.img':add(p,'build/'+p.name)
for row in progress:
 out=Path(row['out'])
 for p in sorted(out.rglob('*')):
  if p.is_file()and p.suffix!='.img':add(p,'native/'+row['name']+'/'+str(p.relative_to(out)))
 add(row['driver'],'checks/'+Path(row['driver']).name)
for pattern in('sexos-r102-e-*.json','sexos-r102-e-*.log','sexos-r102-e-*.py','sexos-r102-d-frozen-*.log','sexos-r102-d-browser-binary-equivalence.json','sexos-r102-d-tested-kaleidoscope.elf','sexos-r102-d-iso-extract.log'):
 for p in sorted(T.glob(pattern)):
  if 'package.log'in p.name:continue
  name='checks/'+p.name
  if name not in members:add(p,name)
for p in sorted(T.glob('sexos-r102-b-*diagnos*.json')):add(p,'diagnostics/'+p.name)
p=T/'sexos-r102-b-stale-launcher-negative-control.json';add(p,'diagnostics/'+p.name)
old=T/'sexos-alpha-r102-launcher-b-frozen';add(old/'source-binding.json','diagnostics/b/source-binding.json')
for name in('scripts/launcher_workflow_gate.py','scripts/tests/test_launcher_workflow_gate.py'):add(old/'source'/name,'diagnostics/b/source/'+name)
for run in('launcher-wide','launcher-compact'):
 out=T/('sexos-r102-b-native-'+run)
 if out.exists():
  for p in sorted(out.rglob('*')):
   if p.is_file()and p.suffix!='.img':add(p,'diagnostics/b/'+run+'/'+str(p.relative_to(out)))
out=T/'sexos-r102-c-native-launcher-wide'
for p in sorted(out.rglob('*')):
 if p.is_file()and p.suffix!='.img':add(p,'diagnostics/c/launcher-wide/'+str(p.relative_to(out)))
oldc=T/'sexos-alpha-r102-launcher-c-frozen';add(oldc/'source-binding.json','diagnostics/c/source-binding.json');add(oldc/'source/servers/silk-shell/src/main.rs','diagnostics/c/silk-shell-main.rs')
out=T/'sexos-r102-d-native-clipboard-wide'
for p in sorted(out.rglob('*')):
 if p.is_file()and p.suffix!='.img':add(p,'diagnostics/d/clipboard-wide/'+str(p.relative_to(out)))
oldd=T/'sexos-alpha-r102-launcher-d-frozen';add(oldd/'source-binding.json','diagnostics/d/source-binding.json')
for name in('scripts/http_content_gate.py','scripts/tests/test_http_reader_pixels.py'):add(oldd/'source'/name,'diagnostics/d/source/'+name)
seed=T/'sexos-r100a-seed.img';z=T/'sexos-r102-e-seed.img.gz';assert not z.exists();z.write_bytes(gzip.compress(seed.read_bytes(),mtime=0));add(z,'seed.img.gz')
screens=[]
for run,filename,label in [('launcher-wide','boot-clean.ppm','boot-wide'),('launcher-wide','spindle-17-brought.ppm','brought-wide'),('launcher-compact','quil-9-brought.ppm','quil-compact'),('launcher-compact','launcher-exhausted.ppm','reserve-compact')]:
 out=Path(next(r['out']for r in progress if r['name']==run));frames=load(out/'frames.json');frame=next(f for f in frames if f['screenshot']==filename)
 assert frame['screenshot_sha256']==sha(out/filename)
 dest=A/f'{stem}-{label}.png';assert not dest.exists();Image.open(out/filename).save(dest)
 screens.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=run,raw_ppm=filename,raw_sha256=sha(out/filename),serial_bytes=frame['serial_bytes'],serial_sha256=frame['serial_sha256']))
archive=A/f'{stem}-qualified-raw.tar.gz';assert not archive.exists()
inventory=[dict(name=n,bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(members.items())]
with tarfile.open(archive,'w:gz')as tar:
 for row in inventory:
  path=members[row['name']];assert sha(path)==row['sha256'];tar.add(path,arcname=row['name'],recursive=False)
 data=(json.dumps(dict(scope='Final E acceptance and separately labeled B failed/insufficient diagnostic evidence; diagnostics add no acceptance.',members=inventory),indent=2)+'\n').encode();info=tarfile.TarInfo('archive-inventory.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 actual=tar.getmembers();assert len(actual)==len(inventory)+1 and all(p.isfile()for p in actual)
 for row in inventory:
  data=tar.extractfile(row['name']).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
e=dict(round=102,accepted=True,accepted_goal_rounds=23,total_goal_rounds=121,remaining_goal_rounds=98,iso_sha256=binding['iso_sha256'],kernel_sha256=binding['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),architecture_sha256=binding['architecture_sha256'],production_inputs=len(binding['sources']),runner_inputs=len(binding['runner_sha256']),checks=dict(master='BUILD PASS / GREEN_MASTER',rust=logs,rust_test_executions=sum(r['executions']for r in logs),rust_reuse_equivalence=equiv,python_tests=python_count,python_log_sha256=sha(T/'sexos-r102-e-frozen-python.log'),native_runs=3,native_boots=4,independent_frames=69,root_replay_sha256=sha(T/'sexos-r102-e-root-independent-replay.json'),browser_binary_equivalence=scalar),qualification_runs=progress,remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=screens,archive=dict(path=str(archive.relative_to(R/'docs/handoff')),sha256=sha(archive),members=len(inventory)+1,verified=True,bytes=archive.stat().st_size),failed_diagnostics='B wide passed old app glyph checks but admitted screenshots with the old launcher overlay; B compact failed due to pointer occlusion. Both remain diagnostic only. Final E parks the pointer using actual movement receipts and requires distributed source-bound launcher ink erasure. Actual stale B images fail the new oracle. Candidate C failed on a fragmented legacy workspace-switch receipt; final sealed D emits it as one bounded record. The D clipboard regression then exposed an intact atomic Browser receipt following a foreign unfinished log fragment; E corrects the parser without reassembling fields and reruns the complete native cohort on the unchanged image.',limitations=['Native launcher proof covers Quil9, Spindle12 and BOOT-reserved17; successor Quil16/18 paths are actual-helper host checks only.','Queue pressure, hard denial, stale subject and bounded cancellation are host checks; no native hostile/backpressure certification.','The launcher erasure oracle is a controlled text-ink check across old menu lines with explicit same-color Linen overlap; no general whole-desktop absence or presentation acknowledgment claim.','Clipboard Save/cold recovery regression is wide-profile only on this image; no new sustained, public web/general CA, crash/power-loss, physical, SMP, hostile-containment or System Proven claim.'],scope='One substantive round: exact live-incarnation launcher/workspace actions and hidden pre-parent Spindle panes, qualified on one sealed image with two launcher profiles and affected clipboard recovery regression. GLOBAL_VAS, BOOT-only genesis and typed sex-pdx authority preserved; not Unix/POSIX.')
(A/f'{stem}-evidence.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(dict(ok=True,round=102,rust=e['checks']['rust_test_executions'],python=python_count,archive=e['archive'])))
