use crate::config::{TlsCipherSuite, TlsConfig};
use crate::handshake::{ClientHandshake, ServerHandshake};
use crate::key_schedule::{KeySchedule, ReadKeySchedule, WriteKeySchedule};
use crate::record::{ClientRecord, ServerRecord};
use crate::record_reader::RecordReader;
use crate::write_buffer::WriteBuffer;
use crate::{CertificateVerify, CryptoProvider, TlsError, TlsVerifier};
use crate::{
    alert::{Alert, AlertDescription, AlertLevel},
    handshake::{certificate::CertificateRef, certificate_request::CertificateRequest},
};
use core::fmt::Debug;
use digest::Digest;
use embedded_io::Error as _;
use embedded_io::{Read as BlockingRead, Write as BlockingWrite};
use embedded_io_async::{Read as AsyncRead, Write as AsyncWrite};

use crate::application_data::ApplicationData;
use crate::buffer::CryptoBuffer;
use digest::generic_array::typenum::Unsigned;
use p256::ecdh::EphemeralSecret;
use signature::SignerMut;

use crate::content_types::ContentType;
use crate::parse_buffer::ParseBuffer;
use aes_gcm::aead::{AeadCore, AeadInPlace, KeyInit};

pub(crate) fn decrypt_record<CipherSuite>(
    key_schedule: &mut ReadKeySchedule<CipherSuite>,
    record: ServerRecord<'_, CipherSuite>,
    mut cb: impl FnMut(
        &mut ReadKeySchedule<CipherSuite>,
        ServerRecord<'_, CipherSuite>,
    ) -> Result<(), TlsError>,
) -> Result<(), TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    if let ServerRecord::ApplicationData(ApplicationData {
        header,
        data: mut app_data,
    }) = record
    {
        let server_key = key_schedule.get_key()?;
        let nonce = key_schedule.get_nonce()?;

        let crypto = <CipherSuite::Cipher as KeyInit>::new(server_key);
        crypto
            .decrypt_in_place(&nonce, header.data(), &mut app_data)
            .map_err(|_| TlsError::CryptoError)?;

        // SexOS: an unauthenticated server can already encrypt with handshake
        // keys. Empty/all-padding TLSInnerPlaintext has no content type and must
        // fail as a record error, never unwind/abort the owning application.
        let content_end = app_data
            .as_slice()
            .iter()
            .rposition(|byte| *byte != 0)
            .ok_or(TlsError::InvalidRecord)?;
        app_data.truncate(content_end + 1);

        let content_type = ContentType::of(
            app_data.as_slice().last().copied().ok_or(TlsError::InvalidRecord)?,
        ).ok_or(TlsError::InvalidRecord)?;

        trace!("Decrypting: content type = {:?}", content_type);

        // Remove the content type
        app_data.truncate(app_data.len() - 1);

        let mut buf = ParseBuffer::new(app_data.as_slice());
        match content_type {
            ContentType::Handshake => {
                // Decode potentially coalesced handshake messages
                while buf.remaining() > 0 {
                    let inner = ServerHandshake::read(&mut buf, key_schedule.transcript_hash())?;
                    cb(key_schedule, ServerRecord::Handshake(inner))?;
                }
            }
            ContentType::ApplicationData => {
                let inner = ApplicationData::new(app_data, header);
                cb(key_schedule, ServerRecord::ApplicationData(inner))?;
            }
            ContentType::Alert => {
                let alert = Alert::parse(&mut buf)?;
                cb(key_schedule, ServerRecord::Alert(alert))?;
            }
            _ => return Err(TlsError::Unimplemented),
        }
        key_schedule.increment_counter();
    } else {
        trace!("Not decrypting: content_type = {:?}", record.content_type());
        cb(key_schedule, record)?;
    }
    Ok(())
}

pub(crate) fn encrypt<CipherSuite>(
    key_schedule: &WriteKeySchedule<CipherSuite>,
    buf: &mut CryptoBuffer<'_>,
) -> Result<(), TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    let client_key = key_schedule.get_key()?;
    let nonce = key_schedule.get_nonce()?;
    // trace!("encrypt key {:02x?}", client_key);
    // trace!("encrypt nonce {:02x?}", nonce);
    // trace!("plaintext {} {:02x?}", buf.len(), buf.as_slice(),);
    //let crypto = Aes128Gcm::new_varkey(&self.key_schedule.get_client_key()).unwrap();
    let crypto = <CipherSuite::Cipher as KeyInit>::new(client_key);
    let len = buf.len() + <CipherSuite::Cipher as AeadCore>::TagSize::to_usize();

    if len > buf.capacity() {
        return Err(TlsError::InsufficientSpace);
    }

    trace!("output size {}", len);
    let len_bytes = (len as u16).to_be_bytes();
    let additional_data = [
        ContentType::ApplicationData as u8,
        0x03,
        0x03,
        len_bytes[0],
        len_bytes[1],
    ];

    crypto
        .encrypt_in_place(&nonce, &additional_data, buf)
        .map_err(|_| TlsError::InvalidApplicationData)
}

pub struct Handshake<CipherSuite>
where
    CipherSuite: TlsCipherSuite,
{
    traffic_hash: Option<CipherSuite::Hash>,
    secret: Option<EphemeralSecret>,
    certificate_request: Option<CertificateRequest>,
}

impl<CipherSuite> Handshake<CipherSuite>
where
    CipherSuite: TlsCipherSuite,
{
    pub fn new() -> Handshake<CipherSuite> {
        Handshake {
            traffic_hash: None,
            secret: None,
            certificate_request: None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
#[cfg_attr(feature = "defmt", derive(defmt::Format))]
pub enum State {
    ClientHello,
    ServerHello,
    ServerVerify,
    ClientCert,
    ClientCertVerify,
    ClientFinished,
    ApplicationData,
}

impl<'a> State {
    #[allow(clippy::too_many_arguments)]
    pub async fn process<'v, Transport, Provider>(
        self,
        transport: &mut Transport,
        handshake: &mut Handshake<Provider::CipherSuite>,
        record_reader: &mut RecordReader<'_>,
        tx_buf: &mut WriteBuffer<'_>,
        key_schedule: &mut KeySchedule<Provider::CipherSuite>,
        config: &TlsConfig<'a>,
        crypto_provider: &mut Provider,
    ) -> Result<State, TlsError>
    where
        Transport: AsyncRead + AsyncWrite + 'a,
        Provider: CryptoProvider,
    {
        match self {
            State::ClientHello => {
                let (state, tx) =
                    client_hello(key_schedule, config, crypto_provider, tx_buf, handshake)?;

                respond(tx, transport, key_schedule).await?;

                Ok(state)
            }
            State::ServerHello => {
                let record = record_reader
                    .read(transport, key_schedule.read_state())
                    .await?;

                let result = process_server_hello(handshake, key_schedule, record);

                handle_processing_error(result, transport, key_schedule, tx_buf).await
            }
            State::ServerVerify => {
                let record = record_reader
                    .read(transport, key_schedule.read_state())
                    .await?;

                let result =
                    process_server_verify(handshake, key_schedule, crypto_provider, record);

                handle_processing_error(result, transport, key_schedule, tx_buf).await
            }
            State::ClientCert => {
                let (state, tx) = client_cert(handshake, key_schedule, crypto_provider, tx_buf)?;

                respond(tx, transport, key_schedule).await?;

                Ok(state)
            }
            State::ClientCertVerify => {
                let (result, tx) = client_cert_verify(key_schedule, crypto_provider, tx_buf)?;

                respond(tx, transport, key_schedule).await?;

                result
            }
            State::ClientFinished => {
                let tx = client_finished(key_schedule, tx_buf)?;

                respond(tx, transport, key_schedule).await?;

                client_finished_finalize(key_schedule, handshake)
            }
            State::ApplicationData => Ok(State::ApplicationData),
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub fn process_blocking<'v, Transport, Provider>(
        self,
        transport: &mut Transport,
        handshake: &mut Handshake<Provider::CipherSuite>,
        record_reader: &mut RecordReader<'_>,
        tx_buf: &mut WriteBuffer,
        key_schedule: &mut KeySchedule<Provider::CipherSuite>,
        config: &TlsConfig<'a>,
        crypto_provider: &mut Provider,
    ) -> Result<State, TlsError>
    where
        Transport: BlockingRead + BlockingWrite + 'a,
        Provider: CryptoProvider,
    {
        match self {
            State::ClientHello => {
                let (state, tx) =
                    client_hello(key_schedule, config, crypto_provider, tx_buf, handshake)?;

                respond_blocking(tx, transport, key_schedule)?;

                Ok(state)
            }
            State::ServerHello => {
                let record = record_reader.read_blocking(transport, key_schedule.read_state())?;

                let result = process_server_hello(handshake, key_schedule, record);

                handle_processing_error_blocking(result, transport, key_schedule, tx_buf)
            }
            State::ServerVerify => {
                let record = record_reader.read_blocking(transport, key_schedule.read_state())?;

                let result =
                    process_server_verify(handshake, key_schedule, crypto_provider, record);

                handle_processing_error_blocking(result, transport, key_schedule, tx_buf)
            }
            State::ClientCert => {
                let (state, tx) = client_cert(handshake, key_schedule, crypto_provider, tx_buf)?;

                respond_blocking(tx, transport, key_schedule)?;

                Ok(state)
            }
            State::ClientCertVerify => {
                let (result, tx) = client_cert_verify(key_schedule, crypto_provider, tx_buf)?;

                respond_blocking(tx, transport, key_schedule)?;

                result
            }
            State::ClientFinished => {
                let tx = client_finished(key_schedule, tx_buf)?;

                respond_blocking(tx, transport, key_schedule)?;

                client_finished_finalize(key_schedule, handshake)
            }
            State::ApplicationData => Ok(State::ApplicationData),
        }
    }
}

fn handle_processing_error_blocking<CipherSuite>(
    result: Result<State, TlsError>,
    transport: &mut impl BlockingWrite,
    key_schedule: &mut KeySchedule<CipherSuite>,
    tx_buf: &mut WriteBuffer,
) -> Result<State, TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    if let Err(TlsError::AbortHandshake(level, description)) = result {
        let (write_key_schedule, read_key_schedule) = key_schedule.as_split();
        let tx = tx_buf.write_record(
            &ClientRecord::Alert(Alert { level, description }, false),
            write_key_schedule,
            Some(read_key_schedule),
        )?;

        respond_blocking(tx, transport, key_schedule)?;
    }

    result
}

fn respond_blocking<CipherSuite>(
    tx: &[u8],
    transport: &mut impl BlockingWrite,
    key_schedule: &mut KeySchedule<CipherSuite>,
) -> Result<(), TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    transport
        .write_all(tx)
        .map_err(|e| TlsError::Io(e.kind()))?;

    key_schedule.write_state().increment_counter();

    transport.flush().map_err(|e| TlsError::Io(e.kind()))?;

    Ok(())
}

async fn handle_processing_error<CipherSuite>(
    result: Result<State, TlsError>,
    transport: &mut impl AsyncWrite,
    key_schedule: &mut KeySchedule<CipherSuite>,
    tx_buf: &mut WriteBuffer<'_>,
) -> Result<State, TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    if let Err(TlsError::AbortHandshake(level, description)) = result {
        let (write_key_schedule, read_key_schedule) = key_schedule.as_split();
        let tx = tx_buf.write_record(
            &ClientRecord::Alert(Alert { level, description }, false),
            write_key_schedule,
            Some(read_key_schedule),
        )?;

        respond(tx, transport, key_schedule).await?;
    }

    result
}

async fn respond<CipherSuite>(
    tx: &[u8],
    transport: &mut impl AsyncWrite,
    key_schedule: &mut KeySchedule<CipherSuite>,
) -> Result<(), TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    transport
        .write_all(tx)
        .await
        .map_err(|e| TlsError::Io(e.kind()))?;

    key_schedule.write_state().increment_counter();

    transport
        .flush()
        .await
        .map_err(|e| TlsError::Io(e.kind()))?;

    Ok(())
}

fn client_hello<'r, Provider>(
    key_schedule: &mut KeySchedule<Provider::CipherSuite>,
    config: &TlsConfig,
    crypto_provider: &mut Provider,
    tx_buf: &'r mut WriteBuffer,
    handshake: &mut Handshake<Provider::CipherSuite>,
) -> Result<(State, &'r [u8]), TlsError>
where
    Provider: CryptoProvider,
{
    key_schedule.initialize_early_secret(config.psk.as_ref().map(|p| p.0))?;
    let (write_key_schedule, read_key_schedule) = key_schedule.as_split();
    let client_hello = ClientRecord::client_hello(config, crypto_provider);
    let slice = tx_buf.write_record(&client_hello, write_key_schedule, Some(read_key_schedule))?;

    if let ClientRecord::Handshake(ClientHandshake::ClientHello(client_hello), _) = client_hello {
        handshake.secret.replace(client_hello.secret);
        Ok((State::ServerHello, slice))
    } else {
        Err(TlsError::EncodeError)
    }
}

fn process_server_hello<CipherSuite>(
    handshake: &mut Handshake<CipherSuite>,
    key_schedule: &mut KeySchedule<CipherSuite>,
    record: ServerRecord<'_, CipherSuite>,
) -> Result<State, TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    match record {
        ServerRecord::Handshake(server_handshake) => match server_handshake {
            ServerHandshake::ServerHello(server_hello) => {
                trace!("********* ServerHello");
                let secret = handshake.secret.take().ok_or(TlsError::InvalidHandshake)?;
                let shared = server_hello
                    .calculate_shared_secret(&secret)
                    .ok_or(TlsError::InvalidKeyShare)?;
                key_schedule.initialize_handshake_secret(shared.raw_secret_bytes())?;
                Ok(State::ServerVerify)
            }
            _ => Err(TlsError::InvalidHandshake),
        },
        ServerRecord::Alert(alert) => {
            Err(TlsError::HandshakeAborted(alert.level, alert.description))
        }
        _ => Err(TlsError::InvalidRecord),
    }
}

fn process_server_verify<Provider>(
    handshake: &mut Handshake<Provider::CipherSuite>,
    key_schedule: &mut KeySchedule<Provider::CipherSuite>,
    crypto_provider: &mut Provider,
    record: ServerRecord<'_, Provider::CipherSuite>,
) -> Result<State, TlsError>
where
    Provider: CryptoProvider,
{
    let mut state = State::ServerVerify;
    decrypt_record(key_schedule.read_state(), record, |key_schedule, record| {
        match record {
            ServerRecord::Handshake(server_handshake) => {
                match server_handshake {
                    ServerHandshake::EncryptedExtensions(_) => {}
                    ServerHandshake::Certificate(certificate) => {
                        let transcript = key_schedule.transcript_hash();
                        if let Ok(verifier) = crypto_provider.verifier() {
                            verifier.verify_certificate(transcript, certificate)?;
                            debug!("Certificate verified!");
                        } else {
                            debug!("Certificate verification skipped due to no verifier!");
                        }
                    }
                    ServerHandshake::CertificateVerify(verify) => {
                        if let Ok(verifier) = crypto_provider.verifier() {
                            verifier.verify_signature(verify)?;
                            debug!("Signature verified!");
                        } else {
                            debug!("Signature verification skipped due to no verifier!");
                        }
                    }
                    ServerHandshake::CertificateRequest(request) => {
                        handshake.certificate_request.replace(request.try_into()?);
                    }
                    ServerHandshake::Finished(finished) => {
                        if !key_schedule.verify_server_finished(&finished)? {
                            warn!("Server signature verification failed");
                            return Err(TlsError::InvalidSignature);
                        }

                        // trace!("server verified {}", verified);
                        state = if handshake.certificate_request.is_some() {
                            State::ClientCert
                        } else {
                            handshake
                                .traffic_hash
                                .replace(key_schedule.transcript_hash().clone());
                            State::ClientFinished
                        };
                    }
                    _ => return Err(TlsError::InvalidHandshake),
                }
            }
            ServerRecord::ChangeCipherSpec(_) => {}
            _ => return Err(TlsError::InvalidRecord),
        }

        Ok(())
    })?;
    Ok(state)
}

fn client_cert<'r, Provider>(
    handshake: &mut Handshake<Provider::CipherSuite>,
    key_schedule: &mut KeySchedule<Provider::CipherSuite>,
    crypto_provider: &mut Provider,
    buffer: &'r mut WriteBuffer,
) -> Result<(State, &'r [u8]), TlsError>
where
    Provider: CryptoProvider,
{
    handshake
        .traffic_hash
        .replace(key_schedule.transcript_hash().clone());

    let request_context = &handshake
        .certificate_request
        .as_ref()
        .ok_or(TlsError::InvalidHandshake)?
        .request_context;

    // Declare cert before certificate so owned data outlives the CertificateRef that borrows it
    let cert = crypto_provider.client_cert();
    let mut certificate = CertificateRef::with_context(request_context);
    let next_state = if let Some(ref cert) = cert {
        certificate.add(cert.into())?;
        State::ClientCertVerify
    } else {
        State::ClientFinished
    };
    let (write_key_schedule, read_key_schedule) = key_schedule.as_split();

    buffer
        .write_record(
            &ClientRecord::Handshake(ClientHandshake::ClientCert(certificate), true),
            write_key_schedule,
            Some(read_key_schedule),
        )
        .map(|slice| (next_state, slice))
}

fn client_cert_verify<'r, Provider>(
    key_schedule: &mut KeySchedule<Provider::CipherSuite>,
    crypto_provider: &mut Provider,
    buffer: &'r mut WriteBuffer,
) -> Result<(Result<State, TlsError>, &'r [u8]), TlsError>
where
    Provider: CryptoProvider,
{
    let (result, record) = match crypto_provider.signer() {
        Ok((mut signing_key, signature_scheme)) => {
            let ctx_str = b"TLS 1.3, client CertificateVerify\x00";

            // 64 (pad) + 34 (ctx) + 48 (SHA-384) = 146 bytes required
            let mut msg: heapless::Vec<u8, 146> = heapless::Vec::new();
            msg.resize(64, 0x20).map_err(|_| TlsError::EncodeError)?;
            msg.extend_from_slice(ctx_str)
                .map_err(|_| TlsError::EncodeError)?;
            msg.extend_from_slice(&key_schedule.transcript_hash().clone().finalize())
                .map_err(|_| TlsError::EncodeError)?;

            let signature = signing_key.sign(&msg);

            trace!(
                "Signature: {:?} ({})",
                signature.as_ref(),
                signature.as_ref().len()
            );

            let certificate_verify = CertificateVerify {
                signature_scheme,
                signature: heapless::Vec::from_slice(signature.as_ref()).unwrap(),
            };

            (
                Ok(State::ClientFinished),
                ClientRecord::Handshake(
                    ClientHandshake::ClientCertVerify(certificate_verify),
                    true,
                ),
            )
        }
        Err(e) => {
            error!("Failed to obtain signing key: {:?}", e);
            (
                Err(e),
                ClientRecord::Alert(
                    Alert::new(AlertLevel::Warning, AlertDescription::CloseNotify),
                    true,
                ),
            )
        }
    };

    let (write_key_schedule, read_key_schedule) = key_schedule.as_split();

    buffer
        .write_record(&record, write_key_schedule, Some(read_key_schedule))
        .map(|slice| (result, slice))
}

fn client_finished<'r, CipherSuite>(
    key_schedule: &mut KeySchedule<CipherSuite>,
    buffer: &'r mut WriteBuffer,
) -> Result<&'r [u8], TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    let client_finished = key_schedule
        .create_client_finished()
        .map_err(|_| TlsError::InvalidHandshake)?;

    let (write_key_schedule, read_key_schedule) = key_schedule.as_split();

    buffer.write_record(
        &ClientRecord::Handshake(ClientHandshake::Finished(client_finished), true),
        write_key_schedule,
        Some(read_key_schedule),
    )
}

fn client_finished_finalize<CipherSuite>(
    key_schedule: &mut KeySchedule<CipherSuite>,
    handshake: &mut Handshake<CipherSuite>,
) -> Result<State, TlsError>
where
    CipherSuite: TlsCipherSuite,
{
    key_schedule.replace_transcript_hash(
        handshake
            .traffic_hash
            .take()
            .ok_or(TlsError::InvalidHandshake)?,
    );
    key_schedule.initialize_master_secret()?;

    Ok(State::ApplicationData)
}

#[cfg(test)]
mod sexos_record_regressions {
    use super::*;
    use crate::{Aes128GcmSha256, record::RecordHeader};
    use aes_gcm::Aes128Gcm;
    use embedded_io::ErrorType;

    // Both sides use the actual freshly constructed read schedule's test key
    // and nonce. AEAD encryption is real; no decrypt mock or certificate bypass
    // is introduced into the production path by this harness.
    fn encrypted(plaintext: &[u8]) -> std::vec::Vec<u8> {
        let mut schedule = KeySchedule::<Aes128GcmSha256>::new();
        let key = schedule.read_state().get_key().unwrap().clone();
        let nonce = schedule.read_state().get_nonce().unwrap();
        let length = plaintext.len() + 16;
        let header = [23, 3, 3, (length >> 8) as u8, length as u8];
        let mut backing = [0u8; 128];
        let mut data = CryptoBuffer::wrap_with_pos(&mut backing, 0);
        data.extend_from_slice(plaintext).unwrap();
        Aes128Gcm::new(&key).encrypt_in_place(&nonce, &header, &mut data).unwrap();
        let mut wire = header.to_vec();
        wire.extend_from_slice(data.as_slice());
        wire
    }
    struct Input<'a>(&'a [u8]);
    impl ErrorType for Input<'_> {type Error = core::convert::Infallible;}
    impl BlockingRead for Input<'_> {
        fn read(&mut self, out: &mut [u8]) -> Result<usize, Self::Error> {
            let n = out.len().min(self.0.len()).min(3);
            out[..n].copy_from_slice(&self.0[..n]);
            self.0 = &self.0[n..];
            Ok(n)
        }
    }
    fn decode(wire: &[u8]) -> (Result<(), TlsError>, usize) {
        let mut input = Input(wire);
        let mut backing = [0u8; 128];
        let mut reader = RecordReader::new(&mut backing);
        let mut schedule = KeySchedule::<Aes128GcmSha256>::new();
        let mut calls = 0;
        let result = reader.read_blocking(&mut input, schedule.read_state()).and_then(|record| {
            decrypt_record(schedule.read_state(), record, |_, _| {calls += 1; Ok(())})
        });
        (result, calls)
    }
    #[test]
    fn authenticated_empty_inner_plaintext_is_a_record_error_not_a_panic() {
        let (result, calls) = decode(&encrypted(&[]));
        assert!(matches!(result, Err(TlsError::InvalidRecord)));
        assert_eq!(calls, 0);
    }
    #[test]
    fn authenticated_all_zero_padding_has_no_content_type() {
        for length in [1, 16, 64] {
            let (result, calls) = decode(&encrypted(&[0u8; 64][..length]));
            assert!(matches!(result, Err(TlsError::InvalidRecord)));
            assert_eq!(calls, 0);
        }
    }
    #[test]
    fn actual_encrypted_application_record_accepts_zero_payload_and_padding() {
        // TLS permits empty ApplicationData. Its nonzero inner content type is
        // distinct from an absent type, including after stripping zero padding.
        for plaintext in [&[23u8][..], &[23, 0, 0][..], &[7, 8, 23, 0][..]] {
            let (result, calls) = decode(&encrypted(plaintext));
            assert!(result.is_ok());
            assert_eq!(calls, 1);
        }
    }
    #[test]
    fn actual_record_reader_rejects_each_truncated_header_ciphertext_and_tag() {
        let wire = encrypted(&[23, 0, 0]);
        for end in 0..wire.len() {
            let (result, calls) = decode(&wire[..end]);
            assert!(matches!(result, Err(TlsError::IoError)), "prefix {end}");
            assert_eq!(calls, 0);
        }
    }
    #[test]
    fn ciphertext_corruption_and_missing_aead_tag_never_reach_callback() {
        let mut wire = encrypted(&[23]);
        let last = wire.len() - 1;
        wire[last] ^= 1;
        assert!(matches!(decode(&wire), (Err(TlsError::CryptoError), 0)));
        // A complete record with a short encrypted body reaches AEAD's actual
        // tag-length check, rather than only the transport's EOF check.
        for length in 0..16 {
            let mut short = [0u8; 21];
            short[..5].copy_from_slice(RecordHeader::decode([23, 3, 3, 0, length]).unwrap().data());
            assert!(matches!(decode(&short[..5 + length as usize]), (Err(TlsError::CryptoError), 0)));
        }
    }
}
