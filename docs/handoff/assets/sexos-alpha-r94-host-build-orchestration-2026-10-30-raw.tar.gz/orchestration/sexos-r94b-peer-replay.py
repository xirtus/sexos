from pathlib import Path
import hashlib,json,re,sys
frozen=Path('/tmp/sexos-alpha-r94b-frozen').resolve();root=frozen/'source';sys.path.insert(0,str(root/'scripts'))
import tls_exchange_gate as gate
from check_dns_capture import inspect as dns_check
from network_contention_gate import frozen_binding,cleanup_receipts
from check_nic_command import inspect as nic_check
from check_self_wait import inspect as wait_check
progress=json.loads(Path('/tmp/sexos-r94b-peer-suite-progress.json').read_text());bound=frozen_binding(root,frozen/'tested.iso',frozen/'source-binding.json');contract=gate.load_contract(root);rows=[]
for row in progress:
 if row['status']!=0:continue
 out=Path(row['out']);manifest=json.loads((out/'manifest.json').read_text());result=json.loads((out/'result.json').read_text());peer=json.loads((out/'peer-exchanges.json').read_text());raw=(out/'wire.pcap').read_bytes();trace=(out/'serial.log').read_text(errors='replace');mode=manifest['mode'];wire=gate.inspect_wire(raw,peer['tls'],mode);dns=dns_check(raw,'echo',attempts=peer['dns_send_attempts'],expected=peer['dns']);exchange=gate.inspect_exchange(trace,mode,wire,dns,raw,manifest['host_utc_start'],manifest['host_utc_end']);pixels=[]
 assert result['ok']and manifest['binding']==bound and gate.command_profile(manifest['command'])['ok']
 for capture in result['pixels']:
  path=out/capture['screenshot'];assert hashlib.sha256(path.read_bytes()).hexdigest()==capture['screenshot_sha256'];assert capture['source_sha256']==contract['source_sha256']==manifest['pixel_source_sha256'];check=None
  # Replay the actual earlier Applied frame for Pending screenshots. A later
  # Cancelled view must not rewrite the earlier DNS/status composition.
  for layout in reversed(list(re.finditer(r'\[browser.tls.peer.layout\] base=\d+ bytes=64 viewport=\d+ state='+capture['expected']+r' pixels=unconfirmed',trace))):
   following=re.search(r'\[browser.tls.peer.layout\] base=\d+ bytes=64 viewport=\d+ state=(?!'+capture['expected']+r'\b)\w+ pixels=unconfirmed',trace[layout.end():]);prefix=trace[:layout.end()+following.start()]if following else trace;check=gate.verify_peer_pixels(prefix,path.read_bytes(),capture['expected'],contract,tuple(map(int,manifest['resolution'].split('x'))))
   if check['ok']:break
  assert check and check['ok'],check;pixels.append(dict(screenshot=path.name,expected=capture['expected'],checked_pixels=check['checked_pixels']))
 authority=nic_check(trace,expected=1,preparation=True,ethernet=True,network_config=True,routing=True);waiting=wait_check(trace);cleanup=None
 if mode=='close':
  boundary=trace.index('[browser.tls.peer.closed]');cleanup=cleanup_receipts(trace,15,15,boundary);assert result['cleanup']==cleanup
 assert all(check['ok']for check in(wire,dns,exchange,authority,waiting)),(row['name'],wire,dns,exchange)
 rows.append(dict(name=row['name'],ok=True,out=str(out),mode=mode,authenticated=mode=='ready',wire=wire['joins'],exchange=exchange['joins'],pixels=pixels,cleanup=cleanup,authority=authority,self_wait=waiting,raw_sha256={name:hashlib.sha256((out/name).read_bytes()).hexdigest()for name in('wire.pcap','serial.log','manifest.json','peer-exchanges.json','result.json')}))
expected={(mode,profile)for mode in gate.MODES for profile in('wide','compact')};actual={(json.loads((Path(row['out'])/'manifest.json').read_text())['mode'],'compact'if row['name'].endswith('-compact')else'wide')for row in rows};complete=len(progress)==24 and len(rows)==24 and all(row['status']==0 for row in progress)and actual==expected
result=dict(ok=True,replayed=len(rows),runs=len(rows),complete24_terminal=complete,source_binding_sha256=bound['sha256'],binding=bound,rows=rows,scope='Fresh independent process rereads frozen checker/source, exact image/binding, raw PCAP, endpoint observations, serial joins and actual screenshot pixels; does not add missing native workflows or infer certificate rejection from transport EOF.')
Path('/tmp/sexos-r94b-peer-independent-replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'ok':True,'replayed':len(rows)}))
