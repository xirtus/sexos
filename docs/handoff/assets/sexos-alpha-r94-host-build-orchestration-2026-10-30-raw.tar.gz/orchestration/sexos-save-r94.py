"""Prepared round94 final94b single-cohort archive. PREPARED ONLY: execute only after root confirms final94b closure and binding.
No build, test suite, native workflow, staging or commit is launched here.
"""
from pathlib import Path
import hashlib,json,re,os,shutil,subprocess,tarfile
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Users/xmacbookm5/Projects/Sex');ASSETS=ROOT/'docs/handoff/assets';LOCAL=ROOT/'.evidence/alpha-2026-10-29/r94'
FROZEN=Path('/tmp/sexos-alpha-r94b-frozen');BUILD=Path('/tmp/sexos-alpha-r94-build');HOST=Path('/tmp/sexos-alpha-r94b-host')
PYTHON=Path('/tmp/sexos-r94b-python-final.log')
ISO='8850fc4fc76b8e32eec9a3bfa55f150dc15d66fa9223acd87509cc582a7a28c2'
BINDING_SHA='0c25fd8b340f391224cc7f7758f7c234647f147a7b281bcdaf6066c531dca92c'
KERNEL_SHA='caddc54087546cba97e70f107c1e416a5343e27a75c61655ab6d590913de4dcb'

def j(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as file:
  for part in iter(lambda:file.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def tree_files(path):
 path=Path(path);assert path.is_dir(),path
 for file in sorted(path.rglob('*')):
  # Compiler caches are unbound output, not evidence. Filter before checking
  # symlinks because Cargo caches contain symlinked dependency artifacts.
  if any(part in ('target','__pycache__')for part in file.relative_to(path).parts):continue
  assert not file.is_symlink(),file
  if file.is_file():yield file

def bound_snapshot():
 assert re.fullmatch(r'[0-9a-f]{64}',BINDING_SHA),'root-confirmed final94b binding required before archive'
 assert sha(FROZEN/'source-binding.json')==BINDING_SHA
 b=j(FROZEN/'source-binding.json');p=b['build_provenance']
 assert b['iso_sha256']==ISO==p['iso_sha256']==sha(FROZEN/'tested.iso')
 assert p['build_gate']=='PASS'and p['source_image_binding']=='sealed_build_this_run'and p['sources_unchanged_during_build']is True
 assert b['sources']==p['production_source_sha256']and len(b['sources'])==535 and len(b['runner_sha256'])==491
 assert sha(FROZEN/'tested.kernel')==b['kernel_sha256']==KERNEL_SHA
 for group in('sources','runner_sha256'):
  for name,digest in b[group].items():
   assert not any(part in ('target','__pycache__')for part in Path(name).parts),('boundcacheforbidden',group,name)
   assert sha(FROZEN/'source'/name)==digest,(group,name)
 build=(BUILD/'report.md').read_text();assert re.search(r'FINAL_SCORE[^\n]*GREEN_MASTER',build)and re.search(r'BUILD_GATE[^\n]*PASS',build)and 'probe_seconds: 25'in build
 assert j(BUILD/'provenance.json')['iso_sha256']==ISO
 assert j(BUILD/'provenance.json')['production_source_sha256']==b['sources'],'BuildA production must exactly equal final94b production'
 return b,build

def raw_archive(label,roots):
 name=f'sexos-alpha-r94-{label}-2026-10-30-raw.tar.gz';target=ASSETS/name;members=[]
 with tarfile.open(target,'w:gz',compresslevel=9)as archive:
  for arcroot,source in roots:
   source=Path(source)
   if source.is_dir():files=[(arcroot+'/'+str(file.relative_to(source)),file)for file in tree_files(source)]
   else:assert source.is_file();files=[(arcroot,source)]
   for member,file in files:
    assert not file.is_symlink();digest=sha(file);archive.add(file,arcname=member,recursive=False)
    assert sha(file)==digest,('source changed during archive',file)
    members.append(dict(path=member,size=file.stat().st_size,sha256=digest))
 assert len({x['path']for x in members})==len(members)
 # Independently decompress every member immediately; no extraction, links or
 # path traversal. Inventory is compact metadata, not duplicated result JSON.
 expected={x['path']:x for x in members};seen=set()
 with tarfile.open(target,'r:gz')as archive:
  for member in archive:
   assert member.isfile()and member.name in expected and member.name not in seen
   h=hashlib.sha256();size=0;stream=archive.extractfile(member)
   for part in iter(lambda:stream.read(1024*1024),b''):h.update(part);size+=len(part)
   assert(size,h.hexdigest())==(expected[member.name]['size'],expected[member.name]['sha256']),member.name;seen.add(member.name)
 assert seen==set(expected)
 return dict(path=name,sha256=sha(target),compressed_bytes=target.stat().st_size,regular_members=len(members),uncompressed_bytes=sum(x['size']for x in members),members=members,decompression_verified=True)

def png(source,label,scope):
 source=Path(source);raw=source.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',raw);assert header,source
 dimensions=list(map(int,header.groups()));assert len(raw)-header.end()==dimensions[0]*dimensions[1]*3
 target=ASSETS/f'sexos-alpha-r94-{label}-2026-10-30.png';subprocess.run(['sips','-s','format','png',str(source),'--out',str(target)],check=True,stdout=subprocess.DEVNULL)
 data=target.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'and[int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')]==dimensions
 return dict(path=target.name,sha256=sha(target),source_ppm_sha256=sha(source),dimensions=dimensions,scope=scope)


def native_json_links(paths,archive):
 inventory={member['path']:member for member in archive['members']};links=[]
 def walk(value,trail=()):
  if isinstance(value,dict):
   for key,item in value.items():yield from walk(item,trail+(str(key),))
  elif isinstance(value,list):
   for index,item in enumerate(value):yield from walk(item,trail+(str(index),))
  elif isinstance(value,str):yield trail,value
 for name,directory in paths.items():
  for file in sorted(directory.glob('*.json')):
   for trail,value in walk(j(file)):
    target=Path(value)
    if target.is_absolute()or not value or target.suffix not in('.ppm','.json','.pcap','.img','.log'):continue
    candidate=(file.parent/target).resolve()
    if trail and trail[-1]=='screenshot':assert candidate.is_file(),('missing accepted screenshot',name,file,trail,value)
    if not candidate.is_file():continue
    assert candidate.is_relative_to(directory.resolve()),('relative native reference escapes acceptedrun',name,trail,value)
    relative=candidate.relative_to(directory.resolve());member='native/'+directory.name+'/'+str(relative)
    assert member in inventory and sha(candidate)==inventory[member]['sha256'],('native reference absent/wrong in archive',member)
    links.append(dict(source='native/'+directory.name+'/'+file.name,field='.'.join(trail),target=member,sha256=inventory[member]['sha256']))
 return dict(ok=True,count=len(links),links=links,scope='Every existing relative evidence-file reference in accepted native JSON joined to exact archived member; screenshots require a present local file.')

PEER_MODES=('wrong-name','expired','future','client-only','foreign-root','corrupt-signature','unsupported-version','truncated-handshake','stall','ready','cancel','close')
def accepted_rows():
 expected=[('peer','/tmp/sexos-r94b-peer-suite-progress.json',['peer-'+mode+'-'+profile for mode in PEER_MODES for profile in ('wide','compact')]),
  ('private','/tmp/sexos-r94b-tls-native-suite-progress.json',['tls-'+mode+'-'+profile for mode in ('ready','close','unsupported','invalid-year')for profile in ('wide','compact')]),
  ('regression','/tmp/sexos-r94b-regression-suite-progress.json',['chain-e1000e','stream-e1000','time-normal-wide','entropy-ready-compact','profile','compact','document-reboot','history-reboot','switch-wide','switch-compact'])]
 rows=[];failed=[]
 for kind,progress,names in expected:
  cohort=j(progress);successful={}
  for row in cohort:
   assert isinstance(row['status'],int),('nonterminal cohort member',kind,row)
   if row['status']==0:
    assert row['name']not in successful,('duplicate accepted native case',kind,row['name'])
    successful[row['name']]=row
   else:failed.append(row)
  assert set(successful)==set(names),('incomplete final42 cohort',kind,set(successful),set(names))
  rows.extend(successful[name]for name in names)
 assert len(rows)==42 and all(r['status']==0 for r in rows)
 assert len({Path(r['out']).resolve()for r in rows})==42
 for row in rows:
  if 'source_binding_sha256'in row:assert row['source_binding_sha256']==BINDING_SHA,('accepted native binding mismatch',row['name'])
  # Legacy regression orchestration carries its binding in each actual
  # manifest/ISO/runner hash closure, verified before any archive writes.
 return rows,failed

def independent_replay(path,expected):
 replay=j(path)
 assert replay['ok']and replay['runs']==expected and replay['source_binding_sha256']==BINDING_SHA,('missing/wrong frozen independent replay',path)
 if expected==24:assert replay['complete24_terminal'] is True
 return replay

def control_diagnostics():
 fresh=Path('/tmp/sexos-r94-original-negotiation-control-fresh.log');text=fresh.read_text()
 assert 'Compiling sexos-embedded-tls-record-tests'in text
 assert 'test result: FAILED. 0 passed; 6 failed;'in text
 expected=('selected_suite_must_match_the_actual_single_offered_suite','version_compression_and_legacy_session_must_match_offer','key_group_point_extent_and_encoding_are_checked','duplicate_missing_unknown_or_unoffered_extensions_reject','extension_payload_and_outer_extent_are_exact','unsupported_retry_is_rejected_before_key_agreement')
 for name in expected:assert re.search(r'test handshake::server_hello::sexos_negotiation_tests::'+name+r' \.{3} FAILED',text),name
 cached=Path('/tmp/sexos-r94-original-negotiation-control.log').read_text()
 assert 'test result: ok. 6 passed; 0 failed'in cached and 'AssertionError: 0'in cached
 patched=next(Path(row['log'])for row in j(HOST/'report.json')['checks']if '[sexnet.tls.records.host] PASS'in Path(row['log']).read_text());assert 'test result: ok. 26 passed; 0 failed'in patched.read_text()
 return [dict(scope='Six grouped assertions against the exact original ServerHello parser fail in a fresh separate Cargo target. The patched actual vendor passes26unit tests. Control failures demonstrate the original malformed/unoffered selection gap; they are not failed accepted guest runs.',fresh_original='orchestration/'+fresh.name,patched_vendor='host/'+patched.name,original_parser_sha256='5b0c6b6e9059ef1210310e342f9e06984188a94c76e4ff09b2457d072cb8d064',failed_control_groups=list(expected)),
  dict(scope='First original-parser control reused an incompatible cached artifact and unexpectedly passed six assertions, causing its orchestration assertion to fail. Retained diagnostic only; no control-proof or native-acceptance claim.',cached_unusable='orchestration/sexos-r94-original-negotiation-control.log')]

def candidate_a_diagnostic():
 progress=Path('/tmp/sexos-r94-peer-suite-progress.json');rows=j(progress)
 assert rows and rows[0]['name']=='peer-wrong-name-wide'and rows[0]['status']!=0
 failed=rows[0];path=Path(failed['out']);r=j(path/'result.json');trace=(path/'serial.log').read_text(errors='replace')
 assert r['ok']is False and re.search(r'\[browser.tls.peer.rejected\] ticket=2 positive_release=1 authenticated=0 failure=Some\(Certificate\)',trace)
 assert re.search(r'\[browser.tls.peer.view\] state=Unavailable controlled_profile=1 public_internet=0',trace)
 a=Path('/tmp/sexos-alpha-r94-frozen');binding=j(a/'source-binding.json');assert binding['iso_sha256']==ISO
 assert binding['sources']==j(FROZEN/'source-binding.json')['sources'],'candidateA/B production differs'
 return dict(scope='CandidateA wrong-name guest correctly reports Certificate rejection and positive lease cleanup. Its endpoint checker waited for EOF until a30second timeout and rejected the workflow. CandidateA host/Python/checker/native evidence is retained only as diagnostic, never included in the42 accepted final94b runs; final checker claims bounded no-extra-application-byte observation without EOF/FIN proof.',candidate_binding_sha256=sha(a/'source-binding.json'),candidate_production_equals_final=True,accepted=False,progress='orchestration/'+progress.name,manifest='diagnostics/candidate-a-native/'+path.name+'/manifest.json',result='diagnostics/candidate-a-native/'+path.name+'/result.json',driver='drivers/'+Path(failed['driver']).name,host='diagnostics/candidate-a-host/report.json',python='orchestration/sexos-r94-python-final.log'),path

def archive():
 binding,build_report=bound_snapshot()
 for group in ('sources','runner_sha256'):
  for name,digest in binding[group].items():assert sha(ROOT/name)==digest,(group,name)
 # Every declared third-party input, including licenses, original manifest and
 # exact patch/test lock, belongs to this same sealed production source closure.
 import tomllib
 vendor='vendor/embedded-tls-0.19.0/'
 provenance=tomllib.loads((FROZEN/'source'/vendor/'UPSTREAM.toml').read_text())
 assert len(provenance['files'])==100
 for row in provenance['files']:
  assert binding['sources'][vendor+row['path']]==row['sha256']
 assert vendor+'UPSTREAM.toml'in binding['sources']
 host=j(HOST/'report.json')
 assert host['checks_passed']and host['sources_unchanged_during_checks']and host['run_status']=='complete'
 assert len(host['checks'])==38 and all(r['exit_code']==0 for r in host['checks'])
 for name,digest in host['source_sha256'].items():assert sha(FROZEN/'source'/name)==digest
 check_logs=[Path(row['log']).resolve()for row in host['checks']]
 assert len(check_logs)==len(set(check_logs))==38
 assert all(path.is_relative_to(HOST.resolve())for path in check_logs)
 rust=sum(int(n)for f in check_logs for n in re.findall(r'test result: ok\. (\d+) passed',f.read_text(errors='replace')))
 assert rust>0,('actual complete final38 host Rust count missing',rust)
 python_log=PYTHON.read_text();python_counts=re.findall(r'^Ran (\d+) tests in ',python_log,re.M)
 assert len(python_counts)==1 and python_log.rstrip().endswith('OK'),'final94b full Python log missing/composite/not passed'
 python_count=int(python_counts[0]);assert python_count>0
 assert list(host['obligations'].values()).count('open')==7 and list(host['obligations'].values()).count('partial')==23 and host['system_proven']is False
 rows,failed_final=accepted_rows()
 peer_replay=independent_replay('/tmp/sexos-r94b-peer-independent-replay.json',24)
 private_replay=independent_replay('/tmp/sexos-r94b-tls-independent-replay.json',8)
 scalar=j('/tmp/sexos-r94b-scalar-instructions.json')
 assert scalar['ok']and scalar['iso_sha256']==ISO and scalar['instructions']>0
 assert scalar['elf_sha256']==sha('/tmp/sexos-r94b-tested-kaleidoscope.elf')and scalar['disassembly_sha256']==sha('/tmp/sexos-r94b-kaleidoscope.disassembly')
 paths={};summaries=[]
 for row in rows:
  name=row['name'];path=Path(row['out']);r=j(path/'result.json');m=j(path/'manifest.json');assert r['ok']
  assert m.get('iso_sha256',m.get('binding',{}).get('iso_sha256'))==ISO
  if 'binding'in m:
   assert m['binding']['sha256']==BINDING_SHA and m['binding']['production_files']==535 and m['binding']['runner_files']==491
  for group in ('runner_sha256','pixel_source_sha256','authority_source_sha256'):
   for file,digest in m.get(group,{}).items():
    if group=='runner_sha256'and '/'not in file:file='scripts/'+file
    assert sha(FROZEN/'source'/file)==digest,(name,group,file)
  trace=(path/'serial.log').read_text(errors='replace')
  assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[sexfiles.defer.drop\]',trace)
  for check in ('check_nic_command.json','check_self_wait.json','check_document_views.json','check_document_snapshots.json'):
   if (path/check).exists():assert j(path/check)['ok']
  summary=dict(name=name,result_ok=True,mode=m.get('mode'),model=m.get('model'),resolution=m.get('resolution',r.get('resolution')),
   manifest='native/'+path.name+'/manifest.json',result='native/'+path.name+'/result.json',serial='native/'+path.name+'/serial.log',disk='native/'+path.name+'/nvme.img')
  if name.startswith('peer-'):
   assert all(r[k]['ok']for k in ('wire','dns','exchange','authority','self_wait'))
   assert not r['server_errors']and r['error']is None
   summary['exchange']=r['exchange'];summary['cleanup']=r['cleanup'];summary['wire']=r['wire'];summary['scope']=r['scope']
   if m['mode']in PEER_MODES[:9]:assert '[browser.tls.peer.authenticated]'not in trace and '[browser.tls.peer.response]'not in trace and '[browser.tls.peer.released]'not in trace
   if m['mode']in ('truncated-handshake','stall'):assert re.search(r'\[browser.tls.peer.rejected\] ticket=2 positive_release=1 authenticated=0 failure=None',trace),('transport cleanup mislabeled TLS parser rejection',name)
  if name.startswith('tls-'):
   assert all(r[k]['ok']for k in ('tls','public_wire','owner_packet_joins','authority','self_wait'));summary['tls']=r['tls']
  if name in ('profile','compact'):
   summary['private_pages']=sum(int(n)for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace));assert summary['private_pages']>0
  if name.startswith('switch-'):
   assert r['switch_cycles']==10 and len(r['switches'])==40 and r['pixel_errors']==[];summary['switches']=40
  summaries.append(summary);paths[name]=path
 pages={s['name']:s['private_pages']for s in summaries if 'private_pages'in s};switches={s['name']:s['switches']for s in summaries if 'switches'in s}
 assert len(pages)==2 and pages['profile']==pages['compact']and sum(switches.values())==80
 diagnostics=control_diagnostics();candidate_a,a_native=candidate_a_diagnostic();diagnostics.append(candidate_a)
 for row in failed_final:
  diagnostics.append(dict(scope='Retained failed final-cohort attempt; excluded from accepted42. Exact raw result/manifest/driver preserved separately.',name=row['name'],out=row['out'],status=row['status'],accepted=False))
 # No candidate artifact may be silently replaced by this final-cohort writer.
 assert not list(ASSETS.glob('sexos-alpha-r94-*'))
 ASSETS.mkdir(parents=True,exist_ok=True);LOCAL.mkdir(parents=True,exist_ok=True)
 diagnostic_native=[('diagnostics/candidate-a-native/'+a_native.name,a_native)]
 diagnostic_native.extend(('diagnostics/final-failed-native/'+Path(row['out']).name,Path(row['out']))for row in failed_final if Path(row['out']).is_dir())
 archives={'frozen':raw_archive('frozen',[('frozen',FROZEN)]),
  'native':raw_archive('native',[('native/'+p.name,p)for p in paths.values()]+diagnostic_native)}
 drivers=sorted(p for p in (set(Path('/tmp').glob('sexos-r94*driver.log'))|{PYTHON})if 'archive-driver'not in p.name)
 orchestration=[p for p in Path('/tmp').glob('sexos*r94*')if p.is_file()and p not in drivers and 'archive-driver'not in p.name and p.suffix in ('.py','.json','.log','.disassembly','.elf')]
 diagnostic_roots=[('diagnostics/candidate-a-host',Path('/tmp/sexos-alpha-r94-host')),('diagnostics/candidate-a-frozen-binding.json',Path('/tmp/sexos-alpha-r94-frozen/source-binding.json')),('diagnostics/original-negotiation-control',Path('/tmp/sexos-r94-original-negotiation-control'))]
 a_frozen=Path('/tmp/sexos-alpha-r94-frozen');a_binding=j(a_frozen/'source-binding.json')
 for name,digest in a_binding['runner_sha256'].items():
  if binding['runner_sha256'].get(name)!=digest:
   file=a_frozen/'source'/name;assert sha(file)==digest
   diagnostic_roots.append(('diagnostics/candidate-a-changed-runners/'+name,file))
 archives['host_build_orchestration']=raw_archive('host-build-orchestration',[('host',HOST),('build',BUILD)]+diagnostic_roots+[('orchestration/'+p.name,p)for p in sorted(orchestration)]+[('drivers/'+p.name,p)for p in drivers])
 inventory={m['path']for archive in archives.values()for m in archive['members']}
 for diagnostic in diagnostics:
  for key,value in diagnostic.items():
   if isinstance(value,str)and value.startswith(('orchestration/','drivers/','diagnostics/')):assert value in inventory,(key,value)
 links=native_json_links(paths,archives['native'])
 selections=[
  ('peer-'+mode+'-'+profile,'peer-unavailable.ppm','peer-'+mode+'-'+profile,
   'Actual '+profile+' Unavailable after positive lease cleanup and actual guest '+('Certificate'if mode in ('wrong-name','expired','corrupt-signature')else'Handshake')+' failure under controlled public-root fixture; no authenticated peer or application request.')
  for mode in ('wrong-name','expired','corrupt-signature')for profile in ('wide','compact')]+[
  ('peer-ready-wide','peer-verified.ppm','peer-verified-wide','Actual wide guest authenticated38-byte request/41-byte reply, encrypted close_notify and positive lease RELEASE; public controlled root only.'),
  ('peer-ready-compact','peer-verified.ppm','peer-verified-compact','Actual compact controlled encrypted exchange after positive RELEASE.'),
  ('peer-cancel-wide','peer-pending.ppm','peer-pending-wide','Actual outstanding controlled handshake before Q; no peer authentication claimed.'),
  ('peer-cancel-compact','peer-cancelled.ppm','peer-cancelled-compact','Actual Q cancellation after positive duplex cleanup RELEASE.'),
  ('tls-ready-wide','tls-first.ppm','private-hello-wide','Explicit local L remains a private ClientHello with no peer.'),
  ('tls-ready-compact','tls-cleared.ppm','private-cleared-compact','Compact local L/Q owned future/queue erasure status.'),
  ('tls-unsupported-wide','tls-first.ppm','entropy-unavailable-wide','Disabled entropy profile cannot prepare TLS; no alternate random source.'),
  ('tls-invalid-year-compact','tls-first.ppm','utc-unavailable-compact','Invalid1999 RTC profile cannot prepare TLS; no synthetic or last-good time.')]
 assert len(selections)==14

 images={label:png(paths[run]/file,label,scope)for run,file,label,scope in selections}
 for run,file,label,scope in selections:
  member='native/'+paths[run].name+'/'+file;assert member in inventory
  images[label]['source_ppm_member']=member
 evidence=dict(round=94,
  scope='Actual guest fail-closed controlled TLS certificate/name/time/EKU/root/signature and unsupported-version rejection, strict offered-suite/TLS13/P256/ServerHello extents, exact retained decoder diagnostics and positive cleanup before Unavailable. Positive encrypted38/41-byte exchange, Q and terminalClose regressions remain separately checked. Truncation/stall proves bounded transport cleanup only. Exact GLOBAL_VAS/BOOT/sex-pdx rules retained; public test root only, no Unix/POSIX or public Internet/HTTPS document claim.',
  iso_sha256=ISO,kernel_sha256=binding['kernel_sha256'],source_binding_sha256=BINDING_SHA,
  source_counts=dict(production=535,runners=491),source_binding_member='frozen/source-binding.json',
  host=dict(gates=38,rust_executions=rust,python_tests=python_count,report_member='host/report.json',source_binding_sha256=BINDING_SHA),
  native=dict(count=42,controlled_peer=24,private_preparation=8,regressions=10,source_binding_sha256=BINDING_SHA,runs=summaries),
  peer_independent_frozen_replay=peer_replay,tls_independent_frozen_replay=private_replay,
  native_json_references=links,archives=archives,selected_images=images,private_pages=pages,
  ordinary_switches=switches,ordinary_switches_total=80,instruction_scope=scalar,
  acceptance_status=dict(open=7,partial=23,system_proven=False),
  joint_binding=dict(all_production_and_runner_bytes_match_frozen_and_working_tree=True,vendor_files=101,
   scope='Every535 production and491 runner input, including full reviewed third-party source/license/patch closure, matches sealed frozen and current source bytes. Host architecture report separately binds its selected source set.'),
  excluded_unbound_caches=dict(relative_directory_components=['target','__pycache__'],before_symlink_checks=True,bound_sources_or_runners_excluded=False),
  diagnostics=diagnostics,
  limits=['Controlled root/server keys are deliberately public test fixtures; no public CA or Internet authentication guarantee.',
   'No general HTTPS/HTTP document integration, arbitrary endpoints, certificate revocation, RNG/RTC authenticity, latest-image sustained run, hostile containment, physical hardware, SMP or full replay proof.',
   'After the exact authenticated41-byte response and encrypted outgoing close_notify, bounded peer tail ciphertext is drained without validation; no claim that the entire closing stream was authenticated.',
   'Private erasure covers owned future/queues/chunks; no stack/register/cache erasure claim.',
   'Only the two ready peer workflows qualify authenticated38/41-byte exchange and encrypted close_notify. Cancel/Close deliberately stall before ServerHello; generic shared raw scope text adds no authentication or application-completion proof to those modes.',
   'Truncated-handshake and stall scenarios show finite transport cleanup with failure=None, not parser EOF handling, certificate rejection or peer-FIN proof.',
   'The original cached control artifact is unusable; only the separate fresh target six failed original-parser groups support that regression comparison.',
   'PCAP independently checks TCP/TLS record framing and plaintext absence; actual host OpenSSL independently receives the public guest request/reply and verifies guest close_notify. This is a controlled endpoint, not a TLS proxy.'])
 target=ASSETS/'sexos-alpha-r94-2026-10-30-evidence.json';target.write_text(json.dumps(evidence,indent=2)+'\n')
 for artifact in archives.values():shutil.copyfile(ASSETS/artifact['path'],LOCAL/artifact['path'])
 shutil.copyfile(target,LOCAL/target.name)
 print(json.dumps(dict(evidence=str(target),evidence_sha256=sha(target),archives=3,pngs=len(images),raw_members=sum(a['regular_members']for a in archives.values()),compressed_bytes=sum(a['compressed_bytes']for a in archives.values()),native=42,host_gates=38,rust_executions=rust,python_tests=python_count,private_pages=pages,switches=80)))

if __name__=='__main__':archive()
