import errno,json,socket,subprocess,time
from pathlib import Path
began=time.monotonic();checks=[];out=Path('/tmp/sexos-r94b-post-peer-port-checks.json')
while True:
 sockets=[];blocked=[]
 try:
  for port,kind in[(46078,socket.SOCK_STREAM),(46079,socket.SOCK_STREAM),(46080,socket.SOCK_STREAM),(46079,socket.SOCK_DGRAM)]:
   s=socket.socket(socket.AF_INET,kind);sockets.append(s)
   try:s.bind(('127.0.0.1',port))
   except OSError as error:
    if error.errno!=errno.EADDRINUSE:raise
    blocked.append(dict(port=port,protocol='TCP'if kind==socket.SOCK_STREAM else'UDP'))
 finally:
  for s in sockets:s.close()
 owners=[]
 for item in blocked:
  cmd=['lsof','-nP',('-iTCP:'if item['protocol']=='TCP'else'-iUDP:')+str(item['port'])]+(['-sTCP:LISTEN']if item['protocol']=='TCP'else[]);r=subprocess.run(cmd,capture_output=True,text=True)
  if r.stdout.strip():owners.append(dict(command=cmd,output=r.stdout.strip()))
 checks.append(dict(elapsed_seconds=time.monotonic()-began,blocked=blocked,live_owners=owners));out.write_text(json.dumps(checks,indent=2)+'\n')
 if owners:raise RuntimeError('live fixture port owner: '+str(owners))
 if not blocked:print('ACTUAL_POST_PEER_BIND_CHECKS_PASS');break
 print('WAITING_NO_LIVE_LISTENER',blocked,flush=True)
 if time.monotonic()-began>=120:raise TimeoutError('fixtureportsremainunavailableafter120s')
 time.sleep(.5)
