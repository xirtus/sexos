from pathlib import Path
p=Path('vendor/embedded-tls-0.19.0/src/handshake/server_hello.rs');s=p.read_text();s=s.replace('use crate::{TlsError, unused};','use crate::TlsError;\nuse crate::config::TlsCipherSuite;\nuse crate::extensions::extension_data::{supported_groups::NamedGroup,supported_versions::{TLS13,SupportedVersionsServerHello}};\nuse crate::extensions::extension_data::key_share::KeyShareServerHello;')
start=s.index('    pub fn parse(');end=s.index('    pub fn key_share(',start)
s=s[:start]+'''    /// SexOS supports the exact offered suite and a single TLS1.3/P256
    /// exchange. An unoffered selection cannot be inferred from the key bytes.
    pub fn parse<C: TlsCipherSuite>(buf: &mut ParseBuffer<'a>) -> Result<ServerHello<'a>, TlsError> {
        if buf.read_u16()? != 0x0303 { return Err(TlsError::InvalidSupportedVersions); }
        let mut random = [0;32]; buf.fill(&mut random)?;
        const RETRY:[u8;32]=[0xcf,0x21,0xad,0x74,0xe5,0x9a,0x61,0x11,0xbe,0x1d,0x8c,0x02,0x1e,0x65,0xb8,0x91,0xc2,0xa2,0x11,0x16,0x7a,0xbb,0x8c,0x5e,0x07,0x9e,0x09,0xe2,0xc8,0xa8,0x33,0x9c];
        if random==RETRY { return Err(TlsError::InvalidHandshake); }
        // The actual ClientHello always offers an empty legacy session ID.
        if buf.read_u8()? != 0 { return Err(TlsError::InvalidSessionIdLength); }
        let suite=CipherSuite::parse(buf).map_err(|_|TlsError::InvalidCipherSuite)?;
        if suite as u16 != C::CODE_POINT { return Err(TlsError::InvalidCipherSuite); }
        if buf.read_u8()? != 0 { return Err(TlsError::InvalidHandshake); }
        let length=buf.read_u16()? as usize;
        let mut offered=buf.slice(length)?;
        if !buf.is_empty() { return Err(TlsError::InvalidExtensionsLength); }
        let mut extensions=Vec::new(); let(mut version,mut key)=(false,false);
        while !offered.is_empty() {
            let kind=offered.read_u16()?; let size=offered.read_u16()? as usize;
            let mut data=offered.slice(size)?;
            let extension=match kind {
                43 if !version && size==2 => {
                    let selected=SupportedVersionsServerHello::parse(&mut data)?;
                    if selected.selected_version!=TLS13 { return Err(TlsError::InvalidSupportedVersions); }
                    version=true;ServerHelloExtension::SupportedVersions(selected)
                },
                51 if !key && size==69 => {
                    let share=KeyShareServerHello::parse(&mut data)?;
                    if share.0.group!=NamedGroup::Secp256r1 || share.0.opaque.len()!=65
                        || share.0.opaque[0]!=4 || PublicKey::from_sec1_bytes(share.0.opaque).is_err() {
                        return Err(TlsError::InvalidKeyShare);
                    }
                    key=true;ServerHelloExtension::KeyShare(share)
                },
                _ => return Err(TlsError::InvalidHandshake),
            };
            if !data.is_empty() { return Err(TlsError::InvalidExtensionsLength); }
            extensions.push(extension).map_err(|_|TlsError::InvalidHandshake)?;
        }
        if !version || !key { return Err(TlsError::InvalidHandshake); }
        Ok(Self { extensions })
    }

'''+s[end:];p.write_text(s)
p=Path('vendor/embedded-tls-0.19.0/src/handshake/mod.rs');s=p.read_text();needle='HandshakeType::ServerHello => ServerHandshake::ServerHello(ServerHello::parse(buf)?),';assert needle in s;s=s.replace(needle,'''HandshakeType::ServerHello => {
                let mut body=buf.slice(content_len as usize)?;
                ServerHandshake::ServerHello(ServerHello::parse::<CipherSuite>(&mut body)?)
            },''');p.write_text(s)
