from pathlib import Path
import tarfile,shutil,subprocess,os,hashlib
base=Path('vendor/embedded-tls-0.19.0');out=Path('/tmp/sexos-r94-original-negotiation-control');assert not out.exists();shutil.copytree(base,out,ignore=shutil.ignore_patterns('target','__pycache__'))
archive=next(Path('/Users/xmacbookm5/.cargo/registry/cache').glob('*/embedded-tls-0.19.0.crate'))
with tarfile.open(archive)as t:
 for name in ['src/handshake/mod.rs','src/handshake/server_hello.rs']:
  old=t.extractfile('embedded-tls-0.19.0/'+name).read()
  if name.endswith('server_hello.rs'):
   tests=(base/name).read_text().split('#[cfg(test)]\nmod sexos_negotiation_tests',1)[1]
   tests=tests.replace('::<Aes128GcmSha256>','').replace('::<Aes256GcmSha384>','')
   data=old+b'\n#[cfg(test)]\nmod sexos_negotiation_tests'+tests.encode()
   print('Original parser SHA256',hashlib.sha256(old).hexdigest(),flush=True)
  else:data=old
  (out/name).write_bytes(data)
command=['cargo','test','--locked','--manifest-path',str(out/'sexos-record-tests/Cargo.toml'),'--target','aarch64-apple-darwin','--lib','sexos_negotiation_tests']
result=subprocess.run(command,env={**os.environ,'RUSTFLAGS':'--cfg aes_force_soft --cfg polyval_force_soft','CARGO_TARGET_DIR':'/tmp/sexos-r94-vendor-tests-target'})
assert result.returncode==101,result.returncode
print('EXPECTED_CONTROL_FAILURE: exact original parser accepts unoffered/malformed selections; see six failed assertions',flush=True)
