from pathlib import Path
import hashlib,json,re
f=Path('/tmp/sexos-alpha-r94b-frozen');binding=json.loads((f/'source-binding.json').read_text());groups={name:json.loads(Path('/tmp/sexos-r94b-'+name+'-suite-progress.json').read_text())for name in('peer','tls-native','regression')};assert [len(groups[k])for k in groups]==[24,8,10]and all(row['status']==0 for rows in groups.values()for row in rows)
peer=json.loads(Path('/tmp/sexos-r94b-peer-independent-replay.json').read_text());private=json.loads(Path('/tmp/sexos-r94b-tls-independent-replay.json').read_text());assert peer['ok']and peer['runs']==24 and peer['complete24_terminal']and private['ok']and private['runs']==8
binding_sha=hashlib.sha256((f/'source-binding.json').read_bytes()).hexdigest();assert peer['source_binding_sha256']==private['source_binding_sha256']==binding_sha
ready=[];close=[]
for row in groups['peer']:
 out=Path(row['out']);r=json.loads((out/'result.json').read_text());assert r['ok']and r['binding']['sha256']==binding_sha
 if row['name'].startswith('peer-ready-'):
  ssl=json.loads((out/'peer-exchanges.json').read_text())['tls'][0];joined=r['exchange']['joins'][0];wire=r['wire']['joins'][0];ready.append(dict(name=row['name'],ssl=ssl,task_bytes=joined['task_bytes'],private_bytes=joined['private_bytes'],tx=wire['outgoing_bytes'],rx=wire['incoming_bytes']))
 if row['name'].startswith('peer-close-'):
  trace=(out/'serial.log').read_text();assert '[browser.tls.peer.closed] pending=1 terminal=1 owned_storage=erased'in trace;pages=list(map(int,re.findall(r'\[app.private.retired\][^\r\n]*pages=(\d+)',trace)));assert pages==[123];close.append(dict(name=row['name'],pending=1,pages=pages[0],glyphs='Pending before Close only'))
profiles={};switches=0;reboots={}
for row in groups['regression']:
 out=Path(row['out']);r=json.loads((out/'result.json').read_text());assert r['ok']
 if r.get('iso_sha256'):assert r['iso_sha256']==binding['iso_sha256']
 if row['name']in('profile','compact'):profiles[row['name']]=sum(map(int,re.findall(r'\[app.private.retired\][^\r\n]*pages=(\d+)',(out/'serial.log').read_text())))
 if row['name'].startswith('switch-'):assert len(r['switches'])==40 and not r['pixel_errors'];switches+=len(r['switches'])
 if row['name']in('document-reboot','history-reboot'):reboots[row['name']]=r
assert profiles=={'profile':427,'compact':427}and switches==80 and len(reboots)==2
failure=Path('/tmp/sexos-alpha-r94-peer-wrong-name-wide');failed=json.loads((failure/'result.json').read_text());assert not failed['ok']and failed['server_errors']==['TimeoutError: timed out']
result=dict(ok=True,native=42,peer=24,private_tls=8,regressions=10,iso_sha256=binding['iso_sha256'],source_binding_sha256=binding_sha,production=len(binding['sources']),runners=len(binding['runner_sha256']),ready=ready,close=close,profile_pages=profiles,switches=switches,reboots=reboots,independent_peer_replay_runs=peer['runs'],independent_private_replay_runs=private['runs'],failed_candidate_A=dict(path=str(failure),result_sha256=hashlib.sha256((failure/'result.json').read_bytes()).hexdigest(),scope='Rejected candidate only: actual Certificate rejection/positive cleanup occurred but host checker wrongly required EOF; no native acceptance inherited by B'),scope='Exact frozenB image 42 finite normal-image workflows. Controlled BOOT profile only; no publicInternet/publicCA/physical/SMP/hostile-containment or full daily-driver claim. Rejected peers carry no FIN/EOF claim; incomplete/stall cases prove bounded transport cleanup only.')
Path('/tmp/sexos-r94b-native-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in('ok','native','peer','private_tls','regressions','profile_pages','switches','source_binding_sha256')}))
