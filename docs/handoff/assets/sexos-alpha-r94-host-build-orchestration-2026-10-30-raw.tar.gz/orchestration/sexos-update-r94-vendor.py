from pathlib import Path
import hashlib,tomllib,tarfile,difflib,re
base=Path('vendor/embedded-tls-0.19.0');p=base/'UPSTREAM.toml';s=p.read_text();meta=tomllib.loads(s)
archive=next(Path('/Users/xmacbookm5/.cargo/registry/cache').glob('*/embedded-tls-0.19.0.crate'))
assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['archive_sha256']
patch=[]
with tarfile.open(archive)as t:
 originals={m.name.split('/',1)[1]:t.extractfile(m).read()for m in t if m.isfile()}
 for record in meta['files']:
  name=record['path']
  if 'upstream_sha256'not in record:continue
  old=originals[name];assert hashlib.sha256(old).hexdigest()==record['upstream_sha256'];assert len(old)==record['upstream_bytes']
  new=(base/name).read_bytes()
  if old!=new:patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(base/'SEXOS_PATCHES.patch').write_text(''.join(patch))
s=s.replace('Reject empty/all-padding TLSInnerPlaintext and unsupported post-handshake records without panic. No new TLS features, providers, protocols or authority.','Reject empty/all-padding TLSInnerPlaintext and unsupported post-handshake records without panic. Require exact offered suite, TLS1.3/P256 ServerHello selections and message/extents; reject unsupported retries and duplicate/unoffered extensions. No new TLS features, providers, protocols or authority.')
for record in meta['files']:
 name=record['path'];data=(base/name).read_bytes();h=hashlib.sha256(data).hexdigest()
 pattern=r'(\[\[files\]\]\npath = '+re.escape('"'+name+'"')+r'\nsha256 = ")[^"]+("\nbytes = )\d+'
 s,n=re.subn(pattern,lambda m:m[1]+h+m[2]+str(len(data)),s);assert n==1,name
p.write_text(s);newhash=hashlib.sha256(p.read_bytes()).hexdigest()
p=Path('scripts/check_tls_platform.py');s=p.read_text();s,n=re.subn(r"VENDOR_PROVENANCE_SHA256 = '[0-9a-f]+'",f"VENDOR_PROVENANCE_SHA256 = '{newhash}'",s);assert n==1;p.write_text(s)
print('Vendor inputs pinned',newhash,'original members',len(originals),'patchlines',len(patch))
