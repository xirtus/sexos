from pathlib import Path
import json,subprocess,time,os
f=Path('/tmp/sexos-alpha-r94b-frozen');scripts=f/'source/scripts';iso=f/'tested.iso';seed=Path('/tmp/sexos-alpha-r26-native/nvme.img');rows=[]
progress=Path('/tmp/sexos-r94b-regression-suite-progress.json')
assert not progress.exists(),'fresh regression progress required'
def check(out,script,*args):
 with(out/(script.removesuffix('.py')+'.json')).open('w')as log:r=subprocess.run(['python3',str(scripts/script),str(out/'serial.log'),*map(str,args)],stdout=log,stderr=subprocess.STDOUT)
 return r.returncode
def run(name,script,*args):
 out=Path('/tmp/sexos-alpha-r94b-'+name);assert not out.exists()and not Path('/tmp/sexos-r94b-'+name+'-driver.log').exists(),'fresh regression evidence required';began=time.monotonic();print('START',name,flush=True)
 with Path('/tmp/sexos-r94b-'+name+'-driver.log').open('w')as log:r=subprocess.run(['python3',str(scripts/script),'--iso',str(iso),'--out',str(out),*map(str,args)],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 status=r.returncode
 if not status:status=check(out,'check_nic_command.py','--ethernet','--network-config','--routing')or check(out,'check_self_wait.py')
 if not status and name in ['profile','compact','document-reboot','history-reboot','switch-wide','switch-compact']:
  status=check(out,'check_document_views.py')
  if not status and not name.startswith('switch-'):
   required='16,18'if name in ['profile','compact']else'9';extra=[]
   if name=='history-reboot':required=''
   if name in ['document-reboot','history-reboot']:extra=['--no-terminal']
   status=check(out,'check_document_snapshots.py','--require-clients',required,'--minimum',0 if name=='history-reboot'else 1,*extra)
 rows.append(dict(name=name,status=status,seconds=time.monotonic()-began,out=str(out)));progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,status,flush=True)
 if status:raise SystemExit(status)
run('chain-e1000e','http_redirect_gate.py','--source-disk',seed,'--binding',f/'source-binding.json','--mode','chain','--model','e1000e','--resolution','1280x800')
run('stream-e1000','http_content_gate.py','--source-disk',seed,'--mode','stream','--model','e1000','--resolution','1024x768')
run('time-normal-wide','certificate_time_gate.py','--source-disk',seed,'--binding',f/'source-binding.json','--mode','normal')
run('entropy-ready-compact','entropy_seed_gate.py','--source-disk',seed,'--binding',f/'source-binding.json','--mode','ready','--model','e1000','--resolution','1024x768')
run('profile','quil_workflow_gate.py','--source-disk',seed,'--round','94','--workspace-refresh','--third-quil','--soak-seconds','100','--rehearsal','--capture-profile')
run('compact','quil_workflow_gate.py','--source-disk',seed,'--round','94','--workspace-refresh','--third-quil','--soak-seconds','1','--rehearsal','--capture-profile','--resolution','1024x768')
boot=Path('/tmp/sexos-alpha-r94b-profile')
run('document-reboot','quil_reboot_gate.py','--source-disk',boot/'nvme.img','--boot-a',boot,'--round','94')
run('history-reboot','spindle_durable_reboot_gate.py','--boot-a',boot,'--recall','echo alpha17')
run('switch-wide','app_switch_gate.py','--source-disk',seed,'--no-legacy','--switch-cycles','10','--focus-feedback')
run('switch-compact','app_switch_gate.py','--source-disk',seed,'--no-legacy','--switch-cycles','10','--focus-feedback','--resolution','1024x768')
