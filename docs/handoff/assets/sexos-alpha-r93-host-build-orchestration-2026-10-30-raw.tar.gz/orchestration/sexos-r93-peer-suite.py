from pathlib import Path
import json,subprocess,time,os,hashlib
f=Path('/tmp/sexos-alpha-r93-frozen');script=f/'source/scripts/tls_exchange_gate.py';iso=f/'tested.iso';binding=f/'source-binding.json';seed=Path('/tmp/sexos-alpha-r26-native/nvme.img');progress=Path('/tmp/sexos-r93-peer-suite-progress.json');rows=json.loads(progress.read_text());assert len(rows)==1 and rows[0]['name']=='peer-ready-wide'
first=json.loads((Path(rows[0]['out'])/'result.json').read_text());assert first['ok'];rows[0]['status']=0;rows[0]['session_terminal_exit_code']=0;rows[0]['source_binding_sha256']=hashlib.sha256(binding.read_bytes()).hexdigest();progress.write_text(json.dumps(rows,indent=2)+'\n')
for mode,profile,model,resolution in [('ready','compact','e1000','1024x768'),('cancel','wide','e1000e','1280x800'),('cancel','compact','e1000','1024x768'),('close','wide','e1000e','1280x800'),('close','compact','e1000','1024x768')]:
 name='peer-'+mode+'-'+profile;out=Path('/tmp/sexos-alpha-r93-'+name);driver=Path('/tmp/sexos-r93-'+name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(script),'--iso',str(iso),'--binding',str(binding),'--source-disk',str(seed),'--out',str(out),'--mode',mode,'--model',model,'--resolution',resolution];row=dict(name=name,status='running',out=str(out),driver=str(driver),command=command,source_binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest());rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic();print('START',name,flush=True)
 with driver.open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert json.loads((out/'result.json').read_text())['ok']
print('ALL6_CONTROLLED_TLS_EXCHANGES_PASS',flush=True)
