"""Prepared round93 single-cohort archive. Execute only after root confirms closure.
No build, test suite, native workflow, staging or commit is launched here.
"""
from pathlib import Path
import hashlib,json,re,os,shutil,subprocess,tarfile
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path('/Users/xmacbookm5/Projects/Sex');ASSETS=ROOT/'docs/handoff/assets';LOCAL=ROOT/'.evidence/alpha-2026-10-29/r93'
FROZEN=Path('/tmp/sexos-alpha-r93-frozen');BUILD=Path('/tmp/sexos-alpha-r93-build');HOST=Path('/tmp/sexos-alpha-r93-host')
PYTHON=Path('/tmp/sexos-r93-python-final.log')
ISO='70fdee93d65c002d81b79a0652c0b19826cc497b3d0894b3f220358d00b3bea8'
BINDING_SHA='c14b6390bc61f6cc121553098f20d0d2be380e51b94cab03b4ebf0b5e48f7770'

def j(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as file:
  for part in iter(lambda:file.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def tree_files(path):
 path=Path(path);assert path.is_dir(),path
 for file in sorted(path.rglob('*')):
  # Compiler caches are unbound output, not evidence. Filter before checking
  # symlinks because Cargo caches contain symlinked dependency artifacts.
  if any(part in ('target','__pycache__')for part in file.relative_to(path).parts):continue
  assert not file.is_symlink(),file
  if file.is_file():yield file

def bound_snapshot():
 assert sha(FROZEN/'source-binding.json')==BINDING_SHA
 b=j(FROZEN/'source-binding.json');p=b['build_provenance']
 assert b['iso_sha256']==ISO==p['iso_sha256']==sha(FROZEN/'tested.iso')
 assert p['build_gate']=='PASS'and p['source_image_binding']=='sealed_build_this_run'and p['sources_unchanged_during_build']is True
 assert b['sources']==p['production_source_sha256']and len(b['sources'])==535 and len(b['runner_sha256'])==491
 assert sha(FROZEN/'tested.kernel')==b['kernel_sha256']
 for group in('sources','runner_sha256'):
  for name,digest in b[group].items():
   assert not any(part in ('target','__pycache__')for part in Path(name).parts),('boundcacheforbidden',group,name)
   assert sha(FROZEN/'source'/name)==digest,(group,name)
 build=(BUILD/'report.md').read_text();assert re.search(r'FINAL_SCORE[^\n]*GREEN_MASTER',build)and re.search(r'BUILD_GATE[^\n]*PASS',build)and 'probe_seconds: 25'in build
 assert j(BUILD/'provenance.json')['iso_sha256']==ISO
 return b,build

def raw_archive(label,roots):
 name=f'sexos-alpha-r93-{label}-2026-10-30-raw.tar.gz';target=ASSETS/name;members=[]
 with tarfile.open(target,'w:gz',compresslevel=9)as archive:
  for arcroot,source in roots:
   source=Path(source)
   if source.is_dir():files=[(arcroot+'/'+str(file.relative_to(source)),file)for file in tree_files(source)]
   else:assert source.is_file();files=[(arcroot,source)]
   for member,file in files:
    assert not file.is_symlink();digest=sha(file);archive.add(file,arcname=member,recursive=False)
    assert sha(file)==digest,('source changed during archive',file)
    members.append(dict(path=member,size=file.stat().st_size,sha256=digest))
 assert len({x['path']for x in members})==len(members)
 # Independently decompress every member immediately; no extraction, links or
 # path traversal. Inventory is compact metadata, not duplicated result JSON.
 expected={x['path']:x for x in members};seen=set()
 with tarfile.open(target,'r:gz')as archive:
  for member in archive:
   assert member.isfile()and member.name in expected and member.name not in seen
   h=hashlib.sha256();size=0;stream=archive.extractfile(member)
   for part in iter(lambda:stream.read(1024*1024),b''):h.update(part);size+=len(part)
   assert(size,h.hexdigest())==(expected[member.name]['size'],expected[member.name]['sha256']),member.name;seen.add(member.name)
 assert seen==set(expected)
 return dict(path=name,sha256=sha(target),compressed_bytes=target.stat().st_size,regular_members=len(members),uncompressed_bytes=sum(x['size']for x in members),members=members,decompression_verified=True)

def png(source,label,scope):
 source=Path(source);raw=source.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',raw);assert header,source
 dimensions=list(map(int,header.groups()));assert len(raw)-header.end()==dimensions[0]*dimensions[1]*3
 target=ASSETS/f'sexos-alpha-r93-{label}-2026-10-30.png';subprocess.run(['sips','-s','format','png',str(source),'--out',str(target)],check=True,stdout=subprocess.DEVNULL)
 data=target.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'and[int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')]==dimensions
 return dict(path=target.name,sha256=sha(target),source_ppm_sha256=sha(source),dimensions=dimensions,scope=scope)


def native_json_links(paths,archive):
 inventory={member['path']:member for member in archive['members']};links=[]
 def walk(value,trail=()):
  if isinstance(value,dict):
   for key,item in value.items():yield from walk(item,trail+(str(key),))
  elif isinstance(value,list):
   for index,item in enumerate(value):yield from walk(item,trail+(str(index),))
  elif isinstance(value,str):yield trail,value
 for name,directory in paths.items():
  for file in sorted(directory.glob('*.json')):
   for trail,value in walk(j(file)):
    target=Path(value)
    if target.is_absolute()or not value or target.suffix not in('.ppm','.json','.pcap','.img','.log'):continue
    candidate=(file.parent/target).resolve()
    if trail and trail[-1]=='screenshot':assert candidate.is_file(),('missing accepted screenshot',name,file,trail,value)
    if not candidate.is_file():continue
    assert candidate.is_relative_to(directory.resolve()),('relative native reference escapes acceptedrun',name,trail,value)
    relative=candidate.relative_to(directory.resolve());member='native/'+directory.name+'/'+str(relative)
    assert member in inventory and sha(candidate)==inventory[member]['sha256'],('native reference absent/wrong in archive',member)
    links.append(dict(source='native/'+directory.name+'/'+file.name,field='.'.join(trail),target=member,sha256=inventory[member]['sha256']))
 return dict(ok=True,count=len(links),links=links,scope='Every existing relative evidence-file reference in accepted native JSON joined to exact archived member; screenshots require a present local file.')

def accepted_rows():
 peer=j('/tmp/sexos-r93-peer-suite-progress.json')
 private=j('/tmp/sexos-r93-tls-native-suite-progress.json')
 regression=j('/tmp/sexos-r93-regression-suite-progress.json')
 expected_peer=['peer-'+mode+'-'+profile for mode in ('ready','cancel','close') for profile in ('wide','compact')]
 # A failed pre-QEMU fixture bind is diagnostic only, never a native acceptance.
 # Select exactly the final successful cases, including the preserved retry.
 successful={}
 for row in peer:
  if row['status']==0:
   assert row['name'] not in successful,('duplicate accepted peer name',row['name'])
   successful[row['name']]=row
 assert set(successful)==set(expected_peer),('incomplete six-case peer cohort',set(successful))
 peer=[successful[name]for name in expected_peer]
 assert Path(peer[2]['out']).name=='sexos-alpha-r93-peer-cancel-wide-retry'
 assert [r['name']for r in private]==['tls-'+mode+'-'+profile for mode in ('ready','close','unsupported','invalid-year')for profile in ('wide','compact')]
 assert [r['name']for r in regression]==['chain-e1000e','stream-e1000','time-normal-wide','entropy-ready-compact','profile','compact','document-reboot','history-reboot','switch-wide','switch-compact']
 rows=peer+private+regression
 assert len(rows)==24 and all(r['status']==0 for r in rows)
 assert len({Path(r['out']).resolve()for r in rows})==24
 for row in rows:
  if 'source_binding_sha256'in row:assert row['source_binding_sha256']==BINDING_SHA
 return rows

def independent_replay(path,expected):
 replay=j(path)
 assert replay['ok']and replay['runs']==expected and replay['source_binding_sha256']==BINDING_SHA,('missing/wrong frozen independent replay',path)
 return replay

def bind_failure_diagnostic():
 first=Path('/tmp/sexos-r93-peer-first-attempt-progress.json');rows=j(first)
 assert len(rows)==3 and [r['status']for r in rows]==[0,0,1]
 failed=rows[-1];assert failed['name']=='peer-cancel-wide'
 directory=Path(failed['out']);assert directory.is_dir()and not list(directory.iterdir())
 trace=Path(failed['driver']);text=trace.read_text()
 assert 'OSError: [Errno 48] Address already in use'in text and 'peer.start()'in text
 assert not (directory/'manifest.json').exists()and not (directory/'serial.log').exists()
 return dict(scope='Host fixture TCP46080 bind failed before QEMU launch after two passing peer workflows. Original progress/trace and actual empty output directory retained as diagnostic; not a native test failure or native pass.',
  first_progress='orchestration/'+first.name,trace='drivers/'+trace.name,output_directory=str(directory),output_directory_entries=[],qemu_launched=False,native_accepted=False,
  resumed_port_checks='orchestration/sexos-r93-peer-port-waits.json',resume_script='orchestration/sexos-r93-peer-resume.py')

def archive():
 binding,build_report=bound_snapshot()
 for group in ('sources','runner_sha256'):
  for name,digest in binding[group].items():assert sha(ROOT/name)==digest,(group,name)
 # Every declared third-party input, including licenses, original manifest and
 # exact patch/test lock, belongs to this same sealed production source closure.
 import tomllib
 vendor='vendor/embedded-tls-0.19.0/'
 provenance=tomllib.loads((FROZEN/'source'/vendor/'UPSTREAM.toml').read_text())
 assert len(provenance['files'])==100
 for row in provenance['files']:
  assert binding['sources'][vendor+row['path']]==row['sha256']
 assert vendor+'UPSTREAM.toml'in binding['sources']
 host=j(HOST/'report.json')
 assert host['checks_passed']and host['sources_unchanged_during_checks']and host['run_status']=='complete'
 assert len(host['checks'])==38 and all(r['exit_code']==0 for r in host['checks'])
 for name,digest in host['source_sha256'].items():assert sha(FROZEN/'source'/name)==digest
 rust=sum(int(n)for f in HOST.glob('*.log')for n in re.findall(r'test result: ok\. (\d+) passed',f.read_text(errors='replace')))
 assert rust==1757,('actual frozen host Rust count',rust)
 python_log=PYTHON.read_text();assert re.findall(r'^Ran (\d+) tests in ',python_log,re.M)==['531']and python_log.rstrip().endswith('OK')
 assert list(host['obligations'].values()).count('open')==7 and list(host['obligations'].values()).count('partial')==23 and host['system_proven']is False
 rows=accepted_rows()
 peer_replay=independent_replay('/tmp/sexos-r93-peer-independent-replay.json',6)
 private_replay=independent_replay('/tmp/sexos-r93-tls-independent-replay.json',8)
 scalar=j('/tmp/sexos-r93-scalar-instructions.json')
 assert scalar['ok']and scalar['iso_sha256']==ISO and scalar['instructions']==72066
 assert scalar['elf_sha256']==sha('/tmp/sexos-r93-tested-kaleidoscope.elf')and scalar['disassembly_sha256']==sha('/tmp/sexos-r93-kaleidoscope.disassembly')
 paths={};summaries=[]
 for row in rows:
  name=row['name'];path=Path(row['out']);r=j(path/'result.json');m=j(path/'manifest.json');assert r['ok']
  assert m.get('iso_sha256',m.get('binding',{}).get('iso_sha256'))==ISO
  if 'binding'in m:
   assert m['binding']['sha256']==BINDING_SHA and m['binding']['production_files']==535 and m['binding']['runner_files']==491
  for group in ('runner_sha256','pixel_source_sha256','authority_source_sha256'):
   for file,digest in m.get(group,{}).items():
    if group=='runner_sha256'and '/'not in file:file='scripts/'+file
    assert sha(FROZEN/'source'/file)==digest,(name,group,file)
  trace=(path/'serial.log').read_text(errors='replace')
  assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[sexfiles.defer.drop\]',trace)
  for check in ('check_nic_command.json','check_self_wait.json','check_document_views.json','check_document_snapshots.json'):
   if (path/check).exists():assert j(path/check)['ok']
  summary=dict(name=name,result_ok=True,mode=m.get('mode'),model=m.get('model'),resolution=m.get('resolution',r.get('resolution')),
   manifest='native/'+path.name+'/manifest.json',result='native/'+path.name+'/result.json',serial='native/'+path.name+'/serial.log',disk='native/'+path.name+'/nvme.img')
  if name.startswith('peer-'):
   assert all(r[k]['ok']for k in ('wire','dns','exchange','authority','self_wait'))
   assert not r['server_errors']and r['error']is None
   summary['exchange']=r['exchange'];summary['cleanup']=r['cleanup'];summary['wire']=r['wire']
  if name.startswith('tls-'):
   assert all(r[k]['ok']for k in ('tls','public_wire','owner_packet_joins','authority','self_wait'));summary['tls']=r['tls']
  if name in ('profile','compact'):
   summary['private_pages']=sum(int(n)for n in re.findall(r'\[app.private.retired\] [^\r\n]*pages=(\d+)',trace));assert summary['private_pages']>0
  if name.startswith('switch-'):
   assert r['switch_cycles']==10 and len(r['switches'])==40 and r['pixel_errors']==[];summary['switches']=40
  summaries.append(summary);paths[name]=path
 pages={s['name']:s['private_pages']for s in summaries if 'private_pages'in s};switches={s['name']:s['switches']for s in summaries if 'switches'in s}
 assert len(pages)==2 and pages['profile']==pages['compact']and sum(switches.values())==80
 diagnostic=bind_failure_diagnostic()
 for name,needle in [('sexos-r93-upstream-empty-control.log','called `Option::unwrap()` on a `None` value'),('sexos-r93-upstream-handler-control.log','not implemented')]:
  text=(Path('/tmp')/name).read_text();assert needle in text and 'test result: FAILED. 0 passed; 1 failed'in text
 vendor_log=Path('/tmp/sexos-r93-vendor-unit.log').read_text();assert 'test result: ok. 20 passed; 0 failed'in vendor_log
 # No candidate artifact may be silently replaced by this final-cohort writer.
 assert not list(ASSETS.glob('sexos-alpha-r93-*'))
 ASSETS.mkdir(parents=True,exist_ok=True);LOCAL.mkdir(parents=True,exist_ok=True)
 diagnostic_path=Path('/tmp/sexos-r93-pre-qemu-bind-diagnostic.json');diagnostic_path.write_text(json.dumps(diagnostic,indent=2)+'\n')
 archives={'frozen':raw_archive('frozen',[('frozen',FROZEN)]),
  'native':raw_archive('native',[('native/'+p.name,p)for p in paths.values()])}
 drivers=sorted(p for p in (set(Path('/tmp').glob('sexos-r93*driver.log'))|{PYTHON})if 'archive-driver'not in p.name)
 orchestration=[p for p in Path('/tmp').glob('sexos*r93*')if p.is_file()and p not in drivers and 'archive-driver'not in p.name and p.suffix in ('.py','.json','.log','.disassembly','.elf')]
 archives['host_build_orchestration']=raw_archive('host-build-orchestration',[('host',HOST),('build',BUILD)]+[('orchestration/'+p.name,p)for p in sorted(orchestration)]+[('drivers/'+p.name,p)for p in drivers])
 inventory={m['path']for archive in archives.values()for m in archive['members']}
 for key in ('first_progress','trace','resumed_port_checks','resume_script'):assert diagnostic[key]in inventory
 links=native_json_links(paths,archives['native'])
 selections=[
  ('peer-ready-wide','peer-verified.ppm','peer-verified-wide','Actual wide framebuffer after guest TLS1.3 encrypted controlled request/reply, encrypted close_notify and positive lease RELEASE.'),
  ('peer-ready-compact','peer-verified.ppm','peer-verified-compact','Actual compact framebuffer after verified controlled encrypted exchange and positive RELEASE.'),
  ('peer-cancel-wide','peer-pending.ppm','peer-pending-wide','Actual outstanding duplex handshake against a deliberately stalled controlled TLS peer, before Q.'),
  ('peer-cancel-compact','peer-cancelled.ppm','peer-cancelled-compact','Actual Q cancellation status after positive duplex cleanup RELEASE; no peer authentication claimed.'),
  ('peer-close-wide','peer-pending.ppm','peer-before-close-wide','Actual pending duplex allocation before terminal Close.'),
  ('peer-close-compact','peer-closed.ppm','peer-after-close-compact','Actual compact desktop after terminal Close and exact service retirement.'),
  ('tls-ready-wide','tls-first.ppm','private-hello-wide','Explicit local L preparation remains a private ClientHello with no peer.'),
  ('tls-ready-compact','tls-cleared.ppm','private-cleared-compact','Compact local L then Q future/queue erasure status.'),
  ('tls-unsupported-wide','tls-first.ppm','entropy-unavailable-wide','Disabled entropy profile cannot prepare TLS; no alternative random source.'),
  ('tls-invalid-year-compact','tls-first.ppm','utc-unavailable-compact','Invalid1999 RTC profile cannot prepare TLS; no synthetic or last-good time.')]
 images={label:png(paths[run]/file,label,scope)for run,file,label,scope in selections}
 for run,file,label,scope in selections:
  member='native/'+paths[run].name+'/'+file;assert member in inventory
  images[label]['source_ppm_member']=member
 evidence=dict(round=93,
  scope='Actual guest TLS1.3 P256/AES128 controlled encrypted request/reply on separately sanctioned fixed port46080 through exact BOOT policy/seed/time and positive DNS release. Explicit duplex custody, fail-closed vendored record handling, Q cancellation and terminal Close. Public test root only; no public Internet or HTTPS document claim.',
  iso_sha256=ISO,kernel_sha256=binding['kernel_sha256'],source_binding_sha256=BINDING_SHA,
  source_counts=dict(production=535,runners=491),source_binding_member='frozen/source-binding.json',
  host=dict(gates=38,rust_executions=rust,python_tests=531,report_member='host/report.json',source_binding_sha256=BINDING_SHA),
  native=dict(count=24,controlled_peer=6,private_preparation=8,regressions=10,source_binding_sha256=BINDING_SHA,runs=summaries),
  peer_independent_frozen_replay=peer_replay,tls_independent_frozen_replay=private_replay,
  native_json_references=links,archives=archives,selected_images=images,private_pages=pages,
  ordinary_switches=switches,ordinary_switches_total=80,instruction_scope=scalar,
  acceptance_status=dict(open=7,partial=23,system_proven=False),
  joint_binding=dict(all_production_and_runner_bytes_match_frozen_and_working_tree=True,vendor_files=101,
   scope='Every535 production and491 runner input, including full reviewed third-party source/license/patch closure, matches sealed frozen and current source bytes. Host architecture report separately binds its selected source set.'),
  excluded_unbound_caches=dict(relative_directory_components=['target','__pycache__'],before_symlink_checks=True,bound_sources_or_runners_excluded=False),
  diagnostics=[diagnostic,dict(scope='Exact unpatched upstream controls deliberately reproduce empty decrypted plaintext unwrap and unexpected post-handshake unimplemented panics. Patched actual vendor library passes20 unit tests; control failures are diagnostic regression evidence, not failures of the accepted frozen guest.',
   original_empty='orchestration/sexos-r93-upstream-empty-control.log',original_handler='orchestration/sexos-r93-upstream-handler-control.log',patched_vendor='orchestration/sexos-r93-vendor-unit.log')],
  limits=['Controlled root/server keys are deliberately public test fixtures; no public CA or Internet authentication guarantee.',
   'No general HTTPS/HTTP document integration, arbitrary endpoints, certificate revocation, RNG/RTC authenticity, latest-image sustained run, hostile containment, physical hardware, SMP or full replay proof.',
   'After the exact authenticated41-byte response and encrypted outgoing close_notify, bounded peer tail ciphertext is drained without validation; no claim that the entire closing stream was authenticated.',
   'Private erasure covers owned future/queues/chunks; no stack/register/cache erasure claim.',
   'PCAP independently checks TCP/TLS record framing and plaintext absence; actual host OpenSSL independently receives the public guest request/reply and verifies guest close_notify. This is a controlled endpoint, not a TLS proxy.'])
 target=ASSETS/'sexos-alpha-r93-2026-10-30-evidence.json';target.write_text(json.dumps(evidence,indent=2)+'\n')
 for artifact in archives.values():shutil.copyfile(ASSETS/artifact['path'],LOCAL/artifact['path'])
 shutil.copyfile(target,LOCAL/target.name)
 print(json.dumps(dict(evidence=str(target),evidence_sha256=sha(target),archives=3,pngs=len(images),raw_members=sum(a['regular_members']for a in archives.values()),compressed_bytes=sum(a['compressed_bytes']for a in archives.values()),native=24,host_gates=38,rust_executions=rust,python_tests=531,private_pages=pages,switches=80)))

if __name__=='__main__':archive()
