from pathlib import Path
import errno,hashlib,json,os,socket,subprocess,time
f=Path('/tmp/sexos-alpha-r93-frozen');script=f/'source/scripts/tls_exchange_gate.py';binding=f/'source-binding.json';progress=Path('/tmp/sexos-r93-peer-suite-progress.json');old=progress.read_bytes();backup=Path('/tmp/sexos-r93-peer-first-attempt-progress.json');assert not backup.exists();backup.write_bytes(old);rows=json.loads(old);assert len(rows)==3 and [r['status']for r in rows]==[0,0,1];failure=rows.pop();assert failure['name']=='peer-cancel-wide';assert not any(Path(failure['out']).iterdir());progress.write_text(json.dumps(rows,indent=2)+'\n');port_evidence=[];port_file=Path('/tmp/sexos-r93-peer-port-waits.json')
def await_ports(name):
 began=time.monotonic();turn=0;checks=[];record=dict(name=name,checks=checks);port_evidence.append(record)
 while True:
  turn+=1;blocked=[];sockets=[]
  try:
   for port,kind in[(46078,socket.SOCK_STREAM),(46079,socket.SOCK_STREAM),(46080,socket.SOCK_STREAM),(46079,socket.SOCK_DGRAM)]:
    sock=socket.socket(socket.AF_INET,kind);sockets.append(sock)
    try:sock.bind(('127.0.0.1',port))
    except OSError as error:
     if error.errno!=errno.EADDRINUSE:raise
     blocked.append(dict(port=port,protocol='TCP'if kind==socket.SOCK_STREAM else'UDP',error=error.errno))
  finally:
   for sock in sockets:sock.close()
  owners=[]
  for item in blocked:
   flag='-iTCP:'+str(item['port'])if item['protocol']=='TCP'else'-iUDP:'+str(item['port']);cmd=['lsof','-nP',flag]+(['-sTCP:LISTEN']if item['protocol']=='TCP'else[]);r=subprocess.run(cmd,capture_output=True,text=True)
   if r.stdout.strip():owners.append(dict(command=cmd,output=r.stdout.strip()))
  check=dict(turn=turn,elapsed_seconds=time.monotonic()-began,blocked=blocked,live_owners=owners);checks.append(check);port_file.write_text(json.dumps(port_evidence,indent=2)+'\n')
  if owners:raise RuntimeError('live process owns required fixture port; preserve/diagnose before continuing: '+str(owners))
  if not blocked:print('PORTS_AVAILABLE',name,'turn',turn,'elapsed',check['elapsed_seconds'],flush=True);return
  print('PORT_WAIT',name,'turn',turn,'blocked',blocked,'no_live_listener',flush=True)
  if time.monotonic()-began>=120:raise TimeoutError('authoritative port bind checks still fail after120seconds')
  time.sleep(.5)
for mode,profile,model,resolution,suffix in [('cancel','wide','e1000e','1280x800','-retry'),('cancel','compact','e1000','1024x768',''),('close','wide','e1000e','1280x800',''),('close','compact','e1000','1024x768','')]:
 name='peer-'+mode+'-'+profile;await_ports(name);out=Path('/tmp/sexos-alpha-r93-'+name+suffix);driver=Path('/tmp/sexos-r93-'+name+suffix+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(script),'--iso',str(f/'tested.iso'),'--binding',str(binding),'--source-disk','/tmp/sexos-alpha-r26-native/nvme.img','--out',str(out),'--mode',mode,'--model',model,'--resolution',resolution];row=dict(name=name,status='running',out=str(out),driver=str(driver),command=command,source_binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest(),infrastructure_attempt=2 if suffix else 1)
 if suffix:row['prior_infrastructure_failure']=failure
 rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic();print('START',name,flush=True)
 with driver.open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert json.loads((out/'result.json').read_text())['ok']
print('ALL6_CONTROLLED_TLS_EXCHANGES_PASS_WITH_PRESERVED_PRE_QEMU_BIND_FAILURE',flush=True)
