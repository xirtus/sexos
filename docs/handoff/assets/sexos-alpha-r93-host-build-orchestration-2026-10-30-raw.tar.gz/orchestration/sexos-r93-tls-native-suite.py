#!/usr/bin/env python3
"""Sequential exact-frozen91b TLS foundation workflows; no handshake claim."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--frozen',type=Path,default=Path('/tmp/sexos-alpha-r93-frozen'));p.add_argument('--seed',type=Path,default=Path('/tmp/sexos-alpha-r26-native/nvme.img'));a=p.parse_args()
f=a.frozen.resolve(strict=True);iso=f/'tested.iso';binding=f/'source-binding.json';runner=f/'source/scripts/tls_prepare_gate.py';held=json.loads(binding.read_text())
assert hashlib.sha256(iso.read_bytes()).hexdigest()==held['iso_sha256']
assert hashlib.sha256(runner.read_bytes()).hexdigest()==held['runner_sha256']['scripts/tls_prepare_gate.py']
rows=[];progress=Path('/tmp/sexos-r93-tls-native-suite-progress.json')
if progress.exists():raise FileExistsError('fresh progress file required; preserve prior workflow evidence')
for mode in('ready','close','unsupported','invalid-year'):
 for profile,model,resolution in(('wide','e1000e','1280x800'),('compact','e1000','1024x768')):
  name='tls-'+mode+'-'+profile;out=Path('/tmp/sexos-alpha-r93-'+name);driver=Path('/tmp/sexos-r93-'+name+'-driver.log')
  if out.exists()or driver.exists():raise FileExistsError('fresh workflow directory/driver required: '+name)
  command=['python3',str(runner),'--iso',str(iso),'--binding',str(binding),'--source-disk',str(a.seed.resolve(strict=True)),'--out',str(out),'--mode',mode,'--model',model,'--resolution',resolution]
  row=dict(name=name,out=str(out),driver=str(driver),command=command,status='running',source_binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest());rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic();print('START',name,flush=True)
  with driver.open('w')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  row.update(status=result.returncode,seconds=time.monotonic()-began)
  if result.returncode==0:
   final=json.loads((out/'result.json').read_text());assert final['ok'];row.update(closed_pending=final['tls']['closed_pending'],tls_joins=final['tls']['joins'],screenshots=len(final['pixels']))
  progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,row['status'],flush=True)
  if result.returncode:raise SystemExit(result.returncode)
print('ALL8_TLS_FOUNDATION_WORKFLOWS_PASS',flush=True)
