#!/usr/bin/env python3
"""Read-only independent replay of the frozen round93 peer evidence.

Invokes the exact frozen checker functions without QEMU, sockets, compiler runs,
input injection, source edits or bytecode writes. Only the final receipt is saved.
"""
import sys
sys.dont_write_bytecode=True
import hashlib,json,re
from pathlib import Path
FROZEN=Path('/tmp/sexos-alpha-r93-frozen').resolve()
ROOT=FROZEN/'source'
sys.path.insert(0,str(ROOT/'scripts'))
import tls_exchange_gate as gate
PROGRESS=Path('/tmp/sexos-r93-peer-suite-progress.json')
OUTPUT=Path('/tmp/sexos-r93-peer-independent-replay.json')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def normalized(value):return json.loads(json.dumps(value,sort_keys=True))
def require(condition,message):
 if not condition:raise AssertionError(message)
def same(actual,expected,message):require(normalized(actual)==normalized(expected),message)
def load(path):return json.loads(path.read_text())
def check():
 binding_path=FROZEN/'source-binding.json';binding=load(binding_path)
 require(len(binding['sources'])==535 and len(binding['runner_sha256'])==491,'unexpected frozen cohort counts')
 for group in('sources','runner_sha256'):
  for name,wanted in binding[group].items():
   p=(ROOT/name).resolve();require(p.is_relative_to(ROOT)and p.is_file()and sha(p)==wanted,'frozen '+group+' mismatch: '+name)
 same(binding['sources'],binding['build_provenance']['production_source_sha256'],'build source map differs from frozen production cohort')
 require(binding['architecture_sha256']==sha(ROOT/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7','architecture binding changed')
 require(sha(FROZEN/'tested.kernel')==binding['kernel_sha256']==binding['build_provenance']['kernel_sha256'],'kernel binding changed')
 frozen=gate.frozen_binding(ROOT,FROZEN/'tested.iso',binding_path)
 require(frozen['production_files']==535 and frozen['runner_files']==491,'frozen binding counts differ')
 contract=gate.load_contract(ROOT)
 for name,wanted in contract['source_sha256'].items():require(sha(ROOT/name)==wanted,'contract source changed: '+name)
 require(Path(gate.__file__).resolve()==ROOT/'scripts/tls_exchange_gate.py','wrong checker imported')
 rows=load(PROGRESS);require(len(rows)==6 and all(row['status']==0 for row in rows),'missing accepted terminal row')
 require({row['name']for row in rows}=={f'peer-{mode}-{size}'for mode in('ready','cancel','close')for size in('wide','compact')},'wrong accepted scenario roster')
 results=[];failed_attempts=[];seed_hashes={}
 secret_patterns=re.compile(r'CLIENT_HANDSHAKE_TRAFFIC_SECRET|SERVER_HANDSHAKE_TRAFFIC_SECRET|CLIENT_TRAFFIC_SECRET_\d|SERVER_TRAFFIC_SECRET_\d|EARLY_EXPORTER_SECRET|EXPORTER_SECRET|CLIENT_RANDOM\s+[0-9a-fA-F]|-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----')
 for row in rows:
  out=Path(row['out']).resolve();manifest=load(out/'manifest.json');saved=load(out/'result.json');peer=load(out/'peer-exchanges.json')
  mode=manifest['mode'];resolution=tuple(map(int,manifest['resolution'].split('x')))
  require(saved['ok']is True and saved['error']is None and saved['server_errors']==[],'saved scenario failed: '+row['name'])
  require(mode==saved['mode']==row['command'][row['command'].index('--mode')+1],'mode binding mismatch')
  require(row['source_binding_sha256']==sha(binding_path),'accepted cohort binding differs')
  same(saved['binding'],frozen,'saved result binding differs');same(manifest['binding'],frozen,'manifest binding differs')
  require(Path(manifest['command'][manifest['command'].index('-cdrom')+1]).resolve()==FROZEN/'tested.iso','wrong actual ISO command')
  require(Path(row['command'][1]).resolve()==ROOT/'scripts/tls_exchange_gate.py','wrong launched checker')
  same(gate.command_profile(manifest['command']),manifest['platform_profile'],'actual platform profile rerun differs')
  require(manifest['platform_profile']['ok']is True,'platform profile failed')
  require(manifest['host_utc_start']<manifest['host_utc_end'],'invalid actual UTC bracket')
  require(manifest['target']['ok']is True and manifest['target']['target_sha256']==sha(ROOT/'x86_64-sex.json'),'target receipt source binding differs')
  require(manifest['target']['cfg']['os']==['none']and manifest['target']['cfg']['env']==['']and manifest['target']['cfg']['families']==[]and manifest['target']['cfg']['unix']is False,'manifest compiler metadata is Unix')
  seed=Path(row['command'][row['command'].index('--source-disk')+1]).resolve()
  seed_hashes.setdefault(str(seed),sha(seed));require(seed_hashes[str(seed)]==manifest['input_disk_sha256'],'input disk binding differs')
  same(manifest['pixel_source_sha256'],contract['source_sha256'],'manifest pixel contract differs')
  endpoint=manifest['tls_peer'];require(endpoint['keylog_enabled']is False and peer['keylog_enabled']is False,'key logging enabled')
  require(endpoint['endpoint']=='127.0.0.1:46080'and endpoint['host_forwards']is False and endpoint['minimum_version']==endpoint['maximum_version']=='TLSv1.3'and endpoint['group']=='P-256'and endpoint['num_tickets']==0 and endpoint['public_test_root']is True,'wrong controlled endpoint profile')
  require(len(peer['tls'])==1,'wrong actual endpoint connection count')
  tls=peer['tls'][0]
  if mode=='ready':
   require(tls['tls_version']=='TLSv1.3'and tls['cipher']==gate.CIPHER and tls['sni']==gate.HOST and tls['unwrap_completed']is True,'actual negotiated SSL/unwrap missing')
   require(bytes.fromhex(tls['request_hex'])==gate.REQUEST and len(gate.REQUEST)==38 and bytes.fromhex(tls['response_hex'])==gate.RESPONSE and len(gate.RESPONSE)==41,'actual endpoint application bytes differ')
  else:
   require(tls['handshake_stalled']is True and tls['tls_version']is None and tls['cipher']is None and tls['request_hex']is None and tls['response_hex']is None and tls['unwrap_completed']is False,'pending fixture claimed a completed TLS exchange')
  for path in [out/'manifest.json',out/'result.json',out/'peer-exchanges.json',out/'serial.log',out/'qemu.log',Path(row['driver'])]:
   require(not secret_patterns.search(path.read_text(errors='replace')),'secret material marker in '+str(path))
  require(not any('keylog'in p.name.lower()or p.suffix in('.key','.pem')for p in out.iterdir()),'unexpected key/keylog file in native output')
  raw=(out/'wire.pcap').read_bytes();trace=(out/'serial.log').read_text(errors='replace')
  wire=gate.inspect_wire(raw,peer['tls'],mode)
  dns=gate.dns_capture(raw,'echo',attempts=peer['dns_send_attempts'],expected=peer['dns'])
  exchange=gate.inspect_exchange(trace,mode,wire,dns,raw,manifest['host_utc_start'],manifest['host_utc_end'])
  authority=gate.nic_check(trace,expected=1,preparation=True,ethernet=True,network_config=True,routing=True)
  waiting=gate.wait_check(trace)
  for key,value in(('wire',wire),('dns',dns),('exchange',exchange),('authority',authority),('self_wait',waiting)):
   require(value['ok']is True,f'{row["name"]} {key} replay failed: {value.get("errors")}');same(value,saved[key],f'{row["name"]} {key} replay differs from saved result')
  pixels=[]
  for old in saved['pixels']:
   state=old['expected'];pixel_trace=trace;slice_kind='full immutable final trace';cut=len(trace)
   if state=='Pending':
    pattern=r'\[shell.browser.input\] code=16 down=1 slot=43 accepted=1'if mode=='cancel'else r'\[browser.tls.peer.closed\] pending=1 terminal=1 owned_storage=erased'
    boundary=re.search(pattern,trace);require(boundary is not None,'missing actual pending screenshot boundary');cut=boundary.start();pixel_trace=trace[:cut];slice_kind='before actual Q forwarded'if mode=='cancel'else'before actual terminal peer.closed'
   ppm=out/old['screenshot'];require(sha(ppm)==old['screenshot_sha256'],'actual PPM hash differs')
   same(old['source_sha256'],contract['source_sha256'],'pixel source hash binding differs')
   actual=gate.verify_peer_pixels(pixel_trace,ppm.read_bytes(),state,contract,resolution)
   require(actual['ok']is True,f'{row["name"]} {state} pixel replay failed: {actual.get("errors")}')
   same(actual,{k:v for k,v in old.items()if k not in('screenshot','screenshot_sha256','source_sha256')},'pixel replay differs from saved receipt')
   pixel_saved=load(out/(ppm.stem+'-pixels.json'));same(pixel_saved,old,'separate pixel receipt differs')
   pixels.append(dict(expected=state,trace_slice=slice_kind,trace_end_offset=cut,screenshot=ppm.name,sha256=sha(ppm),resolution=list(resolution),checked_pixels=actual['checked_pixels'],expected_ink_pixels=actual['expected_ink_pixels'],geometry=actual['geometry']))
  require([p['expected']for p in pixels]==(['Verified']if mode=='ready'else['Pending','Cancelled']if mode=='cancel'else['Pending']),'wrong pixel proof roster')
  cleanup=None;closed_ppm=None
  if mode=='close':
   close=re.search(r'\[browser.tls.peer.closed\] pending=1 terminal=1 owned_storage=erased',trace);require(close is not None,'missing close marker')
   cleanup=gate.cleanup_receipts(trace,15,15,close.start());same(cleanup,saved['cleanup'],'exact cleanup receipt replay differs')
   ack=re.search(r'\[net.app.cleanup.ack\] target=15 task=15 client_leases=0 shared_cache=retained ok=1',trace[close.start():]);require(ack is not None,'missing exact network cleanup ACK');end=close.start()+ack.end()
   require(not re.search(r'\[net.job.egress.submit\] ticket=2 |\[net.dns.egress.submit\] ticket=1 ',trace[end:]),'retired exact incarnation logged private egress after ACK')
   ppm=out/'peer-closed.ppm'
   data=ppm.read_bytes();header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',data);require(header is not None,'invalid actual closed PPM header')
   width,height=map(int,header.groups());require(width>0 and height>0 and len(data)-header.end()==width*height*3,'closed PPM byte extent differs');require((width,height)==resolution,'closed framebuffer resolution differs')
   closed_ppm=dict(file=ppm.name,sha256=sha(ppm),resolution=[width,height],glyphs_checked=False,scope='Hash and framebuffer dimensions only; closed-screen glyph content is not independently proved.')
  else:require(saved['cleanup']is None,'unexpected terminal cleanup in non-close mode')
  if row.get('prior_infrastructure_failure'):
   prior=row['prior_infrastructure_failure'];driver=Path(prior['driver']);text=driver.read_text(errors='replace')
   require(prior['status']==1 and 'Address already in use'in text and 'peer.start()'in text and not list(Path(prior['out']).iterdir()),'prior failure was not the retained pre-QEMU bind failure')
   failed_attempts.append(dict(name=prior['name'],driver=str(driver),driver_sha256=sha(driver),output=str(Path(prior['out'])),output_empty=True,classification='Endpoint bind Errno48 before manifest/disk copy/QEMU launch; no guest failure or native run.',accepted_attempt=row['name']))
  flow=wire['joins'][0];join=exchange['joins'][0]
  results.append(dict(name=row['name'],mode=mode,model=manifest['model'],resolution=list(resolution),out=str(out),binding_sha256=frozen['sha256'],host_utc_bracket=[manifest['host_utc_start'],manifest['host_utc_end']],utc_snapshot=join['utc_snapshot'],authenticated=join['authenticated'],ticket=join['ticket'],dns_generation=join['dns_generation'],sequence=join['sequence'],task_bytes=join['task_bytes'],private_bytes=join['private_bytes'],application_request_bytes=38 if mode=='ready'else 0,application_response_bytes=41 if mode=='ready'else 0,tls=normalized(tls),wire=wire,dns=dns,exchange=exchange,authority=authority,self_wait=waiting,pixels=pixels,cleanup=cleanup,post_cleanup_private_egress_submits=0 if cleanup else None,closed_framebuffer=closed_ppm,keylog_enabled=False,secret_marker_scan='No SSL secret/keylog/PEM-private-key material markers in retained textual evidence; no claim about uncaptured process memory.',artifacts_sha256={name:sha(out/name)for name in('manifest.json','result.json','peer-exchanges.json','serial.log','qemu.log','wire.pcap')}))
 return dict(ok=True,runs=len(results),source_binding_sha256=frozen['sha256'],kind='independent_frozen_checker_replay',frozen=str(FROZEN),binding=frozen,kernel_sha256=binding['kernel_sha256'],architecture_sha256=binding['architecture_sha256'],production_hashes_verified=535,runner_hashes_verified=491,checker_sha256=sha(Path(gate.__file__)),pixel_contract_source_count=len(contract['source_sha256']),progress_sha256=sha(PROGRESS),scenarios=results,summary=dict(accepted_native_scenarios=6,independent_wire_dns_exchange_nic_selfwait_replays=6,actual_authenticated_SSL_exchanges=2,actual_exact_application_request_bytes_each=38,actual_exact_application_response_bytes_each=41,pending_cancel_scenarios=2,pending_close_scenarios=2,whole_glyph_and_padding_pixel_snapshots=sum(len(r['pixels'])for r in results),whole_glyph_and_padding_pixels=sum(p['checked_pixels']for r in results for p in r['pixels']),closed_PPM_hash_and_dimension_checks=2,closed_PPM_glyph_proofs=0),prior_infrastructure_attempts=failed_attempts,scope='Recomputed strict frozen checker receipts from retained raw PCAP, actual endpoint OpenSSL public observations/send attempts, immutable serial traces, source-bound PPM glyph/padding pixels, command manifests and exact UTC brackets. This is independent checker replay, not scheduler/input-record replay, a new native execution, public-Internet/public-CA qualification, physical/SMP/hostile-containment proof, secret-memory audit or validation of discarded post-response TLS control tails.',replay_script_sha256=sha(Path(__file__)))
try:
 result=check()
except Exception as exc:
 result=dict(ok=False,error=type(exc).__name__+': '+str(exc),scope='Independent read-only frozen checker replay failed; no new guest execution.')
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in('scenarios',)},indent=2))
if not result['ok']:raise SystemExit(1)
