from pathlib import Path
import hashlib,json,tarfile,re,io
from PIL import Image
root=Path('/Users/xmacbookm5/Projects/Sex/docs/handoff/assets')
target=root/'sexos-alpha-r93-2026-10-30-evidence.json'
e=json.loads(target.read_text());assert e['round']==93 and e['native']['count']==24
assert e['source_counts']==dict(production=535,runners=491)
assert (e['host']['gates'],e['host']['rust_executions'],e['host']['python_tests'])==(38,1757,531)
assert e['acceptance_status']==dict(open=7,partial=23,system_proven=False)
assert (e['native']['controlled_peer'],e['native']['private_preparation'],e['native']['regressions'])==(6,8,10)
assert e['peer_independent_frozen_replay']['runs']==6 and e['tls_independent_frozen_replay']['runs']==8
sha=lambda b:hashlib.sha256(b).hexdigest()
want={i['source_ppm_sha256']for i in e['selected_images'].values()};pixels={};jsons={};files={};archives={}
for label,a in e['archives'].items():
 path=root/a['path'];assert sha(path.read_bytes())==a['sha256'];expected={m['path']:m for m in a['members']};seen=set()
 with tarfile.open(path,'r:gz')as tar:
  for member in tar:
   assert member.isfile() and not member.name.startswith('/') and '..'not in Path(member.name).parts
   assert member.name in expected and member.name not in seen;seen.add(member.name);m=expected[member.name]
   assert member.size==m['size'];h=hashlib.sha256();chunks=[];keep=member.name.endswith('.json')or m['sha256']in want
   with tar.extractfile(member)as stream:
    for chunk in iter(lambda:stream.read(1024*1024),b''):
     h.update(chunk)
     if keep:chunks.append(chunk)
   assert h.hexdigest()==m['sha256'];assert member.name not in files;files[member.name]=m
   if member.name.endswith('.json'):
    try:jsons[member.name]=json.loads(b''.join(chunks))
    except (json.JSONDecodeError,UnicodeDecodeError):pass
   if m['sha256']in want:pixels[m['sha256']]=b''.join(chunks)
 assert seen==set(expected) and len(seen)==a['regular_members'];archives[label]=len(seen)
b=jsons[e['source_binding_member']];assert b['iso_sha256']==e['iso_sha256']
assert files[e['source_binding_member']]['sha256']==e['source_binding_sha256']
assert len(b['sources'])==535 and len(b['runner_sha256'])==491
for group in ['sources','runner_sha256']:
 for name,digest in b[group].items():assert files['frozen/source/'+name]['sha256']==digest
assert b['sources']['ARCHITECTURE.md']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
h=jsons[e['host']['report_member']];assert h['checks_passed']and h['sources_unchanged_during_checks']and h['run_status']=='complete'
for name,digest in h['source_sha256'].items():assert files['frozen/source/'+name]['sha256']==digest
for run in e['native']['runs']:
 r=jsons[run['result']];m=jsons[run['manifest']];assert r['ok'];assert m.get('iso_sha256',m.get('binding',{}).get('iso_sha256'))==e['iso_sha256']
 if 'binding'in m:assert m['binding']['sha256']==e['source_binding_sha256']
assert set(e['private_pages'])=={'profile','compact'} and e['private_pages']['profile']==e['private_pages']['compact']>0 and e['ordinary_switches_total']==80
selected=[]
for label,i in e['selected_images'].items():
 raw=(root/i['path']).read_bytes();assert sha(raw)==i['sha256'];im=Image.open(io.BytesIO(raw)).convert('RGB');ppm=pixels[i['source_ppm_sha256']]
 header=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',ppm);assert header
 assert im.size==tuple(map(int,header.groups()))==tuple(i['dimensions']);assert im.tobytes()==ppm[header.end():]
 selected.append(i['path'])
result=dict(ok=True,evidence=str(target),evidence_sha256=sha(target.read_bytes()),archives=archives,raw_members=sum(archives.values()),images=selected,native=24,host=38,rust_executions=1757,python_tests=531,private_pages=e['private_pages'],switches=80,diagnostics=len(e['diagnostics']))
Path('/tmp/sexos-r93-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
