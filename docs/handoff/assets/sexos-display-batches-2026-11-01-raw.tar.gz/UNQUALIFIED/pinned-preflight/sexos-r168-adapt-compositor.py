from pathlib import Path
r=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex')
s=(r/'tests/display_surface_groups.rs').read_text()
s=s.replace('fn raster_area(_:&frame_output::Target<\'_>,_:&SilkBar)->bool{panic!("unexpected full redraw");}', '''#[path="../servers/sexdisplay/src/paint_batch.rs"]mod paint_batch;
use paint_batch::{Content,Plan};
static mut ATLAS_CALLS:usize=0;
fn draw_atlas_cards_pass(_:*mut u32,_:usize,_:usize,_:usize,_:&scene::SceneSnapshot){unsafe{ATLAS_CALLS+=1;}}
fn draw_atlas_frame_previews_pass(_:*mut u32,_:usize,_:usize,_:usize,_:&scene::SceneSnapshot){unsafe{ATLAS_CALLS+=1;}}
fn civil_clock_lines(_:&silkbar_model::civil_clock::CivilClock)->[[u8;13];2]{TEST_CLOCK_LINES}''')
s=s.replace('fn redraw_surface_damage(fb:*mut u32,w:usize,h:usize,r:damage::Rect){unsafe{','''fn redraw_surface_damage(fb:*mut u32,w:usize,h:usize,r:damage::Rect){paint_output_batch(fb,w,h,Plan{content:Content::Damage(r),strip:false});}
fn paint_output_batch(fb:*mut u32,w:usize,h:usize,plan:Plan){unsafe{''')
s=s.replace(' let mut preparation=store.prepare(false).unwrap();\n {let target=preparation.target();assert!(raster_damage(&target,r,&DEFAULT_SILK_BAR));}', ''' let captured=capture_scene(w,h,FOCUSED_SURFACE_ID);
 let mut preparation=store.prepare(plan.is_full()).unwrap();
 {let target=preparation.target();assert!(raster_batch(&target,&captured,plan));}''')
s=s.replace('actual Store/Target and raster_damage','actual Store/Target and raster_batch')
s+='''
// The legacy reference computes body pixels independently. Strip glyph/color
// sentinels are the established clock/bar boundary, not a replacement Scene.
unsafe fn independent_batch_pixel(x:usize,y:usize,w:usize,h:usize)->u32{
 if y<50{return match(x,y){(0,0)=>1,(1,0)=>2,(2,0)=>3,(3,0)=>4,_=>9};}
 if y==50{return DEFAULT_THEME.panel_glow;}
 legacy_reference_pixel(x,y,w,h,0)
}
unsafe fn combined_fixture()->(usize,usize,Vec<u32>){
 let(w,h)=(320,260);SURFACES=[SURFACE_EMPTY;MAX_SURFACES];FRAME_GROUPS=FrameGroups::new();FOCUSED_SURFACE_ID=0;
 SURFACES[0]=Surface{x:20,y:70,w:200,h:150,color:0x345678,..surf(9,156)};
 let mut pixels=vec![0;w*h];for y in 0..h{for x in 0..w{pixels[y*w+x]=independent_batch_pixel(x,y,w,h);}}
 (w,h,pixels)
}
#[test]fn combined_area_strip_matches_independent_whole_frame_once(){unsafe{
 let(w,h,mut pixels)=combined_fixture();SURFACES[0].color=0xabcdef;DAMAGE_ORDER.clear();ATLAS_CALLS=0;
 paint_output_batch(pixels.as_mut_ptr(),w,h,Plan{content:Content::Area,strip:true});
 assert_eq!(DAMAGE_ORDER,["restore","launcher","cursor","presented"]);assert_eq!(ATLAS_CALLS,2);
 for y in 0..h{for x in 0..w{assert_eq!(pixels[y*w+x],independent_batch_pixel(x,y,w,h),"area/strip {x}/{y}");}}
 SURFACES=[SURFACE_EMPTY;MAX_SURFACES];
}}
#[test]fn combined_damage_strip_preserves_every_pixel_outside_changed_regions(){unsafe{
 let(w,h,mut pixels)=combined_fixture();let old=pixels.clone();
 fill_damage::update(&mut SURFACES[0],0,5,10,30,20,0x00f0e0d0).unwrap();
 let rect=damage::Rect{x:25,y:80,right:55,bottom:100};DAMAGE_ORDER.clear();ATLAS_CALLS=0;
 paint_output_batch(pixels.as_mut_ptr(),w,h,Plan{content:Content::Damage(rect),strip:true});
 assert_eq!(DAMAGE_ORDER,["restore","launcher","cursor","presented"]);assert_eq!(ATLAS_CALLS,2);
 let mut changed=0;for y in 0..h{for x in 0..w{
  assert_eq!(pixels[y*w+x],independent_batch_pixel(x,y,w,h),"damage/strip {x}/{y}");
  if y>=51&&!(x>=25&&x<55&&y>=80&&y<100){assert_eq!(pixels[y*w+x],old[y*w+x]);}
  changed+=usize::from(pixels[y*w+x]!=old[y*w+x]);
 }}assert_eq!(changed,30*20);SURFACES=[SURFACE_EMPTY;MAX_SURFACES];
}}
#[test]fn combined_cursor_strip_keeps_body_exact_and_finishes_overlays_once(){unsafe{
 let(w,h,mut pixels)=combined_fixture();for pixel in &mut pixels[..51*w]{*pixel=0xdeadbeef;}let body=pixels[51*w..].to_vec();DAMAGE_ORDER.clear();ATLAS_CALLS=0;
 paint_output_batch(pixels.as_mut_ptr(),w,h,Plan{content:Content::Cursor,strip:true});
 assert_eq!(DAMAGE_ORDER,["restore","launcher","cursor","presented"]);assert_eq!(ATLAS_CALLS,2);assert_eq!(&pixels[51*w..],body.as_slice());
 for y in 0..h{for x in 0..w{assert_eq!(pixels[y*w+x],independent_batch_pixel(x,y,w,h),"cursor/strip {x}/{y}");}}
 SURFACES=[SURFACE_EMPTY;MAX_SURFACES];
}}
'''
Path('/tmp/sexos-r168-display-surface-groups.rs').write_text(s)
g=(r/'scripts/display_surface_groups_gate.sh').read_text();g=g.replace("'raster_damage','text_surface_damage'","'raster_batch','raster_full','raster_strip','raster_area','raster_damage','fill_bar_bg_buffer','blur_bar_bg_buffer_radius1','clock_total_seconds','text_surface_damage'")
a=g.index("for name in ['raster_full','raster_strip']:");b=g.index('focus=s[',a)
g=g[:a]+'''for name in ['raster_full','raster_strip','raster_area','raster_damage']:
 body=function(name)
 assert "target: &frame_output::Target<'_>" in body and 'scene: &scene::SceneSnapshot' in body
 for forbidden in ['SceneLease::capture','restore_cursor_under(','draw_launcher_panel(','draw_cursor_z_top(','APP_PRESENT_BITS = 0','HIGH_HALF_BASE']:assert forbidden not in body,(name,forbidden)
prepared=re.sub(r'\\s+','',function('render_prepared'))
assert prepared.count('SceneLease::capture(')==1 and prepared.count('preparation.target()')==1
assert 'store.prepare(plan.is_full())' in prepared and 'raster_batch(&target,scene,plan)' in prepared
assert prepared.index('SceneLease::capture(')<prepared.index('raster_batch(')<prepared.index('preparation.commit(')<prepared.index('report_app_presented();')
batch=re.sub(r'\\s+','',function('raster_batch'))
assert batch.count('restore_cursor_under(')==1 and batch.count('draw_cursor_z_top(')==1 and batch.count('draw_launcher_panel(')==1
assert batch.index('restore_cursor_under(')<batch.index('raster_damage(')<batch.index('raster_strip(')<batch.index('draw_launcher_panel(')<batch.index('draw_cursor_z_top(')
assert 'draw_cursor_z_top(fb,w,h,total,true,scene);'in batch
for name in ['BAR_BG_BUF','BAR_BLUR_BUF','ROW_BUFFER_PROOF_LOGGED','BLUR_PROOF_LOGGED','ANIM_PROOF_LOGGED','R6_GLASS_PROOF_LOGGED','CLOCK_REDRAW_SOURCE','CLOCK_CANON_SS']:
 match=re.search(r'^static(?: mut)? '+name+r':[^;]+;',s,re.M);assert match,name;parts.append(match[0])
for name in ['SILK_RENDER_PROOF_PROFILE_ENABLED','SILKBAR_PHASE3_RECEIVE_PROOF_ENABLED','SILKBAR_PHASE5_PIXEL_PROOF_ENABLED']:
 match=re.search(r'^const '+name+r':[^;]+;',s,re.M);assert match,name;parts.append(match[0])
''' +g[b:]
g=g.replace("assert 'text_damage.rect().filter(|_| fb_live && !transaction_full_render)' in s","assert 'if let Some(rect)=text_damage.rect(){pending_paint.request_damage(rect,w,h);}' in s")
Path('/tmp/sexos-r168-display-surface-groups-gate.sh').write_text(g)
