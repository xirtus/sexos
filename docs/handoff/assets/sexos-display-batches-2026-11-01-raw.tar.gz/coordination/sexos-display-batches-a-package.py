"""Round168 exact eleven-boot/seventy-capture evidence package.
Root must pin executed helpers, review, and run after all native outputs stop.
No guest/build actions: only frozen read-only --check/API replay, then archive.
"""
from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,subprocess,tarfile
T=Path('/tmp');P='sexos-display-batches-a'
COMMIT='ca82b950b1609cb8fac06ac468e77326f8b170a5'
BASELINE='0c185625b086f6843e19d1c5de8c47d4c0a4e505'
BASELINE_BINDING_SHA256='7c9fe5fd43a36d772992b9d24988caf9b1d4d582f741547291fe3d26f09a8a8c'
# Root fills final exact executed-source hashes after orchestration completes.
# No failed native/BOOT coordinator or resume flow belongs to this cohort.
EXECUTED_HELPER_SHA256={'/tmp/sexos-display-batches-a-source-audit.py': '75592491ccf4ef858c8954533e3d40c569c65bfd08f89026ab1bd6032276072c', '/tmp/sexos-display-batches-a-scalar-audit.py': '5b80fc13ff03fdb9f471d0ff31c07a7d9963fc3f4d5f30a2232c5e6286ebe1c7', '/tmp/sexos-display-batches-a-budget-audit.py': 'aa353b12ca3b63e55218c39b7115673df8ee23dec05b6443587bb9d2a68ace90', '/tmp/sexos-display-batches-a-boot-audit.py': '256d030a55b0bec223efb3cbea3ef5dbc66451df2e186921edc0fd4c96898a07', '/tmp/sexos-display-batches-a-native-suite.py': 'f13092523eb400d4a1205033ac938d6f9405e0f1ddf913b746a801cf2462fa21', '/tmp/sexos-display-batches-a-production-equivalence.py': 'a0f477b7b1ffc606b3222e7b429b431ef486a5546b67a8dc4b2398ca92cbc6e3'}
# Current failed preflight alone, never acceptance evidence. Its actual49
# compositor cases passed, but an external obsolete finish-signature guard failed.
UNQUALIFIED_DIAGNOSTIC_SHA256={'/tmp/sexos-r168-compositor.log': 'd3626a2a507660b392fd1f854c6bd40214a8d635be1d5b4dcef16afd40d034c3', '/tmp/sexos-r168-compositor-proof.json': 'e50e4374ef056a4fa49d2e1edb5a2d7fa65c5a9e0cd0ef1d4dfcac311be1b8b3', '/tmp/sexos-r168-adapt-compositor.py': '01cbdccd768d80d1a2288729fc0bb0d8fb8fa348431aed9f43caf6204295db50'}
EXPECTED_CHANGED=['servers/sexdisplay/src/main.rs']
EXPECTED_ADDED=['servers/sexdisplay/src/paint_batch.rs']
EXPECTED_ABI='3b98b23398b7a309a74d5d10526e9234fa372ff448c79f51aa4f4b9f44fdc36a'
EXPECTED_KERNEL='26bace17d464d1ea04667a6ff1dc47514d76be472342ca4ed396000f62a20f89'
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}

def require(value,why):
 if not value:raise AssertionError(why)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def marker(text,tag):
 matches=re.findall(r'^\['+re.escape(tag)+r'\] PASS (\{[^\n]+\})$',text,re.M)
 require(len(matches)==1,('exact host proof marker',tag));return json.loads(matches[0])
def plan():
 rows=[]
 for profile,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
  for mode in ('normal','invalid-year'):rows.append(dict(name=f'clock-{mode}-{profile}',kind='clock',script='certificate_time_gate.py',extra=['--mode',mode],model=model,resolution=res,boots=1,captures=4,mode=mode))
  rows.append(dict(name='connected-'+profile,kind='connected',script='connected_desktop_gate.py',extra=[],model=model,resolution=res,boots=2,captures=17))
  rows.append(dict(name='browser-'+profile,kind='browser',script='browser_reserve_gate.py',extra=['--mode','quiesced'],model=model,resolution=res,boots=1,captures=10,mode='quiesced'))
 return rows

def main():
 F=(T/(P+'-frozen')).resolve(strict=True);R=F/'source'
 archive=T/(P+'-2026-11-01-raw.tar.gz');receipt_path=T/(P+'-package-result.json')
 require(not archive.exists()and not receipt_path.exists(),'archive/receipt already exists; never overwrite')
 required={str(T/(P+s))for s in ('-source-audit.py','-scalar-audit.py','-budget-audit.py','-boot-audit.py','-native-suite.py','-production-equivalence.py')}
 require(required<=set(EXECUTED_HELPER_SHA256),'Root must pin all six executed auditor/coordinator sources')
 for path,digest in {**EXECUTED_HELPER_SHA256,**UNQUALIFIED_DIAGNOSTIC_SHA256}.items():
  require(re.fullmatch('[0-9a-f]{64}',digest)and sha(path)==digest,('executed helper/diagnostic changed',path))
 b=read(F/'source-binding.json');require(b['build_provenance']['git_revision']==COMMIT and b['build_provenance']['build_gate']=='PASS'and b['build_provenance']['sources_unchanged_during_build'],'exact sealed source')
 require(sha(F/'tested.iso')==b['iso_sha256']and sha(F/'tested.kernel')==b['kernel_sha256'],'current sealed image/kernel')
 closure={**b['sources'],**b['runner_sha256']}
 require((len(b['sources']),len(b['runner_sha256']),len(closure))==(586,638,1224),'exact source membership counts')
 require(set(closure)=={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and '__pycache__'not in p.parts},'exact frozen source closure')
 for name,digest in closure.items():
  p=R/name;require(p.resolve().is_relative_to(R)and not p.is_symlink()and sha(p)==digest,('frozen source changed',name))
 require(sum((R/n).stat().st_size for n in closure)==12217001,'exact frozen byte count')
 source=read(T/(P+'-source-audit.json'));scalar=read(T/(P+'-scalar/result.json'));host=read(T/(P+'-frozen-host/report.json'));budget=read(T/(P+'-budget-audit.json'))
 require(source['ok']and(source['commit'],source['iso_sha256'],source['kernel_sha256'],source['unique'],source['total_source_bytes'])==(COMMIT,b['iso_sha256'],b['kernel_sha256'],1224,12217001),'source audit binding/counts')
 require(len(source['rows'])==1224 and {v['path']for v in source['rows']}==set(closure),'all audited Git/source rows')
 for row in source['rows']:require(row['sha256']==closure[row['path']]and row['size']==(R/row['path']).stat().st_size,('source audit row',row['path']))
 require(scalar['ok']and scalar['commit']==COMMIT and scalar['iso_sha256']==b['iso_sha256']and scalar['total_instructions']==324791 and len(scalar['results'])==9,'current nine-ELF scalar scan')
 require({r['name']for r in scalar['results']}=={'kaleidoscope','silk-shell','sexdisplay','quil','silkbar','sexfiles','spindle','linen','sexnet'},'exact scalar ELF set')
 require(sum(r['instructions']for r in scalar['results'])==324791,'scalar aggregate')
 for row in scalar['results']:
  require(not row['vector_or_fp_matches']and row['instructions']>0,'scalar scan failure')
  for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/(P+'-scalar')/(row['name']+suffix))==row[key],'scalar bytes changed')
 require(host['run_status']=='complete'and host['checks_passed']and host['sources_unchanged_during_checks']and len(host['checks'])==46 and all(r['exit_code']==0 for r in host['checks']),'all current46 registered host checks')
 checks={r['id']:r for r in host['checks']};require(len(checks)==46,'unique host check IDs')
 for name,digest in host['source_sha256'].items():require(closure[name]==digest,('host source binding',name))
 obligations=host['obligations'];require(host['system_proven']is False and len(obligations)==30 and sum(v=='partial'for v in obligations.values())==28 and {k for k,v in obligations.items()if v=='open'}=={'EPOCH_COMMIT','DETERMINISTIC_REPLAY'},'honest Open2/Partial28 obligations')
 rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(r['log']).read_text())))for r in host['checks'])
 require(rust==3183,'exact3183 logged Rust test executions, not unique test count')
 scene=marker(Path(checks['display_scene']['log']).read_text(),'display.scene.host')
 require(scene['ok']and(scene['actual_cases'],scene['compiled_runtime_mutants'],scene['source_fence_controls'])==(12,6,2),'actual scene/lease host proof')
 for path,digest in scene['sha256'].items():require(Path(path).resolve().is_relative_to(R)and sha(path)==digest,('scene host source',path))
 groups_log=Path(checks['display_surface_groups']['log']).read_text();require(len(re.findall(r'test result: ok\. 49 passed; 0 failed;',groups_log))==1,'actual49 compositor cases')
 bitmap=marker(groups_log,'bitmap.stores.host');require(bitmap['ok']and(bitmap['actual_case_executions'],bitmap['future_case_executions'],bitmap['compiled_mutants_rejected'],bitmap['published_bytes'],bitmap['published_stores3_bytes'])==(17,17,5,9272,27816),'actual bitmap snapshot controls')
 frames=marker(Path(checks['display_frame_output']['log']).read_text(),'display.frame.output.host')
 require(frames['ok']and frames['cases']==dict(layout=7,store=8,va=6,paint_batch=8,pipeline=9)and(frames['compiled_runtime_mutants'],frames['paint_batch_runtime_mutants'],frames['compiler_trait_controls'],frames['source_controls'],len(frames['wiring']))==(6,3,4,6,9),'actual frame SDK/Store/VA/Main pipeline controls')
 for path,digest in frames['sha256'].items():require(Path(path).resolve().is_relative_to(R)and sha(path)==digest,('frame host source',path))
 cursor_log=Path(checks['display_cursor_output']['log']).read_text()
 require(len(re.findall(r'^\[display.cursor.output.host\] PASS actual_cases=5 compiled_runtime_mutants=2 overlay_source_controls=4 scope=actual_cursor_scene_target_pixels_host_background_menu_CPU_output_not_Main_receipts_or_hardware$',cursor_log,re.M))==1,'actual cursor output proof')
 py=(T/(P+'-frozen-python.log')).read_text();counts=re.findall(r'Ran (\d+) tests in ',py);require(counts==['1132']and py.rstrip().endswith('OK')and 'FAILED ('not in py,'exact1132 Python tests')
 baseline_path=T/'sexos-display-frames-a-frozen/source-binding.json';prior=read(baseline_path);prior_root=baseline_path.parent/'source'
 require(prior['build_provenance']['git_revision']==BASELINE and sha(baseline_path)==BASELINE_BINDING_SHA256,'qualified R167 reference binding only')
 current_keys=set(b['sources']);old_keys=set(prior['sources']);changed=sorted(n for n in current_keys&old_keys if b['sources'][n]!=prior['sources'][n]);added=sorted(current_keys-old_keys);removed=sorted(old_keys-current_keys)
 require(len(old_keys)==585 and changed==EXPECTED_CHANGED and added==EXPECTED_ADDED and not removed,'exact Main-only production change plus paint_batch addition')
 comparison=read(T/(P+'-production-equivalence.json'))
 for k,v in dict(ok=True,baseline_commit=BASELINE,candidate_commit=COMMIT,baseline_production=585,candidate_production=586,changed=changed,added=added,removed=[],unchanged=584,kernel_identical=True,baseline_kernel_sha256=prior['kernel_sha256'],candidate_kernel_sha256=b['kernel_sha256'],abi_inputs=67,prior_abi_inputs=67,abi_added_inputs=[],baseline_binding_sha256=BASELINE_BINDING_SHA256).items():require(comparison[k]==v,('production comparison',k))
 require(prior['kernel_sha256']==b['kernel_sha256']==EXPECTED_KERNEL,'exact unchanged kernel bytes; no native acceptance transfer')
 def abi_inputs(root,count):
  text=(root/'scripts/entrypoint_build.sh').read_text();found=re.findall(r'^ABI_INPUTS=\(\n(.*?)\n\)',text,re.M|re.S);require(len(found)==1,'exact ABI list');values=found[0].split();require(len(values)==len(set(values))==count,'exact ABI input count');return values
 names=abi_inputs(R,67);old_names=abi_inputs(prior_root,67)
 require(names==old_names,'unchanged ordered ABI67 input set')
 for name in names:require(sha(R/name)==sha(prior_root/name),('ABI input bytes changed',name))
 abi=hashlib.sha256(''.join(sha(R/n)+'  '+n+'\n'for n in names).encode()).hexdigest();require(abi==comparison['abi_sha256']==EXPECTED_ABI,'actual unchanged ABI67 hash')
 display=next(v for v in scalar['results']if v['name']=='sexdisplay')
 # Final budget schema is validated against actual scalar ELF/disassembly;
 # no total-stack/physical-free-frame conclusion follows from prologues.
 require(budget['ok']and budget['static_objects']==dict(RENDER_SCENE=59584,FRAME_OUTPUT=88) and budget['elf_sha256']==display['elf_sha256']and budget['elf_bytes']==display['elf_size']==286720,'current Display ELF and scene backing')
 require(budget['prior_elf_bytes']==285704 and budget['elf_byte_delta']==1016,'exact ELF size delta, not a performance claim')
 symbols=(T/(P+'-scalar/sexdisplay-symbols.txt')).read_text()
 def static_symbol(name,size):
  found=[line for line in symbols.splitlines()if re.search(r'\bO\s+\.\S+\s+([0-9a-fA-F]+)\s+\S*'+name+r'$',line)]
  require(len(found)==1,('exact ELF static symbol',name));match=re.search(r'\bO\s+\.\S+\s+([0-9a-fA-F]+)',found[0]);require(int(match[1],16)==size,('static symbol size',name));return found[0]
 scene_symbol=static_symbol('RENDER_SCENE',59584);output_symbol=static_symbol('FRAME_OUTPUT',88)
 require(budget['symbols']==dict(RENDER_SCENE=scene_symbol,FRAME_OUTPUT=output_symbol),'measured static symbol rows')
 candidate_assembly=(T/(P+'-scalar/sexdisplay.asm')).read_text();fences=[line for line in candidate_assembly.splitlines()if re.search(r'\bsfence\b',line)]
 require(fences and fences==budget['cpu_store_fence_instructions'],'decoded CPU store fence; no hardware latch inference')
 prior_scalar=read(T/'sexos-display-frames-a-scalar/result.json');require(prior_scalar['ok']and prior_scalar['commit']==BASELINE and prior_scalar['iso_sha256']==prior['iso_sha256'],'baseline budget-only scalar reference')
 old_display=next(v for v in prior_scalar['results']if v['name']=='sexdisplay')
 for suffix,key in [('.elf','elf_sha256'),('.asm','disassembly_sha256')]:require(sha(T/('sexos-display-frames-a-scalar/sexdisplay'+suffix))==old_display[key],'baseline Display budget reference bytes')
 require(budget['prior_elf_bytes']==old_display['elf_size'],'baseline ELF size')
 for label,prefix in [('candidate',P),('prior','sexos-display-frames-a')]:
  assembly=(T/(prefix+'-scalar/sexdisplay.asm')).read_text()
  expected_frames={'candidate':{'_start':4696,'raster_batch':2344,'render_prepared':1304},'prior':{'_start':4616,'raster_full':2296,'render_prepared':2008}}[label]
  require(set(budget['frames'][label])==set(expected_frames),'exact measured prologues only')
  for name,frame in budget['frames'][label].items():
   require(name in {'_start','raster_batch','render_prepared','raster_full'},('unexpected measured function',name))
   require(frame['local_reservation_bytes']==expected_frames[name] and frame['register_push_bytes']==48 and frame['prologue']and'\n'.join(frame['prologue'])in assembly,('prologue bytes no longer match bound disassembly',label,name))
 require(budget['app_private_pages']==2465 and budget['boot_heap']==dict(bytes=268435456,used=11851408,free=256584048,point='after_grant_seal',allocator_lock_released=True,physical_free_frames='unmeasured'),'exact heap receipt; do not infer disjoint/physical free memory')
 audit=read(T/(P+'-boot-audit.json'));rows=read(T/(P+'-native-progress.json'));planned=plan()
 require(len(rows)==8 and len(planned)==8,'all eight terminal workflows required')
 require((T/(P+'-native-suite.driver.log')).read_text().rstrip().endswith('EIGHT_NATIVE_WORKFLOWS_PASS_10_BOOTS_70_CAPTURES'),'current coordinator must finish successfully')
 expected={(T/(P+'-build/serial.log')).resolve()};geometry_by_path={next(iter(expected)):(1280,800)}
 for spec in planned:
  out=T/(P+'-native-'+spec['name'])
  paths={out.resolve()/phase/'serial.log'for phase in ('session','recovery')}if spec['kind']=='connected'else{out.resolve()/'serial.log'}
  expected|=paths
  for path in paths:geometry_by_path[path]=tuple(map(int,spec['resolution'].split('x')))
 require(audit['ok']and audit['mode']=='explicit_eleven_boot_inventory'and audit['boots']==audit['expected_final_boots']==11 and audit['final_cohort_complete'],'full eleven-boot audit, not smoke')
 require(audit['functional_acceptance_checked']is False and audit['kernel_equality_to_prior_image_asserted']is False,'BOOT inventory is not functional acceptance or prior-kernel equivalence')
 require(audit['frozen']['revision']==COMMIT and audit['frozen']['binding_sha256']==sha(F/'source-binding.json'),'BOOT audit binding')
 require(len(audit['observations'])==11 and {Path(o['path']).resolve()for o in audit['observations']}==expected,'exact eleven boot paths')
 for o in audit['observations']:
  require(Path(o['path']).stat().st_size==o['bytes']and sha(o['path'])==o['sha256'],'audited serial changed')
  require((o['apps'],o['registered_main_domains'],o['self_wait_capacity'],o['private_pages'])==(28,40,64,2465),'unchanged actual inventory')
  require(o['denial_storage']==dict(bytes=1352,owners=28,slots=84,bound=4096,public=1)and o['original_five_authority_lines_byte_identical'],'source authority/layout receipt')
  require(o['heap_budget']==budget['boot_heap'],'exact post-seal heap snapshot')
  width,height=geometry_by_path[Path(o['path']).resolve()];frame=width*4*height;span=(frame+4095)//4096*4096
  serial=Path(o['path']).read_text();tasks={int(m[1])for m in re.finditer(r'^task\.running id=(\d+) pd_id=1(?= )',serial,re.M)}
  require(len(tasks)==1 and next(iter(tasks))>0,'actual observed Display main, never inferred from PD')
  backing=dict(width=width,height=height,pitch=width*4,frame_bytes=frame,span_bytes=span,total_bytes=2*span,buddy_reserved_bytes=8388608,slot=98,region=11,buffers=2,holder_pd=1,holder_main_task=next(iter(tasks)),rights=7,no_peer=True,no_dma=True,zero_leaf_readback_before_seal=True,held_before_first_paint=True,authority_scope='PD-held; no exact-task isolation claim',physical_free_frames='unmeasured')
  require(o['display_frame_backing']==backing,'exact geometry-sized BOOT/held private frame evidence')
  if Path(o['path']).resolve()==(T/(P+'-build/serial.log')).resolve():require(budget['display_frame_backing']==backing,'budget uses sealed-build frame receipt only')
 # Retained current diagnostic is not a failed full host/native suite: its
 # actual compositor passed, then an obsolete external source finder failed.
 diagnostic=read(T/'sexos-r168-compositor-proof.json');diagnostic_log=(T/'sexos-r168-compositor.log').read_text()
 require(diagnostic['compositor_pass']and diagnostic['compositor_tests']==49 and diagnostic['preserved_tests']==46 and diagnostic['new_combined_tests']==3 and diagnostic['full_gate_pass']is False,'exact compositor preflight diagnostic')
 require('tests/display_bitmap_transaction.rs:267'in diagnostic_log and '16 passed; 1 failed;'in diagnostic_log and 'production_uses_owned_live_route_both_paint_branches_and_terminal_cleanup'in diagnostic_log,'retain obsolete external finder failure, no acceptance transfer')
 proofs={};capture_counts={};memory_receipts={};outdirs={};replays=[]
 for spec,row in zip(planned,rows):
  out=(T/(P+'-native-'+spec['name'])).resolve(strict=True);outdirs[spec['name']]=out
  require(row['name']==spec['name']and row['kind']==spec['kind']and Path(row['out']).resolve()==out and row['status']==0 and row['fresh_replay']is True and row['boots']==spec['boots']and row['captures']==spec['captures'],'exact terminal workflow row')
  command=['python3',str(R/'scripts'/spec['script']),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--source-disk',str(T/'sexos-r100a-seed.img'),'--out',str(T/(P+'-native-'+spec['name'])),'--model',spec['model'],'--resolution',spec['resolution'],*spec['extra']]
  require(row['command']==command,'exact native invocation source/image/profile')
  check=command[:];at=check.index('--source-disk');del check[at:at+2];check+=['--check']
  replay=T/(P+'-native-'+spec['name']+'-independent-replay.json');require(Path(row['replay']).resolve()==replay.resolve(strict=True),'exact saved replay path')
  run=subprocess.run(check,capture_output=True,text=True,timeout=300,env=ENV);require(run.returncode==0,('fresh frozen read-only replay',spec['name'],run.stderr[-2000:]))
  fresh=json.loads(run.stdout);saved=read(replay);result=read(out/'result.json');require(fresh==saved and fresh['ok']and result['ok'],'saved/current replay disagreement');replays.append(replay)
  manifests=[read(out/phase/'manifest.json')for phase in ('session','recovery')]if spec['kind']=='connected'else[read(out/'manifest.json')]
  for manifest in manifests:require(manifest['resolution']==spec['resolution']and manifest['model']==spec['model'],'native profile metadata')
  manifest=manifests[0]
  if spec['kind']=='clock':
   require(manifest['mode']==spec['mode']and fresh==dict(ok=True,mode=spec['mode'],captures=4),'exact clock CLI summary')
   code="import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;r=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(r/'scripts'));from certificate_time_gate import replay_evidence;print(json.dumps(replay_evidence(r,Path(sys.argv[2]).resolve(strict=True),Path(sys.argv[3]).resolve(strict=True),Path(sys.argv[4]).resolve(strict=True))))"
   api=subprocess.run(['python3','-c',code,str(R),str(F/'tested.iso'),str(F/'source-binding.json'),str(out)],capture_output=True,text=True,timeout=300,env=ENV);require(api.returncode==0,('full clock replay API',spec['name'],api.stderr[-2000:]));full=json.loads(api.stdout)
   require({n:full[n]for n in('ok','mode','captures')}==fresh and len(full['pixels'])==len(result['pixels'])==4 and all(p['ok']and p['civil_clock']['ok']and p['civil_clock']['caption_profile']=='date-caption-v1'for p in full['pixels']),'four independently replayed full clock/chip pixels')
   fresh=full;memory_receipts['fresh-full-clock/'+spec['name']+'.json']=(json.dumps(full,indent=2,sort_keys=True)+'\n').encode()
  elif spec['kind']=='connected':require(fresh['boots']==2 and fresh['frames']==17 and fresh['same_image']and fresh['same_disk_state']and fresh['full_alpha_acceptance']is False,'representative connected two-boot proof')
  else:
   require(result['mode']=='quiesced'and len(result['frames'])==10 and fresh['captures']==10 and fresh['browser_pixels_qualified']and fresh['launcher_pixels_qualified'],'three held Browser incarnations, nine TLS panels and exhaustion capture')
   require([v['identity']['target']for v in result['chain']]==[15,30,31],'exact current Browser chain')
  proofs[spec['name']]=fresh;capture_counts[spec['name']]=spec['captures']
 require(sum(r['boots']for r in rows)==10 and sum(capture_counts.values())==70,'exact10 native boots/70 captures plus sealed boot')
 # All acceptance preconditions above precede archive creation. Normalized tar
 # metadata/gzip header make repeat construction from identical inputs stable.
 items={}
 def add(name,path):
  path=Path(path);member=PurePosixPath(name);require(not member.is_absolute()and '..'not in member.parts and name not in items,'unsafe/duplicate archive member')
  require(path.is_file()and not path.is_symlink()and path.suffix!='.img',(name,path));items[name]=path
 def tree(prefix,folder):
  folder=Path(folder);require(folder.is_dir(),folder)
  for path in sorted(folder.rglob('*')):
   if path.is_file()and path.suffix!='.img'and '__pycache__'not in path.parts:add(prefix+'/'+str(path.relative_to(folder)),path)
 for name,folder in [('frozen',F),('sealed-build',T/(P+'-build')),('host',T/(P+'-frozen-host')),('scalar',T/(P+'-scalar'))]:tree('qualified/'+name,folder)
 for name,out in outdirs.items():tree('qualified/native/'+name,out)
 diagnostic_names={Path(name).name for name in UNQUALIFIED_DIAGNOSTIC_SHA256}
 for path in sorted(T.glob(P+'-*')):
  if path.is_file()and path.suffix in('.json','.log','.py','.sh','.txt')and path!=receipt_path and not(path.name.startswith(P+'-package')and path.suffix=='.log'):
   prefix='UNQUALIFIED/preflight'if path.name in diagnostic_names or 'preflight'in path.name else'coordination'
   add(prefix+'/'+path.name,path)
 for path in EXECUTED_HELPER_SHA256:add('executed-helpers/'+Path(path).name,path)
 for path in UNQUALIFIED_DIAGNOSTIC_SHA256:add('UNQUALIFIED/pinned-preflight/'+Path(path).name,path)
 for path in replays:add('fresh-checks/'+path.name,path)
 add('reference/R167-source-binding.json',baseline_path)
 for name in ('result.json','sexdisplay.elf','sexdisplay.asm'):add('reference/R167-budget-only/'+name,T/'sexos-display-frames-a-scalar'/name)
 require(sha(audit['reference']['path'])==audit['reference']['sha256'],'original authority reference changed');add('reference/original-authority.serial.log',audit['reference']['path'])
 summary=dict(ok=True,round=168,source_commit=COMMIT,source_binding_sha256=sha(F/'source-binding.json'),iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],host=dict(registered=46,rust_log_test_executions=rust,python_tests=1132,scene=scene,bitmap=bitmap,frame_output=frames,cursor=dict(actual_cases=5,compiled_runtime_mutants=2,source_controls=4),compositor_cases=49),source=dict(files=1224,bytes=12217001),scalar=dict(elfs=9,instructions=324791,vector_fp_matches=0),budget=budget,production_comparison=comparison,native=dict(boots=11,sealed_build_boots=1,native_boots=10,clock_boots=4,connected_boots=4,browser_boots=2,capture_counts=capture_counts,qualified_captures=70,proofs=proofs,alpha_acceptance=False,sustained_acceptance=False,complete_all_app_reserves=False),boot_observations=audit['observations'],obligations=obligations,system_proven=False,executed_helpers=EXECUTED_HELPER_SHA256,diagnostics=dict(compositor_preflight='UNQUALIFIED external legacy test267 source finder:49 actual compositor cases passed, then16/17 bitmap cases; final frozen registered gate independently required to pass'),frame_storage=dict(scene_static_bytes=59584,frame_store_static_bytes=88,physical_buddy_bytes_per_boot=8388608,authority='PD-held Region54/55; all tasks in Display PD share authority'),scope='Retained bounded dirty-work plan, one captured Display scene/Target/publication for each completed batch, and receipt-driven lifecycle completion; raw producer intake remains mutable and Dirty is not a causal input stream. Display-owned private preparation and complete checked CPU publication with scoped scene release; not hardware latch/vblank, complete epochs or deterministic replay. Native evidence: clock/date, representative connected session/cold recovery, and Browser15→30→31 quiesced Close/panel/exhaustion controls. No Alpha/1800-second, full all-app reserve chain, performance speedup, hardware/SMP/hostile isolation, exact-task isolation or physical erasure claim. Region54/55 authority is PD-held; no new capkind, runtime mint or kernel allocation policy. Stack measurements cover explicit prologues only; app pages and Display backing are not additive disjoint memory totals. Earlier images transfer no native acceptance.')
 # Recheck source/image and audited raw logs after the read-only replays,
 # before constructing any archive. Archive reopen also checks every member.
 require(sha(F/'tested.iso')==b['iso_sha256']and sha(F/'tested.kernel')==b['kernel_sha256'],'image changed during replay')
 require(read(F/'source-binding.json')==b and sha(baseline_path)==BASELINE_BINDING_SHA256,'source bindings changed during replay')
 for name,digest in closure.items():require(sha(R/name)==digest,('source changed during replay',name))
 for o in audit['observations']:require(sha(o['path'])==o['sha256']and Path(o['path']).stat().st_size==o['bytes'],'audited serial changed during replay')
 for path,digest in {**EXECUTED_HELPER_SHA256,**UNQUALIFIED_DIAGNOSTIC_SHA256}.items():require(sha(path)==digest,('pinned evidence changed during replay',path))
 manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path))for name,path in items.items()}
 embedded={**memory_receipts,'COHORT.json':(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode(),'SCOPE.md':b'Round168: eleven explicit boots and seventy captures only after fresh frozen replay. Open2/Partial28. R167 binding/Display ELF references support source/kernel/budget comparison, not acceptance transfer. Kernel and ABI unchanged; current native image must qualify independently. Current obsolete external compositor-fixture diagnostic remains UNQUALIFIED; no failed full-suite/build/native or BOOT-parser/resume flow. Dirty is a bounded output obligation plan, not causal input capture. Intake remains mutable; no whole-system epoch or replay completion. Two private frames remain held by the Display PD, not isolated per task. Complete CPU copy is not a hardware flip/latch. No Alpha/1800s/performance/hardware/full-epoch claim.\n'}
 for name,data in embedded.items():require(name not in manifest,'embedded member collision');manifest[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
 with archive.open('xb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9)as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT)as tar:
  for name in sorted(set(items)|set(embedded)|{'MANIFEST.json'}):
   info=tarfile.TarInfo(name);info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
   if name in items:
    info.size=manifest[name]['bytes']
    with items[name].open('rb')as stream:tar.addfile(info,stream)
   else:payload=data if name=='MANIFEST.json'else embedded[name];info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();require(len(members)==len(manifest)+1 and all(m.isfile()for m in members),'archive member count/type')
  require({m.name for m in members}==set(manifest)|{'MANIFEST.json'},'exact archive names');require(tar.extractfile('MANIFEST.json').read()==data,'manifest reopen')
  for name,meta in manifest.items():
   payload=tar.extractfile(name).read();require(len(payload)==meta['bytes']and hashlib.sha256(payload).hexdigest()==meta['sha256'],('archive member changed',name))
 for name,path in items.items():require(path.stat().st_size==manifest[name]['bytes']and sha(path)==manifest[name]['sha256'],('input changed during packaging',name))
 receipt=dict(ok=True,archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_reopened_verified=True,cohort=summary)
 with receipt_path.open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
