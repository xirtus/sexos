from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-alpha-evidence-a-frozen';O=T/'sexos-alpha-evidence-a-compact-rehearsal'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');v=read(T/'sexos-alpha-evidence-a-compact-independent-replay.json');h=read(T/'sexos-alpha-evidence-a-host42/report.json');result=read(O/'result.json');assert v['ok']and v['acceptance']is False and v['verified_captures']==20 and h['checks_passed']and len(h['checks'])==42 and not h['source_drift'];assert 'Ran 902 tests in 'in(T/'sexos-alpha-evidence-a-python.log').read_text();assert read(T/'sexos-alpha-evidence-a-production-equivalence.json')['ok']
for n,d in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==d,n
assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
items={}
def add(name,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and name not in items;items[name]=p

def tree(prefix,root):
 for p in sorted(Path(root).rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('rehearsal',O);tree('host',T/'sexos-alpha-evidence-a-host42')
# Never archive the live1800s tree or its changing log/index as terminal data.
for name in ['sexos-alpha-evidence-a-python.log','sexos-alpha-evidence-a-host42-driver.log','sexos-alpha-evidence-a-compact-rehearsal-driver.log','sexos-alpha-evidence-a-compact-independent-replay.json','sexos-alpha-evidence-a-production-equivalence.json','sexos-alpha-evidence-preflight-final.log']:
 add('coordination/'+name,T/name)
add('coordination/package.py',Path(__file__));manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-alpha-evidence-rehearsal-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for name,p in sorted(items.items()):tar.add(p,arcname=name,recursive=False)
 entry=tarfile.TarInfo('payload-members.json');entry.mode=0o644;entry.size=len(raw);tar.addfile(entry,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  data=tar.extractfile(m).read();expected=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256']
d=dict(implementation_and_rehearsal_qualified=True,sustained_alpha_accepted=False,goal_complete=False,branch='codex/alpha-evidence',base='73c06c82460f79032446e33dcc67976b2599edb5',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),production_equivalence=read(T/'sexos-alpha-evidence-a-production-equivalence.json'),registered_host_checks=42,rust_test_executions=2628,python_tests=902,native_rehearsal=dict(boots=1,verified_captures=20,resolution='1024x768',acceptance=False,cycles=1,active_elapsed_seconds=result['soak']['active_elapsed_seconds'],elapsed_seconds=result['soak']['elapsed_seconds'],boot_successors=result['soak']['boot_successors'],terminal_quil_scope=result['soak']['quil_close']['terminal_scope'],remaining_obligations=result['soak']['remaining_obligations'],independent_replay=True),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(raw).hexdigest(),all_members_size_and_sha256_verified=True),release_gates=dict(open=2,partial=28,system_proven=False),scope='Same qualified production image, new frozen runner inputs. Unique immutable capture names/prefix hashes, exact glyphs including civil clock, explicit RTC and source binding, terminal disk captured after QEMUexit, honest pending-attempt vs terminal-close facts. Short rehearsal proves workflow/replay, not1800s alpha. The separately running compact1800s output is intentionally excluded.')
p=A/'sexos-alpha-evidence-rehearsal-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print('ARCHIVE',len(items)+1,'members',archive.stat().st_size,'bytes, all size/hash verified; short rehearsal not sustained acceptance')
