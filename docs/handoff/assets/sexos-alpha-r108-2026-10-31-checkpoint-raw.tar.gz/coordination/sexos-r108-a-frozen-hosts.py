from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,os,re,subprocess,time
F=Path('/tmp/sexos-alpha-r108-connected-a-frozen');R=F/'source';T=Path('/tmp');P=T/'sexos-r108-a-frozen-host-progress.json';assert not P.exists();B=F/'source-binding.json';start=hashlib.sha256(B.read_bytes()).hexdigest();rows=[]
names=['service_custody_host_gate','display_surface_groups_gate','display_text_readability_gate','launcher_host_gate','linen_text_delivery_gate','sexdrive_dma_host_gate']
def run(name):
 log=T/('sexos-r108-a-frozen-'+name+'.log');assert not log.exists();began=time.monotonic()
 with log.open('w')as stream:r=subprocess.run(['bash',str(R/'scripts'/(name+'.sh'))],cwd=R,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','BROWSER_ASSET_FENCE_NEGATIVE_LOG':str(T/'sexos-r108-a-fence-negative.log')})
 text=log.read_text();return dict(gate=name,exit_code=r.returncode,seconds=time.monotonic()-began,log=str(log),rust_executions=sum(int(n)for n in re.findall(r'test result: ok\. (\d+) passed;',text)),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with ThreadPoolExecutor(max_workers=3)as pool:
 for future in as_completed([pool.submit(run,n)for n in names]):
  row=future.result();rows.append(row);P.write_text(json.dumps(rows,indent=2)+'\n');print(row['gate'],row['exit_code'],row['rust_executions'],flush=True)
assert len(rows)==6 and all(r['exit_code']==0 for r in rows)
assert hashlib.sha256(B.read_bytes()).hexdigest()==start
print('ALL6_FROZEN_HOST_GATES_PASS',sum(r['rust_executions']for r in rows),flush=True)
