from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/Projects/Sex');F=T/'sexos-alpha-r108-connected-b-frozen';A=R/'docs/handoff/assets'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=read(F/'source-binding.json');assert b['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for n,v in {**b['sources'],**b['runner_sha256']}.items():assert sha(F/'source'/n)==sha(R/n)==v,n
hosts=read(T/'sexos-r108-a-frozen-host-progress.json');assert len(hosts)==6 and all(r['exit_code']==0 for r in hosts)and sum(r['rust_executions']for r in hosts)==2104
for tag,count in [('a',833),('b',836)]:
 text=(T/('sexos-r108-'+tag+'-frozen-python.log')).read_text();assert re.search(r'Ran '+str(count)+r' tests in ',text)and text.rstrip().endswith('OK')
assert read(T/'sexos-r108-a-b-source-equivalence.json')['ok'];assert read(T/'sexos-r108-a-native-connected-wide/session/result.json')['ok']is False
assert read(T/'sexos-r108-a-launcher-antecedent-diagnostic.json')['accepted']is False
scalar=read(T/'sexos-r108-a-scalar/result.json');assert scalar['ok']and scalar['iso_sha256']==b['iso_sha256']and scalar['results'][0]['instructions']==91044
items={};disks=[]
def add(name,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and name not in items;items[name]=p

def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*.img')):
  owner=subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True);assert not owner.stdout.strip(),str(p)
  raw=p.read_bytes();z=p.with_name(p.name+'.gz')
  if not z.exists():
   with z.open('xb')as stream:
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0)as compressed:compressed.write(raw)
  assert gzip.decompress(z.read_bytes())==raw;disks.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=sha(z)))
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for label,folder in [('frozen-a','sexos-alpha-r108-connected-a-frozen'),('frozen-b','sexos-alpha-r108-connected-b-frozen'),('build-a','sexos-alpha-r108-connected-a-build'),('native-a-diagnostic','sexos-r108-a-native-connected-wide'),('scalar','sexos-r108-a-scalar')]:tree(label,T/folder)
for p in sorted(T.glob('sexos-r108-*')):
 if p.is_file()and p.suffix in('.py','.log','.json'):add('coordination/'+p.name,p)
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();digest=hashlib.sha256(raw).hexdigest();archive=A/'sexos-alpha-r108-2026-10-31-checkpoint-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(raw);m.mode=0o644;tar.addfile(m,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len(set(m.name for m in members))==len(members)
 for m in members:
  data=tar.extractfile(m).read();expected=dict(bytes=len(raw),sha256=digest)if m.name=='payload-members.json'else manifest[m.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],m.name
result=dict(checkpoint_verified=True,round=108,round_accepted=False,goal_status='active',accepted_rounds='80-107',accepted_count=28,remaining_rounds='108-200',remaining_count=93,build='GREEN_MASTER',production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),rust_executions=2104,python_a=833,python_b=836,compiled_guard_controls_rejected=2,native_acceptance=False,native_diagnostic=dict(original_ok=False,reason='checker demanded previous launcher before any launcher Open',raw_unchanged=True,corrected_guard_diagnostic_accepted=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=digest,all_members_size_and_sha256_verified=True,disks=disks),release_gates=dict(open=7,partial=23,system_proven=False),scope='Tested implementation checkpoint at explicit user commit/push request. Native A failed; corrected B native qualification remains pending. No completed108, alpha, hostile-containment, physical/SMP, crash/power-loss or general daily-driver claim.')
p=A/'sexos-alpha-r108-2026-10-31-checkpoint-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in('checkpoint_verified','round_accepted','iso_sha256','binding_sha256')}));print('archive',archive.stat().st_size,'bytes',len(items)+1,'verified members')
