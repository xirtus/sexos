from pathlib import Path
import re,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);source=(root/'servers/sexdisplay/src/main.rs').read_text();parts=[]
for name in ['module_rect','ascii_glyph_index','civil_clock_lines','civil_clock_fg_at','civil_clock_drawn','clock_fg_at','handle_civil_clock_update','clock_canon_apply_to_bar']:
    values=re.findall(r'^fn '+name+r'\b.*?^\}',source,re.M|re.S);assert len(values)==1,name;parts+=values
for name in ['FONT','FONT_ASCII_5X7']:
    values=re.findall(r'^const '+name+r':.*?^\];',source,re.M|re.S);assert len(values)==1,name;parts+=values
for name in ['CLOCK_CANON_HH','CLOCK_CANON_MM','CLOCK_CANON_SS']:
    values=re.findall(r'^static mut '+name+r':.*?;',source,re.M);assert len(values)==1,name;parts+=values
# The actual event-loop dispatch selects the strict boundary before narrowing,
# and every canonical/demo path is gated off for ordinary civil presentation.
arm=source.split('silkbar_model::OP_SILKBAR_UPDATE => {',1)[1].split('                0x11 =>',1)[0]
assert arm.index('handle_civil_clock_update(')<arm.index('handle_silkbar_update(')
assert 'msg.caller_pd,msg.caller_task,[msg.arg0,msg.arg1,msg.arg2]'in arm
assert 'if bar.civil_enabled && msg.arg0 as u32==UpdateKind::SetClock as u32{continue;}'in arm
assert 'if !bar.civil_enabled && !clock_from_silkbar {'in source
assert 'bar.civil_enabled=option_env!("SEXOS_LEGACY_DEMO_CLOCK").is_none();'in source
assert 'bar.civil_clock.health(raw_ticks)'in source
composer=re.findall(r'^fn top_strip_pixel\b.*?^\}',source,re.M|re.S);assert len(composer)==1 and 'clock_fg_at(x, y, bar)'in composer[0]
assert source.count('top_strip_pixel(x, y, bar)')==2
for name,path in [('render','full'),('redraw_top_strip','strip')]:
    actual=re.findall(r'^fn '+name+r'\b.*?^\}',source,re.M|re.S);assert len(actual)==1
    assert actual[0].index('core::ptr::write_volatile(')<actual[0].index('civil_clock_drawn(bar,w,h,"'+path+'")')
    assert actual[0].index('draw_launcher_panel(')<actual[0].index('civil_clock_drawn(bar,w,h,"'+path+'")')
(out/'display.rs').write_text('\n'.join(parts)+'\n')
# Mutate the real receiver, not a substitute host implementation. The focused
# authority regression must reject a model with its nonzero wrong-task guard removed.
(out/'lib.rs').write_text((root/'crates/silkbar-model/src/lib.rs').read_text())
civil=(root/'crates/silkbar-model/src/civil_clock.rs').read_text();assert '||caller!=expected'in civil
(out/'civil_clock.rs').write_text(civil.replace('||caller!=expected','',1))
fixture=(root/'tests/silkbar_civil_clock.rs').read_text().replace('../crates/sex-pdx/src/clock_source.rs',str(root/'crates/sex-pdx/src/clock_source.rs')).replace('../crates/sex-pdx/src/desktop_style.rs',str(root/'crates/sex-pdx/src/desktop_style.rs'))
(out/'mutant.rs').write_text(fixture.replace('../crates/silkbar-model/src/lib.rs',str(out/'lib.rs')))
