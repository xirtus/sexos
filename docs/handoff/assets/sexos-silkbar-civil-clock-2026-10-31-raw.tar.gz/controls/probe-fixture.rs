// SPDX-License-Identifier: GPL-3.0-only
extern crate self as sex_pdx;
#[path="/private/tmp/sexos-silkbar-clock-b-frozen/source/crates/sex-pdx/src/clock_source.rs"]pub mod clock_source;
#[path="/tmp/sexos-silkbar-clock-controls/probe-mutant.rs"]mod civil_clock;
