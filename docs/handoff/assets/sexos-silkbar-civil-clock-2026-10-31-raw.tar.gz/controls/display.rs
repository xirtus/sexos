fn module_rect(bar: &SilkBar, slot: ModuleSlot) -> (usize, usize, usize, usize) {
    let lb = &bar.layout[slot as usize];
    (lb.x, lb.y, lb.w, lb.h)
}
fn ascii_glyph_index(byte: u8) -> Option<usize> {
    use sex_pdx::desktop_style::{ASCII_FIRST, ASCII_LAST};
    (ASCII_FIRST..=ASCII_LAST).contains(&byte).then(|| (byte - ASCII_FIRST) as usize)
}
fn civil_clock_lines(clock:&silkbar_model::civil_clock::CivilClock)->[[u8;13];2]{
    use silkbar_model::civil_clock::State;
    let mut lines=[[b' ';13];2];
    let (first,second):(&[u8],&[u8])=match clock.state(){
        State::Snapshot=>(b"UTC 00:00:00",b"q35 1s snap"),
        State::Rollback=>(b"UTC blocked",b"q35 1s stop"),
        State::Exhausted=>(b"UTC ended",b"src? prec?"),
        State::Unavailable=>(b"UTC unknown",b"q35 1s fail"),
        State::Unknown if clock.is_stale()=>(b"UTC stale",b"q35 1s old"),
        State::Unknown=>(b"UTC unknown",b"src? prec?"),
    };
    lines[0][..first.len()].copy_from_slice(first);lines[1][..second.len()].copy_from_slice(second);
    if clock.state()==State::Snapshot{
        let day=clock.seconds()%86_400;
        for(at,value)in[(4,day/3600),(7,day/60%60),(10,day%60)]{
            lines[0][at]=b'0'+(value/10)as u8;lines[0][at+1]=b'0'+(value%10)as u8;
        }
    }
    lines
}
fn civil_clock_fg_at(x:usize,y:usize,bar:&SilkBar)->Option<u32>{
    let(cx,cy,cw,ch)=module_rect(bar,ModuleSlot::Clock);
    if x<cx||x>=cx+cw||y<cy||y>=cy+ch{return None;}
    let row=if (cy+1..cy+8).contains(&y){0}else if(cy+11..cy+18).contains(&y){1}else{return None;};
    let col=(x-cx)/6;let px=(x-cx)%6;if col>=13||px>=5{return None;}
    let lines=civil_clock_lines(&bar.civil_clock);let glyph=ascii_glyph_index(lines[row][col])?;
    let py=y-(cy+if row==0{1}else{11});
    ((FONT_ASCII_5X7[glyph][py]>>(4-px))&1!=0).then_some(DEFAULT_THEME.text)
}
fn civil_clock_drawn(bar:&SilkBar,w:usize,h:usize,path:&str){
    use silkbar_model::civil_clock::State;
    if !bar.civil_enabled{return;}
    let(x,y,cw,ch)=module_rect(bar,ModuleSlot::Clock);
    if x.checked_add(cw).map_or(true,|right|right>w)||y.checked_add(ch).map_or(true,|bottom|bottom>h){return;}
    let clock=&bar.civil_clock;
    let stamp=(clock.sequence(),clock.state(),clock.seconds(),clock.is_stale(),w,h);
    static mut LAST_CIVIL_DRAW:Option<(u32,State,u32,bool,usize,usize)>=None;
    unsafe{
        if LAST_CIVIL_DRAW==Some(stamp){return;}
        LAST_CIVIL_DRAW=Some(stamp);
    }
    sex_pdx::serial_record!("[display.civil.draw] sequence={} state={:?} seconds={} stale={} pixels=written path={} x={} y={} w={} h={}",clock.sequence(),clock.state(),clock.seconds(),clock.is_stale()as u8,path,x,y,cw,ch);
}
fn clock_fg_at(x: usize, y: usize, bar: &SilkBar) -> Option<u32> {
    if bar.civil_enabled {return civil_clock_fg_at(x,y,bar);}
    const CLOCK_FG: u32 = DEFAULT_THEME.text;
    const CLOCK_PREFIX:&[u8]=b"DEMO ";
    const CLOCK_DIGIT_OFFSET:usize=30;
    let (cx, cy, _, _) = module_rect(bar, ModuleSlot::Clock);
    let cy = cy + 1; // slight inset into chip area

    // Quick bounding-box reject
    if y < cy || y >= cy + 7 {
        return None;
    }
    if x < cx || x > cx + CLOCK_DIGIT_OFFSET + 45 {
        return None;
    }
    // Both the SilkBar producer and display fallback advance a software
    // demonstration counter. Neither is wall time or a certificate UTC source.
    if x<cx+CLOCK_DIGIT_OFFSET{
        let col=(x-cx)/6;let px=(x-cx)%6;
        if px>=5{return None;}
        let glyph=ascii_glyph_index(*CLOCK_PREFIX.get(col)?)?;
        return ((FONT_ASCII_5X7[glyph][y-cy]>>(4-px))&1!=0).then_some(CLOCK_FG);
    }
    let cx=cx+CLOCK_DIGIT_OFFSET;

    // Colon 1 at offset 14, Colon 2 at offset 31
    if x == cx + 14 || x == cx + 31 {
        if y == cy + 1 || y == cy + 5 {
            return Some(CLOCK_FG);
        }
        return None;
    }

    // Digit offsets: 0, 7, 17, 24, 34, 41
    const DIGITS: [usize; 6] = [0, 7, 17, 24, 34, 41];
    for (di, &dx) in DIGITS.iter().enumerate() {
        if x < cx + dx || x >= cx + dx + 5 {
            continue;
        }
        let col = x - (cx + dx);
        let row = y - cy;
        let digit: usize = match di {
            0 => (bar.clock_hh / 10) as usize,
            1 => (bar.clock_hh % 10) as usize,
            2 => (bar.clock_mm / 10) as usize,
            3 => (bar.clock_mm % 10) as usize,
            4 => (bar.clock_ss / 10) as usize,
            5 => (bar.clock_ss % 10) as usize,
            _ => return None,
        };
        if (FONT[digit][row] >> (4 - col)) & 1 != 0 {
            return Some(CLOCK_FG);
        }
        return None; // digit background pixel
    }
    None
}
fn handle_civil_clock_update(bar:&mut SilkBar,caller_pd:u32,caller_task:u32,args:[u64;3],now:u64)
    ->Result<silkbar_model::civil_clock::Applied,silkbar_model::civil_clock::Reject>{
    use silkbar_model::civil_clock::Reject;
    let expected=sex_pdx::clock_source::STATUS_BAR;
    let min=u32::try_from(sex_pdx::clock_source::MIN_SECONDS).map_err(|_|Reject::Framing)?;
    let max=u32::try_from(sex_pdx::clock_source::MAX_SECONDS).map_err(|_|Reject::Framing)?;
    let result=bar.civil_clock.receive((caller_pd,caller_task),(expected.pd,expected.task),args,min,max,now);
    if result.is_ok(){bar.civil_enabled=true;}
    result
}
fn clock_canon_apply_to_bar(bar: &mut SilkBar) {
    if bar.civil_enabled {return;}
    unsafe {
        bar.clock_hh = CLOCK_CANON_HH;
        bar.clock_mm = CLOCK_CANON_MM;
        bar.clock_ss = CLOCK_CANON_SS;
    }
}
const FONT: [[u8; 7]; 10] = [
    [0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110],
    [0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110],
    [0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b01000, 0b11111],
    [0b01110, 0b10001, 0b00001, 0b00110, 0b00001, 0b10001, 0b01110],
    [0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010],
    [0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110],
    [0b00110, 0b01000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110],
    [0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000],
    [0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110],
    [0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00010, 0b01100],
];
const FONT_ASCII_5X7: [[u8; 7]; 95] = [
    [0, 0, 0, 0, 0, 0, 0], // ASCII 32
    [4, 4, 4, 4, 4, 0, 4], // ASCII 33
    [10, 10, 10, 0, 0, 0, 0], // ASCII 34
    [10, 10, 31, 10, 31, 10, 10], // ASCII 35
    [4, 15, 20, 14, 5, 30, 4], // ASCII 36
    [25, 26, 2, 4, 8, 11, 19], // ASCII 37
    [12, 18, 18, 12, 21, 18, 13], // ASCII 38
    [12, 4, 8, 0, 0, 0, 0], // ASCII 39
    [2, 4, 8, 8, 8, 4, 2], // ASCII 40
    [8, 4, 2, 2, 2, 4, 8], // ASCII 41
    [0, 4, 21, 14, 21, 4, 0], // ASCII 42
    [0, 4, 4, 31, 4, 4, 0], // ASCII 43
    [0, 0, 0, 0, 12, 4, 8], // ASCII 44
    [0, 0, 0, 31, 0, 0, 0], // ASCII 45
    [0, 0, 0, 0, 0, 12, 12], // ASCII 46
    [1, 2, 2, 4, 8, 8, 16], // ASCII 47
    [14, 17, 19, 21, 25, 17, 14], // ASCII 48
    [4, 12, 4, 4, 4, 4, 14], // ASCII 49
    [14, 17, 1, 2, 4, 8, 31], // ASCII 50
    [14, 17, 1, 6, 1, 17, 14], // ASCII 51
    [2, 6, 10, 18, 31, 2, 2], // ASCII 52
    [31, 16, 30, 1, 1, 17, 14], // ASCII 53
    [6, 8, 16, 30, 17, 17, 14], // ASCII 54
    [31, 1, 2, 4, 8, 8, 8], // ASCII 55
    [14, 17, 17, 14, 17, 17, 14], // ASCII 56
    [14, 17, 17, 15, 1, 2, 12], // ASCII 57
    [0, 12, 12, 0, 12, 12, 0], // ASCII 58
    [0, 12, 12, 0, 12, 4, 8], // ASCII 59
    [2, 4, 8, 16, 8, 4, 2], // ASCII 60
    [0, 0, 31, 0, 31, 0, 0], // ASCII 61
    [8, 4, 2, 1, 2, 4, 8], // ASCII 62
    [14, 17, 1, 2, 4, 0, 4], // ASCII 63
    [14, 17, 19, 21, 19, 16, 14], // ASCII 64
    [14, 17, 17, 31, 17, 17, 17], // ASCII 65
    [30, 17, 17, 30, 17, 17, 30], // ASCII 66
    [14, 17, 16, 16, 16, 17, 14], // ASCII 67
    [30, 17, 17, 17, 17, 17, 30], // ASCII 68
    [31, 16, 16, 30, 16, 16, 31], // ASCII 69
    [31, 16, 16, 30, 16, 16, 16], // ASCII 70
    [14, 17, 16, 23, 17, 17, 14], // ASCII 71
    [17, 17, 17, 31, 17, 17, 17], // ASCII 72
    [14, 4, 4, 4, 4, 4, 14], // ASCII 73
    [7, 1, 1, 1, 1, 17, 14], // ASCII 74
    [17, 18, 20, 24, 20, 18, 17], // ASCII 75
    [16, 16, 16, 16, 16, 16, 31], // ASCII 76
    [17, 27, 21, 21, 17, 17, 17], // ASCII 77
    [17, 25, 21, 19, 17, 17, 17], // ASCII 78
    [14, 17, 17, 17, 17, 17, 14], // ASCII 79
    [30, 17, 17, 30, 16, 16, 16], // ASCII 80
    [14, 17, 17, 17, 21, 18, 13], // ASCII 81
    [30, 17, 17, 30, 20, 18, 17], // ASCII 82
    [14, 17, 16, 14, 1, 17, 14], // ASCII 83
    [31, 4, 4, 4, 4, 4, 4], // ASCII 84
    [17, 17, 17, 17, 17, 17, 14], // ASCII 85
    [17, 17, 17, 17, 17, 10, 4], // ASCII 86
    [17, 17, 17, 21, 21, 27, 17], // ASCII 87
    [17, 17, 10, 4, 10, 17, 17], // ASCII 88
    [17, 17, 10, 4, 4, 4, 4], // ASCII 89
    [31, 1, 2, 4, 8, 16, 31], // ASCII 90
    [14, 8, 8, 8, 8, 8, 14], // ASCII 91
    [16, 8, 8, 4, 2, 2, 1], // ASCII 92
    [14, 2, 2, 2, 2, 2, 14], // ASCII 93
    [4, 10, 17, 0, 0, 0, 0], // ASCII 94
    [0, 0, 0, 0, 0, 0, 31], // ASCII 95
    [8, 4, 2, 0, 0, 0, 0], // ASCII 96
    [0, 0, 14, 1, 15, 17, 15], // ASCII 97
    [16, 16, 30, 17, 17, 17, 30], // ASCII 98
    [0, 0, 14, 16, 16, 16, 14], // ASCII 99
    [1, 1, 15, 17, 17, 17, 15], // ASCII 100
    [0, 0, 14, 17, 31, 16, 14], // ASCII 101
    [6, 9, 8, 28, 8, 8, 8], // ASCII 102
    [0, 0, 15, 17, 15, 1, 14], // ASCII 103
    [16, 16, 30, 17, 17, 17, 17], // ASCII 104
    [4, 0, 12, 4, 4, 4, 14], // ASCII 105
    [2, 0, 6, 2, 2, 18, 12], // ASCII 106
    [16, 16, 18, 20, 24, 20, 18], // ASCII 107
    [12, 4, 4, 4, 4, 4, 14], // ASCII 108
    [0, 0, 26, 21, 21, 17, 17], // ASCII 109
    [0, 0, 30, 17, 17, 17, 17], // ASCII 110
    [0, 0, 14, 17, 17, 17, 14], // ASCII 111
    [0, 0, 30, 17, 30, 16, 16], // ASCII 112
    [0, 0, 15, 17, 15, 1, 1], // ASCII 113
    [0, 0, 22, 25, 16, 16, 16], // ASCII 114
    [0, 0, 15, 16, 14, 1, 30], // ASCII 115
    [8, 8, 28, 8, 8, 9, 6], // ASCII 116
    [0, 0, 17, 17, 17, 19, 13], // ASCII 117
    [0, 0, 17, 17, 17, 10, 4], // ASCII 118
    [0, 0, 17, 17, 21, 21, 10], // ASCII 119
    [0, 0, 17, 10, 4, 10, 17], // ASCII 120
    [0, 0, 17, 17, 15, 1, 14], // ASCII 121
    [0, 0, 31, 2, 4, 8, 31], // ASCII 122
    [2, 4, 4, 8, 4, 4, 2], // ASCII 123
    [4, 4, 4, 4, 4, 4, 4], // ASCII 124
    [8, 4, 4, 2, 4, 4, 8], // ASCII 125
    [0, 0, 9, 22, 0, 0, 0], // ASCII 126
];
static mut CLOCK_CANON_HH: u8 = 10;
static mut CLOCK_CANON_MM: u8 = 42;
static mut CLOCK_CANON_SS: u8 = 0;
