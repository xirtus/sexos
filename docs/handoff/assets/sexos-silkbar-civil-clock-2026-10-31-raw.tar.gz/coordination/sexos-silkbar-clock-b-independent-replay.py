from pathlib import Path
import gzip,hashlib,json,re,sys,time
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-silkbar-clock-b-frozen').resolve();R=F/'source';sys.path.insert(0,str(R/'scripts'))
from certificate_time_gate import replay_evidence as clock
from connected_desktop_gate import replay as connected
import tls_responsiveness_gate as tls
from http_content_gate import frame_prefix
from network_contention_gate import frozen_binding
from silkbar_clock_gate import inspect_publications
from clock_source_evidence import validate_clock_sources
from https_asset_gate import verify_parking
P=T/'sexos-silkbar-clock-b-native-progress.json';output=T/'sexos-silkbar-clock-b-independent-replay.json';assert not output.exists();started=time.monotonic()
def normalized(v):return json.loads(json.dumps(v))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 rows=json.loads(P.read_text())
 if any(isinstance(row['status'],int)and row['status']!=0 for row in rows):raise RuntimeError('failed native attempt remains diagnostic')
 if len(rows)==10 and all(row['status']==0 for row in rows):break
 if time.monotonic()-started>900:raise TimeoutError('bounded wait for exact native suite')
 time.sleep(5)
checked=[]
for row in rows:
 out=Path(row['out']).resolve();stored=json.loads((out/'result.json').read_text());assert stored['ok'];name=row['name']
 if name.startswith('clock-'):
  proof=clock(R,F/'tested.iso',F/'source-binding.json',out);assert proof==stored['replay']and proof['captures']==row['verified_captures'];serials=[out/'serial.log']
 elif name.startswith('connected-'):
  proof=connected(R,F/'tested.iso',F/'source-binding.json',out);assert normalized(proof)==stored and proof['boots']==2 and proof['frames']==17;serials=[out/'session/serial.log',out/'recovery/serial.log']
 else:
  manifest=json.loads((out/'manifest.json').read_text());contract=tls.source_contract(R);resolution=tuple(map(int,manifest['resolution'].split('x')));bound=frozen_binding(R,F/'tested.iso',F/'source-binding.json');assert manifest['binding']==stored['binding']==bound and manifest['pixel_source_sha256']==contract['source_sha256']and manifest['keylog_enabled']is False;assert manifest['command'][manifest['command'].index('-cdrom')+1]==str(F/'tested.iso')and tls.https.tls.command_profile(manifest['command'])['ok'];assert manifest['input_disk_sha256']==sha(T/'sexos-r100a-seed.img');raw=(out/'wire.pcap').read_bytes();trace=(out/'serial.log').read_text(errors='replace');peer=json.loads((out/'peer-exchanges.json').read_text());assert peer['keylog_enabled']is False
  wire=tls.https.inspect_wire(raw,peer['tls'],'partial-close');dns=tls.dns_capture(raw,'echo',attempts=peer['dns_send_attempts'],expected=peer['dns']);progress=tls.inspect_progress(trace,wire,dns,raw,manifest['host_utc_start'],manifest['host_utc_end'],contract);panel=dict(ok=True,errors=[],joins=tls.clock_panel(trace,contract,resolution));authority=tls.nic_check(trace,expected=1,preparation=True,ethernet=True,network_config=True,routing=True);waiting=tls.wait_check(trace)
  for key,value in [('wire',wire),('dns',dns),('progress',progress),('clock_panel',panel),('authority',authority),('self_wait',waiting)]:assert value['ok']and normalized(value)==stored[key],(name,key)
  for source in validate_clock_sources(trace):assert int(manifest['host_utc_start'])-1<=int(source['seconds'])<=int(manifest['host_utc_end'])+2
  proof_pixels=[];previous=0
  for frame in stored['pixels']:
   assert frame['source_sha256']==contract['source_sha256']and sha(out/frame['screenshot'])==frame['screenshot_sha256']and frame['serial_end']>previous;prefix=frame_prefix(trace,frame);previous=frame['serial_end'];ppm=(out/frame['screenshot']).read_bytes();kind=frame['kind']
   if kind=='clock':p=tls.civil_pixels(prefix,ppm,contract['civil_clock'],resolution,'Snapshot')
   elif kind=='quil':p=tls.verify_quil_frame(prefix,ppm,frame['expected'],contract,resolution)
   elif kind=='private':p=tls.lifecycle.verify_private_pixels(prefix,ppm,frame['expected'],contract,resolution)
   else:assert kind=='https';p=tls.https.verify_status_pixels(prefix,ppm,frame['expected'],'partial-close',contract,resolution)
   assert p['ok']and all(normalized(v)==frame[k]for k,v in p.items()),(name,frame['screenshot'],p);proof_pixels.append(p)
  clocks=[f for f in stored['pixels']if f['kind']=='clock'];assert len(clocks)==3 and len({f['seconds']for f in clocks})>=2;parks=[a for a in stored['actions']if a.get('kind')=='park'];verify_parking(trace,[dict(f,name=Path(f['screenshot']).stem)for f in clocks],parks,resolution)
  expected=[tls.TOKEN+contract['quil_initial'],tls.TOKEN+tls.AFTER+contract['quil_initial']];assert len(stored['durable'])==2
  for receipt,payload in zip(stored['durable'],expected):
   packed=out/receipt['raw_document'];assert sha(packed)==receipt['raw_document_sha256'];document=json.loads(gzip.decompress(packed.read_bytes()));image=bytearray(document['image_bytes']);assert document['object']==2
   for segment in document['segments']:
    data=bytes.fromhex(segment['hex']);assert len(data)==segment['bytes']and hashlib.sha256(data).hexdigest()==segment['sha256'];image[segment['offset']:segment['offset']+len(data)]=data
   recovery=tls.durable_snapshot(bytes(image),payload);assert all(normalized(v)==receipt[k]for k,v in recovery.items())
  terminal=gzip.decompress((out/'nvme.img.gz').read_bytes());tls.durable_snapshot(terminal,expected[-1]);assert not re.search(r'KERNEL PANIC|KERNEL PAGE FAULT|DOUBLE FAULT|GP FAULT|panicked at|serial.record.overflow|\[fault.kill\]',trace);proof=dict(ok=True,wire=wire,dns=dns,progress=progress,clock_panel=panel,pixels=proof_pixels,durable=stored['durable'],scope='Fresh immutable-prefix/raw-wire/full glyph/durable-document replay of unchanged TLS responsiveness evidence. No cryptographic secrets captured.');serials=[out/'serial.log']
 observations=[]
 for serial in serials:
  text=serial.read_text(errors='replace');admitted=inspect_publications(text);sources=validate_clock_sources(text);assert admitted and any(a['state']==('Unavailable'if 'invalid-year'in name else'Snapshot')for a in admitted.values());observations.append(dict(serial=str(serial),source_samples=len(sources),civil_admissions=len(admitted),scope='BOOT grant and source/publication/admission joins; pixel scope stated per capture.'))
 # Invalid-year has correct Unavailable admissions and deliberately no positive source.
 if 'invalid-year'in name:pass
 raw_index={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(out.rglob('*'))if p.is_file()and p.suffix!='.img'};checked.append(dict(name=name,out=str(out),boots=row['boots'],verified_captures=row['verified_captures'],proof=proof,civil_observations=observations,raw_index=raw_index));print('PASS',name,row['verified_captures'],'captures',flush=True)
result=dict(ok=True,runs=checked,boots=sum(r['boots']for r in checked),verified_captures=sum(r['verified_captures']for r in checked),raw_captures=sum(r['verified_captures']for r in checked)+2,close_observational_raw_captures=2);assert result['boots']==12 and result['verified_captures']==70;output.write_text(json.dumps(result,indent=2)+'\n');print('FRESH_REPLAY_12_BOOTS_70_VERIFIED_72_RAW_PASS',flush=True)
