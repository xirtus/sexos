from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
from PIL import Image
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-silkbar-clock-b-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for n,v in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==v,n
proof=read(T/'sexos-silkbar-clock-b-independent-replay.json');assert proof['ok']and proof['boots']==12 and proof['verified_captures']==70 and proof['raw_captures']==72
h=read(T/'sexos-silkbar-clock-b-host42/report.json');assert h['checks_passed']and len(h['checks'])==42 and h['sources_unchanged_during_checks']and not h['source_drift'];rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(c['log']).read_text())))for c in h['checks']);assert rust==2628;inventory=h['obligations'];assert sum(v=='open'for v in inventory.values())==2 and sum(v=='partial'for v in inventory.values())==28
python=(T/'sexos-silkbar-clock-b-python.log').read_text();assert 'Ran 880 tests in 'in python and python.rstrip().endswith('OK');scalar=read(T/'sexos-silkbar-clock-b-scalar/result.json');assert scalar['ok']and len(scalar['results'])==5 and sum(v['instructions']for v in scalar['results'])==228757 and scalar['iso_sha256']==b['iso_sha256'];controls=read(T/'sexos-silkbar-clock-controls/result.json');assert controls['ok']and controls['rejected_compiled_mutants']==2
for n,v in controls['source_sha256'].items():assert sha(F/'source'/n)==v
items={};disks=[]
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p

def compress(p):
 p=Path(p);assert not subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True).stdout.strip();raw=p.read_bytes();z=p.with_name(p.name+'.gz')
 if not z.exists():
  with z.open('xb')as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0)as g:g.write(raw)
 assert gzip.decompress(z.read_bytes())==raw;disks.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_sha256=sha(z)));return z

def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*.img')):compress(p)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,folder in [('frozen','sexos-silkbar-clock-b-frozen'),('build','sexos-silkbar-clock-b-build'),('host','sexos-silkbar-clock-b-host42'),('scalar','sexos-silkbar-clock-b-scalar'),('controls','sexos-silkbar-clock-controls'),('diagnostic/build-a','sexos-silkbar-clock-a-build')]:tree(prefix,T/folder)
for row in proof['runs']:tree('native/'+row['name'],row['out'])
tree('bootloader',R/'limine');add('bootloader/input-record.json',T/'sexos-browser-sextime-bootloader-inputs.json');add('seed/nvme.img.gz',compress(T/'sexos-r100a-seed.img'))
for p in sorted(T.glob('sexos-silkbar-clock-*')):
 if p.is_file()and p.suffix in('.py','.json','.log'):add('coordination/'+p.name,p)
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();manifest_sha=hashlib.sha256(raw).hexdigest();archive=A/'sexos-silkbar-civil-clock-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 member=tarfile.TarInfo('payload-members.json');member.size=len(raw);member.mode=0o644;tar.addfile(member,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  data=tar.extractfile(m).read();expected=dict(bytes=len(raw),sha256=manifest_sha)if m.name=='payload-members.json'else manifest[m.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],m.name
screens=[]
for label,folder,shot in [('compact','sexos-silkbar-clock-b-native-clock-normal-compact','clock-tile'),('unavailable-compact','sexos-silkbar-clock-b-native-clock-invalid-year-compact','clock-tile'),('after-browser-close-compact','sexos-silkbar-clock-b-native-responsive-compact','clock-after-close')]:
 source=T/folder/(shot+'.ppm');target=A/('sexos-silkbar-civil-clock-2026-10-31-'+label+'.png');assert not target.exists();image=Image.open(source).convert('RGB');pixels=image.tobytes();image.save(target);assert Image.open(target).convert('RGB').tobytes()==pixels;screens.append(dict(path='assets/'+target.name,sha256=sha(target),source_ppm_sha256=sha(source),pixel_identical=True,width=image.width,height=image.height))
result=dict(qualified_on_feature_branch=True,global_goal_complete=False,branch='codex/silkbar-civil-time',base='876c30be591f7152fe6d9a27fc6e4be9901fb1f5',round_number_unassigned=True,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),build='GREEN_MASTER',registered_host_checks=42,rust_test_executions=2628,python_tests=880,compiled_controls=dict(positive_executions=38,rejected=2,source_sha256=controls['source_sha256'],authority_guard_removed_exit=101,occupied_outbox_guard_removed_exit=101),native=dict(cohorts=10,boots=12,verified_captures=70,raw_captures=72,civil_clock_cell_verified_captures=22,positive_snapshot_clock_cells=14,unavailable_clock_cells=8,clock_runs=6,clock_verified_captures=16,connected_runs=2,connected_live_cold_boots=4,connected_verified_captures=34,tls_responsive_runs=2,tls_responsive_captures=20,close_observational_raw_captures=2,independent_replay=True),scalar=dict(elfs=5,instructions=228757,inspected_vector_fp_matches=0,results=scalar['results'],scope=scalar['scope']),release_gates=dict(open=2,partial=28,system_proven=False,inventory=inventory),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=manifest_sha,all_members_size_and_sha256_verified=True,disks=disks),screenshots=screens,diagnostics='First built guest ran without faults and published/admitted/drew actual civil snapshots, but the old boot CLOCK_GATE demanded legacy demo recv/redraw markers and returnedYELLOW. Updated strict civil log joins accept actual source/admission/completed-draw evidence; fresh buildB is GREEN. Complete atomic kernel source records may begin inside an interrupted older user serial line; strict complete-field/end/count/global validation remains. Preflight syntax/registration/fixture diagnostics retained; native cohorts had no failed attempts.',scope='One frozen B cohort binds the exact BOOT self-consumer ClockSource grant6/task6, bounded immutable publication and exact Display sender/version/framing acceptance. Ticks/cadence only schedule reads or expire presentation; no UTC interpolation or last-good fallback. Native22 clock-cell proofs cover Snapshot/Unavailable at both widths, Browser independence and real TLS/Quil input/Save/Close progress; other states/backpressure/rollback/exhaustion have actual-function host scope. Clock wire retains existing epoch; no Unix/POSIX architecture introduced. No physical/authenticated/NTP time, persistent floor, newest-image1800s alpha, publicweb/CA, SMP, crash/power-loss, hostile containment, whole-image/runtime register/cache-erasure or System Proven claim.')
p=A/'sexos-silkbar-civil-clock-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['iso_sha256','registered_host_checks','rust_test_executions','python_tests','native']}));print('ARCHIVE',archive.stat().st_size,'bytes',len(items)+1,'size+hash verified members')
