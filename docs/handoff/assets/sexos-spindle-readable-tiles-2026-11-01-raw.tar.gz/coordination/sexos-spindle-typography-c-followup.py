from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
T=Path('/tmp');F=T/'sexos-spindle-typography-c-frozen';R=F/'source';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'))
from connected_desktop_gate import history_state
progress=T/'sexos-spindle-typography-c-alpha-progress.json';start=time.monotonic()
while True:
 rows=json.loads(progress.read_text())if progress.exists()else[]
 if any(type(row['status'])is int and row['status']!=0 for row in rows):raise RuntimeError('Parent Alpha failure retained')
 if len(rows)==2 and all(row['status']==0 and row.get('fresh_replay')for row in rows):break
 if time.monotonic()-start>1200:raise TimeoutError('Parent Alpha not terminal')
 time.sleep(5)
parent=T/'sexos-spindle-typography-c-alpha-wide';disk=gzip.decompress((parent/'nvme.img.gz').read_bytes());state=history_state(disk);recall=state['commands'][-1];assert state['source']==29 and state['task']==29
p=T/'sexos-spindle-typography-c-parent-last-command.json';assert not p.exists();p.write_text(json.dumps(dict(recall=recall,state=state,parent_disk_sha256=hashlib.sha256(disk).hexdigest()),indent=2)+'\n')
out=T/'sexos-spindle-typography-c-last-writer-cold-aux';driver=T/(out.name+'-driver.log');assert not out.exists()and not driver.exists()
command=['python3',str(R/'scripts/spindle_durable_reboot_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--boot-a',str(parent),'--out',str(out),'--recall',recall];began=time.monotonic()
with driver.open('x')as f:r=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=600)
row=dict(status=r.returncode,command=command,elapsed_seconds=time.monotonic()-began,out=str(out),driver=str(driver));p=T/'sexos-spindle-typography-c-cold-aux-result.json';assert not p.exists();p.write_text(json.dumps(row,indent=2)+'\n')
if r.returncode:raise SystemExit(r.returncode)
v=json.loads((out/'result.json').read_text());assert v['ok']and v['stopped']and v['binding']and v['recall']==recall;raw=(out/'nvme.img').read_bytes();assert hashlib.sha256(raw).hexdigest()==v['final_disk_sha256'];(out/'nvme.img.gz').write_bytes(gzip.compress(raw,mtime=0));print('BOUND_LAST_WRITER29_COLD_PASS',flush=True)
command=['python3',str(T/'sexos-spindle-typography-c-connected-suite.py')]
r=subprocess.run(command,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});raise SystemExit(r.returncode)
