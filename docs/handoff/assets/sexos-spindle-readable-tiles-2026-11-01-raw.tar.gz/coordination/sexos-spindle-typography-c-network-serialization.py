from pathlib import Path
import json,os,signal,time
p=Path('/tmp/sexos-spindle-typography-c-network-serialization.json');a=json.loads(p.read_text());pid=a['coordinator_pid'];start=time.monotonic()
try:
 while True:
  rows=json.loads(Path('/tmp/sexos-spindle-eight-a-sustained-progress.json').read_text());a['older_progress']=[dict(profile=r['profile'],status=r['status'])for r in rows];p.write_text(json.dumps(a,indent=2)+'\n')
  if len(rows)==2 and all(type(r['status'])is int for r in rows):break
  if time.monotonic()-start>1200:raise TimeoutError('Older owned fixtures not terminal')
  time.sleep(5)
finally:
 os.kill(pid,signal.SIGCONT);a.update(state='coordinator_resumed',ended_monotonic=time.monotonic(),hold_seconds=time.monotonic()-a['started_monotonic']);p.write_text(json.dumps(a,indent=2)+'\n')
print('NETWORK_FIXTURE_SERIALIZATION_PARENT_RESUMED',flush=True)
