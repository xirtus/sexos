from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-spindle-typography-c-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-spindle-typography-c-source-audit.json');boot=read(T/'sexos-spindle-typography-c-boot-audit.json');h=read(T/'sexos-spindle-typography-c-frozen-host/report.json');scalar=read(T/'sexos-spindle-typography-c-scalar-v3/result.json');alpha=read(T/'sexos-spindle-typography-c-alpha-progress.json');connected=read(T/'sexos-spindle-typography-c-native-progress.json');cold=read(T/'sexos-spindle-typography-c-last-writer-cold-aux/result.json')
assert audit['ok']and audit['commit']=='348cc9ab4d2988eb58c1e4dcacf8f7b4149d6ad7'and boot['ok']and boot['boots']==10
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2738
assert 'Ran 1037 tests in 'in(T/'sexos-spindle-typography-c-python.log').read_text()
assert len(alpha)==2 and all(row['status']==0 and row['fresh_replay']and row['terminal_history']['source']==29 and row['terminal_history']['task']==29 for row in alpha)
assert len(connected)==2 and all(row['status']==0 and row['boots']==2 and row['verified_captures']==17 for row in connected)
assert cold['ok']and cold['stopped']and cold['binding']and cold['expected']['source']==29 and cold['expected']['task']==29 and cold['recall']=='echo alpha29'
assert scalar['ok']and len(scalar['results'])==8 and all(not r['vector_or_fp_matches']for r in scalar['results'])
controls=read(T/'sexos-spindle-typography-c-lifecycle-controls.json');assert controls['tests']==8 and controls['compiled_mutants_rejected']==3
observations=[]
for row in alpha:
 out=Path(row['out']);text=(out/'serial.log').read_text(errors='replace');r=read(out/'result.json');s=r['soak']['third_spindle'];assert [step['target']for step in s['chain']]==[24,25,26,27,28,29]and s['reserve_exhausted'];accepted=sorted(set(map(int,re.findall(r'\[shell.spindle.status.accepted\] target=(\d+)',text))));assert accepted==[12,17,24,25,26,27,28,29]
 assert '[sext.app.pool.ready] target=24 task=24 bytes=389120 zeroed=389120 workspace_records=2 reused=1 zero_owner=sext ok=1'in text
 observations.append(dict(profile=row['profile'],status_subjects=accepted,third=s,terminal_history=row['terminal_history']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items,(n,p);items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('qualified/frozen',F),('qualified/sealed-build',T/'sexos-spindle-typography-c-build'),('qualified/host',T/'sexos-spindle-typography-c-frozen-host'),('qualified/scalar',T/'sexos-spindle-typography-c-scalar-v3'),('qualified/auxiliary-cold',T/'sexos-spindle-typography-c-last-writer-cold-aux')]:tree(prefix,root)
for row in alpha:tree('qualified/alpha/'+row['profile'],row['out'])
for row in connected:tree('qualified/connected/'+row['profile']['label'],row['out'])
for prefix in ['a','b']:
 for suffix in ['frozen','build','frozen-host']:
  path=T/('sexos-spindle-typography-'+prefix+'-'+suffix)
  if path.exists():tree('superseded/'+path.name,path)
for name in ['sexos-spindle-typography-a-viewport-aux','sexos-spindle-typography-a-viewport-aux-b','sexos-spindle-typography-b-viewport-basic']:tree('diagnostic/'+name,T/name)
for name in ['viewport-basic','viewport-wide-basic']:tree('qualified/'+name,T/('sexos-spindle-typography-c-'+name))
tree('host-controls/lifecycle',T/'sexos-spindle-typography-c-lifecycle-controls')
for name in ['sexos-r146-spindle-layout','sexos-r146-spindle-oracle','sexos-r146-display-scale','sexos-r146-relative-tiles','sexos-r146-cycle-timing']:
 p=T/name
 if p.exists():tree('host-controls/'+name,p)
for p in sorted(T.glob('sexos-spindle-typography-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py','.sh','.txt']and 'package'not in p.name:add('coordination/'+p.name,p)
add('host-controls/compact-boot-profile.log',T/'sexos-r146-relative-tiles-boot-profile.log')
add('coordination/package.py',Path(__file__))
add('visuals/native-font2-preview.png',T/'sexos-spindle-typography-c-network-preview.png')
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-spindle-readable-tiles-2026-11-01-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
captures=sum(row['verified_captures']for row in alpha+connected)
for prefix in ['a','b']:assert read(T/('sexos-spindle-typography-'+prefix+'-frozen/source-binding.json'))['sources']==b['sources']
viewport=[read(T/'sexos-spindle-typography-c-viewport-artifact-audit.json'),read(T/'sexos-spindle-typography-c-viewport-wide-artifact-audit.json')];assert all(v['ok']and len(v['frames'])==4 for v in viewport)
e=dict(round=146,readable_spindle_tiles_qualified=True,full_os_goal_complete=False,source_commit=audit['commit'],product_commit='308d261056c7032352c20a2171c553c939f070a6',main_parent='b7cef540b6b3c55a572bf0e7d6e079ec33c36682',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust+controls['tests'],rust_gate_log_passes=rust,additional_extracted_lifecycle_cases=8,lifecycle_compiled_mutants=3,python_tests=1037,typography=dict(exact_catalog_spindle_panes_only=True,threshold_pixels=128,narrower_scale=1,normal_scale=2,compact_pane_width=244,compact_columns_per_pane=18,compact_total_columns=36,max_text_bytes_per_pane=126,actual_compact_payload_limit=114,other_surface_threshold_unchanged=256),native=dict(sealed_probe_boots=1,alpha_boots=2,connected_boots=4,auxiliary_cold_boots=1,auxiliary_viewport_boots=2,total_qualified_boots=10,registry_verified_captures=captures,viewport_ppms=8,viewport_readonly_frame_audits=viewport,alpha=alpha,connected=connected,spindle_observations=observations,full_history_and_readable_frames=read(T/'sexos-spindle-typography-c-full-history-chain.json'),cold=dict(observed=True,source=29,task=29,fresh_target=12,recall=cold['recall'],generation=cold['expected']['generation'],bytes=cold['expected']['size'],standalone_artifact_replay=False,parent_source_bound_replayed=True),boot_roster_layout_audit=boot,new_image_1800s_acceptance=False),scalar=dict(elfs=8,instructions=sum(r['instructions']for r in scalar['results']),inspected_vector_fp_matches=0,scope=scalar['scope']),timing=dict(final_serial_read_before_cycle_end=True,idle_deadline_anchored_to_same_end=True,acceptance_bound_unchanged=True,actual_helper_tests=5,old_ordering_rejected_by_fake_growing_reader=True,deliberate_16second_idle_rejected=True,old_three_reserve_wide_rejection_preserved=True),serialization=dict(coordinator_only=True,guest_never_stopped=True,hold_seconds=read(T/'sexos-spindle-typography-c-network-serialization.json')['hold_seconds'],release_audit=read(T/'sexos-spindle-typography-c-network-release-audit.json'),coordinator_duration_includes_hold=True),diagnostics=dict(product_sources_a_b_c_identical=True,a_wrong_writer29_seed_rejected=True,a_matching_seed_obsolete_height180_rejected=True,b_vga_requested_compact_without_menu_selection_actual1280_rejected=True,c_actual_compact_menu_selected=True),limits=dict(spindle_incarnations=8,browser_incarnations=1,per_request_file_deferred_task_authentication=False,native_unequal_allocator=False,auxiliary_full_input_replay_cli=False),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Exact Spindle content owner/SID pairs use source-bound2x glyphs at128px with bounded columns and existing prompt/caret semantics. Layout, Display wrapping/glyph/damage and native oracle agree. Compact/wide native tiled-edit-Zoom-exactrestore probes have independent stopped-frame audits; full8-incarnation workflows and connected/cold regression pass. FinalC corrects only future runner geometry/boot selection/timing; A/B production/kernel identical and diagnostics retained. No relaxed acceptance threshold, old failedwide relabel, new1800s, runtime capabilitymint/processVAS or unrestricted daily-driver claim.')
p=A/'sexos-spindle-readable-tiles-2026-11-01-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('READABLE_SPINDLE_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','captures',captures,flush=True)
