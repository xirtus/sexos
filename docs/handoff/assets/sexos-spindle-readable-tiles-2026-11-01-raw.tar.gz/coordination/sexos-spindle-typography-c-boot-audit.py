from pathlib import Path
import hashlib,json,re,sys
T=Path('/tmp');F=T/'sexos-spindle-typography-c-frozen';R=F/'source';sys.path.insert(0,str(R/'scripts'))
from history_roster_evidence import verify_boot_roster
from quil_reserve_catalog import quil_catalog,verify_boot_quil
roots=[T/'sexos-spindle-typography-c-build',T/'sexos-spindle-typography-c-last-writer-cold-aux',T/'sexos-spindle-typography-c-viewport-basic',T/'sexos-spindle-typography-c-viewport-wide-basic']
for suffix in ['alpha-progress','native-progress']:
 rows=json.loads((T/('sexos-spindle-typography-c-'+suffix+'.json')).read_text());assert len(rows)==2 and all(r['status']==0 for r in rows);roots.extend(Path(r['out'])for r in rows)
logs=[]
for root in roots:
 for p in sorted(root.rglob('serial.log')):
  data=p.read_bytes();text=data.decode(errors='replace');roster=verify_boot_roster(R,text);verify_boot_quil(text,quil_catalog(R))
  assert roster['participants']==[dict(target=12,task=12),dict(target=17,task=17),dict(target=24,task=24),dict(target=25,task=25),dict(target=26,task=26),dict(target=27,task=27),dict(target=28,task=28),dict(target=29,task=29)],p
  marker='[boot.history.layout] grant_bytes=88 capability_data_bytes=128 capability_bytes=192 participants=8 bounded=1';assert text.count(marker)==1 and text.index(marker)<text.index('[boot.memory.authority.sealed]'),p
  assert text.count('[boot.self_wait.sealed] tasks=29 capacity=32 max_ticks=64 runtime_registration=0')==1,p
  authority='[files.history.authority] slot=53 present=1 logical=12 runtime_mint=0';assert text.count(authority)==1,p
  logs.append(dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),roster=roster,grant_bytes=88,capability_data_bytes=128,capability_bytes=192))
assert len(logs)==10,len(logs)
p=T/'sexos-spindle-typography-c-boot-audit.json';assert not p.exists();p.write_text(json.dumps(dict(ok=True,boots=10,normal_workflow_boots=6,sealed_probe_boots=1,auxiliary_cold_boots=1,auxiliary_viewport_boots=2,observations=logs,scope='Actual inserted history capability queried beforeseal; exact registered tasks and both family catalogs/layout. Eight actual Spindles, no per-request task authentication.'),indent=2)+'\n');print('TEN_BOOTS_HELD_ROSTER_AND_LAYOUT_PASS',flush=True)
