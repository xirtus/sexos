from pathlib import Path
import hashlib,json,sys
F=Path('/tmp/sexos-spindle-typography-c-frozen');R=F/'source';out=Path('/tmp/sexos-spindle-typography-c-viewport-wide-basic');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'))
from check_spindle_viewport_pixels import verify
from check_desktop_pixels import font_from_source
from spindle_viewport_gate import accepted_layout,validate_relative_layout
from alpha_evidence import frozen_binding
bound=frozen_binding(R,F/'tested.iso',F/'source-binding.json');r=json.loads((out/'result.json').read_text());m=json.loads((out/'manifest.json').read_text());assert r['ok']and r['layout_mode']=='relative-tiles'and r['resolution']=='1280x800'and r['journal_unchanged'];assert m['iso_sha256']==bound['iso_sha256']
text=(out/'serial.log').read_text(errors='replace');font=font_from_source((R/'servers/sexdisplay/src/main.rs').read_text());expected=[('small-recalled','> echo spindle17','tiled'),('small-edited','> echo spindle17x','tiled'),('expanded','> echo spindle17','expanded'),('small-restored','> echo spindle17','restored')];assert len(r['stages'])==4;tiled=None;sequence=0;frames=[]
raw_hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()for p in out.rglob('*')if p.is_file()}
for stage,(name,prompt,phase)in zip(r['stages'],expected):
 assert(stage['name'],stage['prompt'],stage['pixel_errors'])==(name,prompt,[]);end=stage['log_offset'];assert type(end)is int and 0<end<=len(text);prefix=text[:end];ppm=(out/(name+'.ppm')).read_bytes();assert hashlib.sha256(ppm).hexdigest()==stage['ppm_sha256'];layout=accepted_layout(prefix);assert layout==stage['layout'];shape=validate_relative_layout(layout,(1280,800),phase,tiled,sequence if phase!='tiled'else 0)
 if tiled is None:tiled=shape
 if phase in ['expanded','restored']:sequence=layout[0]
 else:sequence=max(sequence,layout[0])
 errors=verify(prefix,ppm,font,12,require_prompt=prompt,require_echo=False,require_all_ink=False,resolution=(1280,800),root=R);assert not errors,(name,errors);frames.append(dict(name=name,layout=layout,prefix_sha256=hashlib.sha256(prefix.encode()).hexdigest(),ppm_sha256=stage['ppm_sha256']))
assert tiled==(640,375,20,6,6)and r['stages'][2]['layout'][1:]==[1280,750,20,6,6]and tuple(r['relative_tiled'])==tiled
assert raw_hashes=={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()for p in out.rglob('*')if p.is_file()}
value=dict(ok=True,frames=frames,source_binding=bound,raw_sha256=raw_hashes,scope='Read-only independent stopped-frame audit of source/image, exact current payload glyphs, framebuffer size, fresh enlargement and exact restore; auxiliary runner has no full native-input replay CLI')
p=Path('/tmp/sexos-spindle-typography-c-viewport-wide-artifact-audit.json');assert not p.exists();p.write_text(json.dumps(value,indent=2)+'\n');print('RELATIVE_VIEWPORT_READONLY_FOUR_FRAME_AUDIT_PASS')
