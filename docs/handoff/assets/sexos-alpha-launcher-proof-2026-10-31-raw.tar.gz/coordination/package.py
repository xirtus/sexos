from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-alpha-launcher-b-frozen';D=T/'sexos-alpha-evidence-a-compact-1800'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');prior=read(T/'sexos-civil-redraw-a-frozen/source-binding.json');assert b['sources']==prior['sources']and b['iso_sha256']==prior['iso_sha256']and b['kernel_sha256']==prior['kernel_sha256']
for n,v in {**b['sources'],**b['runner_sha256']}.items():assert sha(R/n)==sha(F/'source'/n)==v,n
assert b['architecture_sha256']==sha(R/'ARCHITECTURE.md')=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
h=read(T/'sexos-alpha-launcher-b-host42/report.json');assert h['checks_passed']and len(h['checks'])==42 and not h['source_drift'];rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(v['log']).read_text())))for v in h['checks']);assert rust==2630
py=(T/'sexos-alpha-launcher-b-python.log').read_text();assert'Ran 910 tests in 'in py and py.rstrip().endswith('OK')
workflows=[]
for mode in ['compact','wide']:
 o=T/('sexos-alpha-launcher-b-'+mode+'-rehearsal');v=read(T/('sexos-alpha-launcher-b-'+mode+'-independent-replay.json'));r=read(o/'result.json');assert v['ok']and v['acceptance']is False and v['verified_captures']==21 and r['soak']['third_quil']['exhaustion_frame']['kind']=='launcher';workflows.append(dict(profile=mode,verified_captures=21,acceptance=False,terminal_scope=r['soak']['quil_close']['terminal_scope'],remaining_obligations=r['soak']['remaining_obligations']))
failure=read(D/'result.json');m=read(D/'manifest.json');index=read(D/'captures.json');progress=read(D/'progress.json');assert failure['ok']is False and m['error']and index['complete']is False and progress['cycles']==84 and progress['elapsed_seconds']>=1800
for n,v in m['raw_sha256'].items():assert sha(D/n)==v,n
assert'failed alpha attempt remains diagnostic'in(T/'sexos-alpha-launcher-failed-a-negative-replay.log').read_text()
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p

def tree(prefix,root):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen-b',F);tree('diagnostic/frozen-a',T/'sexos-alpha-evidence-a-frozen');tree('diagnostic/failed-compact-a',D);tree('host',T/'sexos-alpha-launcher-b-host42')
for mode in ['compact','wide']:tree('rehearsal/'+mode,T/('sexos-alpha-launcher-b-'+mode+'-rehearsal'))
# Never include either live1800s tree, its mutable progress/index or driver log.
for n in ['sexos-alpha-launcher-b-freeze.log','sexos-alpha-launcher-b-host42-driver.log','sexos-alpha-launcher-b-python.log','sexos-alpha-launcher-b-compact-driver.log','sexos-alpha-launcher-b-wide-driver.log','sexos-alpha-launcher-b-compact-independent-replay.json','sexos-alpha-launcher-b-wide-independent-replay.json','sexos-alpha-launcher-failed-a-negative-replay.log','sexos-alpha-evidence-a-compact-1800-driver.log']:
 add('coordination/'+n,T/n)
add('coordination/package.py',Path(__file__));manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-alpha-launcher-proof-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 member=tarfile.TarInfo('payload-members.json');member.size=len(raw);member.mode=0o644;tar.addfile(member,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for member in members:
  data=tar.extractfile(member).read();expected=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())if member.name=='payload-members.json'else manifest[member.name];assert len(data)==expected['bytes']and hashlib.sha256(data).hexdigest()==expected['sha256'],member.name
result=dict(implementation_and_rehearsals_qualified=True,sustained_alpha_accepted=False,goal_complete=False,branch='codex/alpha-launcher-proof',base='c4a64f8c8e687b713b83903b07906c95153e4bc4',production_inputs_identical_to_civil_repaint_cohort=True,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),registered_host_checks=42,rust_test_executions=rust,python_tests=910,native=dict(boots=2,verified_captures=42,launcher_exhaustion_captures=2,independent_replay=True,workflows=workflows),diagnostic_failed_a=dict(accepted=False,cycles=84,elapsed_seconds=progress['elapsed_seconds'],registry_complete=False,error=failure['error'],raw_registry_captures=len(index['frames']),negative_replay_exit=1,scope='Failed final legacy launcher wait; no full terminal cleanup or sustained acceptance.'),prior_image_qualification=dict(path='assets/sexos-civil-clock-repaint-2026-10-31-evidence.json',sha256=sha(A/'sexos-civil-clock-repaint-2026-10-31-evidence.json')),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(raw).hexdigest(),all_members_size_and_sha256_verified=True),release_gates=dict(open=2,partial=28,system_proven=False),scope='Same optimized production image, corrected source-bound alpha runner. Real fresh selection after exact third-incarnation cleanup, atomic closed/exhausted row, positive text Applied and full launcher glyphs. Short rehearsals only. Original failed compact remains diagnostic; live older-wide and corrected-compact1800s outputs are excluded. Pending-I/O terminal Quil teardown, physical/storage and global epoch release gates remain.')
p=A/'sexos-alpha-launcher-proof-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('ARCHIVE',len(items)+1,'members',archive.stat().st_size,'bytes; all verified. Two rehearsals42 captures; failedA retained, not accepted.')
