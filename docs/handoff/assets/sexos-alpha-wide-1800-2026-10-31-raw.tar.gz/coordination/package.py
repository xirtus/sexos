from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-alpha-evidence-a-frozen';O=T/'sexos-alpha-evidence-a-wide-1800'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');v=read(T/'sexos-alpha-evidence-a-wide-1800-independent-replay.json');r=read(O/'result.json');s=r['soak'];assert r['ok']and v['ok']and r['acceptance']and v['acceptance']and v['cycles']==85 and v['verified_captures']==206 and s['elapsed_seconds']>=1800
assert s['quil_close']['terminal_scope']=='safe_completed_save_close'and not s['pending_quil_close']and s['remaining_obligations']==['Quil pending-I/O terminal teardown']
inputs={**b['sources'],**b['runner_sha256']};raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join('20c50957027e69c258b98e701ef1efab0d2563f6:'+n+'\n'for n in inputs).encode());pos=0
for n,d in inputs.items():
 end=raw.index(b'\n',pos);h=raw[pos:end].split();assert len(h)==3 and h[1]==b'blob';size=int(h[2]);pos=end+1;assert hashlib.sha256(raw[pos:pos+size]).hexdigest()==sha(F/'source'/n)==d,n;pos+=size+1
assert pos==len(raw)and len(inputs)==1143
h=read(T/'sexos-alpha-evidence-a-host42/report.json');assert h['checks_passed']and len(h['checks'])==42 and not h['source_drift'];assert'Ran 902 tests in 'in(T/'sexos-alpha-evidence-a-python.log').read_text()
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p

def tree(prefix,root):
 for p in sorted(Path(root).rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('wide-session',O);tree('host',T/'sexos-alpha-evidence-a-host42')
for n in ['sexos-alpha-evidence-a-wide-1800-independent-replay.json','sexos-alpha-evidence-a-wide-1800-driver.log','sexos-alpha-evidence-a-python.log','sexos-alpha-evidence-a-host42-driver.log']:add('coordination/'+n,T/n)
add('coordination/package.py',Path(__file__));manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-alpha-wide-1800-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();e=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==e['bytes']and hashlib.sha256(content).hexdigest()==e['sha256'],m.name
result=dict(accepted_v2_sustained_workflow=True,full_os_goal_complete=False,source_commit='20c50957027e69c258b98e701ef1efab0d2563f6',current_optimized_image_acceptance=False,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=574,runner_inputs=569,registered_host_checks=42,rust_test_executions=2628,python_tests=902,resolution='1280x800',model='e1000e',elapsed_seconds=s['elapsed_seconds'],active_elapsed_seconds=s['active_elapsed_seconds'],idle_elapsed_seconds=s['idle_elapsed_seconds'],cycles=85,verified_captures=206,independent_replay=True,documents=r['documents'],terminal_scope=s['quil_close']['terminal_scope'],pending_save_close_guard=s['pending_save_close_guard'],pending_quil_close=False,pending_spindle_close=s['pending_spindle_close'],boot_successors=s['boot_successors'],remaining_obligations=s['remaining_obligations'],release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Completed older-image wide sustained workflow with85 distinct active cycles, bounded intentional idle,206 immutable source-bound pixel captures, exact durable documents, pending-save decline, completed-save confirmed Quil Close, BOOT successor recovery/cleanup and pending Spindle retirement. Every frozen input matches commit20c50957. Not optimized-image acceptance, actual Quil pending-device-I/O teardown, physical/power-loss/SMP, global epoch replay or general daily-driver qualification.')
p=A/'sexos-alpha-wide-1800-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('ARCHIVE',len(items)+1,'members',archive.stat().st_size,'bytes; older wide85cycles206captures acceptedv2, remainingQuilIO obligation explicit')
