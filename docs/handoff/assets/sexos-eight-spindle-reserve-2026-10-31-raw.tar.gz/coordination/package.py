from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-spindle-eight-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-spindle-eight-a-source-audit.json');boot=read(T/'sexos-spindle-eight-a-boot-audit.json');h=read(T/'sexos-spindle-eight-a-frozen-host/report.json');scalar=read(T/'sexos-spindle-eight-a-scalar-v3/result.json');alpha=read(T/'sexos-spindle-eight-a-alpha-progress.json');connected=read(T/'sexos-spindle-eight-a-native-progress.json');cold=read(T/'sexos-spindle-eight-a-last-writer-cold-aux/result.json')
assert audit['ok']and audit['commit']=='502dda457c9fc8e22733918f20c8b37750cee022'and boot['ok']and boot['boots']==8
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2730
assert 'Ran 1017 tests in 'in(T/'sexos-spindle-eight-a-frozen-python.log').read_text()
assert len(alpha)==2 and all(row['status']==0 and row['fresh_replay']and row['terminal_history']['source']==29 and row['terminal_history']['task']==29 for row in alpha)
assert len(connected)==2 and all(row['status']==0 and row['boots']==2 and row['verified_captures']==17 for row in connected)
assert cold['ok']and cold['stopped']and cold['binding']and cold['expected']['source']==29 and cold['expected']['task']==29 and cold['recall']=='echo alpha29'
assert scalar['ok']and len(scalar['results'])==8 and all(not r['vector_or_fp_matches']for r in scalar['results'])
controls=read(T/'sexos-spindle-eight-a-lifecycle-controls.json');assert controls['tests']==8 and controls['compiled_mutants_rejected']==3
observations=[]
for row in alpha:
 out=Path(row['out']);text=(out/'serial.log').read_text(errors='replace');r=read(out/'result.json');s=r['soak']['third_spindle'];assert [step['target']for step in s['chain']]==[24,25,26,27,28,29]and s['reserve_exhausted'];accepted=sorted(set(map(int,re.findall(r'\[shell.spindle.status.accepted\] target=(\d+)',text))));assert accepted==[12,17,24,25,26,27,28,29]
 assert '[sext.app.pool.ready] target=24 task=24 bytes=389120 zeroed=389120 workspace_records=2 reused=1 zero_owner=sext ok=1'in text
 observations.append(dict(profile=row['profile'],status_subjects=accepted,third=s,terminal_history=row['terminal_history']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items,(n,p);items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('qualified/frozen',F),('qualified/sealed-build',T/'sexos-spindle-eight-a-build'),('qualified/host',T/'sexos-spindle-eight-a-frozen-host'),('qualified/scalar',T/'sexos-spindle-eight-a-scalar-v3'),('qualified/auxiliary-cold',T/'sexos-spindle-eight-a-last-writer-cold-aux')]:tree(prefix,root)
for row in alpha:tree('qualified/alpha/'+row['profile'],row['out'])
for row in connected:tree('qualified/connected/'+row['profile']['label'],row['out'])
tree('diagnostic/initial-host',T/'sexos-spindle-eight-a-host')
tree('host-controls/lifecycle',T/'sexos-spindle-eight-a-lifecycle-controls')
for name in ['sexos-r145-catalog-host','sexos-r145-history-host','sexos-r145-activation-desktop']:
 p=T/name
 if p.exists():tree('host-controls/'+name,p)
for p in sorted(T.glob('sexos-spindle-eight-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py','.sh','.txt']and 'package'not in p.name:add('coordination/'+p.name,p)
for name in ['sexos-r145-spindle-reserve-probe-tests.log','sexos-r145-eight-spindle-pixels.log']:add('host-controls/'+name,T/name)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-eight-spindle-reserve-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
captures=sum(row['verified_captures']for row in alpha+connected)
e=dict(round=145,eight_spindle_boot_reserve_qualified=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='bb94770822d7906e82be93696bd52bf7ef39f081',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust+controls['tests'],rust_gate_log_passes=rust,additional_extracted_lifecycle_cases=controls['tests'],lifecycle_compiled_mutants=3,python_tests=1017,boot=dict(catalog_subjects=17,spindle_targets=[12,17,24,25,26,27,28,29],main_self_wait_tasks=29,self_wait_capacity=32,grant_bytes=88,capability_data_bytes=128,capability_bytes=192,app_surfaces=50,desktop_tracked_surfaces=51,retained_lifecycle_capacity=32,initial_lifecycle_surfaces=17,later_native_frames=15,future_two_browser_capacity=34),native=dict(sealed_probe_boots=1,alpha_boots=2,connected_boots=4,auxiliary_cold_boots=1,total_qualified_boots=8,registry_verified_captures=captures,alpha=alpha,connected=connected,spindle_observations=observations,full_history_chain=read(T/'sexos-spindle-eight-a-full-history-chain.json'),cold=dict(observed=True,source=29,task=29,fresh_target=12,recall=cold['recall'],generation=cold['expected']['generation'],bytes=cold['expected']['size'],standalone_artifact_replay=False,parent_source_bound_replayed=True),boot_roster_layout_audit=boot,new_image_1800s_acceptance=False,positive_controlled_tcp_releases=12,pcap_proof=False),scalar=dict(elfs=8,instructions=sum(r['instructions']for r in scalar['results']),inspected_vector_fp_matches=0,scope=scalar['scope']),limits=dict(finite_spindle_incarnations=8,per_request_file_deferred_task_authentication=False,native_unequal_allocator=False,browser_incarnations=1),diagnostics=dict(initial_host_static_initializer_guard_outdated=True,final_host_checks_passed=True),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Five additional BOOT-only Spindle reservations through29; exact eight-participant held recovery grant and complete source-derived retained lifecycle budget. Both sizes execute all eight incarnations/seven relaunches, six new reserve probes each with owned history, storage create-fill-verify-delete, controlled1025-byte echo through positive RELEASE, final durable echo, exact next-generation recovery, pane glyphs, five-role cleanup/private-zero reuse and exhaustion. Cold29-to-fresh12 observes generation55/761bytes andechoalpha29; auxiliary probe with bound parent replay, no standalone replay. No runtime capability mint/processVAS, general deferred task authentication, unbounded reuse, public network/packet capture, native unequal allocator, new1800s or unrestricted daily-driver acceptance claim.')
p=A/'sexos-eight-spindle-reserve-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('EIGHT_SPINDLE_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','captures',captures,flush=True)
