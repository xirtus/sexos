from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');F=T/'sexos-reserve-cold-a-frozen';R=F/'source';P=T/'sexos-reserve-cold-a-native-progress.json';assert not P.exists();rows=[]
def run(label,kind,out,script,extra,captures):
 driver=T/(out.name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(R/'scripts'/script),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--out',str(out),'--model',model,'--resolution',res,*extra]
 row=dict(profile=label,kind=kind,command=command,out=str(out),driver=str(driver),status='running');rows.append(row);P.write_text(json.dumps(rows,indent=2)+'\n');print('START',label,kind,flush=True);began=time.monotonic()
 with driver.open('x')as f:r=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,elapsed_seconds=time.monotonic()-began);P.write_text(json.dumps(rows,indent=2)+'\n');print('END',label,kind,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 value=json.loads((out/'result.json').read_text());assert value['ok']
 replay=T/(out.name+'-independent-replay.json');assert not replay.exists()
 with replay.open('x')as f:r=subprocess.run(command+['--check'],cwd=R,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 assert r.returncode==0;check=json.loads(replay.read_text());assert check['ok'];row.update(fresh_replay=True,verified_captures=captures);P.write_text(json.dumps(rows,indent=2)+'\n')
for label,model,res in [('compact','e1000','1024x768'),('wide','e1000e','1280x800')]:
 parent=T/('sexos-reserve-cold-a-parent-'+label);cold=T/('sexos-reserve-cold-a-cold-'+label);pending=T/('sexos-reserve-cold-a-pending-'+label);pendingcold=T/('sexos-reserve-cold-a-pending-cold-'+label)
 run(label,'complete_reserve',parent,'quil_workflow_gate.py',['--source-disk',str(T/'sexos-r100a-seed.img'),'--soak-seconds','20','--rehearsal','--third-quil','--capture-profile','--find'],26)
 run(label,'last_save_cold',cold,'quil_reserve_cold_gate.py',['--session',str(parent)],1)
 run(label,'pending_io',pending,'quil_workflow_gate.py',['--source-disk',str(T/'sexos-r100a-seed.img'),'--pending-io-close','--capture-profile'],12)
 run(label,'pending_io_cold',pendingcold,'pending_io_cold_gate.py',['--session',str(pending)],1)
assert len(rows)==8 and sum(r['verified_captures']for r in rows)==80
print('RESERVE_COLD_8BOOTS_80_CAPTURES_PASS',flush=True)
