from pathlib import Path
import hashlib,io,json,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-reserve-cold-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-reserve-cold-a-source-audit.json');boot=read(T/'sexos-reserve-cold-a-boot-audit.json');rows=read(T/'sexos-reserve-cold-a-native-progress.json')
assert audit['ok']and audit['same_production_image_as_round136']and len(audit['runner_changes_from_round136'])==4
assert len(rows)==8 and all(row['status']==0 and row['fresh_replay']for row in rows)and sum(row['verified_captures']for row in rows)==80
assert boot['ok']and boot['boots']==8
assert 'Ran 975 tests in 'in(T/'sexos-reserve-cold-a-python.log').read_text()
proofs=[]
for row in rows:
 if row['kind']=='last_save_cold':
  p=Path(row['out']);v=read(T/(p.name+'-independent-replay.json'));assert v['ok']and v['cold_recovery_verified']and v['chain']['final_target']==23 and v['chain']['targets']==[9,16,18,19,20,21,22,23]
  proofs.append(dict(profile=row['profile'],chain=v['chain'],load=v['load'],frame=dict(name=v['frame']['name'],sha256=v['frame']['screenshot_sha256']),fresh_replay=True))
assert len(proofs)==2
assert all(v['load']['bytes']==20 and v['chain']['recovered']==dict(bank=0,generation=12,identity=327681,bytes=20,hash='0x1066708195bedecd')for v in proofs)
previous=read(A/'sexos-quil-eight-reserve-2026-10-31-evidence.json');assert previous['source_commit']=='9287fa3e1f7c8d14ae4d460ddb6e6935a845d6ea'and previous['iso_sha256']==b['iso_sha256']and previous['kernel_sha256']==b['kernel_sha256']
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F)
for row in rows:tree('native/'+Path(row['out']).name,Path(row['out']))
for p in sorted(T.glob('sexos-reserve-cold-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
for name in ['source-audit.json','host/report.json','scalar-v2/result.json']:
 p=T/('sexos-eight-e-'+name);add('prior-production-evidence/'+name,p)
add('prior-production-evidence/source-binding.json',T/'sexos-eight-e-frozen/source-binding.json')
add('prior-production-evidence/round136-evidence.json',A/'sexos-quil-eight-reserve-2026-10-31-evidence.json');add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-quil-reserve-cold-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=137,qualified_last_incarnation_cold_recovery=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='778cd1ab85e165f2d891d824817c72326d4ab962',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,python_tests=975,native=dict(total_new_boots=8,verified_workflow_captures=80,all_fresh_replays=True,groups=rows,last_save_cold_proofs=proofs),prior_production_qualification=dict(round=136,source_commit=previous['source_commit'],same576_production_files=True,same_iso_kernel=True,registered_host_checks=43,rust_test_executions=2684,scalar_decoded_instructions=228332,scope='Existing production/host/static scan evidence. Four Python checker/test changes qualified here; host gates not rerun or relabelled as new.'),sustained_expanded_image_acceptance=False,release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='New checker cohort, same qualified Round136 production image. Both complete eight-Quil terminal disks cold-boot into freshQuil9 and load the lastQuil23 save with exact journal identity/generation/bank/payload and full completed viewport/clock pixels. The default pending-device Close/cold path is requalified at bothsizes. Read-only replay opens no guest/device. No power-loss/crash-consistency, new1800s, physical/SMP/hostile containment/global epoch, unbounded relaunch or daily-driver acceptance claim.')
p=A/'sexos-quil-reserve-cold-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('RESERVE_COLD_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
