from pathlib import Path
import hashlib,json,re
frozen=Path('/tmp/sexos-alpha-r105-utf8-h-frozen');elf=Path('/tmp/sexos-r105-h-tested-kaleidoscope.elf');dis=Path('/tmp/sexos-r105-h-kaleidoscope.disassembly')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];matches=[]
fp=re.compile(r'^(?:f(?:2xm1|abs|add.*|bld|bstp|chs|clex|cmov.*|com.*|cos|decstp|div.*|free.*|iadd.*|icom.*|idiv.*|ild.*|imul.*|incstp|init|ist.*|isub.*|ld.*|mul.*|nclex|ninit|nop|nsave.*|nst.*|patan|prem.*|ptan|rndint|rstor.*|save.*|scale|sin.*|sqrt|st.*|sub.*|tst|ucom.*|wait|xam|xch.*|xtract|yl2x.*)|vzeroall|vzeroupper|ldmxcsr|stmxcsr|xsave.*|xrstor.*)$')
for line in dis.read_text().splitlines():
 m=re.match(r'^\s*[0-9a-f]+:\s+(\S+)(.*)$',line)
 if not m:continue
 rows.append(line)
 if re.search(r'%(?:[xyz]mm\d+|mm\d+|st(?:\(|\b))',m[2])or fp.fullmatch(m[1]):matches.append(line)
assert len(rows)>10000
r=dict(ok=not matches,iso_sha256=sha(frozen/'tested.iso'),elf_sha256=sha(elf),disassembly_sha256=sha(dis),instructions=len(rows),vector_or_fp_matches=matches,scope='Decoded ISO-extracted Browser operands and inspected floating-point/state mnemonics only; no runtime stack/register/cache-erasure, scheduler, hostile containment or whole-image instruction proof.')
Path('/tmp/sexos-r105-h-scalar-instructions.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));assert r['ok']
