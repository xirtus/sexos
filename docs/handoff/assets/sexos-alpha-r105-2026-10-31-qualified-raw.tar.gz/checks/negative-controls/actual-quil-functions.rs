unsafe fn quil_source()->sex_pdx::text_selection::Source {sex_pdx::text_selection::Source{generation:QUIL_GENERATION,revision:QUIL_REVISION}}

unsafe fn quil_selection_bind() {
    QUIL_SELECTION.clear();
    if QUIL_SELECTION.bind(quil_source(),QUIL_BUFFER_LEN).is_ok(){let _=QUIL_SELECTION.move_to(quil_source(),QUIL_CURSOR_POS.min(QUIL_BUFFER_LEN),false);}
}

unsafe fn quil_selection_record() {
    if let Some(s)=QUIL_SELECTION.snapshot(){sex_pdx::serial_record!("[quil.selection] generation={} revision={} bytes={} anchor={} caret={}",s.source().generation,s.source().revision,s.len(),s.anchor(),s.caret());}
}

unsafe fn quil_selection_fence() {
    QUIL_GENERATION=0;QUIL_UNICODE_INPUT.clear();QUIL_UNICODE_SNAPSHOT=None;QUIL_INPUT_NOTICE=None;QUIL_SELECTION.clear();QUIL_COPY_SNAPSHOT=None;QUIL_PASTE_SNAPSHOT=None;QUIL_CLIPBOARD.close();
}

unsafe fn quil_revision_changed()->bool {
    let Some(next)=QUIL_REVISION.checked_add(1) else{quil_selection_fence();return false};
    QUIL_REVISION=next;QUIL_COPY_SNAPSHOT=None;QUIL_PASTE_SNAPSHOT=None;quil_selection_bind();
    sex_pdx::serial_record!("[quil.document.edit] revision={} pending={} bytes={}",QUIL_REVISION,DOCUMENT_IO.busy()as u8,QUIL_BUFFER_LEN);true
}

unsafe fn quil_fresh_source() {
    QUIL_UNICODE_INPUT.clear();QUIL_INPUT_NOTICE=None;QUIL_UNICODE_SNAPSHOT=None;
    let Some(next)=QUIL_GENERATION.checked_add(1).filter(|_|QUIL_GENERATION!=0)else{quil_selection_fence();return};
    QUIL_GENERATION=next;QUIL_REVISION=0;QUIL_COPY_SNAPSHOT=None;QUIL_PASTE_SNAPSHOT=None;UNDO_HEAD=0;UNDO_COUNT=0;UNDO_REDO_COUNT=0;
    if QUIL_CLIPBOARD.pending(){QUIL_CLIPBOARD.cancel(sex_pdx::get_ticks());}
    quil_selection_bind();
}

unsafe fn quil_replace(range:(usize,usize),incoming:&[u8])->bool {
    if QUIL_GENERATION==0 || QUIL_REVISION.checked_add(1).is_none()
        || view::replacement_len(QUIL_BUFFER_LEN,range,incoming.len()).is_none()
        || !sex_pdx::text_encoding::valid_text(incoming)
        || !sex_pdx::text_encoding::valid_text(&QUIL_BUFFER[..QUIL_BUFFER_LEN])
        || !sex_pdx::text_encoding::is_boundary(&QUIL_BUFFER[..QUIL_BUFFER_LEN],range.0)
        || !sex_pdx::text_encoding::is_boundary(&QUIL_BUFFER[..QUIL_BUFFER_LEN],range.1) {return false}
    text_buffer_undo_push();
    let Some(caret)=view::replace(&mut QUIL_BUFFER,&mut QUIL_BUFFER_LEN,range,incoming)else{return false};
    QUIL_CURSOR_POS=caret;QUIL_GOAL_COL=usize::MAX;QUIL_DIRTY=true;
    quil_revision_changed();quil_selection_record();true
}

fn quil_clipboard_status()->Option<&'static[u8]> {
    unsafe {if !QUIL_CLIPBOARD_NOTICE&&!QUIL_CLIPBOARD.pending(){return None}
        if let Some(error)=QUIL_CLIPBOARD_ERROR {return Some(error)}
        use sex_pdx::clipboard_client::View;
        Some(match QUIL_CLIPBOARD.view(){View::Idle=>return None,View::Pending=>b"CLIPBOARD...",View::Ready=>b"PASTED",View::Copied=>b"COPIED",View::Cancelled=>b"CANCELLED",View::Empty=>b"EMPTY SELECTION",View::Unsupported=>b"UNSUPPORTED",View::Busy=>b"CLIPBOARD BUSY",View::Denied=>b"CLIPBOARD DENIED",View::Uncertain=>b"CLIPBOARD UNCERTAIN"})
    }
}

fn quil_clipboard_events(palette_active:bool) {
    unsafe {while let Some(event)=QUIL_CLIPBOARD.take_event(){
        use sex_pdx::clipboard_client::{Event,View};
        QUIL_CLIPBOARD_NOTICE=true;
        match event {
            Event::Export{ticket,cut}=>{
                QUIL_CLIPBOARD_ERROR=None;
                if QUIL_NAME_MODE||palette_active||QUIL_UNICODE_INPUT.active() {QUIL_CLIPBOARD.decline(ticket,View::Unsupported,sex_pdx::get_ticks());continue}
                let Some(snapshot)=QUIL_SELECTION.snapshot() else{QUIL_CLIPBOARD.decline(ticket,View::Cancelled,sex_pdx::get_ticks());continue};
                let(start,end)=snapshot.range();
                sex_pdx::serial_record!("[quil.clipboard.intent] ticket={} action={} generation={} revision={} start={} end={}",ticket,if cut{"cut"}else{"copy"},snapshot.source().generation,snapshot.source().revision,start,end);
                if cut {QUIL_COPY_SNAPSHOT=Some((ticket,snapshot));}
                if !QUIL_CLIPBOARD.publish(ticket,snapshot.source(),&QUIL_BUFFER[start..end],sex_pdx::get_ticks()){QUIL_COPY_SNAPSHOT=None;}
            },
            Event::Paste{ticket}=>{
                QUIL_CLIPBOARD_ERROR=None;
                if QUIL_NAME_MODE||palette_active||QUIL_UNICODE_INPUT.active() {QUIL_CLIPBOARD.decline(ticket,View::Unsupported,sex_pdx::get_ticks());continue}
                let Some(snapshot)=QUIL_SELECTION.snapshot()else{QUIL_CLIPBOARD.decline(ticket,View::Cancelled,sex_pdx::get_ticks());continue};
                QUIL_PASTE_SNAPSHOT=Some((ticket,snapshot));
                sex_pdx::serial_record!("[quil.clipboard.intent] ticket={} action=paste generation={} revision={} start={} end={}",ticket,snapshot.source().generation,snapshot.source().revision,snapshot.range().0,snapshot.range().1);
                if !QUIL_CLIPBOARD.read(ticket,sex_pdx::get_ticks()){QUIL_PASTE_SNAPSHOT=None;}
            },
            Event::Published{ticket,cut,len,generation,hash}=>{
                let mut applied=false;
                if cut {if let Some((old,snapshot))=QUIL_COPY_SNAPSHOT.take(){if old==ticket&&QUIL_SELECTION.unchanged(snapshot){applied=quil_replace(snapshot.range(),&[]);}}}
                if cut&&!applied {QUIL_CLIPBOARD_ERROR=Some(b"COPIED / CUT SKIPPED");}
                sex_pdx::serial_record!("[quil.clipboard.published] ticket={} bytes={} generation={} hash={:#x} cut={} applied={}",ticket,len,generation,hash,cut as u8,applied as u8);
            },
            Event::Ready{ticket,len,generation,hash}=>{
                let mut applied=false;let mut reason="selection_changed";
                if let Some((old,snapshot))=QUIL_PASTE_SNAPSHOT.take(){if old==ticket&&QUIL_SELECTION.unchanged(snapshot){
                    if QUIL_SELECTION.replacement_len(snapshot,len).is_err(){reason="capacity";}
                    else if let Some(bytes)=QUIL_CLIPBOARD.bytes(){applied=quil_replace(snapshot.range(),bytes);if applied{reason="applied";}}
                }}
                QUIL_CLIPBOARD.settle(applied);
                if !applied{QUIL_CLIPBOARD_ERROR=Some(if reason=="capacity"{b"PASTE TOO LARGE"}else{b"SELECTION CHANGED"});}
                sex_pdx::serial_record!("[quil.clipboard.paste] ticket={} bytes={} generation={} hash={:#x} applied={} atomic=1 reason={}",ticket,len,generation,hash,applied as u8,reason);
            },
            Event::Stopped{ticket,view}=>{
                if QUIL_COPY_SNAPSHOT.is_some_and(|(t,_)|t==ticket){QUIL_COPY_SNAPSHOT=None;}
                if QUIL_PASTE_SNAPSHOT.is_some_and(|(t,_)|t==ticket){QUIL_PASTE_SNAPSHOT=None;}
                sex_pdx::serial_record!("[quil.clipboard.stopped] ticket={} state={:?} payload_erased=1",ticket,view);
            },
        }
        draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);
    }}
}

fn quil_dispatch_key(key:sex_pdx::app_key::Key,palette_active:&mut bool,selected_row:&mut u8) {
    // USB keycodes and retained PS/2 scan codes describe the same editor key.
    let code=match key.code{105=>0x4b,106=>0x4d,102=>0x47,107=>0x4f,103=>0x48,108=>0x50,104=>0x49,109=>0x51,111=>0x53,other=>other};
    let key=sex_pdx::app_key::Key{code,..key};
    unsafe {
        QUIL_CLIPBOARD_NOTICE=false;
        QUIL_INPUT_NOTICE=None;
        if QUIL_UNICODE_INPUT.active() {
            match QUIL_UNICODE_INPUT.key(key.code) {
                unicode_input::Action::Commit{bytes,len}=>{
                    let applied=QUIL_UNICODE_SNAPSHOT.take().is_some_and(|s|QUIL_SELECTION.unchanged(s)&&quil_replace(s.range(),&bytes[..len]));
                    if !applied {QUIL_INPUT_NOTICE=Some(b"UNICODE INPUT NOT APPLIED");}
                    sex_pdx::serial_record!("[quil.unicode.commit] bytes={} applied={} revision={} pending={}",len,applied as u8,QUIL_REVISION,DOCUMENT_IO.busy()as u8);
                },
                unicode_input::Action::Cancelled=>{QUIL_UNICODE_SNAPSHOT=None;sex_pdx::serial_record!("[quil.unicode.cancel] effects=0");},
                unicode_input::Action::Refused=>{sex_pdx::serial_record!("[quil.unicode.refused] reason=invalid_or_overflow effects=0");},
                unicode_input::Action::Pending=>{},
            }
            draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);return
        }
        if key.control {
            match key.code {
                0x16 if key.shift&&!QUIL_NAME_MODE&&!*palette_active=>{
                    QUIL_UNICODE_INPUT.begin();QUIL_UNICODE_SNAPSHOT=QUIL_SELECTION.snapshot();
                    sex_pdx::serial_record!("[quil.unicode.begin] generation={} revision={} effects=0",QUIL_GENERATION,QUIL_REVISION);
                    draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);
                },
                0x1e if !QUIL_NAME_MODE=>{*palette_active=false;let _=QUIL_SELECTION.select_all(quil_source());QUIL_CURSOR_POS=QUIL_BUFFER_LEN;quil_selection_record();draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);},
                0x31=>document_action(sex_pdx::document_view::NEW,palette_active,selected_row),
                0x18=>document_action(sex_pdx::document_view::OPEN,palette_active,selected_row),
                0x1f=>document_action(if key.shift{sex_pdx::document_view::SAVE_AS}else{sex_pdx::document_view::SAVE},palette_active,selected_row),
                0x13=>{if QUIL_CLIPBOARD.pending(){QUIL_CLIPBOARD.cancel(sex_pdx::get_ticks());QUIL_CLIPBOARD_NOTICE=true;QUIL_CLIPBOARD_ERROR=None;}document_action(sex_pdx::document_view::QUIESCE,palette_active,selected_row);},
                0x2c if !QUIL_NAME_MODE=>{*palette_active=false;if key.shift{text_buffer_redo();}else{text_buffer_undo();}draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);},
                0x15 if !QUIL_NAME_MODE=>{*palette_active=false;text_buffer_redo();draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);},
                // C/X/V arrive only as a separately authorized Shell INTENT.
                _=>{},
            }
            return
        }
        if QUIL_NAME_MODE||*palette_active||key.code==0x01 {
            SHIFT_HELD=key.shift;
            quil_dispatch_palette_key(key.code as u64,1,palette_active,selected_row);return
        }
        let source=quil_source();
        let Some(snapshot)=QUIL_SELECTION.snapshot()else{return};
        let old=QUIL_CURSOR_POS;
        let movement=match key.code {
            0x4b=>Some(QUIL_SELECTION.move_to(source,if !key.shift&&snapshot.range().0!=snapshot.range().1{snapshot.range().0}else{sex_pdx::text_encoding::previous(&QUIL_BUFFER[..QUIL_BUFFER_LEN],snapshot.caret())},key.shift)),
            0x4d=>Some(QUIL_SELECTION.move_to(source,if !key.shift&&snapshot.range().0!=snapshot.range().1{snapshot.range().1}else{sex_pdx::text_encoding::next(&QUIL_BUFFER[..QUIL_BUFFER_LEN],snapshot.caret())},key.shift)),
            0x47=>Some(QUIL_SELECTION.home(source,key.shift)),
            0x4f=>Some(QUIL_SELECTION.end(source,key.shift)),
            0x48|0x50|0x49|0x51=>{
                let steps=if key.code==0x49||key.code==0x51{DOCUMENT_VIEW.body_rows().max(1)}else{1};
                let next=view::vertical_steps(&QUIL_BUFFER[..QUIL_BUFFER_LEN],snapshot.caret(),DOCUMENT_VIEW.cols,&mut QUIL_GOAL_COL,key.code==0x48||key.code==0x49,steps).unwrap_or(snapshot.caret());
                Some(QUIL_SELECTION.move_to(source,next,key.shift))
            },_=>None,
        };
        if let Some(result)=movement {
            if result.is_ok(){QUIL_CURSOR_POS=QUIL_SELECTION.snapshot().unwrap().caret();if !matches!(key.code,0x48|0x50|0x49|0x51){QUIL_GOAL_COL=usize::MAX;}quil_selection_record();sex_pdx::serial_record!("[quil.cursor.move] old={} new={} len={} dir={} ok=1",old,QUIL_CURSOR_POS,QUIL_BUFFER_LEN,match key.code{0x4b=>"left",0x4d=>"right",0x47=>"home",0x4f=>"end",0x48=>"up",0x49=>"pageup",0x51=>"pagedown",_=>"down"});draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);}return
        }
        let range=snapshot.range();let selected=range.0!=range.1;
        let changed=match key.code {
            0x0e=>{let range=if selected{range}else{(sex_pdx::text_encoding::previous(&QUIL_BUFFER[..QUIL_BUFFER_LEN],snapshot.caret()),snapshot.caret())};range.0!=range.1&&quil_replace(range,&[])},
            0x53=>{let range=if selected{range}else{(snapshot.caret(),sex_pdx::text_encoding::next(&QUIL_BUFFER[..QUIL_BUFFER_LEN],snapshot.caret()))};range.0!=range.1&&quil_replace(range,&[])},
            0x0f=>quil_replace(range,b"\t"),
            0x1c=>quil_replace(range,b"\n"),
            _=>{if let Some(ch)=scancode_to_char(key.code as u64,key.shift){sex_pdx::serial_record!("[quil.text.recv] code={} ch={}",key.code,ch);quil_replace(range,&[ch])}else{false}},
        };
        if changed {draw_text_lines(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);}
    }
}

fn text_buffer_undo_push() {
    mark_dirty();
    unsafe {
        UNDO_RING[UNDO_HEAD][..QUIL_BUFFER_LEN]
            .copy_from_slice(&QUIL_BUFFER[..QUIL_BUFFER_LEN]);
        for i in QUIL_BUFFER_LEN..QUIL_BUFFER_MAX_LEN {
            UNDO_RING[UNDO_HEAD][i] = 0;
        }
        UNDO_LENS[UNDO_HEAD] = QUIL_BUFFER_LEN;
        UNDO_CURSORS[UNDO_HEAD] = QUIL_CURSOR_POS;
        UNDO_HEAD = (UNDO_HEAD + 1) % UNDO_DEPTH;
        if UNDO_COUNT < UNDO_DEPTH { UNDO_COUNT += 1; }
        UNDO_REDO_COUNT = 0; // new edit clears redo
        let idx = if UNDO_HEAD == 0 { UNDO_DEPTH - 1 } else { UNDO_HEAD - 1 };
        serial_println!("[quil.undo.push] idx={} len={} ok=1", idx, QUIL_BUFFER_LEN);
    }
}

fn text_buffer_undo() -> bool {
    unsafe {
        if UNDO_COUNT==0||QUIL_REVISION.checked_add(1).is_none()||QUIL_GENERATION==0{return false}
        let old_len=QUIL_BUFFER_LEN;
        let index=if UNDO_HEAD==0{UNDO_DEPTH-1}else{UNDO_HEAD-1};
        for i in 0..QUIL_BUFFER_MAX_LEN{core::mem::swap(&mut QUIL_BUFFER[i],&mut UNDO_RING[index][i]);}
        core::mem::swap(&mut QUIL_BUFFER_LEN,&mut UNDO_LENS[index]);
        core::mem::swap(&mut QUIL_CURSOR_POS,&mut UNDO_CURSORS[index]);
        UNDO_HEAD=index;UNDO_COUNT-=1;UNDO_REDO_COUNT=UNDO_REDO_COUNT.saturating_add(1).min(UNDO_DEPTH);
        QUIL_DIRTY=true;QUIL_GOAL_COL=usize::MAX;quil_revision_changed();
        serial_println!("[quil.undo.apply] old_len={} new_len={} ok=1",old_len,QUIL_BUFFER_LEN);true
    }
}

fn text_buffer_redo() -> bool {
    unsafe {
        if UNDO_REDO_COUNT==0||QUIL_REVISION.checked_add(1).is_none()||QUIL_GENERATION==0{return false}
        let old_len=QUIL_BUFFER_LEN;let index=UNDO_HEAD;
        for i in 0..QUIL_BUFFER_MAX_LEN{core::mem::swap(&mut QUIL_BUFFER[i],&mut UNDO_RING[index][i]);}
        core::mem::swap(&mut QUIL_BUFFER_LEN,&mut UNDO_LENS[index]);
        core::mem::swap(&mut QUIL_CURSOR_POS,&mut UNDO_CURSORS[index]);
        UNDO_HEAD=(UNDO_HEAD+1)%UNDO_DEPTH;UNDO_COUNT=(UNDO_COUNT+1).min(UNDO_DEPTH);UNDO_REDO_COUNT-=1;
        QUIL_DIRTY=true;QUIL_GOAL_COL=usize::MAX;quil_revision_changed();
        serial_println!("[quil.redo.apply] old_len={} new_len={} ok=1",old_len,QUIL_BUFFER_LEN);true
    }
}

fn mark_dirty() { unsafe { DIRTY = true; } }

fn scancode_to_char(scancode: u64, shift: bool) -> Option<u8> {
    match scancode as u8 {
        // Letters: lowercase by default, uppercase with shift
        0x10 => Some(if shift { b'Q' } else { b'q' }),
        0x11 => Some(if shift { b'W' } else { b'w' }),
        0x12 => Some(if shift { b'E' } else { b'e' }),
        0x13 => Some(if shift { b'R' } else { b'r' }),
        0x14 => Some(if shift { b'T' } else { b't' }),
        0x15 => Some(if shift { b'Y' } else { b'y' }),
        0x16 => Some(if shift { b'U' } else { b'u' }),
        0x17 => Some(if shift { b'I' } else { b'i' }),
        0x18 => Some(if shift { b'O' } else { b'o' }),
        0x19 => Some(if shift { b'P' } else { b'p' }),
        0x1E => Some(if shift { b'A' } else { b'a' }),
        0x1F => Some(if shift { b'S' } else { b's' }),
        0x20 => Some(if shift { b'D' } else { b'd' }),
        0x21 => Some(if shift { b'F' } else { b'f' }),
        0x22 => Some(if shift { b'G' } else { b'g' }),
        0x23 => Some(if shift { b'H' } else { b'h' }),
        0x24 => Some(if shift { b'J' } else { b'j' }),
        0x25 => Some(if shift { b'K' } else { b'k' }),
        0x26 => Some(if shift { b'L' } else { b'l' }),
        0x2C => Some(if shift { b'Z' } else { b'z' }),
        0x2D => Some(if shift { b'X' } else { b'x' }),
        0x2E => Some(if shift { b'C' } else { b'c' }),
        0x2F => Some(if shift { b'V' } else { b'v' }),
        0x30 => Some(if shift { b'B' } else { b'b' }),
        0x31 => Some(if shift { b'N' } else { b'n' }),
        0x32 => Some(if shift { b'M' } else { b'm' }),
        // Numbers/symbols: unshifted=digit, shifted=symbol
        0x02 => Some(if shift { b'!' } else { b'1' }),
        0x03 => Some(if shift { b'@' } else { b'2' }),
        0x04 => Some(if shift { b'#' } else { b'3' }),
        0x05 => Some(if shift { b'$' } else { b'4' }),
        0x06 => Some(if shift { b'%' } else { b'5' }),
        0x07 => Some(if shift { b'^' } else { b'6' }),
        0x08 => Some(if shift { b'&' } else { b'7' }),
        0x09 => Some(if shift { b'*' } else { b'8' }),
        0x0A => Some(if shift { b'(' } else { b'9' }),
        0x0B => Some(if shift { b')' } else { b'0' }),
        // Punctuation
        0x27 => Some(if shift { b':' } else { b';' }),
        0x28 => Some(if shift { b'"' } else { b'\'' }),
        0x33 => Some(if shift { b'<' } else { b',' }),
        0x34 => Some(if shift { b'>' } else { b'.' }),
        0x35 => Some(if shift { b'?' } else { b'/' }),
        0x39 => Some(b' '),  // space (no shift variant)
        0x1C => None, 0x0E => None, 0x0F => None,
        _ => None,
    }
}
