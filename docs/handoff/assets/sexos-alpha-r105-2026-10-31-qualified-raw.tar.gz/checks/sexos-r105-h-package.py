"""Prepare final105 evidence only after root-authorized terminal qualification.

Run --check-only for read-only acceptance preflight; --execute creates assets.
This helper never builds, boots, changes sources, or edits reports.
"""
from pathlib import Path
import argparse,gzip,hashlib,io,json,os,re,subprocess,tarfile
from PIL import Image
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');C='h'
F=T/f'sexos-alpha-r105-utf8-{C}-frozen';B=T/f'sexos-alpha-r105-utf8-{C}-build'
A=R/'docs/handoff/assets';STEM='sexos-alpha-r105-2026-10-31'
DIAGNOSTIC_CANDIDATES=('d','e','f','g')
EXPECTED_RUST={'service-custody':1782,'display':56,'readability':9,'launcher':35,'text-pipeline':65,'drive-wait':38}
MARKERS={'service-custody':'[service.custody.host.gate] PASS','display':'[gate.display_surface_groups.result] PASS',
 'readability':'[gate.display_text_readability.result] PASS','launcher':'[launcher.workspace.host] PASS',
 'text-pipeline':'[gate.linen_text_delivery.result] PASS','drive-wait':'[gate.sexdrive_service.result] PASS'}
SCOPES={'service-custody':'Actual Rust custody/clipboard/UTF8/editor/reader/network functions with explicitly modeled host callbacks.',
 'display':'Actual display Stage/scalar/scanline/damage and exact parent policy functions; not guest pixel evidence.',
 'readability':'Actual readable layout/contrast functions; separate executions, not unique-test deduplication.',
 'launcher':'Actual Shell action/workspace/admission callbacks; not native frame evidence.',
 'text-pipeline':'Actual UTF8 Reader/shared Outbox/Display Stage/Applied integration with finite transport callbacks.',
 'drive-wait':'Actual four NVMe completion wait paths/dispatch with fake ticks, CQEs and event words; native checks qualify affected guest workflows only.'}
REQUIRED_DIAGNOSTICS=('sexos-r105-d-utf8-outbox-diagnostic.json','sexos-r105-e-atomic-receipt-diagnostic.json','sexos-r105-f-nvme-timeout-diagnostic.json','sexos-r105-g-launcher-receipt-diagnostic.json')
EXCLUDED_CACHE_COMPONENTS={'target','__pycache__'}
CHECK_SUFFIXES={'.rs','.py','.json','.log','.disassembly','.elf'}
SCOPE=('One substantive UTF8 round: explicit scalar entry, byte-preserving text/clipboard/Save/cold reopen, fixed source-bound finite glyph repertoire and visible unsupported-glyph fallback, plus complete atomic UTF8 display handoff. Four NVMe completion waits now use bounded elapsed ticks/yield and preserve DMA quarantine on uncertainty. Single GLOBAL_VAS, immutable BOOT capability genesis and typed exact-incarnation sex-pdx authority remain; not Unix/POSIX.')
LIMITATIONS=[
 'Text uses one scalar per fixed cell and a finite font with visible fallback. No Unicode shaping, grapheme composition, normalization, IME, bidirectional layout or Unicode filenames are qualified.',
 'Readability native entry/toolbar/Save proof is original Quil9 at two desktop sizes; clipboard uses a source-defined fixed12288-byte UTF8 HTTP fixture and same-image cold recovery. Tiny viewports, broad queue pressure and other instances remain host-function scopes unless separately recorded.',
 'NVMe wait evidence covers exactly four runtime completion paths and the actual host fake-clock/CQE/event-word cases. The bounded callback assumes the clock/yield callback returns; no arbitrary callback-termination or whole-driver timing proof is claimed.',
 'The scalar audit inspects decoded operands/mnemonics in the ISO-extracted Browser ELF only. It is not a whole-image, runtime stack/register/cache-erasure or hostile containment proof.',
 'The finite captured endpoint is a controlled plain-HTTP fixture. No public web/CA, physical hardware, SMP, crash/power-loss, full-system deterministic replay, sustained daily-driver or System Proven claim.'
]

def load(path):return json.loads(Path(path).read_text())
def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as stream:
  for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def safe(name):
 p=Path(name)
 assert name and not p.is_absolute()and '..'not in p.parts and not(EXCLUDED_CACHE_COMPONENTS&set(p.parts)),name
 return name

def verify_frozen(directory,live=False):
 directory=Path(directory);binding=load(directory/'source-binding.json');sources={**binding['sources'],**binding['runner_sha256']}
 assert not(set(binding['sources'])&set(binding['runner_sha256']))
 for name,expected in sources.items():
  safe(name);path=directory/'source'/name;assert path.is_file()and not path.is_symlink()and sha(path)==expected,name
  if live:assert sha(R/name)==expected,('live source differs',name)
 assert sha(directory/'tested.iso')==binding['iso_sha256'];assert sha(directory/'tested.kernel')==binding['kernel_sha256']
 return binding

def ensure_no_qemu():
 p=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True,check=True)
 owners=[line for line in p.stdout.splitlines()if re.search(r'(^|\s|/)qemu-system-[^/ ]+\s*$',line)]
 assert not owners,('QEMU remains live; do not package/compress',owners)

def validation():
 binding=verify_frozen(F,True);assert(len(binding['sources']),len(binding['runner_sha256']))==(563,531)
 assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
 assert load(B/'provenance.json')['iso_sha256']==binding['iso_sha256']and '| **FINAL_SCORE** | **GREEN_MASTER** |'in(B/'report.md').read_text()
 progress=load(T/f'sexos-r105-{C}-native-suite-progress.json');replay_path=T/f'sexos-r105-{C}-root-independent-replay.json';replay=load(replay_path)
 assert len(progress)==6 and all(type(row['status'])is int and row['status']==0 for row in progress)
 assert replay['ok']and replay['complete']and(replay['native_runs'],replay['native_boots'],replay['frames'])==(6,8,98)
 assert replay['source_binding_sha256']==sha(F/'source-binding.json')and sum(row['boots']for row in progress)==8
 assert sum(row['frames']for row in replay['runs'])==98
 expected_names={'readability-wide','readability-compact','launcher-wide','launcher-compact','clipboard-wide','clipboard-compact'}
 assert{row['name']for row in progress}==expected_names and{row['name']for row in replay['runs']}==expected_names
 for row in progress:
  other=next(r for r in replay['runs']if r['name']==row['name']);assert other['ok']and all(other[k]==row[k]for k in('out','mode','profile','boots'))
  assert other['frames']==(9 if row['name'].startswith('readability-')else 29 if row['name'].startswith('launcher-')else 11)
  assert row['source_binding_sha256']==sha(F/'source-binding.json')and load(Path(row['out'])/'result.json')['ok']
  if row['name'].startswith('readability-'):
   result=load(Path(row['out'])/'result.json');assert result['text_profile']=='utf8'and result['unicode_input']['operations']==4 and result['journal']['bytes']==19
  if row['name'].startswith('clipboard-'):
   manifests=[load(Path(row['out'])/boot/'manifest.json')for boot in('write','recovery')]
   assert all(m['text_profile']=='utf8'and m['body_bytes']==12288 for m in manifests)and manifests[0]['body_sha256']==manifests[1]['body_sha256']
 logs=[]
 for label,expected in EXPECTED_RUST.items():
  path=T/f'sexos-r105-{C}-frozen-{label}.log';text=path.read_text();assert MARKERS[label]in text
  assert not re.search(r'test result: FAILED|error: aborting|^error\[E',text,re.M),(label,'failure in host log')
  count=sum(map(int,re.findall(r'\btest result: ok\. (\d+) passed;',text)));assert count==expected,(label,count,expected)
  logs.append(dict(name=label,path=str(path),executions=count,sha256=sha(path),scope=SCOPES[label]))
 assert sum(row['executions']for row in logs)==1985
 python_log=T/f'sexos-r105-{C}-frozen-python.log';text=python_log.read_text();assert re.search(r'^OK$',text,re.M)
 counts=re.findall(r'Ran (\d+) tests',text);assert len(counts)==1 and int(counts[0])==767
 negative=load(T/f'sexos-r105-{C}-negative-controls.json');assert negative['ok']and negative['source_binding_sha256']==sha(F/'source-binding.json')and len(negative['controls'])==4
 assert{row['name']for row in negative['controls']}=={'unicode-overflow','viewport-budget','atomic-outbox','browser-source'}
 assert all(row['negative_rejected']and row['baseline_passed']and row['returncode']!=0 for row in negative['controls'])
 control_inputs={'unicode-overflow':('servers/quil/src/unicode_input.rs','tests/quil_clipboard_ui.rs'),'viewport-budget':('servers/quil/src/view.rs','tests/quil_view.rs'),'atomic-outbox':('servers/silk-shell/src/linen_text_delivery.rs','tests/linen_text_delivery.rs'),'browser-source':('apps/kaleidoscope/src/http_probe.rs','tests/http_probe.rs')}
 for row in negative['controls']:
  module,fixture=control_inputs[row['name']];directory=T/f'sexos-r105-{C}-negatives';log=directory/(row['name']+'-mutant-test.log');baseline=directory/(row['name']+'-baseline-test.log')
  assert row['source_sha256']==sha(F/'source'/module)and row['fixture_sha256']==sha(F/'source'/fixture)
  assert row['mutant_sha256']==sha(directory/(row['name']+'-mutant.rs'))and row['log_sha256']==sha(log)
  assert row['returncode']==101 and '1 failed;'in log.read_text()and row['test']+' ... FAILED'in log.read_text()
  assert '1 passed;'in baseline.read_text()and 'test result: FAILED'not in baseline.read_text()

 scalar=load(T/f'sexos-r105-{C}-scalar-instructions.json');assert scalar['ok']and scalar['instructions']==89412 and scalar['vector_or_fp_matches']==[]
 assert scalar['iso_sha256']==binding['iso_sha256']and scalar['elf_sha256']==sha(T/f'sexos-r105-{C}-tested-kaleidoscope.elf')and scalar['disassembly_sha256']==sha(T/f'sexos-r105-{C}-kaleidoscope.disassembly')
 for name in REQUIRED_DIAGNOSTICS:assert (T/name).is_file()
 return dict(binding=binding,progress=progress,replay=replay,replay_path=replay_path,rust=logs,python_count=int(counts[0]),python_log=python_log,negative=negative,scalar=scalar)

class Collector:
 def __init__(self):self.members={};self.disk_copies=[];self.excluded_caches=[];self.omitted_negative_binaries=[]
 def add(self,path,name):
  path=Path(path);safe(name);assert path.is_file()and not path.is_symlink(),path
  if name in self.members:assert self.members[name]==path;return
  self.members[name]=path
 def disk(self,path):
  path=Path(path);ensure_no_qemu();owner=subprocess.run(['lsof','-t',str(path)],capture_output=True,text=True)
  assert owner.returncode in (0,1)and not owner.stdout.strip()and not owner.stderr.strip(),('raw disk is owned',str(path),owner.stdout,owner.stderr)
  before=path.stat();raw_sha=sha(path);candidates=[path.with_name(path.name+'.gz'),path.parent/'root-terminal-disk.img.gz'];compressed=next((p for p in candidates if p.is_file()),None)
  created=False
  if compressed is None:
   compressed=path.with_name(path.name+'.archive-copy.gz');assert not compressed.exists();created=True
   with path.open('rb')as source,compressed.open('xb')as target:
    with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0)as zipped:
     for block in iter(lambda:source.read(1<<20),b''):zipped.write(block)
  h=hashlib.sha256();size=0
  with gzip.open(compressed,'rb')as stream:
   for block in iter(lambda:stream.read(1<<20),b''):h.update(block);size+=len(block)
  after=path.stat();assert(before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)and raw_sha==sha(path)==h.hexdigest()and size==after.st_size
  ensure_no_qemu();owner2=subprocess.run(['lsof','-t',str(path)],capture_output=True,text=True);assert owner2.returncode in(0,1)and not owner2.stdout.strip()and not owner2.stderr.strip()
  self.disk_copies.append(dict(raw=str(path),raw_sha256=raw_sha,bytes=size,compressed=str(compressed),compressed_sha256=sha(compressed),created_after_terminal_checks=created,uncompressed_verified=True));return compressed
 def tree(self,directory,prefix,controls_only=False):
  directory=Path(directory);assert directory.is_dir(),directory
  for path in sorted(directory.rglob('*')):
   relative=path.relative_to(directory)
   if EXCLUDED_CACHE_COMPONENTS&set(relative.parts):
    self.excluded_caches.append(str(path));continue
   assert not path.is_symlink(),path
   if not path.is_file():continue
   if controls_only and path.suffix not in CHECK_SUFFIXES:self.omitted_negative_binaries.append(str(path));continue
   if path.suffix=='.img':
    compressed=self.disk(path);self.add(compressed,prefix+'/'+str(relative)+'.verified.gz')
   else:self.add(path,prefix+'/'+str(relative))
 def frozen(self,directory,prefix):
  binding=verify_frozen(directory)
  for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):self.add(Path(directory)/'source'/name,prefix+'/source/'+name)
  for name in('source-binding.json','tested.iso','tested.kernel'):self.add(Path(directory)/name,prefix+'/'+name)

def collect(context):
 c=Collector();c.frozen(F,'final');c.tree(B,'build')
 for row in context['progress']:
  c.tree(row['out'],'native/'+row['name']);c.add(row['driver'],'checks/'+Path(row['driver']).name)
 for candidate in ('a','b','c'):
  c.tree(T/f'sexos-alpha-r105-utf8-{candidate}-build','diagnostics/'+candidate+'/build')
 for candidate in DIAGNOSTIC_CANDIDATES:
  c.frozen(T/f'sexos-alpha-r105-utf8-{candidate}-frozen','diagnostics/'+candidate+'/frozen');c.tree(T/f'sexos-alpha-r105-utf8-{candidate}-build','diagnostics/'+candidate+'/build')
  historical=load(T/f'sexos-r105-{candidate}-native-suite-progress.json')
  for row in historical:
   out=Path(row['out'])
   if out.is_dir():c.tree(out,'diagnostics/'+candidate+'/native/'+row['name'])
   driver=Path(row['driver'])
   if driver.is_file():c.add(driver,'diagnostics/'+candidate+'/checks/'+driver.name)
 for candidate in ('a','b','c')+DIAGNOSTIC_CANDIDATES+(C,):
  for path in sorted(T.glob(f'sexos-r105-{candidate}-*')):
   if not path.is_file()or path.suffix not in CHECK_SUFFIXES or 'package.log'in path.name:continue
   prefix='checks'if candidate==C else'diagnostics/'+candidate+'/checks';c.add(path,prefix+'/'+path.name)
  controls=T/f'sexos-r105-{candidate}-negatives'
  if controls.is_dir():c.tree(controls,('checks'if candidate==C else'diagnostics/'+candidate+'/checks')+'/negative-controls',True)
 for name in REQUIRED_DIAGNOSTICS:c.add(T/name,'diagnostics/'+name)
 # Explicit non-executable raw diagnostic data; no wildcard .bin build outputs.
 for name in ('sexos-r105-d-actual-reader-frame.bin','sexos-r105-d-outbox-negative.rs','sexos-r105-d-outbox-negative.json'):
  path=T/name
  if path.is_file():c.add(path,'diagnostics/d/host-repro/'+name)
 seed=T/'sexos-r100a-seed.img';compressed=c.disk(seed);c.add(compressed,'seed.img.gz')
 return c

def screenshots(context):
 specifications=[('readability-wide','','resaved.ppm','editor-wide'),('readability-compact','','commands.ppm','commands-compact'),('clipboard-wide','write','browser-reverse.ppm','clipboard-wide-selected'),('clipboard-compact','recovery','quil-cold-reopened.ppm','cold-compact')];result=[]
 for name,boot,filename,label in specifications:
  row=next(r for r in context['progress']if r['name']==name);out=Path(row['out'])/boot;frames=load(out/'frames.json');found=[f for f in frames if f['screenshot']==filename];assert len(found)==1;frame=found[0];raw=out/filename
  assert frame['screenshot_sha256']==sha(raw);serial=(out/'serial.log').read_bytes();size=frame['serial_bytes'];assert 0<size<=len(serial)and digest_bytes(serial[:size])==frame['serial_sha256']
  dest=A/f'{STEM}-{label}.png';assert not dest.exists()
  with Image.open(raw)as image:
   image=image.convert('RGB');original=image.tobytes();dimensions=image.size;image.save(dest)
  with Image.open(dest)as image:assert image.convert('RGB').tobytes()==original and image.size==dimensions
  result.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=name,boot=boot,raw_ppm=filename,raw_sha256=sha(raw),serial_bytes=size,serial_sha256=frame['serial_sha256'],rgb_sha256=digest_bytes(original),dimensions=dimensions,pixel_identical=True))
 return result

def archive(collector):
 path=A/f'{STEM}-qualified-raw.tar.gz';assert not path.exists();inventory=[dict(name=name,bytes=source.stat().st_size,sha256=sha(source))for name,source in sorted(collector.members.items())]
 note=dict(scope='Final candidate '+C.upper()+' acceptance only. Every superseded candidate/source/native failure remains historical diagnostics, never inherited acceptance.',excluded_unbound_cache_components=sorted(EXCLUDED_CACHE_COMPONENTS),excluded_unbound_caches=collector.excluded_caches,omitted_negative_compiled_outputs=collector.omitted_negative_binaries,raw_disk_omissions_only_with_exact_compressed_copy=collector.disk_copies,members=inventory)
 index=(json.dumps(note,indent=2)+'\n').encode()
 with path.open('xb')as target,gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as tar:
  for row in inventory:
   source=collector.members[row['name']];assert sha(source)==row['sha256'];info=tarfile.TarInfo(row['name']);info.size=row['bytes'];info.mtime=0;info.uid=info.gid=0;info.mode=0o644
   with source.open('rb')as stream:tar.addfile(info,stream)
  info=tarfile.TarInfo('archive-inventory.json');info.size=len(index);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(index))
 expected=inventory+[dict(name='archive-inventory.json',bytes=len(index),sha256=digest_bytes(index))]
 with tarfile.open(path,'r:gz')as tar:
  members=tar.getmembers();assert len(members)==len(expected)and all(member.isfile()for member in members)and{member.name for member in members}=={row['name']for row in expected}
  for row in expected:
   data=tar.extractfile(row['name']).read();assert len(data)==row['bytes']and digest_bytes(data)==row['sha256'],row['name']
 return dict(path=str(path.relative_to(R/'docs/handoff')),sha256=sha(path),members=len(expected),verified=True,bytes=path.stat().st_size,raw_disk_copies=collector.disk_copies)

def main():
 p=argparse.ArgumentParser();mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--check-only',action='store_true');mode.add_argument('--execute',action='store_true');args=p.parse_args();context=validation()
 if args.check_only:print(json.dumps(dict(ok=True,mode='read-only preflight',candidate=C,rust=sum(r['executions']for r in context['rust']),python=context['python_count'],native_runs=6,native_boots=8,frames=98)));return
 ensure_no_qemu();evidence_path=A/f'{STEM}-evidence.json';assert A.is_dir()and not evidence_path.exists()
 for label in ('editor-wide','commands-compact','clipboard-wide-selected','cold-compact'):assert not(A/f'{STEM}-{label}.png').exists()
 assert not(A/f'{STEM}-qualified-raw.tar.gz').exists();collector=collect(context);pictures=screenshots(context);raw=archive(collector)
 # Recheck sealed/live hashes after collection and archive verification.
 assert verify_frozen(F,True)==context['binding']
 evidence=dict(round=105,accepted=True,accepted_goal_rounds=26,total_goal_rounds=121,remaining_goal_rounds=95,candidate=C.upper(),iso_sha256=context['binding']['iso_sha256'],kernel_sha256=context['binding']['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),architecture_sha256=context['binding']['architecture_sha256'],production_inputs=len(context['binding']['sources']),runner_inputs=len(context['binding']['runner_sha256']),checks=dict(master='BUILD PASS / GREEN_MASTER',rust=context['rust'],rust_test_executions=1985,python_tests=context['python_count'],python_log_sha256=sha(context['python_log']),native_runs=6,native_boots=8,independent_frames=98,root_replay_sha256=sha(context['replay_path']),scalar_audit=context['scalar'],semantic_negative_controls=context['negative']),qualification_runs=context['progress'],remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=pictures,archive=raw,failed_diagnostics='Superseded A compile and B/C build attempts, complete D/E/F/G frozen closures and native raw failures/results are retained. D valid UTF8 reader failed shared ASCII outbox admission; E real legacy receipt fragmentation failed strict joins; F real NVMe bounded-poll timeout preserved prior Save and quarantine; G real legacy launcher-open receipt fragmentation failed a strict same-line join despite successful prior readability boots. Those candidates contribute no final native acceptance.',limitations=LIMITATIONS,scope=SCOPE)
 with evidence_path.open('x')as stream:stream.write(json.dumps(evidence,indent=2)+'\n')
 print(json.dumps(dict(ok=True,round=105,candidate=C,rust=1985,python=context['python_count'],archive=raw)))
if __name__=='__main__':main()
