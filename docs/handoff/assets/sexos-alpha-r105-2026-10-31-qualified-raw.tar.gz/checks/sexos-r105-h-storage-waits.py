"""Supplemental raw observation; complete native acceptance is separate."""
from pathlib import Path
import hashlib,json,re
T=Path('/tmp');progress=json.loads((T/'sexos-r105-h-native-suite-progress.json').read_text());assert len(progress)==6 and all(type(r['status'])is int and r['status']==0 for r in progress)
pattern=re.compile(rb'\[sexdrive\.nvme\.wait\] cid=(\d+) head=(\d+) phase=(\d+) polls=(\d+) turns=(\d+) elapsed_ticks=(\d+) result=Ok\(\(\)\)\r?\n');rows=[]
for row in progress:
 for path in sorted(Path(row['out']).rglob('serial.log')):
  raw=path.read_bytes();matches=list(pattern.finditer(raw));assert len(matches)==raw.count(b'[sexdrive.nvme.wait]'),str(path)
  observations=[]
  for m in matches:
   cid,head,phase,polls,turns,elapsed=map(int,m.groups());assert 0<=head<16 and phase in(0,1)and 1<=turns<4096 and turns*64<polls<=(turns+1)*64 and elapsed<1000
   observations.append(dict(offset=m.start(),cid=cid,head=head,phase=phase,polls=polls,turns=turns,elapsed_ticks=elapsed))
  rows.append(dict(run=row['name'],serial=str(path),serial_sha256=hashlib.sha256(raw).hexdigest(),observations=observations))
assert len(rows)==8 and sum(len(r['observations'])for r in rows)>0
v=dict(ok=True,boots=8,total_cooperative_completions=sum(len(r['observations'])for r in rows),runs=rows,scope='Observed exact driver slow-wait records in terminal accepted native serial logs. Every recorded pause reached matching CQE; this does not cover fast unlogged completions, arbitrary hardware-time failure, whole-driver timing, crash/power loss or hostile containment.')
p=T/'sexos-r105-h-storage-waits.json';assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(dict(ok=True,boots=8,cooperative_completions=v['total_cooperative_completions'])))
