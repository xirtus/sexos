from pathlib import Path
import json,os,re,subprocess
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');B=T/'sexos-alpha-r105-utf8-h-build';F=T/'sexos-alpha-r105-utf8-h-frozen'
assert not B.exists() and not F.exists()
def run(cmd,label,cwd=R,env=None):
 p=T/('sexos-r105-h-'+label+'.log');assert not p.exists();print('START',label,flush=True)
 with p.open('w')as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
run(['bash','scripts/master_runtime_gate.sh','--keep-log'],'build-console',env={**os.environ,'GATE_DIR':str(B)})
run(['python3','scripts/freeze_native_evidence.py','--root',str(R),'--build',str(B),'--out',str(F),'--iso','sexos-v1.0.0.iso','--kernel','iso_root/sexos-kernel'],'freeze')
jobs=[]
for label,cmd in [(n,['bash','scripts/'+s])for n,s in [('service-custody','service_custody_host_gate.sh'),('display','display_surface_groups_gate.sh'),('readability','display_text_readability_gate.sh'),('launcher','launcher_host_gate.sh'),('text-pipeline','linen_text_delivery_gate.sh'),('drive-wait','sexdrive_dma_host_gate.sh')]]+ [('python',['python3','-m','unittest','discover','-s','scripts/tests'])]:
 p=T/('sexos-r105-h-frozen-'+label+'.log');assert not p.exists();log=p.open('w');proc=subprocess.Popen(cmd,cwd=F/'source',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT);jobs.append((label,proc,log))
failed=[]
for label,proc,log in jobs:
 code=proc.wait();log.close();print('HOST',label,code,flush=True)
 if code:failed.append((label,code))
assert not failed,failed
counts=[sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',(T/('sexos-r105-h-frozen-'+n+'.log')).read_text(),re.M)))for n in ['service-custody','display','readability','launcher','text-pipeline','drive-wait']];assert counts==[1782,56,9,35,65,38],counts
assert re.search(r'Ran 767 tests.*\n\nOK', (T/'sexos-r105-h-frozen-python.log').read_text(),re.S)
run(['python3','/tmp/sexos-r105-h-negative-controls.py'],'negative-controls')
run(['python3','/tmp/sexos-r105-h-native-suite.py'],'native-suite')
run(['python3','/tmp/sexos-r105-h-independent-replay.py'],'independent-replay')
run(['xorriso','-osirrox','on','-indev',str(F/'tested.iso'),'-extract','/apps/kaleidoscope','/tmp/sexos-r105-h-tested-kaleidoscope.elf'],'iso-extract')
p=T/'sexos-r105-h-kaleidoscope.disassembly';assert not p.exists()
with p.open('w')as log:subprocess.run(['/Users/xmacbookm5/.rustup/toolchains/nightly-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin/llvm-objdump','--disassemble','--no-show-raw-insn','--x86-asm-syntax=att','/tmp/sexos-r105-h-tested-kaleidoscope.elf'],stdout=log,check=True)
run(['python3','/tmp/sexos-r105-h-audit-instructions.py'],'scalar-audit')
print('R105H_ALL_QUALIFICATION_PASS_ACCEPTANCE_PENDING_ROOT_REVIEW',flush=True)
