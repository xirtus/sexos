from pathlib import Path
import hashlib,json,os,re,subprocess
F=Path('/tmp/sexos-alpha-r105-utf8-h-frozen').resolve();R=F/'source';T=Path('/tmp/sexos-r105-h-negatives');T.mkdir();rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,name,env=None):
 p=T/(name+'.log')
 with p.open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 return r.returncode,p

def paths(f,overrides):
 s=f.read_text()
 def one(m):
  target=(f.parent/m[1]).resolve();return '#[path="'+str(overrides.get(target,target))+'"]'
 return re.sub(r'#\[path\s*=\s*"([^"]+)"\]',one,s)

# Actual frozen canonical extraction, rather than a shadow editor implementation.
gate=(R/'scripts/quil_clipboard_host_gate.sh').read_text();extract=gate.split("<<'PY'\n",1)[1].split('\nPY\n',1)[0]
actual=T/'actual-quil-functions.rs';code,log=run(['python3','-c',extract,str(R),str(actual)],'extract');assert code==0
for name,fixture,module,mutant,test,externs,env in [
 ('unicode-overflow','tests/quil_clipboard_ui.rs','servers/quil/src/unicode_input.rs',None,'unicode_digit_overflow_requires_recovery_and_cannot_commit_a_silent_prefix',[],{**os.environ,'QUIL_CLIPBOARD_UI_SOURCE':str(actual)}),
 ('viewport-budget','tests/quil_view.rs','servers/quil/src/view.rs',Path('/tmp/sexos-r105-b-quil-view.rs'),'one_four_byte_character_does_not_collapse_otherwise_ascii_viewport',[],None),
 ('atomic-outbox','tests/linen_text_delivery.rs','servers/silk-shell/src/linen_text_delivery.rs',Path('/tmp/sexos-alpha-r105-utf8-d-frozen/source/servers/silk-shell/src/linen_text_delivery.rs'),'utf8_reader_frame_crosses_every_full_boundary_and_only_exact_applied_publishes_metadata',[],None),
 ('browser-source','tests/http_probe.rs','apps/kaleidoscope/src/http_probe.rs',None,'utf8_charset_and_split_scalars_retain_exact_bytes_only_after_positive_release',None,None),
]:
 source=R/module;mutant_path=T/(name+'-mutant.rs');original=source.read_text()
 if name=='unicode-overflow':
  old='if self.invalid || self.digits == 0 || !text_encoding::is_text_scalar(self.value)';assert original.count(old)==1;changed=original.replace(old,'if self.digits == 0 || !text_encoding::is_text_scalar(self.value)')
 elif name=='browser-source':
  old='self.document[self.document_len]=byte;';assert original.count(old)==1;changed=original.replace(old,"self.document[self.document_len]=match byte {b'\\n'=>b'\\n',32..=126=>byte,0..=31|127=>b' ',_=>b'?'};")
 else:changed=mutant.read_text()
 assert changed!=original;mutant_path.write_text(changed)
 if externs is None:
  lib=T/'libsex_net_config.rlib';code,log=run(['rustc','--edition=2021','--crate-name','sex_net_config','--crate-type','rlib',str(R/'crates/sex-net-config/src/lib.rs'),'-o',str(lib)],'config');assert code==0
  externs=['--extern','sex_net_config='+str(lib)]
 for kind,overrides in [('baseline',{}),('mutant',{source.resolve():mutant_path})]:
  root=T/(name+'-'+kind+'-fixture.rs');root.write_text(paths(R/fixture,overrides));binary=T/(name+'-'+kind)
  code,log=run(['rustc','--edition=2021','-A','dead_code','--test',str(root),*externs,'-o',str(binary)],name+'-'+kind+'-compile',env);assert code==0,(name,kind,log)
  code,log=run([str(binary),'--exact',test,'--test-threads=1'],name+'-'+kind+'-test',env)
  if kind=='baseline':assert code==0,(name,log)
  else:
   assert code==101 and '1 failed;'in log.read_text() and test+' ... FAILED'in log.read_text(),(name,code,log)
   rows.append(dict(name=name,test=test,negative_rejected=True,returncode=code,source_sha256=sha(source),mutant_sha256=sha(mutant_path),fixture_sha256=sha(R/fixture),baseline_passed=True,log_sha256=sha(log)))
result=dict(ok=True,source_binding_sha256=sha(F/'source-binding.json'),controls=rows,scope='Actual frozen editor Unicode overflow, Quil viewport budgeting and Browser raw UTF8 retention and shared atomic UTF8 frame outbox functions; separately compiled mutations fail their corresponding real regression. No production/frozen image changed.')
Path('/tmp/sexos-r105-h-negative-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
