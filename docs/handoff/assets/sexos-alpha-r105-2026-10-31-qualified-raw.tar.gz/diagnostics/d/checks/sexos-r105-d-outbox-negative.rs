extern crate self as sex_pdx;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/crates/sex-pdx/src/text_encoding.rs"]pub mod text_encoding;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/crates/sex-pdx/src/desktop_style.rs"]pub mod desktop_style;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/crates/sex-pdx/src/network_config.rs"]pub mod network_config;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/crates/sex-pdx/src/text_batch.rs"]pub mod text_batch;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/apps/kaleidoscope/src/document_reader.rs"]mod reader;
#[path="/private/tmp/sexos-alpha-r105-utf8-d-frozen/source/servers/silk-shell/src/linen_text_delivery.rs"]mod outbox;
fn main(){let body=std::fs::read("/tmp/sexos-r105-d-captured-profile-body.bin").unwrap();let mut r=reader::Reader::new();r.resize(640,375);let f=r.render_path_selected(&body,b"/welcome",None);std::fs::write("/tmp/sexos-r105-d-actual-reader-frame.bin",&f.bytes[..f.len]).unwrap();let mut o=outbox::Outbox::atomic(300);let accepted=o.queue_selected(&f.bytes[..f.len],0xcdd6f4,outbox::Metadata{count:12288,first:f.first,rows:f.body_rows,selected:258},f.selection);let pending=o.pending();let mut calls=0;o.poll(4,|_|{calls+=1;outbox::Admission::Accepted});println!("{{\"accepted\":{},\"pending\":{},\"send_calls\":{},\"bytes\":{},\"first\":{},\"end\":{},\"body_rows\":{},\"rows\":{},\"cols\":{},\"total_lines\":{}}}",accepted,pending,calls,f.len,f.first,f.end,f.body_rows,f.rows,f.cols,f.total_lines);assert!(!accepted&&!pending&&calls==0);}
