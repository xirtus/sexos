from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-alpha-launcher-b-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
audit=read(T/'sexos-alpha-launcher-b-paired-audit.json');assert audit['ok']
b=read(F/'source-binding.json');h=read(T/'sexos-alpha-launcher-b-host42/report.json')
assert h['checks_passed']and len(h['checks'])==42 and not h['source_drift']
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2630
assert 'Ran 910 tests in 'in(T/'sexos-alpha-launcher-b-python.log').read_text()
profiles=[]
for label in ['compact','wide']:
 out=T/('sexos-alpha-launcher-b-'+label+'-1800');r=read(out/'result.json');v=read(T/(out.name+'-independent-replay.json'));s=r['soak']
 assert r['ok']and r['acceptance']and v['ok']and v['acceptance']and v['cycles']==86 and v['verified_captures']==209 and s['elapsed_seconds']>=1800
 assert s['quil_close']['terminal_scope']=='safe_completed_save_close'and not s['pending_quil_close']
 profiles.append(dict(profile=label,cycles=86,verified_captures=209,elapsed_seconds=s['elapsed_seconds'],active_elapsed_seconds=s['active_elapsed_seconds'],idle_elapsed_seconds=s['idle_elapsed_seconds'],documents=r['documents'],terminal_scope=s['quil_close']['terminal_scope'],pending_device_close=False,remaining_obligations=s['remaining_obligations']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
tree('frozen',F);tree('host',T/'sexos-alpha-launcher-b-host42')
for label in ['compact','wide']:
 stem='sexos-alpha-launcher-b-'+label+'-1800';tree('sessions/'+label,T/stem)
 for suffix in ['-independent-replay.json','-driver.log']:add('coordination/'+stem+suffix,T/(stem+suffix))
for n in ['sexos-alpha-launcher-b-paired-audit.json','sexos-alpha-launcher-b-python.log','sexos-alpha-launcher-b-host42-driver.log']:add('coordination/'+n,T/n)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-alpha-paired-1800-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name]
  assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(accepted_v2_sustained_workflow=True,full_os_goal_complete=False,source_commit=audit['commit'],iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],production_inputs=574,runner_inputs=569,registered_host_checks=42,rust_test_executions=rust,python_tests=910,profiles=profiles,total_cycles=172,total_verified_captures=418,independent_source_and_replay_audit=audit,integrated_catalog_image_acceptance=False,release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Two terminal optimized-image1800s workflows. Completed-save Close only; separate pending-device qualification remains separately bound. Every frozen input matches96f4436c. Not qualification of the later catalog integration, physical/power-loss/SMP/global epoch replay or general daily-driver readiness.')
p=A/'sexos-alpha-paired-1800-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('PAIRED_ALPHA_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
