"""Reject unreadable title ink and hidden-toolbar regressions in actual code."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
F=Path('/tmp/sexos-alpha-r104-readable-b-frozen');R=F/'source';T=Path('/tmp');records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Use the same frozen extraction of actual renderer bodies as the positive gate.
p=T/'sexos-r104-b-negative-title-production.rs';s=(R/'scripts/display_surface_groups_gate.sh').read_text();code=s.split("<<'PY'\n",1)[1].split('\nPY\n',1)[0];sys.argv=['extract',str(R),str(p)];exec(compile(code,'frozen-display-extractor','exec'))
s=p.read_text();needle='Some(sex_pdx::desktop_style::contrast_ink(background))';assert s.count(needle)==1;s=s.replace(needle,'Some(0xFFFFFF)',1);p.write_text(s)
items=[('title',R/'tests/display_surface_groups.rs',{'DISPLAY_COMPOSITION_SOURCE':str(p)},'actual_toolbar_pixels_choose_contrast_after_blending_in_scalar_scanline_and_damage_paths','right: 0')]
# Test the actual layout with only the height guard disabled; no fixture API drift.
layout=T/'sexos-r104-b-negative-document-view.rs';s=(R/'crates/sex-pdx/src/document_view.rs').read_text();needle='desired_toolbar != 0 && rows >= desired_toolbar + 2';assert s.count(needle)==1;layout.write_text(s.replace(needle,'desired_toolbar != 0',1))
original=R/'tests/quil_view.rs';s=original.read_text()
def module(match):
 path=(original.parent/match[1]).resolve(strict=True)
 if path==R/'crates/sex-pdx/src/document_view.rs':path=layout
 return '#[path = '+json.dumps(str(path))+']'
s=re.sub(r'#\[\s*path\s*=\s*"([^"]+)"\s*\]',module,s);test=T/'sexos-r104-b-negative-quil-tests.rs';test.write_text(s)
items.append(('layout',test,{},'every_drawable_short_view_keeps_a_caret_row_and_hides_nonfitting_controls','l.body_rows() > 0'))
for name,source,extra,test_name,failure in items:
 binary=T/('sexos-r104-b-negative-'+name+'-host');env={**os.environ,**extra};build=subprocess.run(['rustc','--edition=2021','--test',str(source),'-o',str(binary)],env=env,capture_output=True,text=True);assert build.returncode==0,build.stderr
 r=subprocess.run([str(binary),'--exact',test_name,'--nocapture','--test-threads=1'],capture_output=True,text=True);log=T/('sexos-r104-b-negative-'+name+'.log');log.write_text(r.stdout+r.stderr);assert r.returncode!=0 and failure in log.read_text(),log.read_text();records.append(dict(name=name,negative_rejected=True,test=test_name,returncode=r.returncode,log_sha256=sha(log),test_source_sha256=sha(source)))
result=dict(ok=True,source_binding_sha256=sha(F/'source-binding.json'),controls=records,scope='Actual frozen renderer fails pure-white title mutation on light background; actual frozen document layout fails when height guard admits nonfitting toolbar. No production or native image changes.')
(T/'sexos-r104-b-negative-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
