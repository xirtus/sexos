from pathlib import Path
import errno,hashlib,json,os,socket,subprocess,time
f=Path('/tmp/sexos-alpha-r104-readable-c-frozen');binding=f/'source-binding.json';progress=Path('/tmp/sexos-r104-c-native-suite-progress.json');assert not progress.exists();rows=[];port_evidence=[];port_file=Path('/tmp/sexos-r104-c-native-port-waits.json')
def await_ports(name):
 began=time.monotonic();turn=0;checks=[];record=dict(name=name,checks=checks);port_evidence.append(record)
 while True:
  turn+=1;blocked=[];sockets=[]
  try:
   for port,kind in[(46078,socket.SOCK_STREAM),(46079,socket.SOCK_STREAM),(46080,socket.SOCK_STREAM),(46079,socket.SOCK_DGRAM)]:
    sock=socket.socket(socket.AF_INET,kind);sockets.append(sock)
    try:sock.bind(('127.0.0.1',port))
    except OSError as error:
     if error.errno!=errno.EADDRINUSE:raise
     blocked.append(dict(port=port,protocol='TCP'if kind==socket.SOCK_STREAM else'UDP',error=error.errno))
  finally:
   for sock in sockets:sock.close()
  owners=[]
  for item in blocked:
   flag='-iTCP:'+str(item['port'])if item['protocol']=='TCP'else'-iUDP:'+str(item['port']);cmd=['lsof','-nP',flag]+(['-sTCP:LISTEN']if item['protocol']=='TCP'else[]);r=subprocess.run(cmd,capture_output=True,text=True)
   if r.stdout.strip():owners.append(dict(command=cmd,output=r.stdout.strip()))
  check=dict(turn=turn,elapsed_seconds=time.monotonic()-began,blocked=blocked,live_owners=owners);checks.append(check);port_file.write_text(json.dumps(port_evidence,indent=2)+'\n')
  if owners:raise RuntimeError('live process owns required fixture port; preserve/diagnose before continuing: '+str(owners))
  if not blocked:print('PORTS_AVAILABLE',name,'turn',turn,'elapsed',check['elapsed_seconds'],flush=True);return
  print('PORT_WAIT',name,'turn',turn,'blocked',blocked,'no_live_listener',flush=True)
  if time.monotonic()-began>=120:raise TimeoutError('authoritative port bind checks still fail after120seconds')
  time.sleep(.5)
jobs=[]
for profile,model,resolution in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]:
 jobs.append(('readability-'+profile,'quil_readability_gate.py',None,profile,model,resolution,1))
for profile,model,resolution in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]:
 jobs.append(('launcher-'+profile,'launcher_workflow_gate.py',None,profile,model,resolution,1))
for profile,model,resolution in [('wide','e1000e','1280x800'),('compact','e1000','1024x768')]:
 jobs.append(('clipboard-'+profile,'clipboard_workflow_gate.py',None,profile,model,resolution,2))
for name,checker,mode,profile,model,resolution,boots in jobs:
 if Path('/tmp/sexos-r104-c-native-STOP').exists():raise SystemExit(75)
 out=Path('/tmp/sexos-r104-c-native-'+name);driver=Path('/tmp/sexos-r104-c-native-'+name+'-driver.log');assert not out.exists()and not driver.exists()
 command=['python3',str(f/'source/scripts'/checker),'--iso',str(f/'tested.iso'),'--binding',str(binding),'--source-disk','/tmp/sexos-r100a-seed.img','--out',str(out),'--model',model,'--resolution',resolution]
 if checker=='http_content_gate.py':
  at=command.index('--binding');del command[at:at+2]
 if mode:command+=['--mode',mode]
 row=dict(name=name,status='port-preflight',out=str(out),driver=str(driver),command=command,mode='clipboard-recovery'if checker=='clipboard_workflow_gate.py'else'quil-readability'if checker=='quil_readability_gate.py'else'launcher-workspace',profile=dict(label=profile,model=model,resolution=resolution),boots=boots,source_binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest());rows.append(row);progress.write_text(json.dumps(rows,indent=2)+'\n');await_ports(name)
 if Path('/tmp/sexos-r104-c-native-STOP').exists():raise SystemExit(75)
 row['status']='running';progress.write_text(json.dumps(rows,indent=2)+'\n');began=time.monotonic();print('START',name,flush=True)
 with driver.open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 row.update(status=r.returncode,seconds=time.monotonic()-began);progress.write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert json.loads((out/'result.json').read_text())['ok']
assert len(rows)==6 and sum(row['boots']for row in rows)==8
print('ALL6_RUNS_8_BOOTS_FROZEN_R104C_NATIVE_PASS',flush=True)
