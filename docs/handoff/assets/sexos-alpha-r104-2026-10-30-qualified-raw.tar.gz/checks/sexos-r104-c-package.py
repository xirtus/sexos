"""Archive final104 evidence only after terminal native runs and raw replay."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
from PIL import Image
R=Path('/Users/xmacbookm5/Projects/Sex');T=Path('/tmp');F=T/'sexos-alpha-r104-readable-c-frozen';B=T/'sexos-alpha-r104-readable-b-build';A=R/'docs/handoff/assets';stem='sexos-alpha-r104-2026-10-30'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding=load(F/'source-binding.json');progress=load(T/'sexos-r104-c-native-suite-progress.json');replay=load(T/'sexos-r104-c-root-independent-replay.json');eq=load(T/'sexos-r104-c-b-equivalence.json');negative=load(T/'sexos-r104-c-negative-controls.json')
assert replay['ok']and replay['complete']and(replay['native_runs'],replay['native_boots'],replay['frames'])==(6,8,98)
assert replay['source_binding_sha256']==sha(F/'source-binding.json')==negative['source_binding_sha256']
assert negative['ok']and len(negative['controls'])==2 and all(r['negative_rejected']for r in negative['controls'])
assert len(progress)==6 and all(type(r['status'])is int and r['status']==0 for r in progress)
assert eq['production_identical']and eq['rust_shell_inputs_identical']
assert binding['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for name,digest in {**binding['sources'],**binding['runner_sha256']}.items():assert sha(F/'source'/name)==digest and sha(R/name)==digest,name
assert load(B/'provenance.json')['iso_sha256']==binding['iso_sha256']==sha(F/'tested.iso')
assert '| **FINAL_SCORE** | **GREEN_MASTER** |'in(B/'report.md').read_text()
logs=[]
for label,expected,marker in [('service-custody',1739,'[service.custody.host.gate] PASS'),('display',52,'[gate.display_surface_groups.result] PASS'),('readability',9,'[gate.display_text_readability.result] PASS'),('launcher',35,'[launcher.workspace.host] PASS')]:
 p=T/f'sexos-r104-b-frozen-{label}.log';text=p.read_text();assert marker in text;count=sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',text,re.M)));assert count==expected,(label,count);logs.append(dict(name=label,path=str(p),executions=count,sha256=sha(p),scope='Completed B frozen Rust checks, exact unchanged Rust/shell inputs proved for C. Separate9 readability and35 launcher executions are not inside service-custody.'))
p=T/'sexos-r104-c-frozen-python.log';text=p.read_text();assert re.search(r'^OK$',text,re.M);python_count=int(re.search(r'Ran (\d+) tests',text)[1]);assert python_count==747
scalar=load(T/'sexos-r104-b-scalar-instructions.json');assert scalar['ok']and scalar['iso_sha256']==binding['iso_sha256']and scalar['elf_sha256']==sha(T/'sexos-r104-b-tested-kaleidoscope.elf')
assert load(T/'sexos-r104-b-host-vendor-isolation.json')['ok']
members={}
def add(path,name):
 path=Path(path);assert path.is_file()and not path.is_symlink(),path;assert name not in members and not name.startswith('/')and '..'not in Path(name).parts;members[name]=path
add(F/'source-binding.json','source-binding.json')
for name in sorted(set(binding['sources'])|set(binding['runner_sha256'])):add(F/'source'/name,'source/'+name)
for name in('tested.iso','tested.kernel'):add(F/name,name)
for p in sorted(B.iterdir()):
 if p.is_file()and p.suffix!='.img':add(p,'build/'+p.name)
for row in progress:
 out=Path(row['out'])
 for p in sorted(out.rglob('*')):
  if p.is_file()and p.suffix!='.img':add(p,'native/'+row['name']+'/'+str(p.relative_to(out)))
 add(row['driver'],'checks/'+Path(row['driver']).name)
for pattern in('sexos-r104-c-*.json','sexos-r104-c-*.log','sexos-r104-c-*.py','sexos-r104-c-*.rs','sexos-r104-b-frozen-*.log','sexos-r104-b-*.disassembly','sexos-r104-b-*.elf','sexos-r104-b-audit-instructions.py','sexos-r104-b-scalar-instructions.json','sexos-r104-b-host-vendor-isolation.json','sexos-r104-b-iso-extract.log'):
 for p in sorted(T.glob(pattern)):
  if 'package.log'in p.name:continue
  name='checks/'+p.name
  if name not in members:add(p,name)
for p in sorted((T/'sexos-alpha-r104-readable-a-build').iterdir()):
 if p.is_file()and p.suffix!='.img':add(p,'diagnostics/a-vendor-generated-target/'+p.name)
for name in('sexos-r104-a-generated-vendor-target.json','sexos-r104-b-readability-helper-diagnostic.json'):
 add(T/name,'diagnostics/'+name)
old=T/'sexos-alpha-r104-readable-b-frozen';add(old/'source-binding.json','diagnostics/b/source-binding.json')
for name in('scripts/quil_readability_gate.py','scripts/tests/test_quil_readability_gate.py'):add(old/'source'/name,'diagnostics/b/source/'+name)
for p in sorted((T/'sexos-r104-b-native-readability-wide').rglob('*')):
 if p.is_file()and p.suffix!='.img':add(p,'diagnostics/b/readability-wide/'+str(p.relative_to(T/'sexos-r104-b-native-readability-wide')))
for directory in('sexos-r104-b-negative-path-diagnostic','sexos-r104-c-negative-expectation-diagnostic'):
 for p in sorted((T/directory).rglob('*')):
  if p.is_file():add(p,'diagnostics/'+directory+'/'+str(p.relative_to(T/directory)))
seed=T/'sexos-r100a-seed.img';z=T/'sexos-r104-c-seed.img.gz';assert not z.exists();z.write_bytes(gzip.compress(seed.read_bytes(),mtime=0));add(z,'seed.img.gz')
screens=[]
for run,boot,filename,label in [('readability-wide','','resaved.ppm','editor-wide'),('readability-compact','','commands.ppm','commands-compact'),('launcher-wide','','spindle-17-brought.ppm','titles-wide'),('clipboard-compact','recovery','quil-cold-reopened.ppm','cold-compact')]:
 out=Path(next(r['out']for r in progress if r['name']==run))/boot;frame=next(f for f in load(out/'frames.json')if f['screenshot']==filename);assert frame['screenshot_sha256']==sha(out/filename)
 dest=A/f'{stem}-{label}.png';assert not dest.exists();Image.open(out/filename).save(dest);screens.append(dict(label=label,path=str(dest.relative_to(R/'docs/handoff')),sha256=sha(dest),run=run,boot=boot,raw_ppm=filename,raw_sha256=sha(out/filename),serial_bytes=frame['serial_bytes'],serial_sha256=frame['serial_sha256']))
archive=A/f'{stem}-qualified-raw.tar.gz';assert not archive.exists();inventory=[dict(name=n,bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(members.items())]
with tarfile.open(archive,'w:gz')as tar:
 for row in inventory:
  path=members[row['name']];assert sha(path)==row['sha256'];tar.add(path,arcname=row['name'],recursive=False)
 data=(json.dumps(dict(scope='FinalC acceptance on unchanged sealedB image. Superseded A/B and initial negative-harness diagnostics add no acceptance.',members=inventory),indent=2)+'\n').encode();info=tarfile.TarInfo('archive-inventory.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 actual=tar.getmembers();assert len(actual)==len(inventory)+1 and all(p.isfile()for p in actual)
 for row in inventory:
  data=tar.extractfile(row['name']).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
e=dict(round=104,accepted=True,accepted_goal_rounds=25,total_goal_rounds=121,remaining_goal_rounds=96,iso_sha256=binding['iso_sha256'],kernel_sha256=binding['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),architecture_sha256=binding['architecture_sha256'],production_inputs=len(binding['sources']),runner_inputs=len(binding['runner_sha256']),checks=dict(master='BUILD PASS / GREEN_MASTER',rust=logs,rust_test_executions=sum(r['executions']for r in logs),rust_reuse_equivalence=eq,python_tests=python_count,python_log_sha256=sha(T/'sexos-r104-c-frozen-python.log'),native_runs=6,native_boots=8,independent_frames=98,root_replay_sha256=sha(T/'sexos-r104-c-root-independent-replay.json'),scalar_audit=scalar,semantic_negative_controls=negative),qualification_runs=progress,remaining_gates=dict(open=7,partial=23,system_proven=False),screenshots=screens,archive=dict(path=str(archive.relative_to(R/'docs/handoff')),sha256=sha(archive),members=len(inventory)+1,verified=True,bytes=archive.stat().st_size),failed_diagnostics='A stopped before compile because root preflight Cargo generated791 target files inside the reviewed vendor tree. Artifacts moved aside; gate now uses temporary Cargo target. B readability completed9captures/two exact saves but its checker wrongly expected2 focus effects rather than3 including legitimate Linen reopen. C binds3 exact held-subject effects to distinct real operation windows; all actual B helpers replay diagnostically, original B result unchanged. Initial negative-harness path/expected-failure setup issues remain separately diagnostic; final C actual semantic mutants are rejected.',limitations=['Native pointer/SaveAs/New/Open/Save/commands proof is original Quil9 at both desktop sizes. Short-height, one-cell, no-glyph, menu scrolling, bounds, denial/queue-pressure and successor-layout cases are actual-function host checks, not tiny-native or hostile certification.','Independent contrast checks sample35,937 RGB grid colors plus all gray/channel values and threshold/palette cases, with actual scalar/scanline/damage pixels. This is scoped title/body-selection color evidence, not all UI accessibility certification.','The fixed5x7 font and existing cell geometry remain; encoding/input105, assets106, navigation107 and integrated108 session remain future work.','Native both-profile clipboard/Save/cold recovery and launcher/workspace regressions qualify this image; no new sustained daily-driver, public-web/general CA, crash/power-loss, physical, SMP, hostile containment or System Proven claim.'],scope='One substantive round: readable responsive Quil controls/help and high-contrast native titles, preserving document/selection/viewport and exact held authority. Host gate artifacts now stay out of reviewed vendor sources. GLOBAL_VAS, BOOT-only genesis and typed sex-pdx authority remain; not Unix/POSIX.')
(A/f'{stem}-evidence.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(dict(ok=True,round=104,rust=e['checks']['rust_test_executions'],python=python_count,archive=e['archive'])))
