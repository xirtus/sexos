#![allow(dead_code,static_mut_refs)]
#[path="catalog.rs"] mod app_catalog;
static LOG: std::sync::Mutex<Vec<String>> = std::sync::Mutex::new(Vec::new());
macro_rules! serial_println {($($a:tt)*) => {LOG.lock().unwrap().push(format!($($a)*));}}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
enum LifecycleState {
    /// SurfaceId reserved but no frame mapped. No display state.
    Allocated = 0,
    /// Surface attached to a Frame. Has geometry but may not be visible.
    Mapped = 1,
    /// Surface in active scene, frame not minimized, z-order includes it.
    Visible = 2,
    /// Surface's frame is in a non-active scene. No input routing.
    Hidden = 3,
    /// Frame collapsed. Surface hidden. No pointer focus.
    Minimized = 4,
    /// Close requested — irreversible. Must transition to Tombstoned.
    Closing = 5,
    /// Surface dead but record exists. Cannot receive focus.
    Tombstoned = 6,
    /// Terminal. SurfaceId eligible for reuse only with generation safety.
    Destroyed = 7,
}
#[derive(Debug, Clone, Copy)]
struct SurfaceLifecycle {
    state: LifecycleState,
    generation: u64,
}
pub const SURFACE_ID_APP: u64 = 100;
pub const SURFACE_ID_STATIC: u64 = 101;
pub const SURFACE_ID_TEST3: u64 = 102;
pub const SURFACE_ID_TEST4: u64 = 103;
pub const SURFACE_ID_LINEN: u64 = 200;
pub const SURFACE_ID_QUIL: u64 = 201;
pub const SURFACE_ID_MESH: u64 = 202;
pub const SURFACE_ID_COLLAR: u64 = 203;
pub const SURFACE_ID_BELL_PLACEHOLDER: u64 = 204;
pub const SURFACE_ID_SPINDLE: u64 = 0x99;
pub const SURFACE_ID_CURSOR: u64 = 0x90;
pub const SURFACE_ID_LAUNCHER: u64 = 0x92;
pub const SURFACE_ID_STATUS: u64 = 0x93;
pub const SURFACE_ID_CLOCK: u64 = 0x94;
pub const SURFACE_ID_BELL: u64 = 0x95;
pub const SURFACE_ID_SCENE_SETTINGS: u64 = 0x96;
pub const SURFACE_ID_ATLAS_OVERLAY: u64 = 0x97;
const BOOT_LIFECYCLE_SURFACES: [(u64, LifecycleState); 17] = [
    (SURFACE_ID_APP, LifecycleState::Allocated),
    (SURFACE_ID_STATIC, LifecycleState::Allocated),
    (SURFACE_ID_TEST3, LifecycleState::Allocated),
    (SURFACE_ID_TEST4, LifecycleState::Allocated),
    (SURFACE_ID_LINEN, LifecycleState::Visible),
    (SURFACE_ID_QUIL, LifecycleState::Visible),
    (SURFACE_ID_MESH, LifecycleState::Visible),
    (SURFACE_ID_COLLAR, LifecycleState::Visible),
    (SURFACE_ID_BELL_PLACEHOLDER, LifecycleState::Visible),
    (SURFACE_ID_SPINDLE, LifecycleState::Visible),
    (SURFACE_ID_CURSOR, LifecycleState::Mapped),
    (SURFACE_ID_LAUNCHER, LifecycleState::Allocated),
    (SURFACE_ID_STATUS, LifecycleState::Allocated),
    (SURFACE_ID_CLOCK, LifecycleState::Allocated),
    (SURFACE_ID_BELL, LifecycleState::Allocated),
    (SURFACE_ID_SCENE_SETTINGS, LifecycleState::Allocated),
    (SURFACE_ID_ATLAS_OVERLAY, LifecycleState::Allocated),
];
const fn native_lifecycle_surface_count() -> usize {
    let mut count = 0;
    let mut index = 0;
    while index < app_catalog::COUNT {
        let row = &app_catalog::INCARNATIONS[index];
        if row.ordinal > 0 || matches!(row.app, app_catalog::App::Browser) {
            count += 1;
        }
        index += 1;
    }
    count
}
const LIFECYCLE_MAX_SURFACES: usize = BOOT_LIFECYCLE_SURFACES.len() + native_lifecycle_surface_count();
static mut LIFECYCLE_TABLE: [Option<(u64, SurfaceLifecycle)>; LIFECYCLE_MAX_SURFACES] = [None; LIFECYCLE_MAX_SURFACES];
static mut LIFECYCLE_GENERATION: u64 = 1;
unsafe fn lifecycle_register(sid: u64, initial_state: LifecycleState) -> bool {
    for i in 0..LIFECYCLE_MAX_SURFACES {
        if let Some((registered_sid, _)) = &LIFECYCLE_TABLE[i] {
            if *registered_sid == sid {
                // Already registered — update state on re-init.
                LIFECYCLE_TABLE[i] = Some((sid, SurfaceLifecycle {
                    state: initial_state,
                    generation: 1,
                }));
                return true;
            }
        }
    }
    for i in 0..LIFECYCLE_MAX_SURFACES {
        if LIFECYCLE_TABLE[i].is_none() {
            LIFECYCLE_TABLE[i] = Some((sid, SurfaceLifecycle {
                state: initial_state,
                generation: 1,
            }));
            return true;
        }
    }
    false
}
unsafe fn lifecycle_state(sid: u64) -> Option<LifecycleState> {
    for i in 0..LIFECYCLE_MAX_SURFACES {
        if let Some((registered_sid, ref record)) = LIFECYCLE_TABLE[i] {
            if registered_sid == sid {
                return Some(record.state);
            }
        }
    }
    None
}
unsafe fn set_lifecycle_state(sid: u64, next: LifecycleState) -> bool {
    for i in 0..LIFECYCLE_MAX_SURFACES {
        if let Some((registered_sid, ref mut record)) = &mut LIFECYCLE_TABLE[i] {
            if *registered_sid == sid {
                let prev = record.state;
                if prev == next {
                    return true; // no-op
                }
                // Bump generation on transitions that invalidate stale references.
                let bump = matches!((prev, next),
                    (LifecycleState::Visible, LifecycleState::Closing)
                    | (LifecycleState::Hidden, LifecycleState::Closing)
                    | (LifecycleState::Minimized, LifecycleState::Closing)
                    | (LifecycleState::Closing, LifecycleState::Tombstoned)
                    | (LifecycleState::Tombstoned, LifecycleState::Destroyed)
                    | (_, LifecycleState::Destroyed)
                );
                if bump {
                    let new_gen = LIFECYCLE_GENERATION.wrapping_add(1);
                    if new_gen == 0 {
                        serial_println!("[lifecycle.generation.bump.wrap] sid={} prev={:?} next={:?}", sid, prev, next);
                        // STOP FIRST: wraparound requires audit of all FocusRef references.
                        // Saturate — do not wrap to 0.
                    } else {
                        LIFECYCLE_GENERATION = new_gen;
                        record.generation = new_gen;
                        serial_println!("[lifecycle.generation.bump] sid={} gen={} prev={:?} next={:?}", sid, new_gen, prev, next);
                    }
                }
                record.state = next;
                serial_println!("[lifecycle.transition.allow] sid={} from={:?} to={:?}", sid, prev, next);
                return true;
            }
        }
    }
    serial_println!("[lifecycle.transition.reject] sid={} reason=unknown_surface", sid);
    false
}
unsafe fn surface_generation(sid: u64) -> Option<u64> {
    for i in 0..LIFECYCLE_MAX_SURFACES {
        if let Some((registered_sid, ref record)) = LIFECYCLE_TABLE[i] {
            if registered_sid == sid {
                return Some(record.generation);
            }
        }
    }
    None
}
unsafe fn lifecycle_init_all() {
    // Legacy descriptors remain allocated until an explicit mapping path;
    // tiling and metadata registration are not capability genesis.
    for &(sid, state) in &BOOT_LIFECYCLE_SURFACES {
        lifecycle_register(sid, state);
    }
    serial_println!("[lifecycle.state.init] lifecycle model initialized");
    serial_println!("[silk.lifecycle.init] ok=1 surfaces={} states=Visible|Mapped|Allocated", BOOT_LIFECYCLE_SURFACES.len());
    serial_println!("[silk.lifecycle.invariant.ok] all_surfaces_registered=1 generation_safe=1 static_table_full=0");
    serial_println!("[silk.lifecycle.surface.live] ok=1 surfaces={}", BOOT_LIFECYCLE_SURFACES.len());
}
const INITIAL_GOLD: [(u64,LifecycleState);17] = [(100,LifecycleState::Allocated),(101,LifecycleState::Allocated),(102,LifecycleState::Allocated),(103,LifecycleState::Allocated),(200,LifecycleState::Visible),(201,LifecycleState::Visible),(202,LifecycleState::Visible),(203,LifecycleState::Visible),(204,LifecycleState::Visible),(153,LifecycleState::Visible),(144,LifecycleState::Mapped),(146,LifecycleState::Allocated),(147,LifecycleState::Allocated),(148,LifecycleState::Allocated),(149,LifecycleState::Allocated),(150,LifecycleState::Allocated),(151,LifecycleState::Allocated)];
const NATIVE_GOLD: &[u64] = &[300, 301, 306, 307, 308, 309, 310, 311, 312, 314, 319, 324, 329, 334, 339];

unsafe fn reset() {
    LIFECYCLE_TABLE = [None; LIFECYCLE_MAX_SURFACES];
    LIFECYCLE_GENERATION = 1;
    LOG.lock().unwrap().clear();
    lifecycle_init_all();
}
unsafe fn snapshot() -> Vec<(u64,LifecycleState,u64)> {
    LIFECYCLE_TABLE.iter().flatten().map(|(sid,r)|(*sid,r.state,r.generation)).collect()
}
unsafe fn fill() {
    reset();
    for &sid in NATIVE_GOLD {
        assert!(lifecycle_register(sid,LifecycleState::Visible), "no retained slot for {sid}");
    }
}
#[test] fn initial_inventory_states() { unsafe {
    reset();
    assert_eq!(snapshot(), INITIAL_GOLD.iter().map(|&(sid,s)|(sid,s,1)).collect::<Vec<_>>());
    let log=LOG.lock().unwrap();
    assert!(log.iter().any(|s|s=="[silk.lifecycle.init] ok=1 surfaces=17 states=Visible|Mapped|Allocated"));
    assert!(log.iter().any(|s|s=="[silk.lifecycle.surface.live] ok=1 surfaces=17"));
}}
#[test] fn complete_catalog_frames_fit_and_next_sid_is_refused() { unsafe {
    // Select by already-recorded frame IDs, independently of the production
    // ordinal/family counting predicate. These are metadata associations only.
    let actual:Vec<_>=app_catalog::INCARNATIONS.iter().map(|r|r.frame())
        .filter(|sid|!INITIAL_GOLD.iter().any(|&(initial,_)|initial==*sid)).collect();
    assert_eq!(actual,NATIVE_GOLD);
    fill(); // In a fixed32 mutant, future rows must fail real registration here.
    assert_eq!(native_lifecycle_surface_count(),NATIVE_GOLD.len());
    assert_eq!(LIFECYCLE_MAX_SURFACES,17+NATIVE_GOLD.len());
    assert_eq!(snapshot().len(),LIFECYCLE_MAX_SURFACES);
    let last=*NATIVE_GOLD.last().unwrap();
    assert_eq!(lifecycle_state(last),Some(LifecycleState::Visible));
    let before=snapshot();
    assert!(!lifecycle_register(999_999,LifecycleState::Visible));
    assert!(!set_lifecycle_state(999_999,LifecycleState::Closing));
    assert_eq!(snapshot(),before);
}}
#[test] fn duplicate_reinitializes_only_existing_slot() { unsafe {
    fill();let sid=*NATIVE_GOLD.last().unwrap();
    assert!(set_lifecycle_state(sid,LifecycleState::Closing));
    assert!(surface_generation(sid).unwrap()>1);
    // Preserve the existing explicit registration/re-init contract, including
    // generation reset; capacity work must not silently alter that behavior.
    assert!(lifecycle_register(sid,LifecycleState::Mapped));
    let entries=snapshot();assert_eq!(entries.len(),LIFECYCLE_MAX_SURFACES);
    assert_eq!(entries.iter().filter(|r|r.0==sid).count(),1);
    assert_eq!(entries.last(),Some(&(sid,LifecycleState::Mapped,1)));
    assert_eq!(&entries[..17],&INITIAL_GOLD.map(|(sid,s)|(sid,s,1)));
}}
#[test] fn tombstones_keep_identity_and_generation_without_freeing_capacity() { unsafe {
    fill();let sid=*NATIVE_GOLD.last().unwrap();let mut previous=surface_generation(sid).unwrap();
    for state in [LifecycleState::Closing,LifecycleState::Tombstoned,LifecycleState::Destroyed] {
        assert!(set_lifecycle_state(sid,state));
        let generation=surface_generation(sid).unwrap();assert!(generation>previous);previous=generation;
        assert_eq!(lifecycle_state(sid),Some(state));
        assert!(!lifecycle_register(999_999,LifecycleState::Visible));
        assert_eq!(snapshot().len(),LIFECYCLE_MAX_SURFACES);
    }
    let before=snapshot();assert!(set_lifecycle_state(sid,LifecycleState::Destroyed));assert_eq!(snapshot(),before);
}}
