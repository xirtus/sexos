fn network_owner(caller:u32)->Option<jobs::Identity>{
    use sex_pdx::app_lifecycle as a;
    for slot in a::SLOTS{
        let Ok(c)=a::catalog(slot)else{continue;};
        if c.target_pd==caller&&caller!=0&&c.task_id!=0&&a::info(slot)==Err(a::LIVE){
            return Some(jobs::Identity{pd:caller,task:c.task_id});
        }
    }
    None
}
fn network_request_owner(caller:u32,caller_task:u32)->Option<jobs::Identity>{
    if caller_task==0{return None;}
    let owner=network_owner(caller)?;
    if caller_task!=caller{return None;}
    Some(owner)
}