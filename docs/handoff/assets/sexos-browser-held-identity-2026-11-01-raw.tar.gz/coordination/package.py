from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-browser-identity-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-browser-identity-a-source-audit.json');boot=read(T/'sexos-browser-identity-a-boot-audit.json');h=read(T/'sexos-browser-identity-a-frozen-host/report.json');scalar=read(T/'sexos-browser-identity-a-scalar-v3/result.json');alpha=read(T/'sexos-browser-identity-a-alpha-progress.json');connected=read(T/'sexos-browser-identity-a-native-progress.json');cold=read(T/'sexos-browser-identity-a-last-writer-cold-aux/result.json')
assert audit['ok']and audit['commit']=='d576eb1776c66eab20fcd96e6113bf3648f24583'and boot['ok']and boot['boots']==8
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2760
assert 'Ran 1037 tests in 'in(T/'sexos-browser-identity-a-python.log').read_text()
assert len(alpha)==2 and all(row['status']==0 and row['fresh_replay']and row['terminal_history']['source']==29 and row['terminal_history']['task']==29 for row in alpha)
assert len(connected)==2 and all(row['status']==0 and row['boots']==2 and row['verified_captures']==17 for row in connected)
assert cold['ok']and cold['stopped']and cold['binding']and cold['expected']['source']==29 and cold['expected']['task']==29 and cold['recall']=='echo alpha29'
assert scalar['ok']and len(scalar['results'])==9 and all(not r['vector_or_fp_matches']for r in scalar['results'])
controls=read(T/'sexos-browser-identity-a-lifecycle-controls.json');assert controls['tests']==8 and controls['compiled_mutants_rejected']==3
observations=[]
for row in alpha:
 out=Path(row['out']);text=(out/'serial.log').read_text(errors='replace');r=read(out/'result.json');s=r['soak']['third_spindle'];assert [step['target']for step in s['chain']]==[24,25,26,27,28,29]and s['reserve_exhausted'];accepted=sorted(set(map(int,re.findall(r'\[shell.spindle.status.accepted\] target=(\d+)',text))));assert accepted==[12,17,24,25,26,27,28,29]
 assert '[sext.app.pool.ready] target=24 task=24 bytes=389120 zeroed=389120 workspace_records=2 reused=1 zero_owner=sext ok=1'in text
 observations.append(dict(profile=row['profile'],status_subjects=accepted,third=s,terminal_history=row['terminal_history']))
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items,(n,p);items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('qualified/frozen',F),('qualified/sealed-build',T/'sexos-browser-identity-a-build'),('qualified/host',T/'sexos-browser-identity-a-frozen-host'),('qualified/scalar',T/'sexos-browser-identity-a-scalar-v3'),('qualified/auxiliary-cold',T/'sexos-browser-identity-a-last-writer-cold-aux')]:tree(prefix,root)
for row in alpha:tree('qualified/alpha/'+row['profile'],row['out'])
for row in connected:tree('qualified/connected/'+row['profile']['label'],row['out'])
tree('diagnostic/initial-host',T/'sexos-browser-identity-a-host')
tree('host-controls/lifecycle',T/'sexos-browser-identity-a-lifecycle-controls')
for name in ['sexos-r148-browser-incarnation','sexos-r148-browser-service-call','sexos-r148-network-request-owner','sexos-r148-browser-identity-controls','sexos-r148-network-owner-controls']:
 p=T/name
 if p.exists():tree('host-controls/'+name,p)
for p in sorted(T.glob('sexos-browser-identity-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py','.sh','.txt']and 'package'not in p.name:add('coordination/'+p.name,p)
for name in ['sexos-r148-browser-identity-controls-driver.log','sexos-r148-network-owner-controls-driver.log','sexos-r148-legacy-service-call.log']:add('host-controls/'+name,T/name)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-browser-held-identity-2026-11-01-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
captures=sum(row['verified_captures']for row in alpha+connected)
e=dict(round=148,browser_held_identity_and_typed_request_task_qualified=True,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='98beda3f52c8ab1a0ab206bab8610c944debb257',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust+controls['tests'],rust_gate_log_passes=rust,additional_extracted_lifecycle_cases=8,python_tests=1037,host_behavior=dict(browser_actual_metadata_cases=5,browser_future_metadata_cases=5,browser_transport_cases=5,browser_compiled_mutants=3,network_request_owner_cases=7,network_compiled_mutants=2,unequal_task_ids_host_only=True),browser=dict(actual_targets=[15],actual_surface=300,held_query_before_effects=True,task_never_inferred_from_domain=True,immutable_private_startup_tuple=True,nested_close_target_task_from_held_tuple=True,paging_probe_original_only=True,future_browser_rows_installed=False),network=dict(typed_dispatches_authenticated=5,paths=['trust','certificate-time','entropy','TCP/TLS','DNS'],actual_kernel_stamped_task_required=True,held_live_main_task_required=True,maintenance_held_custody_unchanged=True,legacy_domain_route_cached_reads_unchanged=True,files_deferred_task_gap_fixed=False),native=dict(sealed_probe_boots=1,alpha_boots=2,connected_boots=4,auxiliary_cold_boots=1,total_qualified_boots=8,registry_verified_captures=captures,alpha=alpha,connected=connected,full_history_chain=read(T/'sexos-browser-identity-a-full-history-chain.json'),cold=dict(observed=True,source=29,task=29,fresh_target=12,generation=cold['expected']['generation'],bytes=cold['expected']['size'],recall=cold['recall'],standalone_artifact_replay=False,parent_source_bound_replayed=True),boot_held_identity_audit=boot,native_unequal_allocator=False,new_image_1800s_acceptance=False),scalar=dict(elfs=9,instructions=sum(r['instructions']for r in scalar['results']),inspected_vector_fp_matches=0,scope=scalar['scope']),diagnostics=dict(initial_legacy_transport_fixture_missing_getter=True,fixed_before_source_commit=True),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='One actual Browser15 selects exact held SELF CatalogInfo before service/paging effects; preserve main task in immutable local tuple and retained nested Close waits. Original-only paging remains BOOT-authorized. Five fresh typed Net job/source paths require actual incoming kernel task equals held live task before effects; maintenance custody and legacy cached/sample Domain-route reads stay separate. Compiled actual metadata/transport/request-owner controls and mutations cover independent task namespaces. Nativebothprofiles/full8appchains/TCP/sourceTLS/connectedcold pass; no new Browser reservation, generalizedFilesdeferredtaskauth, nativeunequalallocator, runtimecapmint/processVAS or daily-driver acceptance claim.')
p=A/'sexos-browser-held-identity-2026-11-01-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('BROWSER_HELD_IDENTITY_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes','captures',captures,flush=True)
