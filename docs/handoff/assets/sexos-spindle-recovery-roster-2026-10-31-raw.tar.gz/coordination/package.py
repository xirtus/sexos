from pathlib import Path
import hashlib,io,json,re,tarfile
T=Path('/tmp');R=Path('/Users/xmacbookm5/.codex/worktrees/browser-sextime/Sex');A=R/'docs/handoff/assets';F=T/'sexos-spindle-roster-a-frozen'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');audit=read(T/'sexos-spindle-roster-a-source-audit.json');h=read(T/'sexos-spindle-roster-a-host/report.json');boot=read(T/'sexos-spindle-roster-a-boot-audit.json');scalar=read(T/'sexos-spindle-roster-a-scalar-v2/result.json')
assert audit['ok']and boot['ok']and boot['boots']==8
assert h['checks_passed']and h['sources_unchanged_during_checks']and len(h['checks'])==43
rust=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',Path(row['log']).read_text())))for row in h['checks']);assert rust==2698
assert 'Ran 989 tests in 'in(T/'sexos-spindle-roster-a-python.log').read_text()
groups={k:read(T/('sexos-spindle-roster-a-'+s+'-progress.json'))for k,s in [('full_relaunch','alpha'),('connected','native')]}
assert all(row['status']==0 for rows in groups.values()for row in rows)and sum(row['verified_captures']for rows in groups.values()for row in rows)==84
assert all(r['fresh_replay']and r['terminal_history']['source']==17 and r['terminal_history']['task']==17 for r in groups['full_relaunch'])
assert scalar['ok']and len(scalar['results'])==6 and sum(r['instructions']for r in scalar['results'])==254656 and all(not r['vector_or_fp_matches']for r in scalar['results'])
auxdir=T/'sexos-spindle-roster-a-last-writer-cold-aux-b';aux=read(auxdir/'result.json');retry=read(T/'sexos-spindle-roster-a-aux-retry-result.json');assert retry['status']==0 and aux['ok']and aux['stopped']and aux['binding']and aux['recall']=='echo alpha17'and aux['expected']['source']==17 and aux['expected']['task']==17
assert not read(T/'sexos-spindle-roster-a-last-writer-cold-aux/result.json')['ok']
items={}
def add(n,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in items;items[n]=p
def tree(prefix,root):
 root=Path(root);assert root.is_dir(),root
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.suffix!='.img'and '__pycache__'not in p.parts:add(prefix+'/'+str(p.relative_to(root)),p)
for prefix,root in [('frozen',F),('sealed-build',T/'sexos-spindle-roster-a-build'),('host',T/'sexos-spindle-roster-a-host'),('scalar',T/'sexos-spindle-roster-a-scalar-v2')]:tree(prefix,root)
for group,rows in groups.items():
 for row in rows:tree('native/'+group+'/'+Path(row['out']).name,Path(row['out']))
tree('native/auxiliary-bound-cold',auxdir);tree('diagnostics/obsolete-recall-argument',T/'sexos-spindle-roster-a-last-writer-cold-aux')
tree('host-expanded-controls/history',T/'sexos-r140-history-host');tree('host-expanded-controls/probe',T/'sexos-r140-probe-host')
for p in sorted(T.glob('sexos-spindle-roster-*')):
 if p.is_file()and p.suffix in ['.json','.log','.py']and 'package'not in p.name:add('coordination/'+p.name,p)
add('coordination/package.py',Path(__file__))
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in items.items()};data=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();archive=A/'sexos-spindle-recovery-roster-2026-10-31-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for n,p in sorted(items.items()):tar.add(p,arcname=n,recursive=False)
 m=tarfile.TarInfo('payload-members.json');m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1 and len({m.name for m in members})==len(members)
 for m in members:
  content=tar.extractfile(m).read();expected=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())if m.name=='payload-members.json'else manifest[m.name];assert len(content)==expected['bytes']and hashlib.sha256(content).hexdigest()==expected['sha256'],m.name
e=dict(round=140,qualified_boot_spindle_recovery_roster=True,actual_spindle_reserve_increased=False,full_os_goal_complete=False,source_commit=audit['commit'],main_parent='85464b45',iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],architecture_sha256=b['architecture_sha256'],committed_source_audit=audit,registered_host_checks=43,rust_test_executions=rust,python_tests=989,native=dict(qualified_boots=8,sealed_probe_boots=1,normal_workflow_boots=6,auxiliary_cold_boots=1,registry_verified_captures=84,groups=groups,all_parent_replays=True,connected_live_cold_replays=True,boot_roster_layout_audit=boot,auxiliary_last_writer_cold=dict(ok=True,bound_parent_replayed=True,writer=aux['expected'],recall=aux['recall'],stopped=True,final_disk_sha256=aux['final_disk_sha256'],screenshot_sha256=sha(auxdir/'recovered-history.ppm'),standalone_readonly_replay=False,pixel_registry=False,scope=aux['scope']),new_image_1800s_acceptance=False),layout=dict(actual_participants=2,grant_bytes=40,capability_data_bytes=128,capability_bytes=192,host_generic_grant_bytes=dict(two=40,three=48,eight=88),cap_table_record_growth_observed=False),scalar=dict(elfs=6,instructions=254656,inspected_vector_fp_matches=0,scope=scalar.get('scope')),diagnostics=dict(auxiliary_a='Wrong driver recall expectation echo spindle17; exact parent last command echo alpha17. Owned guest was stopped and original false result retained. Retry B uses decoded parent expectation on identical immutable source/image.',journal_preflight='Wrong test oracle expected CORRUPT despite an authorized older bank; corrected to require valid older fallback and separately reject both wrong-task banks.'),limitations=dict(actual_spindles=[12,17],per_request_task_authenticated=False,app_startup_unequal_task_namespace_native=False,spindle_startup_task_equals_domain_check_remains=True,third_incarnation_native=False),release_gates=dict(open=2,partial=28,system_proven=False),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=hashlib.sha256(data).hexdigest(),all_members_size_and_sha256_verified=True),scope='Owned bounded held recovery roster populated from actual BOOT main tasks and compared to inserted capability before seal. Catalog-sized history/probe sessions, fair2send pumps, private names/observers. Exact persisted BOOT main-task journal identity, no request-task authentication. Two actual Spindles; generic3/8 host controls and temp3 service catalogs are descriptive fixtures. Native full relaunch and connected live/cold use source-bound immutable replay; auxiliary last-writer cold is observed with bound parent but no standaloneartifactreplay. No runtime mint/processVAS/POSIX, native unequal-task app/thirdreserve/new1800s/physicalSMP/hostilecontainment/globalepoch or daily-driver acceptance claim.')
p=A/'sexos-spindle-recovery-roster-2026-10-31-evidence.json';assert not p.exists();p.write_text(json.dumps(e,indent=2)+'\n');print('SPINDLE_ROSTER_ARCHIVE_PASS',len(items)+1,'members',archive.stat().st_size,'bytes',flush=True)
