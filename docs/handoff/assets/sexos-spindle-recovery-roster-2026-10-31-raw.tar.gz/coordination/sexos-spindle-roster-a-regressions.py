from pathlib import Path
import json,os,subprocess,time
T=Path('/tmp');F=T/'sexos-spindle-roster-a-frozen';R=F/'source';p=T/'sexos-spindle-roster-a-alpha-progress.json'
while True:
 rows=json.loads(p.read_text())
 if any(isinstance(r['status'],int)and r['status']!=0 for r in rows):raise SystemExit('alpha failed')
 if len(rows)==2 and all(r.get('fresh_replay')and r.get('terminal_history')for r in rows):break
 time.sleep(5)
for name,command in [('connected',['python3',str(T/'sexos-spindle-roster-a-connected-suite.py')]),('last-writer-cold-aux',['python3',str(R/'scripts/spindle_durable_reboot_gate.py'),'--iso',str(F/'tested.iso'),'--binding',str(F/'source-binding.json'),'--boot-a',str(T/'sexos-spindle-roster-a-alpha-wide'),'--out',str(T/'sexos-spindle-roster-a-last-writer-cold-aux'),'--recall','echo spindle17'])]:
 driver=T/('sexos-spindle-roster-a-'+name+'-driver.log');assert not driver.exists();print('START',name,flush=True);began=time.monotonic()
 with driver.open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=900)
 row=dict(name=name,command=command,status=r.returncode,driver=str(driver),elapsed_seconds=time.monotonic()-began);p=T/('sexos-spindle-roster-a-'+name+'-coordinator.json');assert not p.exists();p.write_text(json.dumps(row,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if name=='last-writer-cold-aux':
  v=json.loads((T/'sexos-spindle-roster-a-last-writer-cold-aux/result.json').read_text());assert v['ok']and v['stopped']and v['binding']and v['expected']['source']==17 and v['expected']['task']==17
print('ROSTER_CONNECTED_AND_LAST_WRITER_COLD_PASS',flush=True)
