from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/Users/xmacbookm5/Projects/Sex');out=Path('/tmp/sexos-r107-order-controls-d');assert not out.exists();out.mkdir()
names=['scripts/usb_wheel_host_gate.sh','tests/usb_wheel.rs','crates/sex-pdx/src/app_scroll.rs','servers/sexinput/src/main.rs','servers/sexusb/src/main.rs','kernel/src/init.rs','kernel/src/pd/create.rs'];hashes={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in names};rows=[]
for label in ['baseline','key-overtakes-click']:
 case=out/label;case.mkdir()
 for n in names:
  p=case/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,p)
 if label!='baseline':
  p=case/'servers/sexinput/src/main.rs';s=p.read_text();old='let key_first=keys.len>0 && (pointer.len==0 || keys.orders[keys.head]<pointer.batches[pointer.head].order);';assert s.count(old)==1;p.write_text(s.replace(old,'let key_first=keys.len>0;'))
 log=out/(label+'.log')
 with log.open('w')as f:r=subprocess.run(['bash',str(case/'scripts/usb_wheel_host_gate.sh')],stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();assert 'running 21 tests' in text;assert r.returncode==(0 if label=='baseline'else 101),(label,r.returncode)
 rows.append(dict(label=label,exit_code=r.returncode,compiled=True,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()));print(label,r.returncode,flush=True)
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==v for n,v in hashes.items())
(out/'result.json').write_text(json.dumps(dict(ok=True,sources=hashes,controls=rows,scope='actual ordered USB/Input host functions; callbacks are not native transport authority'),indent=2)+'\n')
