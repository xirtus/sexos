"""Fresh-process raw acceptance checks; never boots or rewrites native evidence."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
T=Path('/tmp');F=(T/'sexos-alpha-r107-wheel-d-frozen').resolve();ROOT=F/'source';sys.path.insert(0,str(ROOT/'scripts'))
import http_content_gate as wheel
import https_asset_gate as asset
import clipboard_workflow_gate as clipboard
from network_contention_gate import frozen_binding
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(v):return json.loads(json.dumps(v))
progress=load(T/'sexos-r107-d-native-suite-progress.json');assert len(progress)==8 and all(type(r['status'])is int and r['status']==0 for r in progress)
bound=frozen_binding(ROOT,F/'tested.iso',F/'source-binding.json');runs=[]
for row in progress:
 out=Path(row['out']);assert row['source_binding_sha256']==bound['sha256']
 if row['name'].startswith('wheel-'):
  result=wheel.verify_wheel_evidence(ROOT,F/'tested.iso',F/'source-binding.json',out);assert canonical(result)==load(out/'result.json')['wheel']and result['binding']==bound
  manifest=load(out/'manifest.json');assert(manifest['mode'],manifest['model'],manifest['resolution'])==(row['mode'],row['profile']['model'],row['profile']['resolution']);assert manifest['input_disk_sha256']==sha(T/'sexos-r100a-seed.img')
  assert len(result['pixels'])==row['frames']==len(list(out.glob('*.ppm')))
  assert result['serial_offset_units']==wheel.WHEEL_SERIAL_UNITS
  runs.append(dict(name=row['name'],out=str(out),ok=True,boots=1,frames=row['frames'],profile=row['profile'],mode=row['mode'],root_terminal_disk_sha256=sha(out/'nvme.img'),replay=result))
 elif row['name'].startswith('asset-'):
  result=asset.verify_evidence(ROOT,F/'tested.iso',F/'source-binding.json',out);assert canonical(result)==load(out/'result.json')and result['binding']==bound
  manifest=load(out/'manifest.json');assert(manifest['mode'],manifest['model'],manifest['resolution'])==(row['mode'],row['profile']['model'],row['profile']['resolution']);assert manifest['input_disk_sha256']==sha(T/'sexos-r100a-seed.img');assert len(manifest['frames'])==row['frames']
  assert result['pointer_parking']['captures']==row['frames']
  if row['mode']=='ready':assert len(result['pixels'])==9 and result['trace']['released']==result['trace']['decoded']==2
  runs.append(dict(name=row['name'],out=str(out),ok=True,boots=1,frames=row['frames'],profile=row['profile'],mode=row['mode'],root_terminal_disk_sha256=sha(out/'nvme.img'),replay=result))
 else:
  assert row['name']in('clipboard-wide','clipboard-compact')and row['boots']==2;contract=clipboard.source_contract(ROOT,'utf8');results=[]
  for boot in('write','recovery'):
   r=clipboard.replay_boot(out/boot,contract);assert canonical(dict(r,binding=bound))==load(out/boot/'result.json');results.append(dict(boot=boot,**r))
  first=load(out/'write/manifest.json');second=load(out/'recovery/manifest.json');assert first['binding']==second['binding']==bound and first['final_disk_sha256']==second['input_disk_sha256']
  assert first['text_profile']==second['text_profile']=='utf8'and first['body_sha256']==second['body_sha256']==clipboard.sha(clipboard.UTF8_BODY)
  assert results[0]['document']==results[1]['document']==load(out/'result.json')['document'];assert sum(len(r['pixels'])for r in results)==11
  runs.append(dict(name=row['name'],out=str(out),ok=True,boots=2,frames=11,profile=row['profile'],mode=row['mode'],replay=results))
 print(row['name'],'raw check PASS',flush=True)
assert sum(r['boots']for r in runs)==10 and sum(r['frames']for r in runs)==98
assert frozen_binding(ROOT,F/'tested.iso',F/'source-binding.json')==bound
result=dict(ok=True,complete=True,round=107,source_binding_sha256=bound['sha256'],binding=bound,native_runs=8,native_boots=10,frames=98,runs=runs,scope='Fresh exact-source evaluation of all D terminal raw evidence: two native wheel Reader profiles and two pending-stream Close profiles; raw USB/Input/Shell/App joins, complete reader/launcher/framebuffer checks, no refetch, exact cleanup; both retained image inspection and UTF8 clipboard/Save/cold recovery regressions. No public-web, sustained full daily-driver, physical/SMP, crash/power-loss or hostile-containment claim.')
p=T/'sexos-r107-d-root-independent-replay.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(ok=True,complete=True,native_runs=8,native_boots=10,frames=98)))
