from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/Users/xmacbookm5/Projects/Sex');out=Path('/tmp/sexos-r107-browser-controls-a');assert not out.exists();out.mkdir()
names=['scripts/browser_wheel_host_gate.sh','tests/browser_wheel.rs','apps/kaleidoscope/src/main.rs','apps/kaleidoscope/src/document_reader.rs','crates/sex-pdx/src/app_scroll.rs','crates/sex-pdx/src/text_encoding.rs','crates/sex-pdx/src/desktop_style.rs','crates/sex-pdx/src/network_config.rs','crates/sex-net-config/src/lib.rs']
sources={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in names}
cases=[('baseline',None,None,None),('canonical-word','crates/sex-pdx/src/app_scroll.rs','(event.wire() == word).then_some(event)','Some(event)'),('wheel-direction','apps/kaleidoscope/src/document_reader.rs','let delta = -(wheel as i16) * 3;','let delta = (wheel as i16) * 3;'),('sender-incarnation','apps/kaleidoscope/src/main.rs',' || req.caller_task!=3 {return;}',' {return;}')]
rows=[]
for label,name,old,new in cases:
 case=out/label;case.mkdir()
 for n in names:
  target=case/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,target)
 if name:
  p=case/name;s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
 log=out/(label+'.log');command=['bash',str(case/'scripts/browser_wheel_host_gate.sh')]
 with log.open('w')as stream:r=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text();assert 'running 24 tests' in text,label
 assert r.returncode==(0 if label=='baseline'else 101),(label,r.returncode)
 rows.append(dict(label=label,source=name,command=command,exit_code=r.returncode,compiled=True,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 print(label,r.returncode,flush=True)
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==v for n,v in sources.items())
(out/'result.json').write_text(json.dumps(dict(ok=True,sources=sources,controls=rows,scope='actual Browser/Reader/protocol host semantic controls; no native authority or pixel claim'),indent=2)+'\n')
