from pathlib import Path
import gzip,hashlib,io,json,os,re,subprocess,tarfile
from PIL import Image
T=Path('/tmp');R=Path('/Users/xmacbookm5/Projects/Sex');F=T/'sexos-alpha-r107-wheel-d-frozen';A=R/'docs/handoff/assets'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=read(F/'source-binding.json');assert b['architecture_sha256']=='4085f8fa65234205c5fdab070fe36765d767a46edc001410bf2ed5bfb27a98d7'
for n,v in {**b['sources'],**b['runner_sha256']}.items():assert sha(F/'source'/n)==v and sha(R/n)==v,n
assert sha(F/'tested.iso')==b['iso_sha256'] and sha(F/'tested.kernel')==b['kernel_sha256']
replay=read(T/'sexos-r107-d-root-independent-replay.json');assert replay['ok']and replay['native_runs']==8 and replay['native_boots']==10 and replay['frames']==98
assert read(T/'sexos-r107-c-d-source-equivalence.json')['ok'];hosts=read(T/'sexos-r107-c-frozen-host-progress.json');assert all(r['exit_code']==0 for r in hosts)and sum(r['rust_executions']for r in hosts)==2071
py=(T/'sexos-r107-d-frozen-python.log').read_text();assert re.search(r'Ran 811 tests in ',py)and py.rstrip().endswith('OK')
for folder,count in [('sexos-r107-browser-controls-a',3),('sexos-r107-order-controls-d',1)]:
 c=read(T/folder/'result.json');assert c['ok'];assert len(c['controls'])==count+1
 for n,v in c['sources'].items():assert sha(F/'source'/n)==v,(folder,n)
 assert c['controls'][0]['exit_code']==0 and all(r['compiled']and r['exit_code']==101 for r in c['controls'][1:])
progress=read(T/'sexos-r107-d-native-suite-progress.json');assert len(progress)==8 and all(type(r['status'])is int and r['status']==0 for r in progress)
items={};disks=[]
def add(arc,p):
 p=Path(p);assert p.is_file()and not p.is_symlink(),str(p);assert arc not in items,arc;items[arc]=p

def compressed_disk(p):
 owners=subprocess.run(['lsof','-t',str(p)],capture_output=True,text=True);assert owners.returncode in(0,1)and not owners.stdout.strip(),('live disk owner',str(p),owners.stdout)
 data=p.read_bytes();wanted=hashlib.sha256(data).hexdigest();choices=[p.with_name(p.name+'.gz'),p.with_name(p.name+'.archive-copy.gz')];compressed=next((v for v in choices if v.exists()),choices[-1])
 created=not compressed.exists()
 if created:
  with compressed.open('xb')as stream:
   with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0)as z:z.write(data)
 assert gzip.decompress(compressed.read_bytes())==data
 disks.append(dict(raw=str(p),raw_sha256=wanted,bytes=len(data),compressed=str(compressed),compressed_sha256=sha(compressed),created=created,uncompressed_verified=True))
 return compressed

def tree(arc,root):
 root=Path(root);assert root.is_dir()
 # Produce and verify compressed copies only after each owning run is terminal.
 for p in sorted(root.rglob('*.img')):compressed_disk(p)
 for p in sorted(root.rglob('*')):
  if p.is_file()and '__pycache__'not in p.parts and p.suffix!='.img':add(arc+'/'+str(p.relative_to(root)),p)

tree('frozen',F);tree('build',T/'sexos-alpha-r107-wheel-c-build')
for row in progress:tree('native/'+row['name'],row['out'])
tree('scalar',T/'sexos-r107-d-scalar');tree('semantic/browser',T/'sexos-r107-browser-controls-a');tree('semantic/order',T/'sexos-r107-order-controls-d')
tree('diagnostics/build-a',T/'sexos-alpha-r107-wheel-a-build');tree('diagnostics/build-b',T/'sexos-alpha-r107-wheel-b-build');tree('diagnostics/image-b',T/'sexos-r107-b-diagnostic-image');tree('diagnostics/frozen-c',T/'sexos-alpha-r107-wheel-c-frozen');tree('diagnostics/native-c-reader-wide',T/'sexos-r107-c-native-wheel-reader-wide');tree('diagnostics/control-c-missing-source',T/'sexos-r107-order-controls-c')
add('seed/nvme.img.gz',compressed_disk(T/'sexos-r100a-seed.img'))
for p in sorted(T.glob('sexos-r107-*')):
 if p.is_file()and p.suffix in('.py','.json','.log'):
  # Explicitly retain diagnostics/coordinator/host logs, not unowned unrelated files.
  add('coordination/'+p.name,p)
manifest={name:dict(bytes=p.stat().st_size,sha256=sha(p))for name,p in items.items()};manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();manifest_sha=hashlib.sha256(manifest_bytes).hexdigest()
archive=A/'sexos-alpha-r107-2026-10-31-qualified-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for name,p in sorted(items.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('payload-members.json');info.size=len(manifest_bytes);info.mode=0o644;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(items)+1;assert len(set(m.name for m in members))==len(members)
 for m in members:
  data=tar.extractfile(m).read()
  wanted=dict(bytes=len(manifest_bytes),sha256=manifest_sha)if m.name=='payload-members.json'else manifest[m.name]
  assert len(data)==wanted['bytes']and hashlib.sha256(data).hexdigest()==wanted['sha256'],m.name
shots=[]
for label,run,name in [('wheel-down-wide','wheel-reader-wide','browser-wheel-down'),('wheel-burst-wide','wheel-reader-wide','browser-wheel-burst'),('reader-zoom-wide','wheel-reader-wide','browser-reader-expanded'),('wheel-down-compact','wheel-reader-compact','browser-wheel-down')]:
 source=T/('sexos-r107-d-native-'+run)/(name+'.ppm');target=A/('sexos-alpha-r107-2026-10-31-'+label+'.png');assert not target.exists();image=Image.open(source).convert('RGB');pixels=image.tobytes();image.save(target)
 assert Image.open(target).convert('RGB').tobytes()==pixels
 shots.append(dict(path='assets/'+target.name,sha256=sha(target),source_ppm=str(source),source_ppm_sha256=sha(source),width=image.width,height=image.height,pixel_identical=True))
result=dict(ok=True,round=107,iso_sha256=b['iso_sha256'],kernel_sha256=b['kernel_sha256'],binding_sha256=sha(F/'source-binding.json'),production_inputs=len(b['sources']),runner_inputs=len(b['runner_sha256']),archive=dict(path='assets/'+archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(items)+1,payload_manifest_sha256=manifest_sha,verified=True,raw_disks=disks),screenshots=shots)
p=T/'sexos-r107-d-package-result.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in('ok','round','iso_sha256','binding_sha256')}));print('archive',archive.stat().st_size,'bytes',len(items)+1,'verified members')
