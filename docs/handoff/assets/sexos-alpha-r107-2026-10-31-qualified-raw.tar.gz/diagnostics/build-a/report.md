# Master runtime gate

| BUILD_GATE | FAIL |
| PROBE_GATE | NOT_RUN |
| FINAL_SCORE | RED_MASTER |

Build failed. No existing image was booted or accepted. See /tmp/sexos-alpha-r107-wheel-a-build/build.log.
